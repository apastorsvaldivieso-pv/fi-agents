#!/usr/bin/env python3
"""Build the three agents as self-contained folders, each with its own install file.

The master copy is `plugin/skills/`: three agent skills and four shared skills. Edit there.
This script copies each agent, with its own copy of the shared skills inside it, to

    agents/<agent>/plugin/                 everything the agent needs to run
    agents/<agent>/<agent>.plugin          the file to install in the Claude app
    agents/<agent>/README.md               what it does and how to run it

    python3 tools/build_agents.py            build all three
    python3 tools/build_agents.py --check    fail if agents/ is out of step with plugin/skills/

Standard library only.
"""
import filecmp, json, os, re, shutil, sys, tempfile, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "plugin", "skills")
OUT = os.path.join(ROOT, "agents")
SHARED = ["coverage-list", "source-rules", "sector-metrics", "dashboard-feed"]
IGNORE = shutil.ignore_patterns("__pycache__", "shared", ".DS_Store")
NOTE = "> Shared rules, copied here from the master by `tools/build_agents.py`. Do not edit this copy.\n\n"

AGENTS = {
    "sector-news-brief": {
        "title": "Sector news brief",
        "what": "A daily credit news brief for one sector on Moody's data: the top items, macro, sector and one line per name, with Moody's rating actions, research and the latest sector outlook.",
        "say": ["Run the sector news brief for European telecoms.",
                "Run the sector news brief for European banks for the last 7 days.",
                "Sector news brief for telecoms, last 72 hours, for: Vodafone, Orange, Telefonica."],
        "needs": "The Moody's Credit connector. No web search.",
        # one file this agent borrows from another agent
        "extra": [("earnings-credit/reading-results.md", "reading-results.md")],
    },
    "reg-watch": {
        "title": "Regulatory watch",
        "what": "What regulators published for a sector in a window, and which names on a list each measure covers, ranked on a Moody's metric where there is one.",
        "say": ["Run the regulatory watch for European banks.",
                "Run the regulatory watch for European banks for the last 30 days.",
                "Regulatory watch, last 30 days, for these banks: HSBC, BNP Paribas, Deutsche Bank, UBS."],
        "needs": "The Moody's Credit connector and web search (it reads the regulators' own pages).",
        "extra": [],
    },
    "earnings-credit": {
        "title": "Earnings for credit",
        "what": "An earnings preview or recap for one issuer, set against its Moody's upgrade and downgrade triggers.",
        "say": ["Earnings recap for Vodafone.", "Earnings preview for BNP Paribas."],
        "needs": "The Moody's Credit connector. No web search.",
        "extra": [],
    },
}


def strip_front_matter(text):
    """A shared copy is reference material inside one agent, not a skill of its own."""
    m = re.match(r"^---\n.*?\n---\n+", text, re.S)
    return NOTE + (text[m.end():] if m else text)


def build_one(agent, out_root):
    spec = AGENTS[agent]
    plug = os.path.join(out_root, agent, "plugin")
    skill = os.path.join(plug, "skills", agent)
    shutil.rmtree(os.path.join(out_root, agent), ignore_errors=True)
    shutil.copytree(os.path.join(SRC, agent), skill, ignore=IGNORE)
    for name in SHARED:
        dst = os.path.join(skill, "shared", name)
        shutil.copytree(os.path.join(SRC, name), dst, ignore=IGNORE)
        p = os.path.join(dst, "SKILL.md")
        body = strip_front_matter(open(p, encoding="utf-8").read())     # read first: opening for writing empties the file
        if len(body) < 500:
            raise SystemExit("%s/shared/%s/SKILL.md came out empty" % (agent, name))
        open(p, "w", encoding="utf-8").write(body)
    for src_rel, dst_name in spec["extra"]:
        shutil.copyfile(os.path.join(SRC, src_rel), os.path.join(skill, "shared", dst_name))
    # point the agent's own files at its own copies
    for fname in sorted(os.listdir(skill)):
        if not fname.endswith(".md"):
            continue
        p = os.path.join(skill, fname)
        text = open(p, encoding="utf-8").read()
        for src_rel, dst_name in spec["extra"]:
            text = text.replace("../" + src_rel, "shared/" + dst_name)
        for name in SHARED:
            text = text.replace("../%s/" % name, "shared/%s/" % name)
        left = re.findall(r"\.\./[A-Za-z0-9_./-]+", text)
        if left:
            raise SystemExit("%s/%s still points outside its folder: %s" % (agent, fname, left))
        open(p, "w", encoding="utf-8").write(text)
    os.makedirs(os.path.join(plug, ".claude-plugin"))
    master = json.load(open(os.path.join(ROOT, "plugin", ".claude-plugin", "plugin.json")))
    manifest = {"name": "moodys-" + agent, "version": master.get("version", "0.1.0"),
                "description": spec["what"], "author": master.get("author", {})}
    json.dump(manifest, open(os.path.join(plug, ".claude-plugin", "plugin.json"), "w"), indent=2)
    readme = ["# %s" % spec["title"], "", spec["what"], "",
              "This folder is complete on its own. It does not need the other two agents.", "",
              "## Install", "",
              "Install `%s.plugin` in the Claude app (Settings, Plugins, add from file). It appears as `moodys-%s`." % (agent, agent), "",
              "## It needs", "", spec["needs"], "",
              "## What to type", ""] + ["- \"%s\"" % s for s in spec["say"]] + ["",
              "## What you get", "",
              "The answer in the chat, with a reference number on every figure and rating and a short source list. "
              "If the session has a folder to write to, it also saves the run and rebuilds an optional dashboard page; if not, it says so in one line and the answer is the same.", "",
              "## What is in `plugin/`", "",
              "- `skills/%s/SKILL.md`: the agent's steps." % agent,
              "- `skills/%s/shared/`: its own copy of the four sets of shared rules (names and lists, source rules, sector facts, the answer and dashboard scripts)." % agent,
              "", "To change the agent, edit the master in `plugin/skills/` at the top of the project and run `python3 tools/build_agents.py`.", ""]
    open(os.path.join(out_root, agent, "README.md"), "w", encoding="utf-8").write("\n".join(readme))
    zpath = os.path.join(out_root, agent, agent + ".plugin")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for base, dirs, files in os.walk(plug):
            dirs.sort()
            for f in sorted(files):
                full = os.path.join(base, f)
                z.write(full, os.path.relpath(full, plug))
    return zpath


def trees_equal(a, b):
    cmp = filecmp.dircmp(a, b, ignore=[".DS_Store", "__pycache__"])
    if cmp.left_only or cmp.right_only or cmp.diff_files or cmp.funny_files:
        return False
    return all(trees_equal(os.path.join(a, d), os.path.join(b, d)) for d in cmp.common_dirs)


def main():
    if "--check" in sys.argv:
        tmp = tempfile.mkdtemp()
        drift = []
        for agent in AGENTS:
            build_one(agent, tmp)
            a, b = os.path.join(tmp, agent, "plugin"), os.path.join(OUT, agent, "plugin")
            if not os.path.isdir(b) or not trees_equal(a, b):
                drift.append(agent)
        shutil.rmtree(tmp, ignore_errors=True)
        print("agents in step with the master" if not drift else "out of step, rebuild: %s" % ", ".join(drift))
        return 1 if drift else 0
    for agent in AGENTS:
        z = build_one(agent, OUT)
        n = len(zipfile.ZipFile(z).namelist())
        print("%-18s %s (%d files, %d KB)" % (agent, os.path.relpath(z, ROOT), n, os.path.getsize(z) // 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
