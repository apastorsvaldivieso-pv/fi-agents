#!/usr/bin/env python3
"""Fallback for decision 8: copy the shared skills into each agent skill.

Use this only if, once the plugin is installed, an agent skill cannot open a shared
skill through `../<shared>/SKILL.md`. The shared skills stay the single source; this
script keeps copies inside each agent in step with them.

    python3 tools/vendor_shared.py            copy and point each agent at its own copy
    python3 tools/vendor_shared.py --check    fail if any copy has drifted from the source
    python3 tools/vendor_shared.py --undo     remove the copies and restore the links

Standard library only.
"""
import filecmp, os, shutil, sys

ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "plugin", "skills")
SHARED = ["coverage-list", "source-rules", "sector-metrics", "dashboard-feed"]
AGENTS = ["sector-news-brief", "reg-watch", "earnings-credit"]


def trees_equal(a, b):
    cmp = filecmp.dircmp(a, b)
    if cmp.left_only or cmp.right_only or cmp.diff_files or cmp.funny_files:
        return False
    return all(trees_equal(os.path.join(a, d), os.path.join(b, d)) for d in cmp.common_dirs)


def rewrite(agent, old, new):
    """Repoint links to the shared skills in every .md file at the top of the agent's folder."""
    folder = os.path.join(ROOT, agent)
    for fname in sorted(os.listdir(folder)):
        if not fname.endswith(".md"):
            continue
        path = os.path.join(folder, fname)
        text = open(path, encoding="utf-8").read()
        for name in SHARED:
            text = text.replace(old % name, new % name)
        open(path, "w", encoding="utf-8").write(text)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "copy"
    drift = []
    for agent in AGENTS:
        for name in SHARED:
            src, dst = os.path.join(ROOT, name), os.path.join(ROOT, agent, "shared", name)
            if mode == "--check":
                if os.path.isdir(dst) and not trees_equal(src, dst):
                    drift.append("%s/shared/%s" % (agent, name))
            elif mode == "--undo":
                shutil.rmtree(dst, ignore_errors=True)
            else:
                shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "shared"))
        if mode == "--undo":
            shutil.rmtree(os.path.join(ROOT, agent, "shared"), ignore_errors=True)
            rewrite(agent, "shared/%s/", "../%s/")
        elif mode != "--check":
            rewrite(agent, "../%s/", "shared/%s/")
    if mode == "--check":
        print("copies in step" if not drift else "drifted: %s" % ", ".join(drift))
        return 1 if drift else 0
    print("done: %s" % ("links restored" if mode == "--undo" else "shared skills copied into each agent"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
