# Moody's demo agents

Three credit agents on Moody's data, built for showing fixed income teams at European asset managers what their own team could build. Each agent is a folder that is complete on its own, with one file to install.

## Start here: the three agents

| Agent | Folder | Install this file | You type |
|---|---|---|---|
| Sector news brief | `agents/sector-news-brief/` | `agents/sector-news-brief/sector-news-brief.plugin` | "Run the sector news brief for European telecoms." |
| Regulatory watch | `agents/reg-watch/` | `agents/reg-watch/reg-watch.plugin` | "Run the regulatory watch for European banks." |
| Earnings for credit | `agents/earnings-credit/` | `agents/earnings-credit/earnings-credit.plugin` | "Earnings recap for Vodafone." |

Each folder has a `README.md` (what it does, what it needs, what to type) and a `plugin/` folder with every file the agent uses. None needs another agent to be installed or to have run.

**To use one:** install its `.plugin` file in the Claude app, make sure the Moody's Credit connector is on (and web search, for the regulatory watch), and type the request. The reply is the full answer, with a reference number on every figure and rating and a short source list.

**Other sectors and a client's own names.** The news brief and the earnings agent take any sector and any names in the request; nothing is set up per client. Both were run on sectors that were never prepared (utilities, auto makers, Volkswagen) and worked: see `evals/results/other-sectors.md`. The regulatory watch is built for banks.

## What comes first

1. **The product is each agent's answer in the chat**: complete, correct and sourced.
2. **The answer is the same whatever shows it**: chat, dashboard, Teams, Slack or email. The dashboard is one optional display.
3. **The dashboard step comes last and never blocks.** If the session has no folder to write to, the agent still gives the full answer and says in one line that the dashboard was not updated.

## The rest of this folder

You do not need any of it to run an agent.

| Folder | What it holds |
|---|---|
| `plugin/` | **The master copy**, where changes are made. The three agents share four sets of rules here (names and lists, source rules, sector facts, the answer and dashboard scripts), so a fix lands in all three. `python3 tools/build_agents.py` then rebuilds the three folders in `agents/` |
| `moodys-fi-agents.plugin` | All three agents in one install file, for someone who wants them together |
| `evals/` | The tests: cases per agent, the check script, every saved test run, and the results in `evals/results/` |
| `dashboard/` | The optional dashboard page and the runs it shows |
| `demo-scripts/` | Half a page per agent: what to type, what happens, what to say |
| `HANDOVER.md` | The full record: what was asked, built and tested, what is known not to work, how to maintain it |
| `research/`, `PLAN.md`, `tools/` | The study behind the build, the approved plan, and the build scripts |

## Changing an agent

1. Edit the master in `plugin/skills/`.
2. Run `python3 tools/build_agents.py`. It rebuilds `agents/` and the three install files. `python3 tools/build_agents.py --check` says whether `agents/` is in step with the master.
3. Run the source review in `evals/REVIEW.md` for the agent you changed.
4. Reinstall the agent's `.plugin` file.

## What differs from the approved plan

- **Country filter in name search.** A filter covering all of Europe still returned a Santander subsidiary, and so did Spain alone. Each name is now searched with its one home country, alternatives are requested, and a result is accepted only if its name matches the name asked for.
- **Banco Santander** is not on the checked bank list. Its rated record returns no financials from Moody's. CaixaBank takes its place.
- **KPN** is not on the checked telecoms list: Moody's withdrew its ratings in December 2024. PPF Telecom Holdings takes its place. BT is on the list, with its ratings read from British Telecommunications Limited.
- **Earnings preview** has one more section than planned, "Sector metrics to watch", so a bank preview is not a single row.
- **Regulatory watch** reads each regulator's own publications listing as well as searching, because search alone missed items.
- **The run picker** on each tab shows the eight most recent runs.

## Changes of 15 Nov 2026 (after a review of the saved runs)

- **Regulatory watch ranks only the banks a rule covers.** A G-SIB rule ranks the banks on the FSB's list; the others are named as out of scope. Scope comes from two facts, the FSB list and the bank's country, so it also works on a client's own names.
- **Positions are named for what they are.** "Least headroom / Middle / Most headroom" where the banks are ranked by distance to a requirement, "Weaker third / Middle / Stronger third" where they are ranked by level. "Exposed" and "Resilient" are gone.
- **Each bank's own stated CET1 requirement** is in `plugin/skills/sector-metrics/sectors/banks-scope.md`, with its date and filing. Ten of the fifteen banks have one on file; five do not.
- **Credit Agricole is measured as the group.** The G-SIB is Groupe Credit Agricole, so "who it hits" tables take its metrics from the group's own Moody's record (CET1 17.23% at Q2 2026, against 11.30% for Credit Agricole S.A.). News, ratings and earnings stay on Credit Agricole S.A. A client's own name from a co-operative group with no checked group record is shown and not ranked.
- **The table comes first** on the Regulatory watch tab.
- **A running list of items** (`dashboard/data/items/`) means a run shows every item found so far in the window, and flags as NEW only what the list did not hold before.
- **The earnings recap reads the company's results report** for net debt, liquidity, maturities and shareholder returns. With no transcript, either mode uses the latest filing and says how old it is.
- Runs saved before these changes are in `dashboard/data/archive-before-fixes/`, out of the run picker.
- `moodys-fi-agents.plugin` was rebuilt with these changes, reinstalled and reported working on 15 Nov 2026.

## Later changes of 15 Nov 2026, and where each agent stands

- **The answer in the chat comes first**, with a reference on every figure and rating and a short source list; the dashboard step is last and never blocks.
- **News brief**: a materiality checklist (`plugin/skills/sector-news-brief/materiality.md`), "why it matters" lines only from a source, the direction of a rating review from the rating action, and a mark on items that rest on one aggregator article.
- **Regulatory watch**: a figure keeps the regulator's own qualifier; a table heading names only the measure its names are right for.
- **A standing source review** (`evals/REVIEW.md`): a fresh answer from each agent is checked line by line by a separate reader that re-pulls from the source. Run it whenever a skill changes.

| Agent | Latest source review (wrong / missing / unsupported) | Standing |
|---|---|---|
| Regulatory watch | 0 / 0 / 0 on about 85 facts | Met the target. In the eval runs, two of nine used a stronger word than the regulator's and one missed an item |
| Earnings | 0 / 3 / 0 on about 50 facts (1 / 6 / 1 at the start) | Met the target on wrong and unsupported. Every Moody's figure right. Three items a specialist would want are still left out |
| News brief | 3 / 3 / 1 on about 130 facts (7 / 11 / 7 at the start) | Not at the target after four reviews. Ratings right every time, every "why it matters" sourced. Still dates some items by their article. A sourced first read, to be checked before it is passed on |

The findings are in `evals/results/news-review-4.md`, `reg-review-2.md` and `earnings-review-3.md`. No further fix is in progress.
- The three install files in `agents/` were built on 16 Nov 2026 and have not been installed in the Claude app yet. Each agent was run live from its own folder.

## Feeding the dashboard from another agent

Save a JSON file in `dashboard/data/` in the shape described in `plugin/skills/dashboard-feed/run-file.md`, with your agent's own `agent` id and `title`, then run `dashboard-feed`. It gets its own tab.

## Tests

```bash
python3 evals/selftest.py
```

proves each check catches a planted defect.

```bash
python3 evals/checks.py
```

runs the checks on every saved eval run. Results are in `evals/results/`.
