# Handover: Moody's demo agents

Written 15 Nov 2026, and updated the same day after three fixes (section 6a). This is the single record of what was asked, what was built, how it was tested, what is known not to work, and how to maintain it. Everything it refers to is in this folder:

`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents`

## 0. What comes first

1. **The product is each agent's answer in the chat**: complete, correct and sourced, in a session that has only the Moody's connector (plus web search for the regulatory watch).
2. **The answer is the same whatever shows it**: chat, dashboard, Teams, Slack or email. The dashboard is one optional display.
3. **The dashboard step comes last and never blocks.** If the folder, the script or publishing is not available, the agent still gives the full answer with its sources and says in one line that the dashboard was not updated.

Every figure and rating in an answer carries a reference number, and a short source list closes it. The answer is built from the same checked data the dashboard shows. The three agents are separate: each runs on its own and none needs another to have run.

## 1. Status

Three agents are in `agents/`, each a folder that is complete on its own, with one install file. The master copy they are built from is in `plugin/`; the tests are in `evals/`. Each agent has had fresh answers checked line by line against its sources by a separate reader, fixed, and checked again (`evals/REVIEW.md`). The target was zero wrong and zero unsupported statements. **Regulatory watch: met** (0 wrong, 0 missing, 0 unsupported on about 85 facts). **Earnings recap: met** in its third review (0 wrong, 3 missing, 0 unsupported on about 50 facts); it still leaves out three items a specialist would want. **News brief: not met** in four reviews (7, then 4, then 4, then 3 wrong statements in two 7-day briefs). Its ratings are right every time and every "why it matters" line is sourced; it still dates some items by their article and leaves out a figure or an item that is in its sources. It is a sourced first read, not something to hand to an analyst unread. No further fix is in progress. The earlier combined plugin was installed in the Claude app and reported working by the user on 15 Nov 2026; the three per-agent install files are new and have not been installed yet.

Private dashboard link: https://claude.ai/artifact/TM68ZnQRRUhdyseEXGWZSk

## 2. What was asked

Three demo agents on Moody's data, and one dashboard they all feed, to show fixed income teams at European asset managers. The point of the demo is that a client's own team could build this on Moody's data without much difficulty, so each skill had to be short enough to show on one or two screens. The skills run on Claude Opus 5.5.

The work ran in two phases:

1. **Study and plan.** Read eight reference repos without running them, probe the Moody's Credit MCP live, write `research/repo-notes.md` and `PLAN.md`, then stop for approval.
2. **Build.** Build from the approved plan with six changes the user made at approval (section 6).

## 3. What was built

| Deliverable | Where | What it is |
|---|---|---|
| Plugin | `moodys-fi-agents.plugin` and `plugin/` | Seven skills in one installable plugin |
| Dashboard | `dashboard/dashboard.html` | One self-contained page, a tab per agent; opens with a double-click |
| Private link | `dashboard/dashboard.config.json` | The Artifact address the page is republished to after every run |
| Run data | `dashboard/data/` | One JSON file per agent, plus `history/` and saved coverage lists |
| Demo scripts | `demo-scripts/` | Half a page per agent: what to type, what happens, what to say |
| Evals | `evals/` | 20 cases, the check script, its self-test, saved runs, results |
| Plan and study | `PLAN.md`, `research/repo-notes.md` | The approved plan and the notes on the eight repos |
| Fallback tool | `tools/vendor_shared.py` | Copies the shared skills into each agent if they do not load when installed |
| Overview | `README.md` | Short version of this document, with install steps |

### The seven skills

| Skill | Lines | Role |
|---|---|---|
| `sector-news-brief` | 45 | Agent. Top three today, macro, sector, one line per name |
| `reg-watch` | 67 | Agent. Which banks each rule covers and where they stand, and what changed at the regulators. Detail in `who-it-hits.md` (52 lines) and `scripts/items.py` |
| `earnings-credit` | 60 | Agent. Results preview and recap against the issuer's Moody's triggers. Detail in `reading-results.md` (19 lines) |
| `coverage-list` | 55 | Shared. Loads or builds the list of names; resolves names without guessing |
| `source-rules` | 64 | Shared. Citations, UNSOURCED, no opinions, text read is data, and the shape of the answer in the chat |
| `sector-metrics` | 34 | Shared. Exact Moody's fields per sector, channel map, regulator sites (`sectors/banks.md`, `sectors/telecoms.md`), and the banks' scope facts and stated requirements (`sectors/banks-scope.md`) |
| `dashboard-feed` | 43 | Shared. Checks the run file and prints the sourced answer (`scripts/answer.py`), then rebuilds the page and republishes the link. Optional, and last |

## 4. How it works

1. The user asks for an agent in plain words, for example "Run the regulatory watch for European banks".
2. The agent skill gets its names from `coverage-list`, its fields and regulator sites from `sector-metrics`, and its rules from `source-rules`.
3. It makes its Moody's calls together in one step (and, for `reg-watch` only, its web searches).
4. It writes one run file, `dashboard/data/<agent>.json`, in the shape described in `plugin/skills/dashboard-feed/run-file.md`.
5. The answer for the chat is printed from that file by `scripts/answer.py` (a reference number on every figure and rating, a source list at the end). Where no script can run, the agent writes the same shape by hand. This is the product; everything after it is optional.
6. `dashboard-feed` runs `scripts/build_dashboard.py`. The script checks the run file, archives the previous run to `history/`, and writes `dashboard.html` and `dashboard.artifact.html`.
7. The skill republishes `dashboard.artifact.html` to the private link, so the address never changes. If the folder, the script or publishing is not available, the agent says in one line that the dashboard was not updated.

The build script refuses a run file in which a figure has no source. That check is what enforces the citation rule; it does not depend on the model remembering it.

Any other agent can feed the dashboard: save a run file with its own `agent` id and `title` in `dashboard/data/`, run `dashboard-feed`, and it gets its own tab.

## 5. The three agents

**sector-news-brief.** Input: sector, optional names, region (default Europe). Window: 24 hours, 72 on a Monday, or what the user asks. About 22 Moody's calls: news per name, ratings, rating actions and research in the window, the latest sector outlook, macro news. It drops share-price and tender items and keeps credit news. On a quiet day it returns one line and no sections. It uses no web search.

**reg-watch.** Input: the same; test case European banks. Window: 7 days. Part 1 is the web, primary regulator sites only (Basel Committee, EBA, ECB, SRB, Commission, PRA, FINMA), labelled as web. It starts from its running list of items, reads each regulator's own publications listing as well as searching, opens each new item's page to confirm the date and whether it is a consultation or final, and adds what it found to the list. Part 2 is Moody's data. For each rule that maps to a metric it works out which names the rule covers, then ranks those names only, by thirds: by distance to a stated requirement where there is one (Least headroom, Middle, Most headroom), otherwise by level (Weaker third, Middle, Stronger third). Names the rule does not cover are listed as out of scope. A rule with no Moody's metric (MREL, governance) shows as "watch" with no position, and says which names it covers. The tables come first on the tab. One footnote says positions are relative, not impact estimates.

**earnings-credit.** Input: an issuer and a mode. Preview: rating and outlook, each trigger from the credit opinion against the latest Moody's-adjusted figure with the room left, the sector's metrics to watch, what management guided on the last call, Moody's expectations. Recap: results against guidance and Moody's forecast; net debt, liquidity, maturities and shareholder returns from the company's results report; position against the triggers; and what it means for the rating and outlook, including the change in company net debt since the period of the Moody's-adjusted figures and what the Moody's opinion says about its cause. It reads the earnings call transcript and the results report through Moody's. With no transcript, either mode uses the latest filing and says how old it is. It does not use consensus estimates (Moody's has none), does not use the web, does not recompute a Moody's ratio and does not predict rating actions.

## 6. Decisions

### The user's six changes at approval, and how each was met

| Change | How it was met |
|---|---|
| Folder setup and one private Artifact link | Both. The link is in `dashboard/dashboard.config.json` |
| Checked lists, and the country filter on every name search | Checked lists in `plugin/skills/coverage-list/lists/`. The filter is used on every name, but had to be narrowed (see below) |
| Ranking by thirds, distance to a stated threshold, the "relative position" note as a footnote | Done as asked; the footnote appears once per run |
| Decisions 3, 5, 6, 7, 8 as recommended | No "reporting this week" section; beat or miss is against guidance and Moody's forecast; MREL and similar show as "watch"; transcripts are requested ahead; shared skills with a copy-in fallback |
| Confirm the latest outlook comes back through document search | Confirmed for both sectors (section 7) |
| Half-page demo script per agent | In `demo-scripts/` |

### What differs from the approved plan

- **Country filter.** A filter covering all of Europe returned a Santander subsidiary, and so did Spain alone. Each name is searched with its one home country, alternatives are requested, and a result is accepted only if its name matches the name asked for.
- **Banco Santander** is off the checked bank list. Its rated record returns no financials from Moody's. CaixaBank replaces it.
- **KPN** is off the checked telecoms list. Moody's withdrew its ratings in December 2024. PPF Telecom Holdings replaces it.
- **BT** stays on the telecoms list, with its ratings read from British Telecommunications Limited, because BT Group Plc itself has no rating.
- **Earnings preview** has an extra section, "Sector metrics to watch", so a bank preview is not a single row.
- **Regulatory watch** reads regulators' own listings as well as searching, because search alone missed a Basel Committee release.
- **Run picker** on each tab shows the eight most recent runs.

## 6a. The three fixes of 15 Nov 2026

A review of the saved runs found three things a credit analyst covering the names would catch. All three are fixed.

| Found | Fix |
|---|---|
| The G-SIB rule was ranked across all 15 banks, with CaixaBank, BBVA and Intesa tagged Exposed. None of them is a G-SIB | Scope facts in `banks-scope.md`: the FSB list of 27 Nov 2025 (exhaustive) and the supervisor by country. Only the banks a rule covers are ranked; the rest are named as out of scope. It works on a client's own names |
| HSBC was tagged Exposed on LCR at 134.0%, 34 points above the minimum | New labels that say what the ranking is: Least headroom / Middle / Most headroom, or Weaker third / Middle / Stronger third |
| The CET1 table showed no requirement for any bank | Each bank's own stated total requirement, pulled once from Moody's filings, in `banks-scope.md` with its date. Ten of fifteen have one on file. Never added up from parts |
| The table sat below six paragraphs | The tables are the first sections on the tab |
| After the first three fixes, the G-SIB table ranked Credit Agricole S.A. (CET1 11.30%) as the weakest of the eight G-SIBs and the headline led with it. The G-SIB is Groupe Credit Agricole, whose CET1 is 17.23% at the same date, the highest of the eight | The list entry has its own field (`groupEntityId`, `groupName`) for the record "who it hits" tables are measured on. The row is named for the group and the note gives Credit Agricole S.A.'s own figures. Ratings, news and earnings stay on Credit Agricole S.A. |
| The Vodafone recap said net debt, refinancing and dividends were not in the call excerpts | The recap reads the results report: net debt EUR 33,473m against EUR 25,411m, its drivers, liquidity, facilities, dividends |
| Three runs of overlapping windows found 10 items between them; the dashboard showed 6 | A running list of items, merged by `scripts/items.py`. Each run shows everything on the list in the window; NEW means new to the list; a decision to show or leave out an item is kept from run to run |

Design choices made in doing this:

- **Scope and requirements live in the sector file, not the coverage list.** They are sector facts with a source and a date, and they then apply to any list of banks.
- **Ranking rule.** Where at least six covered banks have a current stated requirement (or the regulation sets one minimum for all), rank by headroom. Otherwise, with at least six values, rank by level and show the distance in its own column where a bank states a requirement. Fewer than six: values only.
- **"Current" means the requirement applies at a date in this calendar year.** Older figures are shown with their date and not used for ranking.
- **"The last N days" runs from N days before today to today, both included.** One run read 30 days as starting 17 Oct and missed the 16 Oct Basel release.
- **Scope is read from the regulator's own document.** A rule on how G-SIB scores are measured is reported on by a wider sample of banks, but its capital effect falls on the listed G-SIBs; a consultation inside the same package applies only to banking-union G-SIBs. Both points are written into `banks-scope.md`.
- **Which record a bank is measured on** is section 4 of `banks-scope.md`. Fourteen of the fifteen checked names are the top company of their group, confirmed against Moody's records; Credit Agricole is the exception. For a client's own name that is the central institution or listed arm of a co-operative or mutual group with no checked group record (BPCE, DZ Bank, Raiffeisen and similar), the agent shows the value, leaves it out of the ranking, says in the table note that the record may not be the consolidated group, and does not search for a group record itself.
- **The dashboard's running list was seeded from history.** The ten items the saved dashboard runs had found, each confirmed on the regulator's own page, were put on the list; the new run then added one (Basel Committee, consolidated guidelines consultation, 5 Nov).
- **Runs saved before the fixes were moved** to `dashboard/data/archive-before-fixes/`, so the run picker cannot open a run with the old labels.

## 6b. The answer-first change of 15 Nov 2026

The original brief routed every agent's output through the dashboard and did not say which came first. The priority is now stated (section 0), and the build follows it.

- **The answer is built from the checked data.** `plugin/skills/dashboard-feed/scripts/answer.py` reads one run file, checks it with the same rules as the dashboard build, and prints the answer for the chat: a reference number on every figure and rating, and a short source list at the end. Ratings pulls and one financial field for many names share one number, so the list stays short.
- **It has to read in about two minutes.** The script refuses an answer of more than 600 words before notes and sources, or one with an over-long headline, item or table note, and names the longest parts. `--max-words` (up to 1,300) is for a wider window or a longer list the user asked for. Default answers in the evals run 440 to 550 words; 30-day regulatory watches run 900 to 1,230.
- **Where no script can run**, the agent writes the same shape by hand. The rule is in "The answer" in `plugin/skills/source-rules/SKILL.md`.
- **The dashboard comes last and never blocks.** If the folder, the script or publishing is not available, the agent gives the full answer and adds one line: "Dashboard not updated: ...".
- **The evals grade the chat answer.** Each run saves its reply word for word; `evals/checks.py` checks it for references, a source list, figures that are not in the checked data, and length. `evals/RUNNER-ANSWER-ONLY.md` runs a case with no folder, no scripts and no publishing.
- **The dashboard page was left as it is.** It still shows the runs made before this change.

## 6c. The news fixes of 15 Nov 2026, and the standing source review

After the first line-by-line review of the news brief (`evals/results/news-review.md`), seven fixes were approved and applied, with two adjustments from the owner.

- **A materiality checklist** in `plugin/skills/sector-news-brief/materiality.md`: results in full, deals, rulings, funding, shareholder returns, CEO or CFO changes, Moody's actions, government measures. Anything on it goes in.
- **"Why it matters" only from a source.** One `getCreditOpinion` call for the names in the top items gives Moody's triggers and outlook; a line with nothing sourced to add is dropped.
- **No absolute statement from one search**, and the bank outlook lookup tries each country.
- **Ratings under review**: which ratings and which direction, from the rating action.
- **An item resting on one aggregator article** is marked "single source, unconfirmed" and kept out of the top items.
- **A material item is never cut to fit the word limit.** Other lines go first; if the brief is still over, it runs over and says so in one line (`answer.py --over-limit-ok`).
- **Regulatory watch, two points**: a figure keeps the regulator's own qualifier ("more than 55%"); a table heading names only the measure its names are right for.
- **The source review is a standing test** for all three agents: `evals/REVIEW.md` says when to run it, gives the prompts and the reader's brief for each agent, and keeps the record of counts.

What the rerun showed is in section 7 and in `evals/results/news-review-2.md`, `reg-review.md` and `earnings-review.md`. The fixes about wording worked. "Results in full" did not.

## 6d. The fixes from the three source reviews, 15 Nov 2026

Approved by the owner after the first review of each agent, and applied together.

- **News brief.** A results step: for a name that reported inside the window, one more news search that returns article bodies, then the call transcript, and the line names whatever is still not returned. An item on the checklist is confirmed with one search before it is marked "single source, unconfirmed". A figure is taken only from an article about that name. An item is dated by its event, or "reported on". "No news returned" only when the search returned nothing.
- **Earnings recap.** A second filing query for guidance ranges, impairments, one-offs and legal matters. The credit opinion call adds the strengths and challenges sections. The net debt movement has to add up. The recap never says the opinion "does not mention" something.
- **Regulatory watch.** Words for how much a measure covers stay the regulator's own. The scope of the Basel methodology consultation of 16 Oct 2026 (the five banking-union G-SIBs, as our reading, because the page names no addressees) is written into `banks-scope.md`, with the general rule for a measure about one region.
- **Tests.** A script check that a results line carries a profit or loss figure and a debt or capital figure, or says which was not returned; new expectations on the recap and on scope words.

Result: the regulatory watch review came back clean. The news brief went from 4 / 5 / 3 to 4 / 2 / 0 and the earnings recap from 1 / 6 / 1 to 1 / 4 / 0. What is left, and why, is in `news-review-3.md` and `earnings-review-2.md`.

## 6e. The last round of fixes, 15 to 16 Nov 2026

- **News brief.** The company's results report is the last resort for a profit or loss figure. A second, keyword search per bank. The research search asks for issuer profiles. A name under review lists every rating the action lists. A figure may come from an article about something else when its sentence names the company, quoted with its outlet. A filing's or article's date is written as such.
- **Earnings recap.** Three filing queries of one subject each; the guidance one uses the preview's wording, which finds the outlook page. The profit or loss for the period comes first, in currency. A figure from a filing is used only if it is found in the saved result. The rating action's text is searched for what moved leverage.
- **Checks.** A recap states a profit or loss as an amount of money; a regulatory watch answer does not say "most Senior Manager".

Result: the earnings recap's review came back with no wrong statement (0 / 3 / 0). The news brief's came back at 3 / 3 / 1, with Vodafone's results and Intesa's offer now in, and three new mistakes. No further round was run.

## 6f. Three self-contained agents, 16 Nov 2026

The owner expected three agent folders, each with everything it needs. The build had three agents that leaned on four shared folders, which is why one agent folder could not be copied and run.

- `tools/build_agents.py` builds `agents/<agent>/`: a `plugin/` folder with the agent and its own copy of the shared rules under `shared/`, a `README.md`, and `<agent>.plugin` to install. Links inside each agent point at its own copies. The shared copies carry no skill header, so they are reference files of that agent and not skills of their own.
- `plugin/skills/` stays the master, the one place to edit. `python3 tools/build_agents.py --check` says whether `agents/` is in step with it.
- The news brief borrows one file from the earnings agent (`reading-results.md`); its folder gets its own copy.
- Each agent was run live from its own folder with nothing else readable (`evals/RUNNER-STANDALONE.md`).
- `moodys-fi-agents.plugin`, all three agents in one file, is kept for anyone who wants them together.

## 7. How it was tested

All testing was live on 15 Nov 2026. Each eval case was run by a fresh Opus 5.5 session given only the user's message and the plugin.

| Test | Result | Record |
|---|---|---|
| Eval cases | What is graded is the answer in the chat. 27 of 30 runs pass every script check (8 news, 14 regulatory watch, 8 earnings); every news and earnings run passes. The three that fail are regulatory watch runs: two write "most" where the PRA says "almost half", one puts BPCE in a second table without the co-operative note. 92 of 111 graded expectations pass | `evals/results/SUMMARY.md` |
| With the dashboard not available | One run per agent with no folder, no scripts and no publishing: each gave its full answer with a source list and one line that the dashboard was not updated, and each passes its checks | `evals/results/SUMMARY.md` |
| Each agent from its own folder | One live run per agent with access to that agent's folder in `agents/` only: every file each skill pointed to was there, and the scripts ran from inside the folder. The regulatory watch produced a 30-day watch with 12 items; the earnings agent a full Vodafone recap; the news brief a quiet 72-hour brief with its reason | `evals/results/SUMMARY.md`, `evals/RUNNER-STANDALONE.md` |
| Live runs | 201: 48 in the first build, 40 for the four fixes, 2 for the first news brief review, 31 for the answer-first change, 25 for the first news fixes, 33 and 19 for the fixes from the source reviews, 3 stand-alone | `evals/runs*/` |
| Recall on a known window | 14 of the 15 runs from an empty list, over five rounds, showed 10 of the 10 known items for 16 Oct to 15 Nov 2026; one showed 9. Three other cold runs of that window missed one item | `evals/results/SUMMARY.md`, `evals/answers/` |
| Source reviews: news brief | Four reviews, two fresh 7-day runs each, re-pulled from Moody's by a separate reader. Wrong / missing / unsupported: 7 / 11 / 7, then 4 / 5 / 3, then 4 / 2 / 0, then 3 / 3 / 1. 30 of 30 ratings right each time | `evals/results/news-review.md` to `news-review-4.md` |
| Source reviews: regulatory watch | Two reviews of a fresh 30-day run: 1 / 0 / 0, then 0 / 0 / 0. Every figure, median, distance, third and requirement matched both times | `evals/results/reg-review.md`, `reg-review-2.md` |
| Source reviews: earnings | Three reviews of a fresh Vodafone recap: 1 / 6 / 1 (not verified), then 1 / 4 / 0, then 0 / 3 / 0. Every Moody's figure right each time | `evals/results/earnings-review.md` to `earnings-review-3.md` |
| Figures re-pulled from the source | 189, all match: 133 in the first build, 50 after the first three fixes and 6 for the Credit Agricole fix | `evals/results/spot-checks.md` |
| Check script against planted defects | Every check catches the defect planted for it | `python3 evals/selftest.py` |
| Refresh from the Claude app | Passed: file written, uncited figure rejected, same link republished | `evals/results/refresh-test.md` |
| Latest outlook through document search | Telecoms: global outlook of 27 Oct 2026. Banks: global outlook of 3 Dec 2025 plus Spain and Italy system outlooks. Moody's has no single European banks outlook | `evals/results/spot-checks.md`, rows 13 and 14 |
| Plugin installed in the Claude app | Reported working by the user, both before the three fixes and after reinstalling the rebuilt plugin. The combined plugin file has been rebuilt five times since and has not been run installed since. The three per-agent install files in `agents/` are new and have not been installed yet; each agent was run live from its own folder | Section 1 |

The cases cover normal runs and edge cases: a quiet day, a Monday window, an unresolvable name, a user's own list, a client's own banks that are not in the sector file, a topic with no Moody's metric, a window with a known answer run three times, a second run on a list that already holds the items, an issuer with no transcript, an issuer whose latest filing is a year old, and text with a planted instruction that the agent must ignore.

## 8. What the Moody's data does and does not do

These were found by live probing and are the reason several rules exist. A maintainer should know them before changing a skill.

- **Name search returns subsidiaries.** "Banco Santander" returns Santander Brasil, Santander Totta or Open Bank depending on the filter. The right parent appears only among the alternatives.
- **The "rated" flag in name search can be wrong.** KPN and BT Group Plc both came back as rated. Ratings are confirmed with `getEntityRatings`.
- **Bank financials need exact field names**, and the full list every time. A two-field request returned 2018 data for UBS. The call is written out in `plugin/skills/sector-metrics/sectors/banks.md`.
- **Some fields are absent.** There is no MREL field. The leverage ratio is missing for about a third of banks. A missing value is shown as "no data" and left out of rankings.
- **Two tools return too much to use** and are banned in `source-rules`: `getEntitySectorOutlook` and `getEntityScorecardV2`.
- **News search takes one name per call.**
- **Document search filters by whole calendar days** and needs keywords.
- **There is no forward earnings calendar and no consensus.**
- **Filings.** `searchCompanyFilings` with types `interim` and `annual` returns ten passages from the latest report of each type, often 100,000 characters or more. "Latest" is not reliable: for banks that file with the US regulator it can be a routine notice, and for some banks the latest interim report held is a year old (BNP Paribas, Societe Generale's unfiltered result, Nordea). The year and quarter in a title can be wrong. A bank's capital requirement is in these filings for ten of the fifteen banks.
- **Transcripts.** The first request for an issuer can take about three minutes. Links expire in five minutes. The quarter label in the metadata can be wrong, so the agent identifies a call by its headline and date. Slide decks are often not found. Some issuers have no transcript (BNP Paribas and Iliad Holding on 15 Nov).

## 9. Known limits

- Six or seven cases per agent show whether a rule holds, not how often.
- Live news and regulator pages change daily, so two runs of the same request can differ. The regulatory watch found four to six items for the same 30-day window across runs.
- The regulatory watch is the slow one: 6 to 28 web calls, three to four minutes.
- Regulator sites sometimes refuse a page fetch. The item is then kept only if its date is shown elsewhere, and marked "page not opened".
- After a few cases' last run, only wording clarifications and the table of regulator listing addresses were added. `reg-01` was rerun on the final text and passed.
- Five of the fifteen banks have no stated CET1 requirement on file (HSBC, Deutsche Bank, Lloyds, Commerzbank, Nordea), and three have only a 2025 figure (BNP Paribas, Barclays, ING). With the G-SIB rule that leaves three current figures among eight banks, so that table is ranked by level, not headroom.
- Groupe Credit Agricole's stated distance (6.7 pp above its SREP requirement at 31 Mar 2026) comes from a results slide whose title did not come through from Moody's filings; it is identified as the group's by its CET1 of 17.1% and the TLAC and MREL ratios beside it. Moody's holds no filings under the group's own record.
- The FSB list in the file is the one of 27 Nov 2025. A new list is due in November 2026 and was not out on 15 Nov.
- The bank requirement table and the G-SIB list are a snapshot. Nothing refreshes them automatically.
- Only two sectors have a sector file and a checked list: European banks and European telecoms. Other sectors go through the general route, which was tested once each on 16 Nov 2026 (`evals/results/other-sectors.md`): the news brief worked on six named utilities and on European auto makers with no names; the earnings recap worked on Volkswagen; the regulatory watch, which is built for banks, listed what changed for six insurers but could not rank them. The one weak step was the sector outlook lookup, written down only for banks and telecoms; a general version was added to `sector-metrics` on 16 Nov 2026 and tested once on utilities.
- **The news brief still makes wrong statements and misses items.** In its last review, two 7-day briefs had 3 wrong statements and 3 missing items. Three were an item dated by its article and not by its event, so old news was shown as new. Three rounds of rule changes took the count from 7 to 3 or 4 and the last round did not move it. `evals/results/news-review-4.md` says what would: a second pass in which the agent re-opens the source of each top item, or a narrower default for demos. Neither has been built.
- **The earnings recap leaves out some items**: in its last review, the size of two tax write-downs, a round of job cuts, and what Moody's said about the deal that raised net debt (which is in the rating action the recap cites). Three small fixes are proposed in `evals/results/earnings-review-3.md`; none has been applied.
- **Regulatory watch: two of nine runs wrote "most" where the PRA says "almost half"**, and one cold run missed an item, although the reviewed run was clean. A script check now catches the word.
- A figure passes the answer check when it carries a reference number, whether or not the reference contains that figure. Only a reader catches a figure that is not in its source.
- In a session with no tools for searching a large result, a filing can be only partly read; the answer says what is missing.
- The run picker holds demo data from the evals, including a banks news run that names Santander (ratings only), BNP Paribas preview and recap runs, and an Iliad Holding run.

## 10. How to maintain it

**After any change to a skill**, rebuild the three agent folders and their install files: `python3 tools/build_agents.py`. Then run the source review for that agent (`evals/REVIEW.md`).

**Run an agent.** Open a Claude session on this folder so new runs land on the same link, with the Moody's Credit MCP and web search connected.

**Change a coverage list.** Edit the JSON in `plugin/skills/coverage-list/lists/`. Confirm each new name is rated and, for banks, that the financials call returns data for it.

**Add a sector.** Copy `plugin/skills/sector-metrics/sectors/telecoms.md`, replace the tables, test the financials call once, and add a checked list.

**Add an agent to the dashboard.** Write a run file with a new `agent` id (shape in `run-file.md`) and run `dashboard-feed`.

**Add a group record for a bank.** If a bank on a list is not the consolidated group that rules apply to, find the group's record in Moody's by hand, check that its financials are the group's, and add `groupEntityId` and `groupName` to the bank's entry in the list file. The agent never does this itself.

**Refresh the bank scope facts.** `plugin/skills/sector-metrics/sectors/banks-scope.md`: replace the G-SIB list when the FSB publishes a new one each November; refresh the requirement table each quarter and each January, by searching each bank's interim and annual filings in Moody's for its stated total CET1 requirement. Record only a total the bank states, with its date.

**The running list of regulatory items** is `dashboard/data/items/reg-watch-<sector>-<region>.json`. To change whether an item is shown, edit its `decision` (and `reason`) there; later runs follow it. Deleting the file starts the list again from empty.

**Rebuild the plugin file after any change to `plugin/`:**

```bash
cd plugin && zip -r ../moodys-fi-agents.plugin . -x "*.DS_Store"
```

Then reinstall it in the Claude app.

**If an installed agent cannot find a shared skill**, run this once and rebuild the plugin file:

```bash
python3 tools/vendor_shared.py
```

**Rerun the checks on the saved runs:**

```bash
python3 evals/checks.py
```

**Rerun a case live.** Give a fresh Opus 5.5 session `evals/RUNNER.md` and the case's `prompt` from the evals file, then run the checks.

## 11. What was not done

- Sending output to Teams, Slack or email was not built. The dashboard carries one line saying it can be, as asked.
- No scheduled runs were set up. Each run is started by hand.
- No emails or messages were sent, no accounts were created and no money was spent. The only thing published outside this folder is the private dashboard link.
- The reference repos were read, not run. The copies used for the study were in a temporary folder and are not kept here; their addresses are in `research/repo-notes.md`.
- This folder is not a git repository, so there is no version history beyond the saved eval rounds.
