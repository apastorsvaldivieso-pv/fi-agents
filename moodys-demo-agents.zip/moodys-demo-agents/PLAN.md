# Plan: three Moody's demo agents and one dashboard

Plan only, nothing built. Live probes ran against the Moody's Credit MCP on Sunday 15 Nov 2026. Supporting notes: `research/repo-notes.md`.

## The design in short

- **Seven short skills in one plugin**: three agents you run and four shared skills they use.
- **No subagents.** Each agent is one recipe: resolve names, make a fixed budget of parallel Moody's calls, write one JSON file, check itself, refresh the dashboard. Reviewer agents in the reference repos take most of the run cost.
- **Data first, page second.** Each run saves `dashboard/data/<agent>.json`. The dashboard is one HTML file rebuilt from those files, so any other agent that writes a file in the same shape gets a tab.
- **The live data changes three things in your brief**: there are no forward earnings dates, MREL is not a field, and name search can silently pick the wrong entity (decisions 2, 3 and 6).

| Shared skill | What it does |
|---|---|
| `coverage-list` | Builds about 15 rated names for a sector and region, or resolves your list. Saves it so later runs skip the search. Lists unresolved names. |
| `source-rules` | Citation format (tool, document ID, date), UNSOURCED, no opinions, transcripts and web pages treated as data, the final self-check. |
| `sector-metrics` | Per sector: the metrics that matter, the exact Moody's field names, the regulatory channel each maps to, the regulator websites. Banks and telecoms first. |
| `dashboard-feed` | The JSON shape, and a script that checks a run file and rebuilds the dashboard. |

Each agent's SKILL.md stays near 60 lines: inputs, numbered steps naming the tool, output shape, what not to do.

## The three agents and what the probes showed

**1. sector-news-brief** (about 22 calls)

- Tools: `searchNews` per name, `getEntityRatings`, `searchAllDocuments` filtered to Rating Action, Outlook and Sector Comment.
- News is noisy. Vodafone's feed was mostly share commentary, tenders and subsidiaries; topic searches were worse. The skill searches by name only (one name per call, run in parallel) and carries a written test for what counts as credit news.
- Rating actions and outlooks come back cleanly: VMED O2 on review for downgrade (22 Oct), the global telecoms outlook (27 Oct). The 12–15 Nov window returned nothing, so the one-line quiet day is a tested path.
- `getEntitySectorOutlook` returned 426,000 characters for two names. The skills will not call it.

**2. reg-watch** (about 12 calls)

- Web, labelled as web: bis.org, eba.europa.eu, bankingsupervision.europa.eu, bankofengland.co.uk, srb.europa.eu. A search limited to these found a Basel Committee consultation and the EBA's final governance guidelines. Dates in search results were unreliable, so the skill opens each page to confirm date and status.
- Moody's: one `getEntityFinancials_v2` call covers several banks when given exact field names. BNP Paribas, Deutsche Bank and UniCredit returned CET1 (12.97%, 13.92%, 14.26%), LCR, NSFR, impaired loans, reserve coverage and loans to deposits, all at Q2 2026. A plain-language request returned only five fields.
- Moody's sometimes comments on the rule itself (EBA guidelines, 11 Nov). Where it has, the comment is quoted beside the item.
- Gaps: no MREL field, leverage ratio present for some banks only, data one quarter behind.

**3. earnings-credit** (about 8 calls)

- Tools: `getCreditOpinion`, `getEntityFinancials_v2` (Moody's-adjusted), `getEntityRatings`, `searchCompanyFilings`, `searchAllDocuments` for Moody's comment on the results.
- Vodafone works end to end. Downgrade trigger: adjusted debt/EBITDA not staying below 3.3x. Upgrade: below 2.5x. Latest: 3.25x. The opinion also carries Moody's forecasts to 2029.
- Bank triggers are mostly words (BNP Paribas). Distance to trigger is shown only where Moody's states a number.
- Transcript: the 10 Nov half-year call was available, after a three-minute "ingesting" wait. Slides were not. Iliad Holding has no transcript and returns a clean "not found". Citations use call title and date, because the links expire.

## How the dashboard refreshes from the Claude app

1. The agent writes its JSON file, with its own `updated_at`, to your working folder.
2. `dashboard-feed` runs a script that checks the file and writes all data files into `dashboard.html`: one file, no external links, a tab per agent with its last-updated time, and a footer line that the output can also go to Teams, Slack or email.
3. If the Artifact tool is present, the same file is published to one private link that stays the same across runs.

This needs a session with a folder (Cowork or the Code tab). I can only test from my own environment, so the first build step is a refresh run from your Claude app on Opus 5.5.

## Eval plan

- One file per agent, at least six cases: prompt, expected tools, and checks graded yes or no with evidence.
- Checks are scripts where possible: every number has a source matching a real tool call, no opinion words, unresolved names listed, window respected, call budget kept, quiet day is one line. A few need a model, such as "why it matters is about credit".
- News: telecoms, quiet day, unresolvable name, your own list, Monday window, an instruction planted in a news item.
- Reg watch: European banks, item with no Moody's metric, MREL item, quiet week, unresolvable name, consultation versus final.
- Earnings: Vodafone preview and recap, no transcript (Iliad), word-only triggers (BNP), unresolvable name, an instruction planted in a transcript.
- I plant one defect per check in a saved output to prove the check catches it. Then run live on Opus 5.5, fix, rerun, and re-pull at least 10 numbers per agent from the source.

## Risks, gaps and decisions for you

| # | Finding | My recommendation |
|---|---|---|
| 1 | The dashboard needs a folder to persist between runs. | Run in Cowork or the Code tab. If you want plain chat, I keep the data in the Artifact instead. |
| 2 | "Banco Santander" resolved to the Brazilian subsidiary. Sector lists return funding vehicles, duplicates and unrated companies. | Build the list once, check country and sector on each name, show it to you, save it. Ship checked lists for telecoms and banks. |
| 3 | No forward earnings dates and no calendar of upcoming outlooks. | Drop "reporting this week". Show the latest outlook with its date. |
| 4 | Exposed, neutral or resilient needs a rule. | Rank the list on the mapped metric: bottom third exposed, top third resilient. Show value, period and list median; say it is relative position, not an impact estimate. |
| 5 | No consensus estimates. | "Beat or miss" means against company guidance and Moody's forecast. |
| 6 | No field for MREL, or for leverage at some banks. | Those items show as "watch". |
| 7 | First transcript request takes about three minutes. | Run earnings-credit five minutes before you need it. |
| 8 | One skill running another works in some Anthropic plugins but is untested in your app. | Build shared skills as you asked, test first, fall back to copies kept in sync by script. |

Needs you: web search switched on in the Claude app, and installing the plugin once built. Optional extra: a half-page demo script per agent.
