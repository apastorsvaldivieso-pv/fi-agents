---
name: dashboard-feed
description: Saves an agent's output as a run file and refreshes the FI Credit Monitor dashboard (one tab per agent, last-updated time on each tab). Use at the end of sector-news-brief, reg-watch and earnings-credit, whenever a skill says "hand the run to dashboard-feed", or when the user asks to refresh, rebuild or publish the dashboard. Any other agent can feed the same dashboard by saving a run file in this shape.
---

# Dashboard feed

One run file per agent goes in; the answer for the chat and one dashboard page come out of it. The answer comes first and does not depend on the page. The page is rebuilt from the files every time, so it can never show something that was not saved.

Folders, relative to the working folder unless the user names others:
- Data: `dashboard/data/`
- Page: `dashboard/dashboard.html`

## Steps

1. **Write the run file** to `dashboard/data/<agent>.json`, replacing the previous one. The shape is in `run-file.md` in this folder. Read it before your first run file. `updated_at` is the time now in UTC, read from the clock (`date -u +%Y-%m-%dT%H:%M:%SZ`), not guessed.

2. **Check the file and give the answer.** `python3 <full path to this skill>/scripts/answer.py dashboard/data/<agent>.json` checks the run file and prints the answer with a reference number on every figure and rating and a source list at the end. Give that output to the user as the answer, unchanged. If it reports errors, fix the run file and run it again (step 4 says how).

3. **Rebuild the page**, using the script that sits in `scripts/` beside this file (give its full path):
   ```bash
   python3 <full path to this skill>/scripts/build_dashboard.py --data dashboard/data --out dashboard/dashboard.html
   ```
   It checks every run file, keeps a copy in `dashboard/data/history/`, and writes the page. To check one file without building, add `--check <file>`.

4. **If a script reports errors, fix the run file and run it again.** A file with errors is left off the page. The usual error is a figure with no source: add the source to that item, cell or `headline_src`, or mark the figure UNSOURCED. Do not remove a figure only to get past the check.

5. **Publish to the private link, if this session can publish Artifacts.** The link is in `dashboard/dashboard.config.json` (`artifact_url`).
   - Read the Artifact at that link first, then publish `dashboard/dashboard.artifact.html` to the same link (pass the link as the Artifact to update; no new icon or title), so the address the user opens in meetings never changes.
   - If no link is saved yet, publish it as a new private Artifact and save the link in that file.
   - If this session cannot publish Artifacts, say so in one line. The local page is still current.

6. **Close with one line** after the answer: which tab was updated and when, the full path of the page, and the link if it was published. In Cowork, give the path; do not try to open the file yourself.

## When something is not available

The answer never waits for the dashboard. If there is no folder to write to, a script cannot run, or publishing is off, stop at that point: give the full answer with its sources (by hand, in the shape `source-rules` gives, if `answer.py` could not run) and close with one line, "Dashboard not updated: <what was not available>." Do not shorten or drop the answer because the page could not be updated.

## What not to do

- Do not edit `dashboard.html` by hand or write HTML yourself. Change the run file and rebuild.
- Do not put a run file on the page that the script rejected.
- Do not change the saved link or publish to a second one.
