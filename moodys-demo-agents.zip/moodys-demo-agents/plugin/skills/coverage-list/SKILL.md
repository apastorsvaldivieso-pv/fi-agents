---
name: coverage-list
description: Builds or loads the list of Moody's-rated names an agent works on, and resolves company names to Moody's entity IDs without guessing. Use whenever a skill needs a coverage list for a sector and region, whenever a user gives company names for a Moody's lookup, and before any Moody's tool call that needs an entity ID.
---

# Coverage list

Inputs: sector, region (default Europe), and optionally the user's own names.
Output: a saved list of entity IDs, plus the names that could not be resolved.

Name search in Moody's is not safe on its own. "Banco Santander" returns a subsidiary first, and sector searches return funding vehicles and duplicates. The steps below exist to stop a wrong entity getting through silently.

## Steps

1. **Reuse a saved list if there is one.** Look for `dashboard/data/coverage/<sector>-<region>.json`. If it exists and the user gave no new names, use it and make no search.

2. **Otherwise start from a checked list if one ships with this skill.** `lists/telecoms-europe.json` and `lists/banks-europe.json` were checked name by name. When the run covers the whole sector, copy the one that fits into `dashboard/data/coverage/` and use it. When the run is for one issuer or a few of the user's names, read it where it is.

3. **The user gave names.** A name that is already on the saved or checked list is taken from it with no search. Resolve every other name separately: one `findEntity` call per name, all in the same step:
   - `data`: the name as the user wrote it.
   - `disambiguationCriteria.country`: the issuer's one home country as an ISO code, for example `["ES"]`. Pass one country, not the whole region; a wider filter returned a subsidiary in testing. The filter is ignored if several names are sent in one call, which is why each name gets its own call.
   - `getAlternatives: true`, `maxAlternatives: 5`.

   Then accept a result only if all three hold:
   - its name matches the name asked for (ignore legal endings such as S.A., plc, AG and a country in brackets);
   - its country is the one you passed and its sector fits;
   - it is rated (`isUnrated` is false).

   If the first result fails but one alternative passes all three, take that alternative. If none passes, the name is **unresolved**: record the name, the reason and the candidates returned. If you do not know the home country, make the call without the country filter, only to record the candidates, and treat the name as unresolved unless exactly one rated candidate matches the name. Do not pick the nearest one.

4. **No names given and no checked list: build one.** One `findEntity` call with `data` such as "Moody's-rated European telecommunications operators" and `numberOfResults: 45`. From the results keep entities that are rated, in the sector and in the region. Keep one entity per group: prefer the parent or the one with a ticker, and drop funding vehicles (names with Finance, Financing, Funding, Capital, Treasury, or a numbered issuing company). Stop at 15. Do not add names from memory; if fewer than 15 survive, say how many.

5. **Confirm the ratings of new names.** `findEntity` can call a name rated when its rating has been withdrawn. For names you just resolved or built, call `getEntityRatings` (up to 10 names per call). In a built list, drop a name with no current rating or with WR. In the user's own list, keep it and set its `note` to "no current Moody's rating".

6. **Show the list** to the user in a short table (name, country) with the unresolved names underneath, then save it. A list built from the user's own names is saved as `<sector>-<region>-own.json`; it never replaces the full list. A single issuer looked up for one run is not saved.

## The saved file

```json
{ "sector": "Telecoms", "region": "Europe", "checked": "2026-11-15",
  "names": [ { "name": "Vodafone Group Plc", "country": "GB", "entityId": "...", "note": "" } ],
  "unresolved": [ { "name": "...", "reason": "..." } ] }
```

Pass `entityId` and `name` (as `orgName`) to every Moody's tool. Carry `unresolved` into the run file.

Some groups are rated at a different company from the one the news is filed under (BT Group is rated at British Telecommunications Limited). Such an entry also has `ratingsEntityId`: use it for ratings, credit opinions and financials, and `entityId` for news and filings.

Some issuers sit inside a group that regulators measure as a whole (Credit Agricole S.A. is inside Groupe Credit Agricole, which is the G-SIB). Such an entry also has `groupEntityId` and `groupName`. Only `reg-watch` uses them, for the metrics in its "who it hits" tables, and it names the row by `groupName`. News, ratings, credit opinions and earnings stay on `entityId`.

## What not to do

- Do not send several names in one `findEntity` call when resolving names.
- Do not accept a result because it is the only one returned.
- Do not rebuild a saved list on every run. Rebuild when the user asks or adds names.
