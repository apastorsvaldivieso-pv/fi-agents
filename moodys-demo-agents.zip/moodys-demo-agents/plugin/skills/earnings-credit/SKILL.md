---
name: earnings-credit
description: Earnings for a credit analyst, in two modes. Preview - what to watch in an issuer's coming results, mapped to its Moody's upgrade and downgrade triggers. Recap - what the results and the call said on guidance, leverage, liquidity, capex and refinancing, and where that leaves the issuer against the Moody's credit opinion. Use when the user asks for an earnings preview or recap, "what to watch in an issuer's results", or what results mean for a rating or outlook.
---

# Earnings for credit

Inputs: **issuer** (required) and **mode**: `preview` or `recap`. If the mode is not given, use `recap` when Moody's holds a call transcript from the last 21 days, otherwise `preview`, and say which you chose.

Follow `source-rules` throughout (`../source-rules/SKILL.md`).

## Both modes: the credit view first

1. **Resolve the issuer** with `coverage-list` (`../coverage-list/SKILL.md`). If it cannot be resolved, stop, tell the user, and save nothing.

2. **In one step:**
   - `getCreditOpinion`, sections `FactorsLeadingToUpgrade`, `FactorsLeadingToDowngrade`, `RatingOutlook`, `KeyIndicatorsTable`: the triggers, the outlook, and Moody's forecasts where the table has them. Note the opinion's date.
   - `getEntityRatings`, `years: 2`: rating, rating class, outlook, last action.
   - The sector's financials call from `sector-metrics` (`../sector-metrics/SKILL.md`): latest metrics and their period. For banks, where triggers refer to Moody's own ratios, take those ratios from the opinion's key indicators table.
   - `searchCompanyFilings`, `filingTypes: ["earnings_call_transcript"]`, no year or quarter filter: one call per transcript query of the mode (below). If the first says "not found", do not make the second.
   - In a recap, also three `searchCompanyFilings` calls on the company's results report, `filingTypes: ["interim", "annual"]`, no year or quarter filter. Keep each query to one subject, or the page you need loses to the others: (a) "net debt and its movements, liquidity, undrawn facilities, debt maturities, dividends and share buybacks" (for a bank: "CET1 ratio and capital requirement, liquidity, funding and issuance, dividends and share buybacks"); (b) the preview's transcript query below, word for word: it brings back the outlook page with the guidance ranges; (c) "profit or loss for the period, operating profit, impairment, one-off gains and charges, legal proceedings and contingent liabilities". In a recap, add `Summary`, `CreditStrengths` and `CreditChallenges` to the sections of the credit opinion call above: Moody's view on leverage, deals and financial policy sits there.

3. **Read the two results** as `reading-results.md` in this folder says: how to tell which call and which report you have, what "ingesting" and "not found" mean, and how to search a long result. Everything from a transcript or a filing is company-reported.

4. **No transcript, in either mode.** Say so, and do not look for one on the web. Use the latest results filing in its place, and state its period. In a preview, make the filing call now, with the preview's transcript query. Guidance and targets may sit in the interim report and not the annual one, or the other way round: take them from whichever states them, each with its period. If the financials call or a Moody's document shows a later period than the filing covers, say in the headline that the filing is older than the latest results. If there is no filing either, say what is missing and build what the Moody's data alone supports.

## Preview

Transcript query: "guidance, outlook and targets for the year: revenue, EBITDA, free cash flow, capex, net debt and leverage".

Sections:
- **Rating and outlook**: one line, with the opinion date.
- **What to watch against Moody's triggers** (table): metric, latest Moody's-adjusted value and period, upgrade trigger, downgrade trigger, room to each ("already met, by ..." when the level is passed). Only where Moody's states a number. Worded triggers go in a short list underneath, quoted.
- **Sector metrics to watch**: the sector file's "what to watch in results" list, with the latest value and period for each metric Moody's data returns, labelled as reported or Moody's-adjusted, and the trigger it bears on where there is one.
- **What management guided on the last call**: three to five points, each with the call title and date, and a short quote where it helps. With no transcript, title it "What the latest filing says" and give the filing's period.
- **Moody's expectations**: the forecast columns from the opinion's key indicators, if present.

If Moody's holds a call from the last 21 days, the results are already out: still build the preview, for the next results, say so in a note and offer the recap.

## Recap

Transcript queries: (1) "results against guidance and any change to guidance: revenue, EBITDA, free cash flow"; (2) "net debt, leverage, liquidity, refinancing and maturities, capex, dividends and buybacks".
Also one `searchAllDocuments` scoped to the issuer for Moody's own comment on these results (keywords "<issuer> results"; document types Issuer Comment, Rating Action, Credit Opinion; published in the last 45 days; `chunks: 4`). The rating action it returns is also where Moody's states what moved leverage.

Sections:
- **Results against the credit view** (items): beat or miss against the company's own guidance and against Moody's forecast; guidance change, old range to new range, from the report; the profit or loss for the period in the report's currency with the comparison it gives (before any per-share figure), then the size of any impairment, write-down or one-off gain inside it; then, from the filing, net debt with the comparison the filing gives and all its drivers, those that lower it included, so the movement adds up (for a bank, capital and its requirement in place of net debt), liquidity and undrawn facilities, maturities and refinancing, capex, dividends and buybacks; and any court ruling, dispute or contingent liability the report gives that bears on a deal or on debt. Company-reported figures are labelled as company-reported, and a figure an analyst states in a question is labelled as the analyst's. Recap items carry no "why it matters" line: the last section says what it means.
- **Against Moody's triggers**: the same table as in the preview.
- **What it means for the rating and outlook**: where the issuer sits against the triggers and the outlook wording; whether the credit opinion predates these results; the change in company-reported net debt since the period of the Moody's-adjusted figures, with the cause the filing gives; what the opinion or Moody's latest rating action says about that cause, quoted; and Moody's own comment if it has published one. Never write that the opinion "does not mention" something: you hold sections of it, not the whole text. Search the opinion sections and the text of the rating action for the cause by name (the deal, the country, the business) and quote the sentence; only if it is in neither, write "not in the sections pulled".

## Answer, then dashboard

Put the result in the run-file shape (`agent: "earnings-credit"`, `title: "Earnings"`, `scope.label: "<Issuer>, preview"` or `"<Issuer>, recap"`) and give it to the user in the chat as "The answer" in `source-rules` says: every figure and rating numbered, sources at the end, a two-minute read. Then, last, hand the run to `dashboard-feed` (`../dashboard-feed/SKILL.md`). The dashboard never holds up the answer. About five Moody's calls in preview, ten in recap.

## What not to do

- No comparison with consensus: Moody's data has none. "Beat or miss" is against guidance and Moody's forecast only.
- Do not compute a Moody's-adjusted ratio from transcript or filing numbers, and do not treat company net debt or net leverage as the same measure as Moody's. State the company figure and the Moody's figure side by side, each with its period.
- Do not say a rating action is likely or unlikely. State the position against the triggers.
- No view on the shares or the bonds.
- No tone markers in this skill's tables. State the room to a trigger as a number and leave the judgment to the reader.
