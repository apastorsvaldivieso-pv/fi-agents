---
name: reg-watch
description: Weekly regulatory watch for one sector - what changed at the primary regulators in the last 7 days (web sources), which names on the coverage list each rule covers, and where each covered name stands on the Moody's metric behind it, from least headroom to most. Keeps a running list of items so every run shows the same items the same way. Use when the user asks for a regulatory watch or reg watch, "what changed in regulation for a sector", or which issuers a new rule or consultation hits. Built and tested on European banks.
---

# Regulatory watch

Inputs: **sector** (required), **names** (optional), **region** (default Europe).
Result: who each rule hits, and what changed, saved as a run file and shown on the dashboard.

Follow `source-rules` throughout (`../source-rules/SKILL.md`). The sector's metrics, channel map, scope facts and regulator sites are in `sector-metrics` (`../sector-metrics/SKILL.md`).

## Part 1: what changed (web, labelled as web)

1. **Window**: the last 7 days, or the window the user states. "The last N days" runs from N days before today to today, both days included (on 15 Nov, the last 30 days is 16 Oct to 15 Nov), so a weekly run overlaps the one before by a day and nothing published on a boundary day is lost. State the dates.

2. **Start from the running list.** It holds every item earlier runs found, with the decision made on each:
   ```bash
   python3 <full path to this skill>/scripts/items.py show --list dashboard/data/items/reg-watch-<sector>-<region>.json --from <first day> --to <last day>
   ```
   No file yet means an empty list.

3. **Search the primary regulators only.** Limit web search to the regulator sites listed for the sector. Up to six searches, whatever the length of the window; one search can cover several sites. No news sites, law-firm notes or commentary.
   Search results miss items. For each regulator, also open its own listing and read off every entry dated inside the window, including the first and last day. Use the listing addresses in the sector file; where it gives none, find the listing by search, and do not guess an address.

4. **What counts as an item**: a rule, standard, guideline, consultation, policy statement, supervisory decision or legislative step addressed to the sector's firms, or an announced change to one (new dates, next steps after a consultation). Every such item is shown; "minor" is not a reason to drop one. One item per measure: a release that announces a final rule and a separate consultation is two items, each under its own page where the regulator gives it one, because the two can cover different firms. If the list already holds the release as one item, keep it as one and say in the table's note which names each measure covers. Leave out only what is not one of these (speeches, newsletters, statistics, periodic lists, appointments, sanctions notices, consumer material, advice from one authority to another, a moved consultation deadline) or is addressed to other kinds of firm.

5. **Open the page of each candidate you will show that the list does not already hold as confirmed** (a candidate you leave out can be judged from the listing), and take three things from the page itself: the publication date, the status (consultation, final, or other), and the effective date or comment deadline. Dates in search results are unreliable. If a page cannot be opened, keep the item only if a listing or a Moody's document shows its date, and say "page not opened".

6. **Add what you found to the list**, then use what it returns. Write the candidates, shown and left out, to a file in the shape given at the top of `scripts/items.py`, and run the same command with `add ... --found <file>`. From its output:
   - `show` is the run's item set: every item on the list inside the window, whether or not this run found it again. Mark an item NEW only where the output says `new: true`.
   - `left_out` goes in one note, grouped by reason. Entries of one kind from one regulator (its speeches in the window) can be one entry on the list.
   - An item already on the list keeps its decision. If you think a decision is wrong, say so in a note; do not work around it.

7. **Write each item**: what changed in one or two sentences, which body, consultation or final, effective date or deadline, and the channel it hits, from the sector's channel map. A rule that changes how a requirement or buffer is measured belongs to that requirement's row. Keep the regulator's own qualifier on a figure: "more than 55%", "at least", "up to", not a rounded "55%". Keep its own words for how much a measure covers too: "almost half of", "some", "all". Never a stronger word than the regulator's ("most" for "almost half").

8. **A channel the user asks about directly** ("who has least headroom if MREL is tightened", "show the liquidity channel") is treated as an item even if nothing changed in the window: add it to "What changed" tagged "Asked", say that no regulatory change was found, and carry it through Part 2. It does not go on the running list.

9. **Moody's view, if there is one.** `searchAllDocuments` on the item's topic (sector, region, published since the item's date, `chunks: 1`), for at most the four items most likely to move credit. If Moody's has commented on that rule, add the title, date and its stated credit direction.

## Part 2: who it hits (Moody's data)

10. **Names** from `coverage-list` (`../coverage-list/SKILL.md`).

11. **Metrics**: if at least one item maps to a metric, make the sector's financials call, once, for all names, exactly as the sector file writes it. For a name with a `groupEntityId`, send that record for the table, and the issuer's own record in the same call for the figure the table's note gives. If none does, skip the call.

12. **Build one table for each metric and set of names covered**, following `who-it-hits.md` in this folder. In short: only the names the rule covers are in the table; they are ranked by distance to a stated requirement where there is one (Least headroom, Middle, Most headroom), otherwise by level (Weaker third, Middle, Stronger third); fewer than six names means values and no ranking.

13. **An item with no mapped metric shows as `watch`**, with no position for any name. Say that Moody's data carries no metric for that channel, and which names on the list the rule covers.

14. **Quiet week** (nothing on the list in the window and nothing asked): one line, `status: "quiet"`, no sections, no Part 2.

15. **Answer, then dashboard.** The result goes to the user in the chat. Sections in this order, so the tables come first:
    - the tables from step 12, titled "Who it hits: <rule> · <metric>";
    - "What changed" (items), newest first;
    - "Who it hits: no Moody's metric" (table: Item, Covers on this list, Metric needed, Call), for the `watch` items.
    If any position was given, add the footnote from `who-it-hits.md` once in `notes`. Set `scope.label` to a few words that tell this run from others in the run picker ("Banks Europe, 30 days"). Put this in the run-file shape (`agent: "reg-watch"`, `title: "Regulatory watch"`) and give it to the user in the chat as "The answer" in `source-rules` says: every figure numbered, sources at the end. Then, last, hand the run to `dashboard-feed` (`../dashboard-feed/SKILL.md`). The dashboard never holds up the answer.

Budget: about six web searches, the regulator listings and new item pages opened, and about eight Moody's calls.

## What not to do

- Do not give a name a position without a Moody's metric behind it, or on a rule that does not cover it.
- Do not add up a capital requirement from its parts, and do not estimate the capital or earnings impact of a rule.
- If you map an item to a metric by your own judgment, because the channel map has no row for it, say so in the item.
- Do not use a regulator press summary from a news site in place of the regulator's own page.
- Do not treat a consultation as a final rule.
