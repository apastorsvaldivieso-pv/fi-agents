---
name: sector-metrics
description: The credit metrics that matter per sector, the exact Moody's field names that return them, how each maps to a regulatory channel, where the latest Moody's sector outlook is found, and which regulator websites count as primary. Use whenever a skill needs sector metrics, a Moody's financials call for a list of names, a regulator source list, or says "see sector-metrics".
---

# Sector metrics

Moody's financials only come back complete when asked for by exact field name. A plain-language request for bank ratios returned five fields; the exact names returned all of them. This skill holds those names so no agent has to rediscover them.

## How to use it

1. Open the file for the sector in `sectors/`:
   - `sectors/banks.md`
   - `sectors/telecoms.md`
2. Use its **financials call** as written, for every name in the coverage list in one call.
3. Use its **channel map** to decide which metric a regulatory item or a results item touches, and which end of the ranking is the weak one.
4. Use its **outlook lookup** for the latest Moody's sector outlook, and its **regulator sites** for web search. For a sector with no file, the outlook lookup is step 4 of the next section.
5. Use its **scope facts**, where the sector has them, to decide which names a rule covers and what each is measured against. For banks they are in `sectors/banks-scope.md`: the G-SIB list, the home supervisor by country, and each bank's stated CET1 requirement.

## A sector with no file

Do not invent field names. Instead:

1. Call `getCreditOpinion` with `sections: ["KeyIndicatorsTable"]` for two names in the sector. The rows of that table are the metrics Moody's itself tracks for the sector.
2. Call `getEntityFinancials_v2` with `filterCriteria: {"sections": ["key_indicators"], "reportingBasis": "adjusted"}` for the list.
3. Say in the run's notes that no sector file exists and the metrics came from the credit opinion's key indicators.
4. **The sector outlook, for any sector.** Up to three `searchAllDocuments` calls, each with `filter: {"documentTypes": ["Outlook"], "publishDate": {"mode": "range", "from": <13 months ago>, "to": <today>}, "penalizeOlderResearch": true}` and `chunks: 1`. Stop at the first call that returns an outlook whose title names this sector, and work from that call's results:
   - keywords "<sector> outlook", with `sectors: [<the sector>]` and `regions: [<the region>]`;
   - the same without `sectors`: Moody's sector labels do not always match the user's word, and the keywords still carry it;
   - the first call again without `regions`: many sector outlooks are global.

   Take the most recent outlook for this sector and ignore other sectors. Where that call's results hold more than one for the sector (regulated and unregulated utilities, for example), report each that covers names on the list; do not search again for the others, say which was not returned. Give its title, its own scope ("Global", "Europe") and its date. Never present an outlook for another region as the outlook for these names. If none of the three calls returns one, write "the search returned no Moody's outlook for <sector>".

To add a sector for good, copy `sectors/telecoms.md`, replace the tables, and test the financials call once.

## Rules that apply to every sector

- A metric missing for a name is "not in Moody's data" (tone `nodata`). It is left out of rankings and medians.
- Always show the period next to the value. Bank data is often one quarter behind reported results.
- A threshold is shown only when the regulation, the regulator's document, a Moody's document or the company's own filing states it. Cite that document, with its date. Never build one from its parts.
