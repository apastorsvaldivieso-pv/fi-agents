# Earnings for credit

An earnings preview or recap for one issuer, set against its Moody's upgrade and downgrade triggers.

This folder is complete on its own. It does not need the other two agents.

## Install

Install `earnings-credit.plugin` in the Claude app (Settings, Plugins, add from file). It appears as `moodys-earnings-credit`.

## It needs

The Moody's Credit connector. No web search.

## What to type

- "Earnings recap for Vodafone."
- "Earnings preview for BNP Paribas."

## What you get

The answer in the chat, with a reference number on every figure and rating and a short source list. If the session has a folder to write to, it also saves the run and rebuilds an optional dashboard page; if not, it says so in one line and the answer is the same.

## What is in `plugin/`

- `skills/earnings-credit/SKILL.md`: the agent's steps.
- `skills/earnings-credit/shared/`: its own copy of the four sets of shared rules (names and lists, source rules, sector facts, the answer and dashboard scripts).

To change the agent, edit the master in `plugin/skills/` at the top of the project and run `python3 tools/build_agents.py`.
