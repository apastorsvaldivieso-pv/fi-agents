# Reading transcripts and filings

Both come from `searchCompanyFilings`. Each call returns long text, often too long to show, in which case it is saved to a file: search that file for the terms you need, do not read it whole. Ignore the `url` field; it expires in minutes.

## The call transcript

- Identify the call by `headline` and `eventDate`. The fiscal year and quarter labels can be wrong. Latest means the most recent event date.
- "Ingesting" means wait: retry the same call about every 30 seconds, up to eight times. If it is still ingesting, finish the rest and tell the user to run again in a few minutes.
- "Not found" means Moody's has no transcript for this issuer. If the answers switch between "ingesting" and "not found", treat it as not found once the retries are used up.
- One transcript query in a preview, two in a recap. If the excerpts do not contain a figure, look for it in the filing. If it is in neither, say so; do not search again for it.

## The results filing

- The call returns the latest interim report and the latest annual report Moody's holds. Tell them apart by `metadata.reportType`, and date them by `metadata.reportingPeriodEndDate` and the dates in the text itself. `metadata.submissionDate` is often just the period end, so give the period, and a publication date only if the text states one. The year and quarter in the title can be wrong (Vodafone's half-year report of 10 Nov 2026 is titled "Interim Report 2026 - Q4").
- Use the report that covers the results being recapped, and state its period and date. If the latest results are full-year results, that is the annual report.
- The latest "interim" filing can be a routine notice (a buyback or a director's shareholding) and not a results report. If so, use the other report and say so.
- If the report is older than the results the call discussed, say so, and take from it only what still holds (maturities, facilities), each with its date.
- Net debt: give the figure, the comparison the report itself makes (for example against the last year-end) and every driver it names, including those that reduce net debt, so the movement adds up. This is the company's own measure, not Moody's-adjusted debt.
- **Every figure you take from a filing must be findable in the saved result.** Search the file for the number itself before using it. A profit, loss or operating profit you cannot find there, on a line that says what it is, is not used: say it was not found.
- Profit or loss: give the profit or loss for the period and the amount attributable to owners where the report gives both, each with last year's figure, and say which is which.
- Guidance, impairments and legal matters: take the ranges from the report's outlook section (old and new), the impairment's size and what it relates to from its note, and any ruling on a deal from the legal or contingent liabilities note. If a search of the saved result does not find one of these, say which.
- Cite a filing as a Moody's source: tool `searchCompanyFilings`, the report's title, its period and submission date, and the page number where the row gives one.
