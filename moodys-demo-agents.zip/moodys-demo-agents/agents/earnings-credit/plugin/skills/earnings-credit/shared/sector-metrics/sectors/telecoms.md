# Telecoms

Checked live on 15 Nov 2026 on Vodafone Group Plc.

## Financials call

`getEntityFinancials_v2`, all names in one call, with:

```json
{ "filterCriteria": { "sections": ["key_indicators"], "reportingBasis": "adjusted" } }
```

Returns Moody's-adjusted key indicators for the latest fiscal year: Revenue, EBITDA, Total Debt, Debt / EBITDA, RCF / Net Debt, (EBITDA - CAPEX) / Interest Expense, EBIT Margin %. Read the period end from the response; fiscal years differ (Vodafone's ends in March).

These are Moody's-adjusted figures. Company-reported net debt to EBITDAaL from a results call is a different measure and must not be compared with them as if it were the same.

## Triggers

`getCreditOpinion` with sections `FactorsLeadingToUpgrade`, `FactorsLeadingToDowngrade`, `RatingOutlook`, `KeyIndicatorsTable`. Telecom triggers are usually numeric, on Moody's-adjusted debt / EBITDA and RCF / net debt. The key indicators table often carries Moody's forecasts for the next years (columns ending in F).

Distance to a trigger is the latest adjusted value against the stated level, for example "3.25x against a downgrade trigger of 3.3x: 0.05x of room".

## Channel map

| Channel | Metric | Weak end of the ranking |
|---|---|---|
| Spectrum fees, coverage obligations, network security rules (capex) | (EBITDA - CAPEX) / Interest Expense | lowest |
| Wholesale and retail price regulation, roaming and termination rates (earnings) | Debt / EBITDA | highest |
| Anything that adds debt or cuts cash flow | RCF / Net Debt | lowest |
| Merger control, market structure, consumer rules | no single metric | no call: `watch` |

A stated threshold is the issuer's own downgrade trigger from its credit opinion. Use it only if you fetched that opinion.

## Outlook lookup

`searchAllDocuments` with keywords "telecommunications outlook", `filter: {"documentTypes": ["Outlook"], "sectors": ["Telecommunications"], "publishDate": {"mode": "range", "from": <13 months ago>, "to": <today>}, "penalizeOlderResearch": true}`, `chunks: 1`. Leave the region out: the sector outlook is global. Take the most recent telecommunications outlook by date and ignore outlooks for other sectors in the results.

## What to watch in results

Service revenue growth by main market, EBITDA (after leases where reported), capex and capital intensity, free cash flow, net debt and the company's own leverage target, liquidity and upcoming maturities, spectrum payments, disposals and M&A, dividends and buybacks.

## Regulator sites (primary sources only)

berec.europa.eu, digital-strategy.ec.europa.eu, competition-policy.ec.europa.eu, ofcom.org.uk, gov.uk (Competition and Markets Authority), bundesnetzagentur.de, arcep.fr, cnmc.es, agcom.it.
