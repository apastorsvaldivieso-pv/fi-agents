# Run file shape

One JSON object per run. The dashboard shows whatever is here and nothing else.

```json
{
  "schema": "fi-dashboard/1",
  "agent": "reg-watch",
  "title": "Regulatory watch",
  "updated_at": "2026-11-15T14:05:00Z",
  "scope": { "sector": "Banks", "region": "Europe", "window": "7 days to 15 Nov 2026", "names": 15 },
  "status": "ok",
  "headline": "One sentence: the single most important thing in this run.",
  "headline_src": ["s2"],
  "sections": [
    { "title": "What changed", "type": "items", "items": [
      { "flag": "NEW", "tag": "Consultation", "name": "Basel Committee",
        "text": "What happened, in one or two sentences.",
        "why": "What it means for the credit view.",
        "src": ["s1"] } ] },
    { "title": "Who it hits", "type": "table",
      "columns": ["Name", "CET1", "Call"],
      "rows": [ ["BNP Paribas", { "v": "12.97%", "src": ["s2"] }, { "tone": "weaker", "v": "" }] ],
      "note": "Out of scope: ...", "note_src": [] },
    { "title": "Note", "type": "text", "text": "A short paragraph.", "src": [] }
  ],
  "sources": [
    { "id": "s1", "kind": "web", "title": "Page title", "date": "2026-11-10", "url": "https://www.bis.org/..." },
    { "id": "s2", "kind": "moodys", "tool": "getEntityFinancials_v2",
      "ref": "Common Equity / Core Tier 1 ratio (as reported), Q2 2026", "title": "BNP Paribas financials",
      "date": "2026-06-30", "url": "https://..." }
  ],
  "unresolved": [ { "name": "Zzyzx Holdings", "reason": "no match in Moody's" } ],
  "notes": [ "Footnotes shown once at the bottom of the tab." ],
  "meta": { "calls": { "moodys": 6, "web": 4 } }
}
```

Required: `agent`, `title`, `updated_at`, `headline`, `sections`, `sources`. Everything else is optional; include `scope` so the reader knows what the run covered.

## Rules the build script enforces

- `agent` is the tab's id: lowercase letters, digits and hyphens. `title` is the tab's label.
- `updated_at` is the moment you write the file, in UTC.
- A source's `date` is the date of the data itself: the period end for financials, the publication date for a document or page, the event date for a call.
- If the headline contains a figure, list its sources in `headline_src`.
- `status` is `ok` or `quiet`. A quiet run is the headline alone, with `sections` empty.
- Section `type` is `items`, `table` or `text`.
- A table cell is plain text, or `{ "v": text, "src": [...], "tone": ... }`. `tone` draws a labelled marker: `least` (Least headroom), `most` (Most headroom), `weaker` (Weaker third), `stronger` (Stronger third), `middle` (Middle), `watch`, `nodata`.
- A table can carry a `note`, one line shown under it, with `note_src` if it holds a figure.
- Every id in a `src` list must exist in `sources`.
- A Moody's source names the `tool` that returned it and a `ref`: document ID, or field name and period, or call title and date. A web source has a `url`.
- **Any figure (a percentage, a multiple, basis points, money, a decimal) must sit in an item or cell that has a `src`, or carry the word UNSOURCED.** Otherwise the file is rejected.
- A rating without a source is reported as a warning. Fix it.

## Optional fields

- `scope.label`: shown first in the scope line and in the run picker, for example "Vodafone, recap".
- `flag` on an item: a short marker such as NEW.
- `name` and `tag` on an item: small labels before the text.
- `order` (a number): where the tab sits. Without it, the three credit agents come first.

Earlier runs are kept automatically. The tab offers a picker with the eight most recent runs, so a preview and a recap, or two sectors, can sit side by side.
