#!/usr/bin/env python3
"""Turn one checked run file into the answer the user reads in the chat.

    python3 answer.py path/to/run.json                 print the answer (Markdown)
    python3 answer.py path/to/run.json --out answer.md also save it

The run file is checked first, with the same rules as the dashboard build. A file with
errors prints the errors and exits 1: fix the run file and run this again. Do not write
the answer around a failed check.

    python3 answer.py path/to/run.json --max-words 1300   only when the user asked for a wider window or a longer list

Every figure and rating in the answer carries a reference number, and the numbers point
to a short source list at the end. The answer has to read in about two minutes: it is
refused, with the longest parts named, if it runs past the word limit (600 before the
notes and sources by default), or if a headline, an item or a table note is too long. Pulls that are the same for many names (ratings, one
financial field for a list of banks) share one number, so the list stays short.
The answer does not depend on the dashboard: this script reads one file and writes text.
Standard library only.
"""
import argparse, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_dashboard as bd

TONES = {"least": "Least headroom", "most": "Most headroom", "weaker": "Weaker third", "stronger": "Stronger third",
         "middle": "Middle", "watch": "Watch", "nodata": "No data",
         "exposed": "Exposed", "neutral": "Neutral", "resilient": "Resilient"}
GROUP_ALL = {"getEntityRatings": "Moody's ratings"}                 # one number for every name's rating pull
GROUP_BY_REF = {"getEntityFinancials_v2": "Moody's financials"}     # one number per field and period
NOTE_BUDGET, NOTE_TRIM = 900, 220
TITLE_MAX, REF_MAX = 80, 90
MAX_WORDS, MAX_HEADLINE, MAX_ITEM, MAX_TABLE_NOTE = 600, 60, 70, 80


def words(text):
    """Words a reader reads: no table bars, no separator rows, no reference marks."""
    text = re.sub(r"\[\d+\]", " ", str(text))
    return len([w for w in re.sub(r"[|]", " ", text).split() if not re.fullmatch(r"[-:*]+", w)])


def body_of(answer):
    """The part of an answer before its notes and its source list."""
    out = []
    for line in answer.splitlines():
        if re.match(r"^\W*(notes|sources)\W*$", line.strip(), re.I):
            break
        out.append(line)
    return "\n".join(out)


def too_long(run, answer, limit):
    """Return a list of length problems, longest parts first. Empty means it reads in about two minutes."""
    parts, problems = [], []
    if words(run.get("headline", "")) > MAX_HEADLINE:
        problems.append("headline is %d words; keep it to %d" % (words(run["headline"]), MAX_HEADLINE))
    for sec in run.get("sections", []):
        title = clean(sec.get("title"))[:50]
        if sec.get("type") == "items":
            for i, it in enumerate(sec.get("items", [])):
                n = words(" ".join(str(it.get(k, "")) for k in ("text", "why")))
                parts.append((n, "%s, item %d" % (title, i + 1)))
                if n > MAX_ITEM:
                    problems.append("%s, item %d is %d words with its 'why'; keep an item to %d" % (title, i + 1, n, MAX_ITEM))
        elif sec.get("type") == "table":
            parts.append((sum(words(c.get("v", "") if isinstance(c, dict) else c) for row in sec.get("rows", []) for c in row), "%s, table cells" % title))
            if sec.get("note"):
                n = words(sec["note"])
                parts.append((n, "%s, table note" % title))
                if n > MAX_TABLE_NOTE:
                    problems.append("%s: the table note is %d words; keep it to %d" % (title, n, MAX_TABLE_NOTE))
        else:
            parts.append((words(sec.get("text", "")), "%s, text" % title))
    total = words(body_of(answer))
    if total > limit:
        top = "; ".join("%s (%d)" % (name, n) for n, name in sorted(parts, reverse=True)[:5])
        problems.insert(0, "the answer is %d words before notes and sources; the limit is %d. Longest parts: %s" % (total, limit, top))
    return problems


def cut(text, n):
    text = clean(text)
    return text if len(text) <= n else text[:n].rsplit(" ", 1)[0] + " …"


def clean(text):
    return re.sub(r"\s+", " ", str(text if text is not None else "")).strip()


def short_name(title):
    return re.sub(r"\s*[-:]?\s*(rating history|financials|financial statements)\s*$", "", clean(title), flags=re.I)


class Refs:
    """Numbers sources in the order the answer first cites them, sharing a number within a group."""

    def __init__(self, sources):
        self.by_id = {s["id"]: s for s in sources}
        self.number, self.members = {}, {}

    def key(self, s):
        tool = s.get("tool")
        if s.get("kind") == "moodys" and tool in GROUP_ALL:
            return ("all", tool)
        if s.get("kind") == "moodys" and tool in GROUP_BY_REF:
            return ("ref", tool, clean(s.get("ref")), clean(s.get("date")))
        return ("one", s["id"])

    def cite(self, ids):
        out = []
        for sid in ids or []:
            s = self.by_id.get(sid)
            if not s:
                continue
            k = self.key(s)
            if k not in self.number:
                self.number[k] = len(self.number) + 1
                self.members[k] = []
            if s not in self.members[k]:
                self.members[k].append(s)
            if self.number[k] not in out:
                out.append(self.number[k])
        return "".join("[%d]" % n for n in sorted(out))

    def lines(self):
        out = []
        for k, n in sorted(self.number.items(), key=lambda kv: kv[1]):
            group = self.members[k]
            s = group[0]
            if k[0] in ("all", "ref"):
                label = (GROUP_ALL if k[0] == "all" else GROUP_BY_REF)[s["tool"]]
                names = [short_name(x.get("title")) for x in group]
                who = ", ".join(names) if len(names) <= 4 and all(len(n) <= 40 for n in names) else ("%d names" % len(names) if len(names) > 4 else "")
                dates = sorted({clean(x.get("date")) for x in group if x.get("date")})
                parts = ["%s (%s)" % (label, s["tool"]), cut(s.get("ref"), REF_MAX) if k[0] == "ref" else "", who,
                         dates[-1] if dates else ""]
            elif s.get("kind") == "web":
                parts = ["Web", cut(s.get("title"), TITLE_MAX), clean(s.get("date")), clean(s.get("url"))]
            else:
                ref = clean(s.get("ref"))
                if " " not in ref and len(ref) > 24:
                    ref = ""                     # an internal article number tells the reader nothing
                parts = ["Moody's (%s)" % s["tool"] if s.get("tool") else "Moody's", cut(s.get("title"), TITLE_MAX),
                         cut(ref, REF_MAX) if ref and ref.lower() not in clean(s.get("title")).lower() else "", clean(s.get("date"))]
            out.append("[%d] %s" % (n, " · ".join(p for p in parts if p)))
        return out


def with_refs(text, marks):
    text = clean(text)
    return (text + " " + marks).strip() if marks else text


def render(run):
    refs = Refs(run.get("sources", []))
    sc = run.get("scope") or {}
    what = sc.get("label") or ", ".join(str(sc[k]) for k in ("sector", "region") if sc.get(k))
    detail = "; ".join(str(x) for x in (sc.get("window"), ("%s name%s" % (sc["names"], "" if str(sc["names"]) == "1" else "s")) if sc.get("names") is not None else None) if x)
    out = ["**%s%s**%s" % (clean(run.get("title")), (": " + what) if what else "", (" (%s)" % detail) if detail else ""), "",
           with_refs(run.get("headline"), refs.cite(run.get("headline_src"))), ""]
    for sec in run.get("sections", []):
        out.append("**%s**" % clean(sec.get("title")))
        out.append("")
        kind = sec.get("type")
        if kind == "items":
            for it in sec.get("items", []):
                lead = " ".join(x for x in (("[%s]" % clean(it["flag"])) if it.get("flag") else "",
                                            ("**%s**" % clean(it["name"])) if it.get("name") else "",
                                            ("(%s)" % clean(it["tag"])) if it.get("tag") else "",
                                            ("(%s)" % TONES.get(it["tone"], it["tone"])) if it.get("tone") else "") if x)
                body = clean(it.get("text"))
                if it.get("why"):
                    body += " *Why it matters:* " + clean(it["why"])
                out.append("- " + with_refs((lead + ": " if lead else "") + body, refs.cite(it.get("src"))))
        elif kind == "table":
            cols = [clean(c).replace("|", "/") for c in sec.get("columns", [])]
            out.append("| " + " | ".join(cols) + " |")
            out.append("|" + "---|" * len(cols))
            for row in sec.get("rows", []):
                cells = []
                for c in row:
                    c = c if isinstance(c, dict) else {"v": c}
                    label = TONES.get(c.get("tone"), c.get("tone") or "")
                    value = clean(c.get("v"))
                    if label and value.lower() == label.lower():
                        value = ""
                    if c.get("tone") == "nodata" and value:
                        label = ""               # the cell already says what is missing
                    cells.append(with_refs(" ".join(x for x in (label, value) if x), refs.cite(c.get("src"))).replace("|", "/"))
                out.append("| " + " | ".join(cells) + " |")
            if sec.get("note"):
                out += ["", "Note: " + with_refs(sec["note"], refs.cite(sec.get("note_src")))]
        else:
            out.append(with_refs(sec.get("text"), refs.cite(sec.get("src"))))
        out.append("")
    if run.get("unresolved"):
        names = "; ".join(u if isinstance(u, str) else "%s%s" % (u.get("name", ""), (" (%s)" % u["reason"]) if u.get("reason") else "")
                          for u in run["unresolved"])
        out += ["**Unresolved names:** %s. Not guessed, not included." % names, ""]
    notes = [clean(n) for n in run.get("notes", []) if clean(n)]
    if notes:
        long = sum(len(n) for n in notes) > NOTE_BUDGET
        out.append("**Notes**")
        out.append("")
        for n in notes:
            out.append("- " + (n if not long or len(n) <= NOTE_TRIM else n[:NOTE_TRIM].rsplit(" ", 1)[0] + " …"))
        if long:
            out.append("- Longer notes are cut here; they are in full in the saved run.")
        out.append("")
    src = refs.lines()
    if src:
        out.append("**Sources**")
        out.append("")
        out += src
    return "\n".join(out).rstrip() + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("run_json")
    ap.add_argument("--out", help="also save the answer to this file")
    ap.add_argument("--over-limit-ok", action="store_true",
                    help="let the answer run over the word limit and say so in one line (news brief only: a material item is never cut to fit)")
    ap.add_argument("--max-words", type=int, default=MAX_WORDS,
                    help="word limit before notes and sources (default %d; raise it only for a wider window or a longer list the user asked for)" % MAX_WORDS)
    args = ap.parse_args()
    try:
        run = bd.load(args.run_json)
        err, warn = bd.check_run(run)
    except (OSError, ValueError) as exc:
        err, warn = ["cannot read: %s" % exc], []
    if err:
        print(json.dumps({"file": args.run_json, "ok": False, "errors": err, "warnings": warn}, indent=1))
        return 1
    text = render(run)
    long = too_long(run, text, args.max_words)
    if long and args.over_limit_ok and all(p.startswith("the answer is") for p in long):
        total = words(body_of(text))
        line = "This brief runs over the two-minute limit (%d words against %d): no material item was cut to fit." % (total, args.max_words)
        marker = "\n**Notes**\n" if "\n**Notes**\n" in text else ("\n**Sources**\n" if "\n**Sources**\n" in text else None)
        text = text.replace(marker, "\n" + line + "\n" + marker, 1) if marker else text.rstrip() + "\n\n" + line + "\n"
        long = []
    if long:
        print(json.dumps({"file": args.run_json, "ok": False, "errors": long,
                          "fix": "Shorten the run file, not the facts: one or two sentences an item, drop a 'why' that repeats the fact, "
                                 "move detail to notes. Then run this again."}, indent=1))
        return 1
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text)
    sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
