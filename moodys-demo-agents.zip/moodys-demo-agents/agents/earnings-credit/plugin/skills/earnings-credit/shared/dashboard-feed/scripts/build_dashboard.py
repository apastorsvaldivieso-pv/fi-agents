#!/usr/bin/env python3
"""Check the saved run files and rebuild the dashboard from them.

    python3 build_dashboard.py --data dashboard/data --out dashboard/dashboard.html
    python3 build_dashboard.py --check path/to/run.json      (check one file, build nothing)

Each *.json file in --data is one agent's latest run and becomes one tab.
Earlier runs are kept in <data>/history/<agent>/; the tab's run picker offers the most recent eight.
Writes two files: <out> opens with a double-click; <out stem>.artifact.html is the same
page without the outer document tags, for publishing to the private Artifact link.
Prints a JSON summary. Exit code 1 means a run file broke a rule and was left out.
Standard library only.
"""
import argparse, datetime, json, os, re, shutil, sys

ORDER = ["sector-news-brief", "reg-watch", "earnings-credit"]
TONES = {"least", "most", "weaker", "stronger", "middle", "watch", "nodata",
         "exposed", "neutral", "resilient"}   # the last three: runs saved before the labels changed
KEEP_HISTORY = 8
# A figure a credit analyst would want to check: %, x multiples, bp, money, decimals.
METRIC = re.compile(r"(?<![A-Za-z0-9])(?:[€$£]\s?\d[\d,.]*|\d[\d,.]*\s?(?:%|pp\b|bps?\b|x\b|bn\b|billion\b|million\b|m\b|notch(?:es)?\b)|\d+\.\d+)")
RATING = re.compile(r"(?<![A-Za-z0-9])(?:Aaa|Aa[1-3]|A[1-3]|Baa[1-3]|Ba[1-3]|B[1-3]|Caa[1-3])(?![A-Za-z0-9])")
AGENT_ID = re.compile(r"^[a-z0-9][a-z0-9-]{1,40}$")


def text_units(run):
    """Yield (where, text, src) for every piece of displayed text that can carry a number."""
    yield "headline", run.get("headline", ""), run.get("headline_src", [])
    for si, sec in enumerate(run.get("sections", [])):
        where = "sections[%d] %r" % (si, sec.get("title", ""))
        kind = sec.get("type")
        if kind == "items":
            for ii, it in enumerate(sec.get("items", [])):
                yield "%s item %d" % (where, ii + 1), " ".join(str(it.get(k, "")) for k in ("text", "why")), it.get("src", [])
        elif kind == "table":
            for ri, row in enumerate(sec.get("rows", [])):
                for ci, cell in enumerate(row):
                    c = cell if isinstance(cell, dict) else {"v": cell}
                    yield "%s row %d col %d" % (where, ri + 1, ci + 1), str(c.get("v", "")), c.get("src", [])
            if sec.get("note"):
                yield "%s note" % where, str(sec["note"]), sec.get("note_src", [])
        else:
            yield where, str(sec.get("text", "")), sec.get("src", [])


def check_run(run):
    """Return (errors, warnings). Errors keep a run off the dashboard."""
    err, warn = [], []
    if not isinstance(run, dict):
        return ["file is not a JSON object"], warn
    for key in ("agent", "title", "updated_at", "headline", "sections", "sources"):
        if key not in run:
            err.append("missing field: %s" % key)
    if err:
        return err, warn
    if not AGENT_ID.match(str(run["agent"])):
        err.append("agent must be lowercase letters, digits and hyphens: %r" % run["agent"])
    try:
        datetime.datetime.fromisoformat(str(run["updated_at"]).replace("Z", "+00:00"))
    except ValueError:
        err.append("updated_at is not an ISO date-time: %r" % run["updated_at"])
    if run.get("status", "ok") not in ("ok", "quiet"):
        err.append("status must be ok or quiet")
    ids = set()
    for s in run["sources"]:
        if not isinstance(s, dict) or not s.get("id"):
            err.append("a source has no id"); continue
        if s["id"] in ids:
            err.append("duplicate source id: %s" % s["id"])
        ids.add(s["id"])
        if s.get("kind") not in ("moodys", "web"):
            err.append("source %s: kind must be moodys or web" % s["id"])
        if not (s.get("ref") or s.get("url")):
            err.append("source %s: needs a ref (document ID, field and period, call title and date) or a url" % s["id"])
        if s.get("kind") == "moodys" and not s.get("tool"):
            err.append("source %s: a Moody's source must name the tool that returned it" % s["id"])
    for si, sec in enumerate(run["sections"]):
        if sec.get("type") not in ("items", "table", "text"):
            err.append("sections[%d]: type must be items, table or text" % si)
        if sec.get("type") == "table":
            width = len(sec.get("columns", []))
            for ri, row in enumerate(sec.get("rows", [])):
                if len(row) != width:
                    err.append("sections[%d] row %d: %d cells for %d columns" % (si, ri + 1, len(row), width))
                for cell in row:
                    if isinstance(cell, dict) and cell.get("tone") and cell["tone"] not in TONES:
                        err.append("sections[%d]: unknown tone %r" % (si, cell["tone"]))
    used = set()
    for where, text, src in text_units(run):
        for sid in src or []:
            used.add(sid)
            if sid not in ids:
                err.append("%s: cites %r, which is not in sources" % (where, sid))
        if "UNSOURCED" in text or src:
            continue
        hit = METRIC.search(text)
        if hit:
            err.append("%s: figure %r has no source and is not marked UNSOURCED" % (where, hit.group(0)))
            continue
        hit = RATING.search(text)
        if hit:
            warn.append("%s: rating %r has no source" % (where, hit.group(0)))
    for sid in sorted(ids - used):
        warn.append("source %s is listed but never cited" % sid)
    if run.get("status") == "quiet" and run["sections"]:
        warn.append("a quiet run should be one line: headline only, no sections")
    return err, warn


def slug(text):
    return re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")[:60] or "run"


def scope_key(run):
    sc = run.get("scope") or {}
    return slug(" ".join(str(sc.get(k, "")) for k in ("label", "sector", "region")))


def load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default="dashboard/data")
    ap.add_argument("--out", default="dashboard/dashboard.html")
    ap.add_argument("--check", metavar="RUN_JSON", help="check one run file and stop")
    args = ap.parse_args()

    if args.check:
        try:
            err, warn = check_run(load(args.check))
        except (OSError, ValueError) as exc:
            err, warn = ["cannot read: %s" % exc], []
        print(json.dumps({"file": args.check, "ok": not err, "errors": err, "warnings": warn}, indent=1))
        return 1 if err else 0

    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "..", "assets", "template.html"), encoding="utf-8") as fh:
        template = fh.read()

    os.makedirs(args.data, exist_ok=True)
    summary, tabs, failed = {"tabs": [], "left_out": []}, [], False
    for name in sorted(os.listdir(args.data)):
        if not name.endswith(".json"):
            continue
        path = os.path.join(args.data, name)
        try:
            run = load(path)
            err, warn = check_run(run)
        except (OSError, ValueError) as exc:
            run, err, warn = None, ["cannot read: %s" % exc], []
        if err:
            failed = True
            summary["left_out"].append({"file": name, "errors": err})
            continue
        agent = run["agent"]
        hist_dir = os.path.join(args.data, "history", agent)
        os.makedirs(hist_dir, exist_ok=True)
        stamp = re.sub(r"[^0-9]", "", str(run["updated_at"]))[:14]
        copy = os.path.join(hist_dir, "%s__%s.json" % (stamp, scope_key(run)))
        if not os.path.exists(copy):
            shutil.copyfile(path, copy)
        # Latest run first, then the most recent earlier runs, newest first.
        runs = [run]
        for old in sorted(os.listdir(hist_dir), reverse=True):
            if len(runs) >= KEEP_HISTORY or not old.endswith(".json") or old == os.path.basename(copy):
                continue
            try:
                prev = load(os.path.join(hist_dir, old))
            except (OSError, ValueError):
                continue
            if check_run(prev)[0]:
                continue
            runs.append(prev)
        tabs.append({"agent": agent, "title": run["title"], "order": run.get("order"), "runs": runs})
        summary["tabs"].append({"agent": agent, "updated_at": run["updated_at"], "runs_shown": len(runs), "warnings": warn})

    def rank(tab):
        if isinstance(tab["order"], (int, float)):
            return (0, tab["order"], tab["agent"])
        return (1, ORDER.index(tab["agent"]) if tab["agent"] in ORDER else len(ORDER), tab["agent"])
    tabs.sort(key=rank)

    built = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    payload = json.dumps({"built_at": built, "tabs": tabs}, ensure_ascii=False, separators=(",", ":"))
    payload = payload.replace("</", "<\\/").replace("<!--", "<\\!--")   # the data carries text from the web
    head, body = template.split("<!--BODY-->", 1)
    body = body.replace("__FI_DATA__", payload)
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
                 '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
                 + head + "</head>\n<body style=\"margin:0\">\n" + body + "</body>\n</html>\n")
    artifact = os.path.splitext(args.out)[0] + ".artifact.html"
    with open(artifact, "w", encoding="utf-8") as fh:
        fh.write(head + body)
    summary.update({"ok": not failed, "built_at": built, "file": args.out, "artifact_file": artifact})
    print(json.dumps(summary, indent=1))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
