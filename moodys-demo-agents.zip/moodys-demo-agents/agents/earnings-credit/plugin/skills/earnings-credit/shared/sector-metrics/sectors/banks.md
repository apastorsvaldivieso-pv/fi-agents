# Banks

Checked live on 15 Nov 2026 against 15 European banks in one call.

## Financials call

`getEntityFinancials_v2`, all names in one call, with:

```json
{ "filterCriteria": {
    "periods": ["LQ"],
    "accountNames": [
      "Common Equity / Core Tier 1 ratio (as reported)",
      "Basel III leverage ratio - Fully loaded",
      "Basel III Liquidity Coverage Ratio (LCR) (as reported)",
      "Basel III Net Stable Funding Ratio (NSFR) (as reported)",
      "Impaired loans / Gross customer loans & advances",
      "Loan loss reserves / Impaired loans",
      "Gross loans and advances to customers / Customer deposits",
      "Risk weighted asset intensity (RWA / Total Assets)"
    ] } }
```

`LQ` is the latest quarter Moody's holds. Read the period from the response and show it.

Always send the full field list above, even if the run needs two of them. With a shorter list, `LQ` came back as a quarter from 2018 for UBS. If one name's period differs from the others' (older, or newer, as with a group record that reports a quarter ahead), ask for that name again with the explicit period the others returned (for example `"periods": ["Q2 2026"]`). If it still differs, show it with its period and leave it out of rankings and medians.

Known gaps: the leverage ratio is missing for about a third of large banks. There is no MREL or TLAC field, and no field for a bank's capital requirement. Banco Santander's rated record returns no financials.

## Channel map

| Regulatory channel | Metric (short name) | Weak end of the ranking | Stated requirement |
|---|---|---|---|
| Capital requirements, buffers (including G-SIB and O-SII buffers) | CET1 ratio | lowest | Firm-specific: the bank's own stated requirement, in `banks-scope.md` |
| Leverage | Leverage ratio (fully loaded) | lowest | 3% |
| Liquidity | LCR | lowest | 100% |
| Stable funding | NSFR | lowest | 100% |
| Provisioning, asset quality | Impaired loans / gross loans | highest | none |
| Provisioning, asset quality | Reserves / impaired loans | lowest | none |
| Funding mix, deposits | Loans / deposits | highest | none |
| Risk weights, internal models, output floor | RWA / total assets | lowest (most reliant on models) | none |
| MREL, TLAC, resolution | no field | no call: `watch` | |
| Governance, reporting, stress testing, large exposures, interest rate risk in the banking book, securitisation, conduct, AML, operational resilience | no field | no call: `watch` | |

A rule that changes how a buffer or requirement is calculated (for example how G-SIB scores are measured) belongs to that buffer's row.

## Scope and requirements

Which banks a rule covers, and what each bank's capital is measured against, are in `banks-scope.md` in this folder: the FSB's G-SIB list, the home supervisor by country, and each bank's own stated CET1 requirement with its date and filing. Read it whenever an item maps to a metric or names a group of banks.

The 3% and 100% minimums are the Basel III standards. Cite them as a web source: "Basel Framework (LEV, LCR, NSF standards)", `https://www.bis.org/basel_framework/`. Local rules can be higher; say so in the footnote. Distance to a minimum is the value minus the minimum, in percentage points.

## Outlook lookup

`searchAllDocuments` with keywords "banks outlook", `filter: {"documentTypes": ["Outlook"], "sectors": ["Banking"], "regions": ["Europe"], "publishDate": {"mode": "range", "from": <13 months ago>, "to": <today>}, "penalizeOlderResearch": true}`, `chunks: 1`.

Moody's publishes a global banks outlook each December and country banking system outlooks through the year, not one European outlook. Report the most recent global outlook, and the country outlooks for the countries in the coverage list, each with its date.

## What to watch in results

Net interest income and margin, cost of risk, CET1 and planned distributions, problem loans, costs, liquidity and deposit trends. Bank upgrade and downgrade triggers in Moody's credit opinions are mostly worded, not numeric.

## Regulator sites (primary sources only)

bis.org (Basel Committee), eba.europa.eu, bankingsupervision.europa.eu (ECB), srb.europa.eu, finance.ec.europa.eu (European Commission), bankofengland.co.uk (PRA), finma.ch.

Listings and feeds that returned dated entries to a plain page fetch on 15 Nov 2026. Open these to read off what was published in the window; some regulators' ordinary news pages are filled in by script and come back empty.

| Regulator | Listing or feed |
|---|---|
| Basel Committee | `https://www.bis.org/committees/bcbs/news` and `https://www.bis.org/committees/bcbs/publications` |
| EBA | `https://www.eba.europa.eu/publications-and-media/press-releases` |
| ECB Banking Supervision | `https://www.bankingsupervision.europa.eu/rss/press.html` and `https://www.bankingsupervision.europa.eu/rss/pub.html` |
| SRB | `https://www.srb.europa.eu/en/news` |
| European Commission | `https://finance.ec.europa.eu/news_en` |
| PRA | `https://www.bankofengland.co.uk/rss/prudential-regulation-publications` |
| FINMA | `https://www.finma.ch/en/rss/news/` |

If one of these stops working, find the regulator's current listing by search and say so in a note. Links inside the Basel Committee's listing are relative to the site root: the page is at `https://www.bis.org` followed by the link as given, for example `https://www.bis.org/publications/<name>`. Do not guess an address.
