# Banks: scope facts and stated requirements

Checked on 15 Nov 2026. Three sets of facts that Moody's financial data does not carry. Each has a source and a date; show both when you use one.

## 1. G-SIBs: the FSB list

Source (web): Financial Stability Board, "2025 List of Global Systemically Important Banks (G-SIBs)", 27 Nov 2025, `https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/`. The next list is due in November 2026; if the FSB has published it, use the new one and say so. Checking costs one search on fsb.org, on top of the regulator searches.

The list is exhaustive: **a bank that is not on it is not a G-SIB.** All 29, by bucket:

- Bucket 4: JP Morgan Chase
- Bucket 3: Bank of America, Citigroup, HSBC, Industrial and Commercial Bank of China
- Bucket 2: Agricultural Bank of China, Bank of China, Barclays, BNP Paribas, China Construction Bank, Goldman Sachs, Groupe Crédit Agricole, Mitsubishi UFJ FG, UBS
- Bucket 1: Bank of Communications, Bank of New York Mellon, Deutsche Bank, Groupe BPCE, ING, Mizuho FG, Morgan Stanley, Royal Bank of Canada, Santander, Société Générale, Standard Chartered, State Street, Sumitomo Mitsui FG, Toronto Dominion, Wells Fargo

The list names groups. Crédit Agricole S.A. is inside Groupe Crédit Agricole, and Banco Santander is "Santander": treat them as G-SIBs. A subsidiary of a listed group is covered through its group, not in its own right.

Two things an analyst will check:
- A rule on how G-SIB scores are measured is reported on by every bank in the Basel Committee's assessment sample, a wider group set by size. Its capital effect, the G-SIB buffer, falls only on the banks on the list. On the capital channel, the names covered are the banks on the list; say both facts in the table's note.
- A rule for G-SIBs of one region covers only the listed banks headquartered there. Banking-union G-SIBs on the checked list: BNP Paribas, Crédit Agricole, Société Générale, Deutsche Bank, ING.
- A measure about the treatment of one region, on a page that names no addressees, is read as a rule for that region's G-SIBs; say in the note that this is our reading. The case on file: the Basel Committee's consultation of 16 Oct 2026 on the G-SIB methodology (whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the framework; its page names no addressees). It covers the five banking-union G-SIBs above. It is never named in the heading of a table that ranks HSBC, Barclays or UBS: it gets a table of its own for those five, or a line in the note.

## 2. Home supervisor, from the bank's country

| Country of the group | Prudential supervisor | Rules that apply at home |
|---|---|---|
| Banking union: AT, BE, BG, CY, DE, EE, ES, FI, FR, GR, HR, IE, IT, LT, LU, LV, MT, NL, PT, SI, SK | ECB Banking Supervision (directly, for significant institutions) | EU law, EBA, ECB, SRB |
| Other EU and EEA: CZ, DK, HU, PL, RO, SE, IS, LI, NO | the national supervisor | EU law, EBA |
| GB | PRA | PRA rules |
| CH | FINMA | FINMA rules |

Which names a rule covers, by who issued it:

| Issued by | Covers |
|---|---|
| Basel Committee | Every bank on the list, once its home country applies the standard. If the standard is for G-SIBs, only the banks in section 1 |
| EBA, European Commission, EU legislation | Banks whose group is in the EU or EEA |
| ECB Banking Supervision, SRB | Banks whose group is in the banking union |
| PRA | Banks whose group is in GB |
| FINMA | Banks whose group is in CH |

All eleven banking-union banks on the checked list are significant institutions supervised directly by the ECB. For a banking-union bank outside the checked list, an item addressed only to significant institutions is "scope not known".

## 3. Each bank's own stated CET1 requirement

Pulled once, on 15 Nov 2026, from the banks' filings as held in Moody's (`searchCompanyFilings`, interim and annual). Each figure is the total the bank itself states, buffers included, under the name the bank gives it. Nothing here was added up from Pillar 1, Pillar 2 and buffers. The measures differ by regime (ECB banks: overall CET1 requirement or MDA trigger; UK banks: overall CET1 requirement; UBS: Swiss going-concern CET1 requirement), so say what each one is.

| Bank | Stated total CET1 requirement | What the bank calls it | Applies as of | Current | Filing held in Moody's |
|---|---|---|---|---|---|
| UBS Group AG | 10.83% | Required going-concern CET1 capital | 30 Jun 2026 | yes | Second quarter 2026 report |
| UniCredit S.p.A. | 10.21% | CET1 overall capital requirement | 30 Jun 2026 | yes | First-half 2026 report |
| CaixaBank, S.A. | 9.12% | CET1 requirement (Pillar 1, Pillar 2 requirement and buffers) | 30 Jun 2026 | yes | Management report January to June 2026 |
| Intesa Sanpaolo S.p.A. | 9.96% | Overall requirement in terms of CET1 ratio | from 1 Jan 2026 | yes | Interim statement at 31 March 2026 |
| Banco Bilbao Vizcaya Argentaria, S.A. | 8.98% | Consolidated CET1 requirement | from 1 Jan 2026 | yes | Annual report on Form 20-F for 2025 |
| Societe Generale | 10.26% | CET1 requirement | shown against 31 Mar 2026 (the column itself is undated) | yes | First quarter 2026 results |
| Groupe Credit Agricole (measured in place of Credit Agricole S.A., see section 4) | total not stated. The group states its distance: 6.7 pp above the SREP requirement, on a phased-in CET1 of 17.1% | Distance to SREP requirement, phased-in CET1 | 31 Mar 2026 | yes, distance only | First quarter 2026 results slides, filed under Credit Agricole S.A. |
| BNP Paribas | 10.51% | CET1 capital requirement | 30 Sep 2025 | older | Third quarter 2025 report |
| Barclays PLC | 12.2% | Overall capital requirement for CET1, excluding any PRA buffer | 31 Dec 2025 | older | Annual report on Form 20-F for 2025 |
| ING Groep N.V. | 11.03% | MDA trigger level for CET1 | 31 Dec 2025 | older | Annual report on Form 20-F for 2025 |
| HSBC Holdings plc | not stated (only the Pillar 2A part is given) | | | | Annual report on Form 20-F for 2025 |
| Deutsche Bank AG | not stated (the table came back garbled and two passages disagree) | | | | Annual report on Form 20-F for 2025 |
| Lloyds Banking Group plc | not stated | | | | Annual report on Form 20-F for 2025 |
| Commerzbank AG | not stated | | | | Interim report at 30 June 2026 |
| Nordea Bank Abp | not stated (the annual report did not load; no 2026 interim report held) | | | | none usable |

Groupe Credit Agricole states a distance and no total. Show the group's own distance, marked "bank-stated, 31 Mar 2026", and do not work a requirement back from it. It counts as a current requirement for ranking. The slide's title did not come through from Moody's filings; it is identified as the group's by its CET1 of 17.1% and by the TLAC and MREL ratios beside it. Credit Agricole S.A.'s own figures, for the table note only: phased-in CET1 11.4% and 2.6 pp above its SREP requirement at 31 Mar 2026 (same slides).

How to use it:
- **Current** means the figure applies at a date in 2026. Only current figures count towards ranking by headroom.
- An **older** figure is still shown, with its date and the word "older", and a distance is still given for it.
- "Not stated" means the filings Moody's returned did not state a total. It does not mean the bank has no requirement.
- Cite a figure as a Moody's source: tool `searchCompanyFilings`, the filing named in the table, and the date it applies as of.
- A bank that is not in this table has no stated requirement here: show "not stated". Do not look one up on the web during a run.

Refresh this table each quarter, and each January when supervisors reset requirements.

## 4. Which record a bank is measured on

A rule is measured on the consolidated group it applies to. On the checked list, fourteen names are the top company of their group, and Moody's financials for them are the group's. The fifteenth is not:

- **Credit Agricole.** The G-SIB, and the group the ECB supervises, is Groupe Credit Agricole (the regional banks and Credit Agricole S.A. together). Moody's holds it as its own record, and the list entry carries it as `groupEntityId`. In every "who it hits" table, take the metrics from that record, at the same period as the other banks, and name the row "Groupe Credit Agricole". In the table's note, say that the issuer on the list is Credit Agricole S.A. and give its own value and period, and its own stated distance (section 3). Moody's credit opinion on Credit Agricole S.A. says its assessment is driven by the group on a consolidated basis.

A client's own names can have the same split. When a name is the central institution or listed arm of a co-operative or mutual group and the list gives it no `groupEntityId` (BPCE, Credit Mutuel and BFCM, DZ Bank, Raiffeisen Bank International and other Raiffeisen central banks, OP Corporate Bank, and similar):

- show its value and period in the table;
- leave it out of the ranking and the median, with "Not ranked: record may not be the consolidated group" in its Position cell;
- say the same in the table's note, naming the bank;
- do not search for a group record yourself. A record is added to a list by hand, after it has been checked.
