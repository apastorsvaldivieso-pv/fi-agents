#!/usr/bin/env python3
"""The running list of regulatory items for one sector and region.

    python3 items.py show --list dashboard/data/items/reg-watch-banks-europe.json --from 2026-11-08 --to 2026-11-15
    python3 items.py add  --list dashboard/data/items/reg-watch-banks-europe.json --from 2026-11-08 --to 2026-11-15 --found found.json

show   prints what the list already holds inside the window. Run it before searching.
add    merges the items in found.json into the list, saves it, and prints every item now
       on the list inside the window. An item is "new" only if the list did not hold it
       before this call. An item already on the list keeps its decision and its reason,
       so the same item is shown or left out the same way on every run.

found.json is a JSON array. Each item:
  { "url": "...", "body": "EBA", "title": "...", "published": "2026-11-05",
    "status": "final | consultation | other", "dates": "effective date or deadline, as the page states it",
    "channel": "...", "decision": "show | left out", "reason": "why, when left out",
    "page_confirmed": true, "same_as": "url of an entry already on the list, if this is the same publication" }

Standard library only.
"""
import argparse, datetime, json, os, re, sys
from urllib.parse import urlparse

FIELDS = ("body", "title", "published", "status", "dates", "channel")


def key(url):
    """One key per page: no scheme, no query, no trailing slash, no language folder."""
    u = urlparse(str(url).strip())
    path = re.sub(r"/+", "/", u.path).rstrip("/")
    path = re.sub(r"^/(en|de|fr|it)(/|$)", "/", path)              # finma.ch/de/... and /en/... are one page
    path = re.sub(r"_(en|de|fr|it)$", "", path)                     # ..._en on europa.eu
    return (u.hostname or "").lower().replace("www.", "") + path.lower()


def load(path):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    return {"about": "Running list of regulatory items found by reg-watch. Each run adds to it. "
                     "Edit a decision here by hand if you disagree with it; runs will then follow it.", "items": []}


def in_window(item, start, end):
    d = str(item.get("published", ""))[:10]
    return bool(d) and start <= d <= end


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("action", choices=["show", "add"])
    ap.add_argument("--list", required=True)
    ap.add_argument("--from", dest="start", required=True, help="first day of the window, YYYY-MM-DD")
    ap.add_argument("--to", dest="end", required=True, help="last day of the window, YYYY-MM-DD")
    ap.add_argument("--found", help="JSON file with the items found in this run (add only)")
    args = ap.parse_args()

    data = load(args.list)
    items = data["items"]
    index = {}
    for it in items:
        for k in [key(it["url"])] + [key(u) for u in it.get("also", [])]:
            index[k] = it
    new, problems = [], []

    if args.action == "add":
        if not args.found:
            ap.error("add needs --found")
        with open(args.found, encoding="utf-8") as fh:
            found = json.load(fh)
        now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for f in found:
            if not f.get("url") or not re.match(r"^\d{4}-\d{2}-\d{2}$", str(f.get("published", ""))):
                problems.append("skipped, needs a url and a published date as YYYY-MM-DD: %r" % (f.get("title") or f.get("url")))
                continue
            if f.get("decision") not in ("show", "left out"):
                problems.append("skipped, decision must be 'show' or 'left out': %r" % f.get("title"))
                continue
            if f["decision"] == "left out" and not f.get("reason"):
                problems.append("skipped, a left-out item needs a reason: %r" % f.get("title"))
                continue
            old = index.get(key(f["url"])) or (index.get(key(f["same_as"])) if f.get("same_as") else None)
            if old:                                     # known: keep the decision, fill gaps, note the extra address
                for k in FIELDS:
                    if f.get(k) and not old.get(k):
                        old[k] = f[k]
                if f.get("page_confirmed") and not old.get("page_confirmed"):
                    old["page_confirmed"] = True
                    for k in FIELDS:                    # a page now read beats a search result
                        if f.get(k):
                            old[k] = f[k]
                if key(f["url"]) != key(old["url"]) and f["url"] not in old.setdefault("also", []):
                    old["also"].append(f["url"])
                index[key(f["url"])] = old
                continue
            entry = {"url": f["url"], "first_seen": now, "page_confirmed": bool(f.get("page_confirmed")),
                     "decision": f["decision"], "reason": f.get("reason", "")}
            for k in FIELDS:
                entry[k] = f.get(k, "")
            items.append(entry); index[key(f["url"])] = entry; new.append(entry)
        items.sort(key=lambda it: (str(it.get("published", "")), it.get("body", ""), it.get("title", "")))
        os.makedirs(os.path.dirname(os.path.abspath(args.list)), exist_ok=True)
        with open(args.list, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=1, ensure_ascii=False)

    window = [it for it in items if in_window(it, args.start, args.end)]
    new_keys = {key(it["url"]) for it in new}
    out = {"list": args.list, "window": [args.start, args.end], "on_list_total": len(items),
           "show": [dict(it, new=key(it["url"]) in new_keys) for it in window if it["decision"] == "show"],
           "left_out": [{"title": it["title"], "body": it["body"], "published": it["published"], "reason": it["reason"], "url": it["url"]}
                        for it in window if it["decision"] == "left out"],
           "not_confirmed_on_page": [it["url"] for it in window if not it.get("page_confirmed")]}
    if args.action == "add":
        out["new_in_this_run"] = len(new)
        out["problems"] = problems
    print(json.dumps(out, indent=1, ensure_ascii=False))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
