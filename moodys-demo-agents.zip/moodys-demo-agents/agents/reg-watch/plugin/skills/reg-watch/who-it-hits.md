# Who it hits: scope, requirement, ranking, table

One table for each metric and set of names covered. Two items that hit the same metric and cover the same names share one table, and its title names both. Work through the four parts in order.

## 1. Scope: which names the rule covers

First read who the rule applies to in the regulator's own page or document, and say it in the table's note in the regulator's words. A title is not enough: a consultation inside a "G-SIB" package can apply to a narrower group. Then use the sector's scope facts (for banks, `shared/sector-metrics/sectors/banks-scope.md`). Two facts about a name decide scope:

- **Is it on a list the rule names?** Such lists are exhaustive. A bank that is not on the FSB's G-SIB list is not a G-SIB.
- **Who is its home supervisor?** Taken from its country.

Then:
- A name the rule covers goes in the table.
- A name it does not cover stays out of the table and is named in the table's `note`, with the reason: "Out of scope: A, B, C (not on the FSB G-SIB list of 27 Nov 2025)". Cite the list in `note_src`.
- Use "scope not known" only when those two facts cannot decide, for example a rule for firms above a size threshold, or for firms a supervisor names one by one. Name those in the note too and leave them out of the ranking.

**Which record.** A name whose list entry has `groupEntityId` is measured on that record: its row carries `groupName`, and the note names the issuer on the list with its own value. A name from a co-operative or mutual group with no `groupEntityId` is shown and not ranked. Both rules are in section 4 of the bank scope file.

This works the same for the user's own names: they need a country, nothing else. Scope is judged for the group at its home. A subsidiary supervised elsewhere is not counted; say so once in `notes` when it matters.

## 2. Requirement: what each name is measured against

- **The regulation sets one minimum for everyone** (LCR, NSFR, leverage ratio): that is every name's requirement. Cite it as the sector file says.
- **The requirement is firm-specific** (CET1): use the bank's own stated total requirement from the sector file's table, with its date and source. It is **current** if it applies at a date in this calendar year. Never add one up from Pillar 1, Pillar 2 and buffers.
- A bank with no figure in that table: "not stated". An older figure is shown with its date and the word "older", and is not used for ranking.
- **Distance** is the value minus the requirement, in percentage points. Show it in its own column for every name that has a requirement, current or older. Where the sector file holds only the bank's own stated distance, show that, marked "bank-stated" with its date.

## 3. Ranking: the names in scope that have a value

Pick the first case that fits:

| Case | When | Rank by | Markers (`tone`) |
|---|---|---|---|
| A | Every such name has the regulation's minimum, or at least six of them (the names in scope, not the whole list) have a current stated requirement | distance to requirement | `least`, `middle`, `most` |
| B | Otherwise, at least six have a value | the metric's level | `weaker`, `middle`, `stronger` |
| C | Fewer than six have a value | not ranked: rows in order of the value | none: write "list too short to rank" in Position and "not ranked" in the median column |

- With n ranked names, the n/3 (rounded down) at the weak end get the first marker, the n/3 at the strong end get the last, the rest `middle`. Names tied across a boundary are `middle`. The channel map says which end is weak.
- In case A, a name with no current requirement is not ranked: write "Not ranked: no current stated requirement" in its Position cell.
- A name with no value has the marker `nodata` and is not ranked.
- Never mix case A and case B markers in one table.

## 4. The table

- Title: "Who it hits: <rule or rules in a few words> (<body>, <date>) · <metric>". The title names only the measure, or measures, that the names in the table are right for. A measure from the same release that covers a different set of names is not in the title: it goes in the note, with the names it covers.
- Columns: Name, the metric with its period, vs median of the ranked names (percentage points), Stated requirement (with its date), Distance to requirement, Position.
- Rows: weakest or least headroom first.
- `note`: the names out of scope and why, then any "scope not known".
- Every value, requirement and distance cell carries its source. A requirement taken from the sector file is cited as a Moody's source with tool `searchCompanyFilings` and a `ref` that says where it came from: "bank sector file, pulled 15 Nov 2026: <filing>, as of <date>".
- The Position cell is the marker alone, for example `{ "tone": "weaker", "v": "" }`. If the table is ranked by level because too few names have a current requirement, say so in the `note`.

If any marker from case A or B was used anywhere in the run, add this footnote once in the run's `notes`, and nowhere else:

"Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact."
