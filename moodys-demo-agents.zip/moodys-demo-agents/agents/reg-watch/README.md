# Regulatory watch

What regulators published for a sector in a window, and which names on a list each measure covers, ranked on a Moody's metric where there is one.

This folder is complete on its own. It does not need the other two agents.

## Install

Install `reg-watch.plugin` in the Claude app (Settings, Plugins, add from file). It appears as `moodys-reg-watch`.

## It needs

The Moody's Credit connector and web search (it reads the regulators' own pages).

## What to type

- "Run the regulatory watch for European banks."
- "Run the regulatory watch for European banks for the last 30 days."
- "Regulatory watch, last 30 days, for these banks: HSBC, BNP Paribas, Deutsche Bank, UBS."

## What you get

The answer in the chat, with a reference number on every figure and rating and a short source list. If the session has a folder to write to, it also saves the run and rebuilds an optional dashboard page; if not, it says so in one line and the answer is the same.

## What is in `plugin/`

- `skills/reg-watch/SKILL.md`: the agent's steps.
- `skills/reg-watch/shared/`: its own copy of the four sets of shared rules (names and lists, source rules, sector facts, the answer and dashboard scripts).

To change the agent, edit the master in `plugin/skills/` at the top of the project and run `python3 tools/build_agents.py`.
