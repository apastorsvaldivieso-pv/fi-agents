# What is material, and how to report it

Read every article returned for a name against this list before writing its line. A brief that reports the good half of a set of results, or leaves out the week's largest deal, is worse than a short one.

## Checklist: anything here goes in

| Kind | Report |
|---|---|
| Results or a trading update | Fetch the figures with the skill's results step, then in full, as the source gives them: profit or loss, naming any impairment or one-off; the direction of revenue and EBITDA; the guidance change, old to new where given; leverage or net debt. For a bank: profit, CET1, and dividends or buybacks. Give the date the results came out, not the date of the call |
| Deals | Acquisitions, disposals, mergers, stake changes and offers: size, stake, and where it stands in the source's own words (agreed, pending, completed, under challenge). Funding and the effect on leverage if the source states them |
| Rulings and disputes | A court, regulatory or tax ruling or dispute with a stated amount, or one that puts a deal at risk |
| Funding | A benchmark bond, capital instruments (AT1, Tier 2), a liability exercise, a large facility, a risk transfer |
| Shareholder returns | Dividends and buybacks, with the amount |
| Management | A change of chief executive or finance chief |
| Moody's | Any rating action, outlook change, issuer comment or credit opinion update on the name in the window |
| Government measures | A levy, tax or rule aimed at the sector with a stated cost. Read the article for the amount before writing that none is stated |

The largest of these lead the Top items. The rest go in the name's line in the table.

## Not material

Share-price commentary, broker target changes, passive shareholding filings, tenders and small contract awards, marketing, awards, management changes below the two posts above, and stories about a subsidiary that do not touch the group's credit.

## An item that rests on one article

If an item on the checklist appears in only one article, or only in articles from aggregators and automated outlets, first try to confirm it: one `searchNews` call for that name with a `query` naming the event, in the window, `searchType: "hybrid"`. A company release, a regulator or a news wire in the results confirms it, and it is then reported like any other item. Results are confirmed by the results step in the skill, not here.

Only if that search confirms nothing: keep the item out of the Top items and mark it "single source, unconfirmed" in the name's line. If it looks like old news retold, leave it out and say so in a note.

## If the brief runs long

Cut in this order, and stop as soon as it fits:
1. Macro, down to one line.
2. Sector research on issuers outside the list.
3. Words in lines for names with nothing material.
4. A "why it matters" that only repeats its item.

Never cut an item on the checklist. If the brief is still over the limit, run the answer script with `--over-limit-ok`; it adds one line saying the brief runs over because nothing material was cut.
