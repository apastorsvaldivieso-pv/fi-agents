---
name: sector-news-brief
description: Daily credit news brief for one sector on Moody's data - the top three things that matter today, then macro, sector and one line per name, with Moody's rating actions, research and the latest sector outlook, and why each item matters for a credit analyst. Use when the user asks for a sector news brief, a morning or daily brief, "what happened in a sector", or news on a coverage list for a fixed income or credit team.
---

# Sector news brief

Inputs: **sector** (required), **names** (optional), **region** (default Europe).
Result: a brief a credit analyst reads in two minutes, saved as a run file and shown on the dashboard.

Follow `source-rules` throughout (`shared/source-rules/SKILL.md`).

## Steps

1. **Set the window.** The last 24 hours (weekends included); on a Monday, the last 72; or the window the user states. Searches cannot go past the present: if the user gives a date later than the clock, search to now and say so. Write down the start and end as UTC date-times and state them in `scope.window`, with the length in hours ("72h to 15 Nov 2026 13:00 UTC").

2. **Get the names** from `coverage-list` (`shared/coverage-list/SKILL.md`): the user's list if given, otherwise the saved or checked list for the sector and region.

3. **Collect, all in one step** (about 22 calls for 15 names, plus one or two for each name that reported in the window):
   - **News, one call per name**: `searchNews` with `entities: [{entityId, orgName, importance: "significance"}]`, `dateRange` set to the window, `maxResultsPerEntity: 8` (20 if the window is longer than 72 hours, or results and other events get crowded out), `sortBy: "recency"`. The tool takes one name per call. Do not use topic searches for company news; they return other regions and tenders. **For banks, a second call per name**, same entity and window, `query: "takeover offer merger acquisition stake bond AT1 dividend buyback levy ruling results"`, `keywordJoiner: "OR"`, `searchType: "hybrid"`, `rerankResults: true`, `maxResultsPerEntity: 10`: a large bank's first call returns mostly share filings, and its deals sit below them.
   - **Ratings**: `getEntityRatings`, up to 10 names per call, `years: 1`. Gives each name's rating, outlook and any action dated inside the window.
   - **Moody's rating actions**: `searchAllDocuments`, `documentTypes: ["Rating Action"]`, the sector and region, `publishDate` set to the window, `chunks: 1`.
   - **Moody's research**: the same call with `documentTypes: ["Sector Comment", "Sector In-Depth", "Issuer Comment", "Issuer In-Depth", "Issuer Profile", "Credit Opinion"]`. In the brief, name the kinds searched when the search returns nothing on the listed names.
   - **Latest sector outlook**: the outlook lookup in `sector-metrics` (`shared/sector-metrics/SKILL.md`). This one is not limited to the window; report its date.
   - **Macro**: one `searchNews` with a `query` that names the region's central banks and currency area (for Europe: "ECB Bank of England euro area inflation interest rates bond yields"), `searchType: "hybrid"`, `rerankResults: true`, the window, `contentType: ["headline"]`, `maxResultsPerEntity: 8`. A query without the region returns other regions.

4. **Decide what is material, with `materiality.md` in this folder.** Go through every name's results against its checklist: anything on it goes into that name's line, and results are reported in full, never only the favourable half. It also says how to treat an item that rests on a single article.

   **Results step.** Headlines rarely carry the figures. For each name whose headlines show results or a trading update published inside the window, make one more call for that name before writing: `searchNews` with the same entity, `query: "results net profit loss impairment guidance net debt leverage dividend"` (for a bank: "results net profit CET1 capital dividend buyback guidance"), `keywordJoiner: "OR"`, `searchType: "hybrid"`, `rerankResults: true`, the window, `contentType: ["headline", "body"]`, `maxResultsPerEntity: 5`. If the articles still lack the profit or loss, or the debt or capital figure, make one `searchCompanyFilings` call for the name, `filingTypes: ["earnings_call_transcript"]`, query "results, change to guidance, net debt and leverage" (company-reported; read it as `shared/reading-results.md` says). If the profit or loss for the period is still missing, one last call: `searchCompanyFilings`, `filingTypes: ["interim", "annual"]`, query "profit or loss for the period, impairment, net debt". Use the report only if its period is the one just reported, and give the profit or loss with the comparison the report makes. Name in the line whatever is still not returned ("leverage not in the sources returned"), and only after these calls and after searching the text you already hold for the figure.

   **Keep only credit news.** An item stays if it changes, or could change, leverage, cash flow, liquidity, funding access, ownership or M&A, regulation or litigation, management, or a rating or outlook. Drop share-price commentary, broker target changes, passive shareholding filings, tenders and small contract awards, marketing, awards, and stories about a subsidiary that do not touch the group's credit. Merge duplicates into one item. An article published inside the window about an event from before it is not new: drop it unless it adds a new fact, and if kept, give the event's date. Date every item by the event, from the source's text; if only an article's or a filing's date is known, write "reported on <date>" or "filed on <date>", never that date as the deal's. Use a figure only when the sentence that carries it names the company: a search also returns other companies' results. A figure for the name that appears in an article about something else may be used, quoted with its outlet ("a first-half loss of EUR 3.6bn, per ShareCast"); if two outlets differ, give both. Moody's research on an issuer outside the list belongs under Sector only if it says something about the sector, marked "not on the list".

5. **Second look, one step, only for what the brief will lead with:**
   - `getCreditOpinion` for the names in the Top items, all in one call, sections `FactorsLeadingToUpgrade`, `FactorsLeadingToDowngrade`, `RatingOutlook`: Moody's stated triggers and outlook, for the "why it matters" lines.
   - For a name whose ratings come back as under review: `searchAllDocuments` scoped to that name, `documentTypes: ["Rating Action"]`, most recent first, `chunks: 1`. Say which ratings are under review and in which direction, from that document: every rating it lists, or "all ratings" when it says so. If it does not say, write "ratings under review (Moody's does not show which in this pull)".
   - For banks, if the outlook lookup returned no outlook for a country on the list, search that country once ("<country> banking system outlook", `documentTypes: ["Outlook"]`, `regions: [<country>]`).

6. **Write the brief**, in this order:
   - **Top today** ("Top this week" or similar if the user set a longer window): up to three items, most important first. Fewer if fewer matter.
   - **Macro**: up to three lines.
   - **Sector**: Moody's actions and research in the window, then one line on the latest Moody's sector outlook with its date.
   - **By name**: a table with one row per name: name, rating with its class and outlook, and one line. A name with nothing material gets "No material credit news."; write "no news returned" only when the search returned nothing at all. A name with no current rating shows "not rated by Moody's" with tone `nodata`. Use no other tone markers in this skill.
   - Each Top item ends with why it matters for the credit view, in one sentence in which every fact has a source: Moody's trigger or outlook wording from step 5, a Moody's-adjusted figure, or a figure from the item's own article. If there is nothing sourced to add beyond the item itself, leave the line out.
   - Say what a search returned, not what exists: "the search returned no Moody's research on the listed names", not "there is none".
   - A material item is never dropped to fit the word limit. Cut other lines first, in the order `materiality.md` gives. If the brief is still over, give it with `--over-limit-ok`, which adds one line saying so.

7. **Quiet day.** If no name has material news and Moody's published no action or research on the sector in the window, the brief is one line: "Nothing material for <sector>, <region>, in the last <window>." Macro headlines alone do not make a day busy. Set `status: "quiet"`, leave `sections` empty; `sources` can be empty too. Do not fill the space with older news or the standing outlook.

8. **Answer, then dashboard.** Put the brief in the run-file shape (`agent: "sector-news-brief"`, `title: "Daily sector news"`) and give it to the user in the chat as "The answer" in `source-rules` says: every figure and rating numbered, sources at the end, a two-minute read. Then, last, hand the run to `dashboard-feed` (`shared/dashboard-feed/SKILL.md`). The dashboard never holds up the answer.

## What not to do

- Do not add upcoming earnings dates or upcoming Moody's publications. Moody's data has no forward calendar.
- Do not present news from outside the window as new.
- Do not write a "why it matters" that no source supports, and do not describe a deal, stake or rating in stronger words than the source uses.
- Do not call `getEntitySectorOutlook`.
- Do not give a view on the bonds or the shares.
