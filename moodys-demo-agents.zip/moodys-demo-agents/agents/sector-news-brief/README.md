# Sector news brief

A daily credit news brief for one sector on Moody's data: the top items, macro, sector and one line per name, with Moody's rating actions, research and the latest sector outlook.

This folder is complete on its own. It does not need the other two agents.

## Install

Install `sector-news-brief.plugin` in the Claude app (Settings, Plugins, add from file). It appears as `moodys-sector-news-brief`.

## It needs

The Moody's Credit connector. No web search.

## What to type

- "Run the sector news brief for European telecoms."
- "Run the sector news brief for European banks for the last 7 days."
- "Sector news brief for telecoms, last 72 hours, for: Vodafone, Orange, Telefonica."

## What you get

The answer in the chat, with a reference number on every figure and rating and a short source list. If the session has a folder to write to, it also saves the run and rebuilds an optional dashboard page; if not, it says so in one line and the answer is the same.

## What is in `plugin/`

- `skills/sector-news-brief/SKILL.md`: the agent's steps.
- `skills/sector-news-brief/shared/`: its own copy of the four sets of shared rules (names and lists, source rules, sector facts, the answer and dashboard scripts).

To change the agent, edit the master in `plugin/skills/` at the top of the project and run `python3 tools/build_agents.py`.
