# Demo script: daily sector news

**Before the meeting (10 minutes ahead).** Run it once on the client's sector so the dashboard tab is fresh. Open the private dashboard link on the Daily sector news tab.

**Type this**

> Run the sector news brief for European telecoms.

Swap in the client's sector. To use their own names: "…for these names: A, B, C".

**What happens**

1. It loads the checked list of 15 rated names (no search needed after the first run).
2. It makes about 22 Moody's calls together: news per name, ratings, Moody's rating actions and research in the window, the latest sector outlook.
3. It throws out share-price chatter and tenders, keeps credit news, writes the brief and refreshes the tab.

**What to say**

- "This is the last 24 hours on your sector, 72 on a Monday. Top three first, then macro, sector, one line per name."
- Click a small source number: "Every rating and figure links to the Moody's document or call it came from."
- If the day is quiet: "It says so in one line. It does not pad."
- "Why it matters is written for the credit view. It gives no view on the bonds."

**Then show the recipe.** Open `plugin/skills/sector-news-brief/SKILL.md`. "This is the whole agent: 45 lines. Your team could write this on your own coverage."

**Good to know**

- The answer in the chat is the product: every figure and rating carries a reference number and the sources are listed at the end. The dashboard tab is updated last and is optional; if it cannot be updated, the agent says so in one line and the answer is unchanged.
- Live news differs every day; do not promise a specific story. On a quiet day, ask for "the last 7 days" to have something to walk through.
- Moody's data has no forward earnings calendar, so the brief does not list who reports this week.
- A name it cannot resolve is listed as unresolved, never guessed.
