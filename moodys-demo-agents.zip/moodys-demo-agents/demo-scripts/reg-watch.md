# Demo script: regulatory watch

**Before the meeting.** Run it once so the Regulatory watch tab is fresh. If the last 7 days were quiet, run the 30-day version below so there is something to walk through.

**Type this**

> Run the regulatory watch for European banks.

For a fuller picture: "…for the last 30 days."

**What happens**

1. It opens its running list of items, reads the regulators' own publication listings and searches their sites only (Basel Committee, EBA, ECB, SRB, Commission, PRA, FINMA), and opens each new item's page to confirm the date and whether it is a consultation or final.
2. It pulls capital, leverage, liquidity and asset-quality metrics for all 15 banks in one Moody's call.
3. For each rule that maps to a metric, it works out which banks the rule covers, then ranks those banks only. Rules with no metric show as "watch".

**What to say**

- Start at the table at the top: "This is who the rule hits. It is Moody's data. The list of what changed is below it and comes from the regulators' own pages, labelled as web."
- Point at the scope line under the table: "A G-SIB rule ranks G-SIBs only. The other banks are named as out of scope, from the FSB's list."
- Point at a position: "Least headroom means closest to the requirement among the banks the rule covers, not that the bank is in trouble. The value, its period, the requirement and the distance are in the row."
- On capital: "Where a bank states its own requirement in its filings, the distance is shown with the date. Where it does not, it says not stated. It never adds one up."
- Point at a watch item: "MREL and governance have no field in the data, so it gives no position. It does not guess."
- NEW flags: "It keeps a list of what it has already found, so NEW means new since the last run, and an item does not appear one week and vanish the next."

**Then show the recipe.** Open `plugin/skills/reg-watch/SKILL.md`, then `who-it-hits.md` beside it and `plugin/skills/sector-metrics/sectors/banks-scope.md`. "The agent is 67 lines. The scope file is where your own lists and requirements would go."

**Good to know**

- The answer in the chat is the product: every figure and rating carries a reference number and the sources are listed at the end. The dashboard tab is updated last and is optional; if it cannot be updated, the agent says so in one line and the answer is unchanged.
- Bank data in Moody's can be one quarter behind reported results; the period is shown.
- A bank's stated capital requirement comes from its filings as held in Moody's, pulled on 15 Nov 2026. Several large banks have none on file; see the table in `banks-scope.md` before the meeting.
- The FSB publishes a new G-SIB list each November. The file holds the list of 27 Nov 2025.
- Credit Agricole is measured as Groupe Credit Agricole, the G-SIB, in these tables. The note under the table gives Credit Agricole S.A.'s own figures.
- Banco Santander is not on the checked list because its rated record returns no financials.
- This is the slowest of the three: allow three to four minutes on a first run. Later runs are quicker because pages already on the list are not reopened.
