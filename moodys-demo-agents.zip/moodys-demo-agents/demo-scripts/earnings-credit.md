# Demo script: earnings for credit

**Before the meeting (at least 5 minutes ahead).** Run it once on the issuer you will show. The first request for a call transcript can take about three minutes while Moody's loads it; after that it is immediate.

**Type this**

> Earnings preview for Vodafone.

and, for an issuer that has just reported:

> Earnings recap for Vodafone.

**What happens**

1. It resolves the issuer and pulls the Moody's credit opinion: upgrade and downgrade triggers, outlook, Moody's forecasts.
2. It pulls the latest Moody's-adjusted metrics, the most recent earnings call transcript and, for a recap, the company's results report from Moody's filings.
3. Preview: what to watch, each metric against its trigger with the room left. Recap: guidance from the call; net debt, liquidity, maturities and shareholder returns from the report; and where that leaves the issuer against the opinion.

**What to say**

- Preview: "This is not an equity preview. The table is the issuer's own Moody's triggers, with the latest adjusted figure and the room to each."
- Recap: "Beat or miss here means against the company's own guidance and Moody's forecast. Company-reported figures are labelled as such and never mixed with Moody's-adjusted ones."
- Point at net debt: "This is the company's own figure from the half-year report, next to the Moody's-adjusted figure for the last full year, each with its date. It says what the Moody's opinion already says about the cause. It does not recompute Moody's ratio."
- "It tells you whether the credit opinion predates the results. It does not predict a rating action."
- Use the run picker on the tab to switch between preview and recap.

**Then show the recipe.** Open `plugin/skills/earnings-credit/SKILL.md`. "Two modes, 60 lines."

**Good to know**

- The answer in the chat is the product: every figure and rating carries a reference number and the sources are listed at the end. The dashboard tab is updated last and is optional; if it cannot be updated, the agent says so in one line and the answer is unchanged.
- Not every issuer has a transcript in Moody's (Iliad Holding and BNP Paribas did not on 15 Nov). The agent says so, uses the latest filing in its place and states the filing's period. For some issuers that filing is a year old; it says that too. Check your issuer before the meeting.
- Presentation slides are often missing. The transcript and the results report are the reliable sources.
- Bank triggers are mostly worded, so the room-to-trigger column is short for banks.
