import json, subprocess
now = subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
def c(v, src, tone=None):
    d = {"v": v, "src": src}
    if tone: d["tone"] = tone
    return d
def pos(t): return {"tone": t, "v": ""}
FS = "bank sector file, pulled 15 Nov 2026: "
sources = [
 {"id":"w1","kind":"web","title":"FSB, 2025 List of Global Systemically Important Banks (G-SIBs)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
 {"id":"w2","kind":"web","title":"BCBS, Amendments to G-SIB framework to address window dressing (standards)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"},
 {"id":"w3","kind":"web","title":"BCBS, Global systemically important banks - methodology review (consultative)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
 {"id":"w4","kind":"web","title":"BCBS, Consolidated guidelines - consequential amendments (consultative)","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
 {"id":"w5","kind":"web","title":"BCBS, Interest rate risk in the banking book - additional Pillar 2 guidance (consultative)","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
 {"id":"w6","kind":"web","title":"EBA, Revised Guidelines on internal governance (EBA/GL/2026/10)","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
 {"id":"w7","kind":"web","title":"EBA, Next steps on supervisory reporting simplification, timelines extended","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
 {"id":"w8","kind":"web","title":"EBA, 2027 EU-wide stress test streamlined, more than 55% reduction in requested data","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
 {"id":"w9","kind":"web","title":"European Commission, Political agreement on the review of the Securitisation Framework","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
 {"id":"w10","kind":"web","title":"PRA, PS20/26 Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
 {"id":"w11","kind":"web","title":"PRA, CP14/26 Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
 {"id":"w12","kind":"web","title":"FINMA, Partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
 {"id":"w13","kind":"web","title":"FINMA, Consultation on partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
 {"id":"m1","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026","title":"CET1 ratio, coverage list (Bank Focus)","date":"2026-06-30"},
 {"id":"m2","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
 {"id":"r1","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"UBS Second quarter 2026 report, as of 30 Jun 2026","title":"UBS Group AG required going-concern CET1","date":"2026-06-30"},
 {"id":"r2","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"SG First quarter 2026 results, as of 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
 {"id":"r3","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"BNP Paribas Third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 capital requirement","date":"2025-09-30"},
 {"id":"r4","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"ING Form 20-F 2025, as of 31 Dec 2025","title":"ING Groep MDA trigger level for CET1","date":"2025-12-31"},
 {"id":"r5","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"Barclays Form 20-F 2025, as of 31 Dec 2025","title":"Barclays overall capital requirement for CET1","date":"2025-12-31"},
 {"id":"r6","kind":"moodys","tool":"searchCompanyFilings","ref":FS+"Credit Agricole Q1 2026 results slides, as of 31 Mar 2026","title":"Groupe Credit Agricole and Credit Agricole S.A. stated distance to SREP CET1","date":"2026-03-31"},
 {"id":"m3","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (Credit Agricole S.A. issuer record)","title":"Credit Agricole S.A. CET1 ratio","date":"2026-06-30"},
]
gsib_rows = [
 ["BNP Paribas", c("12.97%",["m1"]), c("-1.04",["m1"]), c("10.51%, 30 Sep 2025, older",["r3"]), c("2.46 pp",["m1","r3"]), pos("weaker")],
 ["ING Groep N.V.", c("13.07%",["m1"]), c("-0.94",["m1"]), c("11.03% (MDA trigger), 31 Dec 2025, older",["r4"]), c("2.04 pp",["m1","r4"]), pos("weaker")],
 ["Societe Generale", c("13.20%",["m1"]), c("-0.81",["m1"]), c("10.26%, 31 Mar 2026",["r2"]), c("2.94 pp",["m1","r2"]), pos("middle")],
 ["Deutsche Bank AG", c("13.92%",["m1"]), c("-0.09",["m1"]), "not stated", "not stated", pos("middle")],
 ["HSBC Holdings plc", c("14.10%",["m1"]), c("+0.09",["m1"]), "not stated", "not stated", pos("middle")],
 ["Barclays PLC", c("14.30%",["m1"]), c("+0.29",["m1"]), c("12.2% (excl. PRA buffer), 31 Dec 2025, older",["r5"]), c("2.10 pp",["m1","r5"]), pos("middle")],
 ["UBS Group AG", c("14.38%",["m1"]), c("+0.37",["m1"]), c("10.83% (going-concern), 30 Jun 2026",["r1"]), c("3.55 pp",["m1","r1"]), pos("stronger")],
 ["Groupe Credit Agricole", c("17.23%",["m1"]), c("+3.22",["m1"]), "total not stated", c("6.7 pp, bank-stated, 31 Mar 2026",["r6"]), pos("stronger")],
]
EU = "EU/EEA banks (11): all on the list except HSBC, Barclays, Lloyds, UBS"
ALL = "All 15, once each home country applies it"
UK = "HSBC, Barclays, Lloyds (UK groups)"
W = pos("watch")
watch_rows = [
 ["PRA PS20/26 large exposures (10 Nov)", UK, "Large exposures", W],
 ["FINMA AML Ordinance (10 Nov)", "UBS Group AG", "AML", W],
 ["BCBS IRRBB Pillar 2 guidance (9 Nov)", ALL, "IRRBB sensitivity", W],
 ["EBA 2027 stress test (9 Nov)", "EU banks in the EBA sample; sample not on the page, so scope not known by name", "Stress test results", W],
 ["EBA reporting simplification (6 Nov)", EU, "Reporting", W],
 ["EBA internal governance guidelines (5 Nov)", EU, "Governance", W],
 ["BCBS consolidated guidelines amendments (5 Nov)", ALL, "None (cross-references)", W],
 ["FINMA Circular 2019/2 IRRBB (4 Nov)", "UBS Group AG", "IRRBB sensitivity", W],
 ["EC securitisation framework (22 Oct)", EU, "Securitisation exposures", W],
 ["PRA CP14/26 SM&CR (22 Oct)", UK, "Governance", W],
]
items = [
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 completes the large exposures reform: substitution approach mandatory for credit risk mitigation, internal models removed for SFT exposure values, intragroup trading book limit raised to 350% of Tier 1. Takes effect 1 January 2028.","why":"Large exposures channel; UK groups only.","src":["w10"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised Anti-Money Laundering Ordinance published, with a narrowed correspondent banking rule. In force 1 January 2027.","why":"AML channel; UBS only.","src":["w12"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and supervisory monitoring information. Comments by 9 February 2027.","why":"IRRBB channel.","src":["w5"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final 2027 EU-wide stress test methodology cuts requested data by more than 55% and adds a climate-risk module that does not affect core results. Launch end of January 2027, results end of July 2027.","why":"Stress testing channel.","src":["w8"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Reporting simplification: first reference date for new requirements moves to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Final draft ITS report due December 2026.","why":"Reporting channel.","src":["w7"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised internal governance guidelines under CRD VI, more proportionate than the consultation draft. Final, awaiting translation; application date not stated. Moody's (11 Nov) calls the revisions credit positive, mainly for smaller EU banks.","why":"Governance channel.","src":["w6","m2"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consequential amendments so Basel Framework cross-references point to the consolidated guidelines, moving some application guidance there. Comments by 21 December 2026.","why":"","src":["w4"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Revision of Circular 2019/2 updates the interest rate shocks for banking book risk to the Basel July 2024 recalibration and adds focus on earnings effects. Consultation until 15 January 2027.","why":"IRRBB channel; UBS only.","src":["w13"]},
 {"flag":"NEW","tag":"Other","name":"European Commission","text":"Political agreement on the Securitisation Framework review, amending the CRR so bank capital treatment of securitisations is more risk sensitive. Awaits technical finalisation and formal adoption.","why":"Securitisation channel; not yet law, no dates.","src":["w9"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26 proposes removing pre-approval for about half of Senior Manager Functions and ending certification-regime requirements for about 7,700 individuals. Comments by 22 January 2027.","why":"Governance channel; UK groups only.","src":["w11"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"G-SIB indicators to be reported and disclosed as year averages, not year-end values, to curb window dressing (by 1 January 2030); reporting threshold rises from EUR 200 billion to EUR 350 billion leverage exposure from 1 January 2027.","why":"Capital channel via the G-SIB buffer.","src":["w2"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"G-SIB methodology review asks whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 January 2027.","why":"Capital channel via G-SIB scores; most relevant to banking-union G-SIBs.","src":["w3"]},
]
run = {
 "schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"sector":"Banks","region":"Europe","window":"16 Oct to 15 Nov 2026","names":15,"label":"Banks Europe, 16 Oct-15 Nov"},
 "status":"ok",
 "headline":"Twelve regulatory items in 16 Oct to 15 Nov 2026; the one with a capital channel is the Basel G-SIB package of 16 Oct, where BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 among the eight G-SIBs on the list.",
 "headline_src":["w2","w3","m1"],
 "sections":[
  {"title":"Who it hits: G-SIB window-dressing standard and methodology consultation (BCBS, 16 Oct 2026) · CET1 ratio","type":"table",
   "columns":["Name","CET1 (as reported), Q2 2026","vs median of ranked names (pp)","Stated requirement (date)","Distance to requirement","Position"],
   "rows":gsib_rows,
   "note":"Covers the banks on the FSB G-SIB list of 27 Nov 2025 (2026 list not yet found). Indicator reporting falls on the wider BCBS assessment sample. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not G-SIBs). Ranked by level: only three of eight have a current stated requirement. Credit Agricole S.A. itself: CET1 11.3% (Q2 2026), stated distance 2.6 pp (31 Mar 2026).",
   "note_src":["w1","m3","r6"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch_rows,
   "note":"Moody's data carries no field for these channels, so no name is given a position.","note_src":[]},
 ],
 "sources":sources,
 "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Left out (22 entries on the running list): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (BCBS AML/CFT, PRA Digest); sanctions notices (EC, FINMA); periodic list and Eurogroup briefing (ECB); EBA appointment, moved consultation deadlines, Taxonomy advice to the Commission, consumer factsheet and NGFS statement; EC statistics, dialogue summaries, nominations call and assurance-standards feedback; PRA credit union papers; FINMA Bitcoin ETF approval.",
  "Groupe Credit Agricole is measured in place of Credit Agricole S.A. Its latest Moody's quarter was Q3 2026, so Q2 2026 was requested to match the other banks. Local rules can set requirements above the Basel minimums.",
 ],
 "meta":{"calls":{"moodys":5,"web":27}}
}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
