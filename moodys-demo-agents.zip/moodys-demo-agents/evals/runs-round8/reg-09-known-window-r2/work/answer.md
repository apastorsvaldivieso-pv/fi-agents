**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in 16 Oct to 15 Nov 2026; the one with a capital channel is the Basel G-SIB package of 16 Oct, where BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 among the eight G-SIBs on the list. [1][2][3]

**Who it hits: G-SIB window-dressing standard and methodology consultation (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (as reported), Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -1.04 [3] | 10.51%, 30 Sep 2025, older [4] | 2.46 pp [3][4] | Weaker third |
| ING Groep N.V. | 13.07% [3] | -0.94 [3] | 11.03% (MDA trigger), 31 Dec 2025, older [5] | 2.04 pp [3][5] | Weaker third |
| Societe Generale | 13.20% [3] | -0.81 [3] | 10.26%, 31 Mar 2026 [6] | 2.94 pp [3][6] | Middle |
| Deutsche Bank AG | 13.92% [3] | -0.09 [3] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [3] | +0.09 [3] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [3] | +0.29 [3] | 12.2% (excl. PRA buffer), 31 Dec 2025, older [7] | 2.10 pp [3][7] | Middle |
| UBS Group AG | 14.38% [3] | +0.37 [3] | 10.83% (going-concern), 30 Jun 2026 [8] | 3.55 pp [3][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [3] | +3.22 [3] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Covers the banks on the FSB G-SIB list of 27 Nov 2025 (2026 list not yet found). Indicator reporting falls on the wider BCBS assessment sample. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not G-SIBs). Ranked by level: only three of eight have a current stated requirement. Credit Agricole S.A. itself: CET1 11.3% (Q2 2026), stated distance 2.6 pp (31 Mar 2026). [9][10][11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 completes the large exposures reform: substitution approach mandatory for credit risk mitigation, internal models removed for SFT exposure values, intragroup trading book limit raised to 350% of Tier 1. Takes effect 1 January 2028. *Why it matters:* Large exposures channel; UK groups only. [12]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance published, with a narrowed correspondent banking rule. In force 1 January 2027. *Why it matters:* AML channel; UBS only. [13]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and supervisory monitoring information. Comments by 9 February 2027. *Why it matters:* IRRBB channel. [14]
- [NEW] **EBA** (Final): Final 2027 EU-wide stress test methodology cuts requested data by more than 55% and adds a climate-risk module that does not affect core results. Launch end of January 2027, results end of July 2027. *Why it matters:* Stress testing channel. [15]
- [NEW] **EBA** (Other): Reporting simplification: first reference date for new requirements moves to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Final draft ITS report due December 2026. *Why it matters:* Reporting channel. [16]
- [NEW] **EBA** (Final): Revised internal governance guidelines under CRD VI, more proportionate than the consultation draft. Final, awaiting translation; application date not stated. Moody's (11 Nov) calls the revisions credit positive, mainly for smaller EU banks. *Why it matters:* Governance channel. [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments so Basel Framework cross-references point to the consolidated guidelines, moving some application guidance there. Comments by 21 December 2026. [19]
- [NEW] **FINMA** (Consultation): Revision of Circular 2019/2 updates the interest rate shocks for banking book risk to the Basel July 2024 recalibration and adds focus on earnings effects. Consultation until 15 January 2027. *Why it matters:* IRRBB channel; UBS only. [20]
- [NEW] **European Commission** (Other): Political agreement on the Securitisation Framework review, amending the CRR so bank capital treatment of securitisations is more risk sensitive. Awaits technical finalisation and formal adoption. *Why it matters:* Securitisation channel; not yet law, no dates. [21]
- [NEW] **PRA** (Consultation): CP14/26 proposes removing pre-approval for about half of Senior Manager Functions and ending certification-regime requirements for about 7,700 individuals. Comments by 22 January 2027. *Why it matters:* Governance channel; UK groups only. [22]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported and disclosed as year averages, not year-end values, to curb window dressing (by 1 January 2030); reporting threshold rises from EUR 200 billion to EUR 350 billion leverage exposure from 1 January 2027. *Why it matters:* Capital channel via the G-SIB buffer. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review asks whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 January 2027. *Why it matters:* Capital channel via G-SIB scores; most relevant to banking-union G-SIBs. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) | HSBC, Barclays, Lloyds (UK groups) | Large exposures | Watch |
| FINMA AML Ordinance (10 Nov) | UBS Group AG | AML | Watch |
| BCBS IRRBB Pillar 2 guidance (9 Nov) | All 15, once each home country applies it | IRRBB sensitivity | Watch |
| EBA 2027 stress test (9 Nov) | EU banks in the EBA sample; sample not on the page, so scope not known by name | Stress test results | Watch |
| EBA reporting simplification (6 Nov) | EU/EEA banks (11): all on the list except HSBC, Barclays, Lloyds, UBS | Reporting | Watch |
| EBA internal governance guidelines (5 Nov) | EU/EEA banks (11): all on the list except HSBC, Barclays, Lloyds, UBS | Governance | Watch |
| BCBS consolidated guidelines amendments (5 Nov) | All 15, once each home country applies it | None (cross-references) | Watch |
| FINMA Circular 2019/2 IRRBB (4 Nov) | UBS Group AG | IRRBB sensitivity | Watch |
| EC securitisation framework (22 Oct) | EU/EEA banks (11): all on the list except HSBC, Barclays, Lloyds, UBS | Securitisation exposures | Watch |
| PRA CP14/26 SM&CR (22 Oct) | HSBC, Barclays, Lloyds (UK groups) | Governance | Watch |

Note: Moody's data carries no field for these channels, so no name is given a position.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (22 entries on the running list): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (BCBS AML/CFT, PRA Digest); sanctions notices (EC, FINMA); periodic list and Eurogroup briefing (ECB); EBA appointment, moved consultation deadlines, Taxonomy advice to the Commission, consumer factsheet and NGFS statement; EC statistics, dialogue summaries, nominations call and assurance-standards feedback; PRA credit union papers; FINMA Bitcoin ETF approval.
- Groupe Credit Agricole is measured in place of Credit Agricole S.A. Its latest Moody's quarter was Q3 2026, so Q2 2026 was requested to match the other banks. Local rules can set requirements above the Basel minimums.

**Sources**

[1] Web · BCBS, Amendments to G-SIB framework to address window dressing (standards) · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · BCBS, Global systemically important banks - methodology review (consultative) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · CET1 ratio, coverage list (Bank Focus) · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING Groep MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: SG First quarter 2026 results, as of 31 Mar 2026 · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays overall capital requirement for CET1 · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS Group AG required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. stated distance to SREP CET1 · bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, as of 31 … · 2026-03-31
[10] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (Credit Agricole S.A. issuer … · Credit Agricole S.A. CET1 ratio · 2026-06-30
[12] Web · PRA, PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA, Partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · BCBS, Interest rate risk in the banking book - additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA, 2027 EU-wide stress test streamlined, more than 55% reduction in requested … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA, Next steps on supervisory reporting simplification, timelines extended · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA, Revised Guidelines on internal governance (EBA/GL/2026/10) · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · BCBS, Consolidated guidelines - consequential amendments (consultative) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA, Consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · European Commission, Political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · PRA, CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
