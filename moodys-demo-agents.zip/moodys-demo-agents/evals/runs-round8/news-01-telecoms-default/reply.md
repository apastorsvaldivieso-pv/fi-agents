**Daily sector news: Telecoms, Europe** (24h to 15 Nov 2026 22:49 UTC; 15 names)

Nothing material for Telecoms, Europe, in the last 24 hours.

**Notes**

- Left out as old news retold: Ad Hoc News weekend recaps of Deutsche Telekom (raised 2026 guidance, fibre builds, share buyback) and a Kalkine Media piece on Vodafone lifting its outlook describe events from before the window, with no new fact.
- The Moody's searches returned no rating action or research on European telecoms dated 14-15 Nov 2026, and no rating action dated in the window on any of the 15 names.

Daily sector news tab updated 15 Nov 2026 22:51 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-01-telecoms-default/dashboard/dashboard.html (not published as an Artifact in this run).
