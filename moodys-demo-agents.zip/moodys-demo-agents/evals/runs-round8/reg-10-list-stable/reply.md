**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in the window, none new since the last run; the one on a Moody's metric is the Basel Committee's final G-SIB window-dressing rule, where BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 of the eight G-SIBs on the list. [1][2]

**Who it hits: G-SIB window-dressing amendments (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, as reported (Q2 2026) | vs median of ranked names | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 pp [2] | 10.51% (CET1 capital requirement, 30 Sep 2025, older) [3] | 2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 pp [2] | 11.03% (MDA trigger, 31 Dec 2025, older) [4] | 2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 pp [2] | 10.26% (CET1 requirement, 31 Mar 2026) [5] | 2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 pp [2] | not stated | n/a | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 pp [2] | not stated | n/a | Middle |
| Barclays PLC | 14.3% [2] | +0.29 pp [2] | 12.2% (overall CET1 requirement excl. PRA buffer, 31 Dec 2025, older) [6] | 2.10 pp [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 pp [2] | 10.83% (going-concern CET1, 30 Jun 2026) [7] | 3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [8] | +3.22 pp [2][8] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Covers G-SIBs on the FSB list: indicators are reported by every bank in the BCBS assessment sample, but the buffer falls only on listed banks. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three have a current stated requirement. Issuer on the list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [2][9][10]

**Who it hits: G-SIB methodology review, consultation (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, as reported (Q2 2026) | vs median of ranked names | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51% (30 Sep 2025, older) [3] | 2.46 pp [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% (31 Dec 2025, older) [4] | 2.04 pp [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26% (31 Mar 2026) [5] | 2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | n/a | list too short to rank |
| Groupe Credit Agricole | 17.23% [8] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The page does not state scope; it asks about cross-border exposures within the European Banking Union, so we take it to cover the banking-union G-SIBs on the FSB list (our reading). Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. [10][11]

**What changed**

- **FINMA · 10 Nov** (Final): FINMA published its partially revised Anti-Money Laundering Ordinance, recognising updated bank self-regulation as a minimum standard and clarifying correspondent banking and ownership transparency. In force 1 January 2027. Channel: AML (watch). [12]
- **PRA · 10 Nov** (Final): PS20/26 finalises Part 2 of the large exposures changes: credit risk mitigation substitution becomes mandatory and internal models for securities financing transactions are removed. Applies from 1 January 2028 to PRA-authorised UK banks and holding companies. Channel: large exposures (watch). [13]
- **Basel Committee · 9 Nov** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and a new supervisory reporting requirement. Comments by 9 February 2027. Channel: IRRBB (watch). [14]
- **EBA · 9 Nov** (Final): Final methodology for the 2027 EU-wide stress test, with a new climate-risk module and "more than 55%" less requested data. Launch end of January 2027; results end of July 2027. Channel: stress testing (watch). [15]
- **EBA · 6 Nov** (Other): Next steps on the reporting simplification ITS: first reference date moves to December 2027, and to December 2028 for liquidity, asset encumbrance, benchmarking and ESG reporting; final report due December 2026. Channel: reporting (watch). [16]
- **EBA · 5 Nov** (Final): Revised Guidelines on internal governance under CRD VI, with duty mapping and third-country branch governance requirements; application date not stated on the page. Channel: governance (watch). *Why it matters:* Moody's sector comment of 11 Nov 2026 calls the revisions credit positive, with a greater effect on smaller banks. [17][18]
- **Basel Committee · 5 Nov** (Consultation): Proposes updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026. No channel in the sector map; shown as watch by our judgment. [19]
- **FINMA · 4 Nov** (Consultation): Partial revision of Circular 2019/2 to apply the Basel Committee's recalibrated interest rate shocks and give more weight to effects on banks' revenues. Comments by 15 January 2027. Channel: IRRBB (watch). [20]
- **PRA · 22 Oct** (Consultation): CP14/26 proposes Phase 2 of the SM&CR review, easing pre-approval of senior appointments and the certification regime. Comments by 22 January 2027. Channel: governance (watch). [21]
- **European Commission · 22 Oct** (Other): Parliament and Council reached political agreement on the Securitisation Framework review, simplifying due diligence and transparency and making the CRR treatment of securitisations "more risk sensitive". Awaits formal adoption; no application date stated. Channel: securitisation (watch). [22]
- **Basel Committee · 16 Oct** (Final): G-SIB score indicators are to be reported and disclosed as averages over the year rather than year-end values, by 1 January 2030. From 1 January 2027 the reporting threshold rises from 200 billion EUR to 350 billion EUR of leverage exposure. Channel: G-SIB buffer (CET1). [1]
- **Basel Committee · 16 Oct** (Consultation): G-SIB methodology review asks whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 January 2027. Channel: G-SIB buffer (CET1). [11]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| IRRBB Pillar 2 guidance (BCBS, consultation) | All 15 names, once home rules apply | IRRBB sensitivity: no Moody's field | Watch |
| Consolidated guidelines, consequential amendments (BCBS, consultation) | All 15 names, once home rules apply | none: cross-references only | Watch |
| 2027 EU-wide stress test methodology (EBA, final) | Scope not known: EBA sample not named on the page; the 11 EU names are candidates | stress test results: no Moody's field | Watch |
| Supervisory reporting timelines (EBA, next steps) | The 11 EU names (all but HSBC, Barclays, Lloyds, UBS) | reporting: no Moody's field | Watch |
| Internal governance guidelines (EBA, final) | The 11 EU names (all but HSBC, Barclays, Lloyds, UBS) | governance: no Moody's field | Watch |
| Securitisation Framework review (European Commission, political agreement) | The 11 EU names (all but HSBC, Barclays, Lloyds, UBS) | securitisation exposure: no Moody's field | Watch |
| Large exposures, PS20/26 (PRA, final) | HSBC, Barclays, Lloyds | large exposures: no Moody's field | Watch |
| SM&CR Phase 2, CP14/26 (PRA, consultation) | HSBC, Barclays, Lloyds | governance: no Moody's field | Watch |
| AML Ordinance (FINMA, final) | UBS | AML: no Moody's field | Watch |
| Circular 2019/2 interest rate risks (FINMA, consultation) | UBS | IRRBB sensitivity: no Moody's field | Watch |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (23): speeches, blogs, newsletters, sanctions notices, appointments, statistics, credit-union papers, a moved EBA deadline, EBA advice to the Commission, ECB and SRB communications to the Eurogroup, an ECB periodic list, the BCBS press release (its two measures are shown).
- No ECB or SRB measure in the window. The FSB's 2026 G-SIB list is not yet out; the 2025 list is used. No Moody's comment found on the G-SIB, securitisation, stress test or IRRBB items.

**Sources**

[1] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, one call for the coverage … · Bank financials, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, CET1 … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for … · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, CET1 … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, … · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, required … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period; LQ returned Q3 … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Credit Agricole stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole S.A., First quarter 2026 results … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · BCBS: Global systemically important banks - methodology review (consultation) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[12] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA: next steps on supervisory reporting simplification, extended … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 (Sector Comment) · 2026-11-11
[19] Web · BCBS: Consolidated guidelines - consequential amendments (consultation) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[22] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 15 Nov 2026, 23:02 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-10-list-stable/dashboard/dashboard.html. Not published to the private link (publishing is skipped in this session).
