**Regulatory watch: Banks Europe, 7 days, MREL asked** (8 to 15 Nov 2026; 15 names)

No MREL change at any primary regulator in 8 to 15 Nov 2026, and Moody's data has no MREL field, so exposure to a tighter MREL can be shown by scope only: 11 banking-union names (SRB) and 3 UK names (Bank of England); UBS sits under the Swiss regime. [1]

**What changed**

- [Asked] **SRB / Bank of England** (MREL): No MREL or TLAC rule, consultation or decision was published by any primary regulator in the window. The EU's pending resolution simplification would bring MREL closer to the TLAC standard (Moody's, 14 Sep 2026). *Why it matters:* Moody's says that would be credit negative if it reduces bail-inable debt in the EU banking system; the policy direction discussed is easing, not tightening. [1][2]
- [NEW] **PRA** (Final): PS20/26 finalises the remaining Large Exposures changes, including mandatory substitution for credit risk mitigation. Final; effective 1 Jan 2028. *Why it matters:* Large exposures channel; UK groups only. [3]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published in final form; in force 1 Jan 2027. *Why it matters:* AML channel; Swiss groups only. [4]
- [NEW] **Basel Committee** (Consultation): Consults on additional Pillar 2 guidance for interest rate risk in the banking book (model risk, stress testing, earnings indicators) and a new supervisory reporting requirement. Comments by 9 Feb 2027. *Why it matters:* IRRBB channel; a consultation, not a final standard. [5]
- [NEW] **EBA** (Final): Final methodology and draft templates for the 2027 EU-wide stress test; data requested cut by "more than 55%" (headline). Launch end Jan 2027, results end Jul 2027. *Why it matters:* Stress testing channel; adds a first-time climate risk module. [6]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| MREL tightened (asked, no change found) [1] | SRB: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea. Bank of England: HSBC, Barclays, Lloyds | MREL ratio vs requirement (no Moody's field) | Watch |
| PRA PS20/26 Large Exposures Part 2 [3] | HSBC, Barclays, Lloyds | Large exposures (no Moody's field) | Watch |
| FINMA AML Ordinance [4] | UBS | none (AML) | Watch |
| BCBS IRRBB Pillar 2 guidance (consultation) [5] | All 15, once home countries apply it | IRRBB (no Moody's field) | Watch |
| EBA 2027 EU-wide stress test [6] | EU names in the EBA sample (11 EU names on list; sample not checked name by name) | none (stress testing) | Watch |

Note: Out of MREL scope: UBS (Swiss group; FINMA sets its gone-concern requirement, not MREL). Moody's financials carry no MREL or TLAC field, so no name is ranked by headroom.

**Notes**

- Window 8 to 15 Nov 2026, both days included. Left out: speeches (SRB, 10 and 11 Nov, incl. the 10th MREL Workshop keynote); news or meeting summaries (SRB 13 Nov, Commission 11 Nov); consumer material (EBA 9 Nov); statements (EBA NGFS, 13 Nov); appointments (Commission 9 Nov); authority-to-authority reports (ECB to Eurogroup, 9 Nov); measures for other firms (Commission assurance standards, 12 Nov).
- MREL coverage is by resolution authority from each group's country: SRB for banking-union groups, Bank of England for UK groups. The sector file's scope table has no resolution-authority row, so this mapping is a judgment. No financials call was made: no item maps to a Moody's metric.

**Sources**

[1] Moody's (searchAllDocuments) · Banking - Europe: European regulators put more resolve into bank resolution … · PBC_1491385 · 2026-09-14
[2] Moody's (searchAllDocuments) · Banks - EU: EU bank reforms support capital mobility, but could ease some … · PBC_1489046 · 2026-07-27
[3] Web · PRA: PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[4] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[5] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[6] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data

Regulatory watch tab updated 2026-11-15 22:53 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html (not published as an Artifact in this test run).
