# Regulatory watch: European banks, 8–15 Nov 2026

**Four regulatory items in the window, none on liquidity. All four are on channels where Moody's data has no metric (IRRBB, stress testing, large exposures, AML). You asked for the liquidity channel, so it is shown anyway, ranked by LCR headroom over the 100% minimum.**

## Who it hits: liquidity, Asked (no regulatory change found) · LCR

| Name | LCR, Q2 2026 | vs median (pp) | Stated requirement | Distance (pp) | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134.0% [1] | −7.0 [1] | 100% minimum [3] | 34.0 [1][3] | Least headroom |
| BNP Paribas | 134.8% [1] | −6.2 [1] | 100% [3] | 34.8 [1][3] | Least headroom |
| Groupe Credit Agricole | 135.8% [2] | −5.3 [1][2] | 100% [3] | 35.8 [2][3] | Least headroom |
| ING Groep N.V. | 137.0% [1] | −4.0 [1] | 100% [3] | 37.0 [1][3] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.6% [1] | −3.4 [1] | 100% [3] | 37.6 [1][3] | Least headroom |
| UniCredit S.p.A. | 140.0% [1] | −1.0 [1] | 100% [3] | 40.0 [1][3] | Middle |
| Deutsche Bank AG | 140.1% [1] | −0.9 [1] | 100% [3] | 40.1 [1][3] | Middle |
| Commerzbank AG | 141.0% [1] | 0.0 [1] | 100% [3] | 41.0 [1][3] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142.0% [1] | +1.0 [1] | 100% [3] | 42.0 [1][3] | Middle |
| Lloyds Banking Group plc | 144.0% [1] | +3.0 [1] | 100% [3] | 44.0 [1][3] | Middle |
| Societe Generale | 146.4% [1] | +5.4 [1] | 100% [3] | 46.4 [1][3] | Most headroom |
| Nordea Bank Abp | 156.0% [1] | +15.0 [1] | 100% [3] | 56.0 [1][3] | Most headroom |
| Barclays PLC | 157.7% [1] | +16.7 [1] | 100% [3] | 57.7 [1][3] | Most headroom |
| UBS Group AG | 177.3% [1] | +36.3 [1] | 100% [3] | 77.3 [1][3] | Most headroom |
| CaixaBank, S.A. | 193.0% [1] | +52.0 [1] | 100% [3] | 93.0 [1][3] | Most headroom |

Note: all 15 names are covered, because the LCR minimum applies to every bank on the list. Median of the 15: 141.0% [1]. Groupe Credit Agricole is measured in place of Credit Agricole S.A., the issuer on the list (its own LCR: 141.3%, Q2 2026 [1]). The group record first came back at Q3 2026 and was pulled again at Q2 2026 to match the other banks [2].

## What changed

1. **PRA, PS20/26, Large Exposures Framework Part 2** (final policy statement, 10 Nov; effective 1 Jan 2028) [6]. Makes substitution of credit risk mitigation mandatory for large exposure limits, removes internal models for SFT exposure values, and cuts the trading-book excess allowance for third parties to a time-limited 85% of Tier 1. Channel: large exposures (`watch`).
2. **FINMA, AMLO-FINMA partial revision** (final, 10 Nov; in force 1 Jan 2027, four-month transition for self-regulation) [7]. Aligns the ordinance with the revised AMLA ahead of the FATF evaluation, covering correspondent banking, ownership transparency and embargo monitoring, and recognises the revised banks' code of conduct. Channel: AML (`watch`).
3. **Basel Committee, IRRBB additional Pillar 2 guidance** (consultation, 9 Nov; comments by 9 Feb 2027) [4]. Proposes more guidance on IRRBB model validation, stress testing, controls and earnings indicators, plus a new "Supervisory Information" report to supervisors. Channel: IRRBB (`watch`).
4. **EBA, 2027 EU-wide stress test methodology** (final methodology, 9 Nov; launch end-Jan 2027, results end-Jul 2027) [5]. Constrained bottom-up, static balance sheet, with a climate module that does not affect core results. The headline says "more than 55%" fewer data requested; the body says data points were "reduced by 55%". Channel: stress testing (`watch`).
5. **Liquidity (Asked).** No regulatory change found at the primary regulators in the window.

Moody's has published no comment on these four items since they came out.

## Who it hits: no Moody's metric

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures | HSBC, Barclays, Lloyds (UK groups) | Large exposures / Tier 1 | watch |
| FINMA AMLO revision | UBS | none (AML) | watch |
| BCBS IRRBB Pillar 2 guidance | All 15, once applied at home (consultation) | IRRBB (EVE/NII sensitivity) | watch |
| EBA 2027 stress test | EU/EEA banks: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa, BBVA, CaixaBank, Nordea. The sample is set in the methodology and not listed on the page, so scope is not known name by name | Stress-test depletion | watch |

## Notes

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact. Local LCR rules (PRA, FINMA) can be stricter than the Basel 100% minimum.
- Left out as not items: EBA consumer factsheet (9 Nov, consumer material) and its NGFS declaration support (13 Nov, statement); ECB Supervisory Board written overview to the Eurogroup (9 Nov, one authority to another); SRB speeches and news (10, 11, 13 Nov); Commission competitiveness-dialogue summary (11 Nov, statement), its assurance-standards feedback call (12 Nov, addressed to auditors and companies) and tokenisation nominations (9 Nov). The ECB press feed and the Basel Committee news page had nothing in the window.
- The running list of items could not be read or updated in this session, so no item is flagged NEW.
- Dashboard not updated: no folder to write to, scripts cannot run, and publishing is not available.

## Sources

1. Moody's, getEntityFinancials_v2 (Bank Focus): Basel III LCR (as reported), LQ = Q2 2026 (30 Jun 2026), all 15 list names plus Credit Agricole S.A.'s own record. Pulled 15 Nov 2026.
2. Moody's, getEntityFinancials_v2 (Bank Focus): Groupe Credit Agricole LCR, Q2 2026 (re-pulled at the explicit period). Pulled 15 Nov 2026.
3. Web: Basel Framework (LEV, LCR, NSF standards), LCR minimum of 100%. https://www.bis.org/basel_framework/
4. Web: Basel Committee, "Interest rate risk in the banking book – additional Pillar 2 guidance", consultative document, 9 Nov 2026. https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
5. Web: EBA, "EBA streamlines the 2027 EU-wide stress test…", 9 Nov 2026. https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
6. Web: PRA, PS20/26 Amendments to the Large Exposures Framework – Part 2, 10 Nov 2026. https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
7. Web: FINMA, AMLO-FINMA partial revision press release, 10 Nov 2026. https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
