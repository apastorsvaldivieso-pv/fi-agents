**Daily sector news: Telecoms, Europe** (72h to 15 Nov 2026 22:49 UTC (from 12 Nov 22:49 UTC); 15 names)

Telia's sale of its Latvian stakes (LMT, Tet) is due to go through by 17 Nov, and Telenor now holds 66.9% of Bahnhof's shares; Moody's took no rating actions on the sector in the window. [1][2]

**Top this week**

- **Telia Company AB** (Disposal): The Latvian government's directive on buying out Telia's shares in Latvijas Mobilais Telefons (LMT) and Tet will be carried out by the 17 Nov deadline, LMT's vice president told LETA on 13 Nov. The article gives no price. *Why it matters:* Moody's stable outlook assumes Telia keeps adjusted gross debt/EBITDA below 3.0x and RCF/net debt above 22%; downgrade triggers are RCF/net debt below 22% and debt/EBITDA moving towards 3.0x. [1][3]
- **Telenor ASA** (Acquisition): Telenor Sverige now holds about 66.9% of Bahnhof's shares and 90.6% of its votes; Bahnhof's independent board committee recommends accepting its unconditional mandatory cash offer of SEK 62 per share (offer launched 6 Nov), and Telenor published a supplement to the offer document on 13 Nov. *Why it matters:* Moody's positive outlook includes no M&A beyond the GlobalConnect deal, and a more aggressive financial policy in M&A is a stated downgrade factor. [2][4][5]

**Macro**

- UK: headlines say the Bank of England is likely to raise rates further in 2027, and UK price data may strengthen the case. [6]
- Euro area: government bond yields rose on 13 Nov. [7]

**Sector**

- The searches returned no Moody's rating actions and no Moody's research on European telecoms published 12 to 15 Nov. [8]
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable, published 27 Oct 2026, citing solid demand and declining capital intensity against refinancing pressure and structural risks. [9]

**By name**

| Name | Rating (class, outlook) | In the window |
|---|---|---|
| Telia Company AB | Baa1 Senior Unsecured (FC), Stable [10] | Latvian buyout of LMT and Tet stakes due by 17 Nov (see Top). [1] |
| Telenor ASA | Baa1 Senior Unsecured (FC), Positive [10] | Holds 66.9% of Bahnhof shares; offer recommended (see Top). [2] |
| Deutsche Telekom AG | A3 Senior Unsecured (FC), Stable [10] | Bought back 5.22 million shares (single source, unconfirmed). [11] |
| VMED O2 UK Holdings Limited | B1 CFR (FC), ratings under review [10] | CFR, PDR and Virgin Media Bristol bank facility on review for downgrade since 22 Oct. No news in the window. [12] |
| Orange | Baa1 LT Issuer Rating, Stable [10] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (FC), Stable [10] | No material credit news. |
| Telefonica S.A. | Baa3 Senior Unsecured (DC), Stable [10] | No material credit news. |
| Swisscom AG | A2 LT Issuer Rating (DC), Stable [10] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating, Stable [10] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (DC), Stable [10] | No material credit news. |
| TIM S.p.A. | Baa3 LT Issuer Rating (DC), Positive [10] | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (DC), Stable [10] | No material credit news. |
| BT Group Plc | Baa2 LT Issuer Rating, Stable (British Telecommunications Limited) [10] | No material credit news. |
| Iliad S.A. | Ba1 Senior Unsecured (DC), Stable [10] | No material credit news. |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (FC), Positive [10] | No material credit news. |

Note: FC = foreign currency, DC = domestic currency. Rating class is the one Moody's returned for each name.

**Notes**

- You said Monday 16 Nov; the system clock reads Sunday 15 Nov 2026 22:49 UTC, so the Monday 72-hour window was searched up to now. News from later on 15 or 16 Nov is not included.
- Left out as old news retold: Vodafone's raised outlook and dividend, BT's half-year results and pension valuation (released 5 Nov), and Deutsche Telekom's Q3 results and guidance raise (5 Nov), all published before the window.
- The Orange news search returned only unrelated items (places and events named Orange); no Orange group news came back.

**Sources**

[1] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet to be … · LETA Latvian News Agency, 202611130000PPI_____ASIANET_LETA1311202600010004 · 2026-11-13
[2] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · NewsWeb (Oslo Bors), message 686452 · 2026-11-13
[3] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649, Rating outlook and downgrade factors · 2026-03-02
[4] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document in respect of the … · Cision Wire, c4424047 · 2026-11-13
[5] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480, Rating outlook and downgrade factors · 2026-02-24
[6] Moody's (searchNews) · BOE likely to raise rates further in 2027 / BOE's case to raise rates again may … · Forex Factory 202611142153AMSPIDERFIN_NEWS_119112_94037; WN … · 2026-11-15
[7] Moody's (searchNews) · Eurozone bond yields rise; Italy might get ratings upgrade · MSN US, 202611130358AMSPIDERBRDCAST__28738_11440499 · 2026-11-13
[8] Moody's (searchAllDocuments) · Moody's actions and research search · Rating Action; Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Credit … · 2026-11-15
[9] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503, Outlook · 2026-10-27
[10] Moody's ratings (getEntityRatings) · Moody's ratings pull, Moody's ratings pull · 2026-11-15
[11] Moody's (searchNews) · Deutsche Telekom Wins Network Plaudits and Opens Two Fibre Fronts While … · Ad Hoc News Germany, 202611150806AMSPIDEROPNTEEUR_KHi5vIEv · 2026-11-15
[12] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559, Rating Action · 2026-10-22

Daily sector news tab updated at 2026-11-15 22:51 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html (not published to the private link in this run).
