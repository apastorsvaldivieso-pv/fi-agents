**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

No liquidity rule changed in the 30 days to 15 Nov 2026; all 15 banks sit at least 34.00 pp above the 100% LCR minimum, with HSBC, BNP Paribas and Groupe Credit Agricole closest. The capital-channel news is the Basel Committee's final G-SIB window-dressing standard. [1][2][3]

**Who it hits: liquidity channel, asked (no rule in window) · LCR**

| Name | LCR, Q2 2026 | vs median of ranked names (pp) | Stated requirement | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134.00% [1] | -7.00 [1] | 100% (Basel minimum) [2] | 34.00 [1][2] | Least headroom |
| BNP Paribas | 134.77% [1] | -6.23 [1] | 100% (Basel minimum) [2] | 34.77 [1][2] | Least headroom |
| Groupe Credit Agricole | 135.75% [1] | -5.25 [1] | 100% (Basel minimum) [2] | 35.75 [1][2] | Least headroom |
| ING Groep N.V. | 137.00% [1] | -4.00 [1] | 100% (Basel minimum) [2] | 37.00 [1][2] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.60% [1] | -3.40 [1] | 100% (Basel minimum) [2] | 37.60 [1][2] | Least headroom |
| UniCredit S.p.A. | 140.00% [1] | -1.00 [1] | 100% (Basel minimum) [2] | 40.00 [1][2] | Middle |
| Deutsche Bank AG | 140.12% [1] | -0.88 [1] | 100% (Basel minimum) [2] | 40.12 [1][2] | Middle |
| Commerzbank AG | 141.00% [1] | +0.00 [1] | 100% (Basel minimum) [2] | 41.00 [1][2] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142.00% [1] | +1.00 [1] | 100% (Basel minimum) [2] | 42.00 [1][2] | Middle |
| Lloyds Banking Group plc | 144.00% [1] | +3.00 [1] | 100% (Basel minimum) [2] | 44.00 [1][2] | Middle |
| Societe Generale | 146.41% [1] | +5.41 [1] | 100% (Basel minimum) [2] | 46.41 [1][2] | Most headroom |
| Nordea Bank Abp | 156.00% [1] | +15.00 [1] | 100% (Basel minimum) [2] | 56.00 [1][2] | Most headroom |
| Barclays PLC | 157.70% [1] | +16.70 [1] | 100% (Basel minimum) [2] | 57.70 [1][2] | Most headroom |
| UBS Group AG | 177.28% [1] | +36.28 [1] | 100% (Basel minimum) [2] | 77.28 [1][2] | Most headroom |
| CaixaBank, S.A. | 192.99% [1] | +51.99 [1] | 100% (Basel minimum) [2] | 92.99 [1][2] | Most headroom |

Note: Asked channel: no regulatory change found, so all 15 names are shown against the Basel 100% minimum and ranked by distance. Median 141.00%. Groupe Credit Agricole asked again at Q2 2026 (LQ gave Q3 2026). Issuer on the list, Credit Agricole S.A.: LCR 141.29% (Q2 2026). [1]

**Who it hits: G-SIB window-dressing standard and methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1, Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [4] | -1.04 [4] | 10.51%, 30 Sep 2025, older [5] | 2.46 [4][5] | Weaker third |
| ING Groep N.V. | 13.07% [4] | -0.94 [4] | 11.03%, 31 Dec 2025, older [6] | 2.04 [4][6] | Weaker third |
| Societe Generale | 13.20% [4] | -0.81 [4] | 10.26%, vs 31 Mar 2026 [7] | 2.94 [4][7] | Middle |
| Deutsche Bank AG | 13.92% [4] | -0.09 [4] | not stated | – | Middle |
| HSBC Holdings plc | 14.10% [4] | +0.09 [4] | not stated | – | Middle |
| Barclays PLC | 14.30% [4] | +0.29 [4] | 12.2%, 31 Dec 2025, older [8] | 2.10 [4][8] | Middle |
| UBS Group AG | 14.38% [4] | +0.37 [4] | 10.83%, 30 Jun 2026 [9] | 3.55 [4][9] | Stronger third |
| Groupe Credit Agricole | 17.23% [4] | +3.22 [4] | total not stated [10] | 6.7, bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers the 'G-SIB framework'. Every bank in the BCBS assessment sample reports scores; the buffer falls only on FSB-listed G-SIBs (list of 27 Nov 2025; 2026 list not yet out). Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on that list). Ranked by level: three current requirements. Credit Agricole S.A.: CET1 11.30% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). Median 14.01%. [4][10][11]

**What changed**

- **Liquidity (LCR)** (Asked): No regulatory change to the LCR or its minimum was found at the seven regulators in the window. The nearest step is EBA's deferral of new liquidity reporting to December 2028 (6 Nov), a reporting change. [12]
- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes, including mandatory substitution for credit risk mitigation, and keeps a trading book excess allowance for third-party exposures of up to 85% of Tier 1 for at most 10 business days. Effective 1 Jan 2028. Channel: large exposures. [13]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance, recognising revised banking self-regulation as a minimum standard. In force 1 Jan 2027. Channel: AML. [14]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, controls, embedded gains and losses, earnings indicators and a new reporting set. Comments by 9 Feb 2027. Channel: IRRBB. [15]
- [NEW] **EBA** (Final methodology): Final 2027 EU-wide stress test methodology and draft templates, with a reduction of more than 55% in requested data and a first climate-risk module. Launch end-January 2027, results end-July 2027. Channel: stress testing. [16]
- [NEW] **EBA** (Next steps): Supervisory reporting simplification: first reference date for new requirements moves to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028; final ITS report due December 2026. Channel: reporting. [12]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, with more proportionality; awaiting translation, application date not stated. Channel: governance. *Why it matters:* Moody's calls the revisions credit positive for small EU banks (Sector Comment, 11 Nov 2026). [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments updating Basel Framework cross-references to the consolidated guidelines and moving some application guidance there. Comments by 21 Dec 2026. No channel row in the map: watch. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 'Interest rate risks – banks' to implement the Basel Committee's July 2024 recalibrated rate shocks and give more weight to revenue effects. Comments by 15 Jan 2027. Channel: IRRBB. [20]
- [NEW] **European Commission** (Legislative step): Parliament and Council reached political agreement on the securitisation framework review, amending the Securitisation Regulation and the CRR to make the prudential treatment more risk sensitive; formal approval pending. Channel: securitisation. [21]
- [NEW] **PRA** (Consultation): CP14/26 proposes moving some Senior Manager Functions to notification and removing Certification Regime fitness and propriety assessments. Comments by 22 Jan 2027; implementation expected H2 2027. Channel: governance, conduct. [22]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported and disclosed as averages over the year instead of year-end figures, by 1 Jan 2030; the leverage ratio exposure reporting threshold rises from EUR200bn to EUR350bn from 1 Jan 2027. Channel: capital (G-SIB buffer). *Why it matters:* G-SIB scores set the bucket, and so the G-SIB buffer inside each listed bank's CET1 requirement. [3]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 Jan 2027. Channel: capital (G-SIB buffer). [23]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) | HSBC, Barclays, Lloyds | Large exposures: no field | Watch |
| FINMA AML Ordinance (10 Nov) | UBS | AML: no field | Watch |
| BCBS IRRBB Pillar 2 guidance (9 Nov) | All 15, once home rules apply | IRRBB: no field | Watch |
| EBA 2027 stress test (9 Nov) | EU/EEA names in the EBA sample: scope not known (sample not named) | Stress testing: no field | Watch |
| EBA reporting simplification (6 Nov) | 11 EU/EEA names | Reporting: no field | Watch |
| EBA internal governance guidelines (5 Nov) | 11 EU/EEA names | Governance: no field | Watch |
| BCBS consolidated guidelines amendments (5 Nov) | All 15, once home rules apply | No channel row | Watch |
| FINMA Circular 2019/2 IRR (4 Nov) | UBS | IRRBB: no field | Watch |
| EU securitisation agreement (22 Oct) | 11 EU/EEA names | Securitisation: no field | Watch |
| PRA CP14/26 SM&CR phase 2 (22 Oct) | HSBC, Barclays, Lloyds | Governance, conduct: no field | Watch |

Note: Moody's data carries no metric for these channels. 11 EU/EEA names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- The 100% LCR minimum is the Basel standard; local rules can be higher.
- Left out (19 entries): speeches, news and blog posts (ECB, SRB, FINMA); newsletters (BCBS AML/CFT, PRA Digest); sanctions notices (Commission, FINMA); addressed to other firms (Commission assurance standards, PRA credit unions, FINMA Bitcoin ETF); EBA advice to the Commission on Taxonomy disclosures; consumer material, an appointment, a moved deadline, statistics, a periodic list and other non-rules.
- ECB Banking Supervision's press feed showed only speeches in the window, and a search of its site found no supervisory press release.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026, 15 names plus Credit … · Bank Focus financials, European banks · 2026-06-30
[2] Web · Basel Framework (LEV, LCR, NSF standards): LCR minimum 100% · 2026-11-15 · https://www.bis.org/basel_framework/
[3] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[4] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, 15 names plus Credit Agricole … · Bank Focus financials, European banks · 2026-06-30
[5] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, CET1 … · 2025-09-30
[6] Moody's (searchCompanyFilings) · ING stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for … · 2025-12-31
[7] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, CET1 … · 2026-03-31
[8] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, … · 2025-12-31
[9] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, required … · 2026-06-30
[10] Moody's (searchCompanyFilings) · Credit Agricole stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Groupe Credit Agricole, First quarter 2026 results … · 2026-03-31
[11] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · EBA: next steps on supervisory reporting simplification, extended timelines · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[13] Web · PRA PS20/26: Amendments to the Large Exposures Framework – Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[15] Web · BCBS: Interest rate risk in the banking book – additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[16] Web · EBA: 2027 EU-wide stress test, more than 55% reduction in requested data · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[17] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions – Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · BCBS: Consolidated guidelines – consequential amendments (consultative) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA: consultation on partially revised Circular 2019/2 'Interest rate risks – … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · PRA CP14/26: Review of the SM&CR – Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[23] Web · BCBS: Global systemically important banks – methodology review (consultative) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review

Regulatory watch tab updated 2026-11-15T22:56:19Z. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html (not published as an Artifact in this run).
