**Regulatory watch: Banks Europe, own 10 names, 30 days** (16 Oct to 15 Nov 2026; 10 names)

The Basel Committee finalised G-SIB window-dressing rules and opened a G-SIB methodology review on 16 Oct; among ranked G-SIBs, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1, and no liquidity rule changed in the window. [1][2][3]

**Who it hits: G-SIB window dressing and methodology review (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -0.95 [3] | 10.51% (30 Sep 2025, older) [4] | 2.46 pp (older) [3][4] | Weaker third |
| ING Groep | 13.07% [3] | -0.85 [3] | 11.03% MDA trigger (31 Dec 2025, older) [5] | 2.04 pp (older) [3][5] | Weaker third |
| Societe Generale | 13.20% [3] | -0.72 [3] | 10.26% (31 Mar 2026) [6] | 2.94 pp [3][6] | Middle |
| Deutsche Bank | 13.92% [3] | 0.00 [3] | not stated | n/a | Middle |
| HSBC Holdings | 14.10% [3] | +0.18 [3] | not stated | n/a | Middle |
| Barclays | 14.30% [3] | +0.38 [3] | 12.2% (31 Dec 2025, older) [7] | 2.10 pp (older) [3][7] | Stronger third |
| UBS Group | 14.38% [3] | +0.46 [3] | 10.83% going-concern (30 Jun 2026) [8] | 3.55 pp [3][8] | Stronger third |
| BPCE | not in Moody's data [9] | not ranked | not stated | n/a | Not ranked: record may not be the consolidated group |

Note: Covers banks on the FSB G-SIB list; score reporting extends to the Basel assessment sample. The Banking Union treatment under review matters for BNP, SG, DB, ING, BPCE. Out of scope: DZ BANK, Raiffeisen Bank International (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only UBS and SG have a current stated requirement. BPCE not ranked: record may not be the consolidated group. [10]

**Who it hits: liquidity channel (Asked) · LCR**

| Name | LCR Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| HSBC Holdings | 134% [11] | -6.12 [11] | 100% [12] | 34.00 pp [11][12] | Least headroom |
| BNP Paribas | 134.77% [11] | -5.35 [11] | 100% [12] | 34.77 pp [11][12] | Least headroom |
| ING Groep | 137% [11] | -3.12 [11] | 100% [12] | 37.00 pp [11][12] | Middle |
| Deutsche Bank | 140.12% [11] | 0.00 [11] | 100% [12] | 40.12 pp [11][12] | Middle |
| Societe Generale | 146.41% [11] | +6.29 [11] | 100% [12] | 46.41 pp [11][12] | Middle |
| Barclays | 157.7% [11] | +17.58 [11] | 100% [12] | 57.70 pp [11][12] | Most headroom |
| UBS Group | 177.28% [11] | +37.16 [11] | 100% [12] | 77.28 pp [11][12] | Most headroom |
| Raiffeisen Bank International | 143.65% [11] | not ranked | 100% [12] | 43.65 pp [11][12] | Not ranked: record may not be the consolidated group |
| DZ BANK | 148.75% [11] | not ranked | 100% [12] | 48.75 pp [11][12] | Not ranked: record may not be the consolidated group |
| BPCE | not in Moody's data [9] | not ranked | 100% [12] | n/a | Not ranked: record may not be the consolidated group |

Note: No rule change found; shown because asked. The 100% Basel minimum covers all ten names; local rules can be higher. Not ranked: BPCE, DZ BANK, Raiffeisen Bank International (records may not be the consolidated group). [12]

**What changed**

- [Asked] **Liquidity channel (LCR)** (Liquidity): No regulatory change to the LCR or other liquidity requirements was found at the seven primary regulators between 16 Oct and 15 Nov 2026. EBA's reporting item moves liquidity reporting templates to December 2028. [13]
- [NEW] **PRA** (Final): PS20/26 finalises the remaining Large Exposures changes from CP14/24 (securities financing, trading book, credit risk mitigation), including a single 350% higher NCLEG limit. Takes effect 1 January 2028. Channel: large exposures. [14]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published; in force 1 January 2027 with a four-month transition. Channel: AML. [15]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded gains and losses, earnings indicators, and new supervisory reporting. Comments by 9 February 2027. Channel: IRRBB. [16]
- [NEW] **EBA** (Other): Final methodology and milestones for the 2027 EU-wide stress test: launch in January 2027, results at the end of July 2027; data points reduced by 55% (headline: "more than 55%"). Channel: stress testing. [17]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: final report due December 2026; first reference date December 2027, and December 2028 for liquidity, asset encumbrance, benchmarking and ESG. Channel: reporting. [13]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance aligned with CRD VI; application date not stated on the page. Moody's (11 Nov 2026) calls them credit positive for small EU banks. Channel: governance. [18][19]
- [NEW] **Basel Committee** (Consultation): Consequential amendments repointing Basel Framework cross-references to the new consolidated guidelines. Comments by 21 December 2026. No row in the channel map; treated as watch by judgment. [20]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 "Interest rate risks - banks" to apply the Basel Committee's recalibrated rate shocks of July 2024. Comments by 15 January 2027. Channel: IRRBB. [21]
- [NEW] **European Commission** (Other): Political agreement on the Securitisation Framework review, which amends the CRR to make securitisation capital treatment more risk sensitive. Awaits formal approval; application date not stated. Channel: securitisation. [22]
- [NEW] **PRA** (Consultation): CP14/26 proposes moving many Senior Manager roles from pre-approval to notification and removing Certification Regime requirements. Comments by 22 January 2027. Channel: governance, conduct. [23]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be calculated on averages over the reporting year rather than year-end values, by 1 January 2030; the reporting threshold rises from 200 billion EUR to 350 billion EUR from 1 January 2027. Channel: G-SIB buffer (CET1). [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review asks whether to add the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 January 2027. Channel: G-SIB buffer (CET1). [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) [14] | HSBC, Barclays | large exposures | Watch |
| FINMA AML Ordinance (10 Nov) [15] | UBS | AML | Watch |
| Basel IRRBB Pillar 2 guidance (9 Nov) [16] | all ten, once applied at home | IRRBB | Watch |
| EBA 2027 stress test (9 Nov) [17] | scope not known: EU names in the EBA sample, not named in the release | stress test results | Watch |
| EBA reporting simplification (6 Nov) [13] | BNP, DB, ING, SG, BPCE, DZ, RBI | reporting | Watch |
| EBA internal governance guidelines (5 Nov) [18] | BNP, DB, ING, SG, BPCE, DZ, RBI | governance | Watch |
| Basel consolidated guidelines amendments (5 Nov) [20] | all ten, once applied at home | none (framework cross-references) | Watch |
| FINMA Circular 2019/2 interest rate risks (4 Nov) [21] | UBS | IRRBB | Watch |
| EU Securitisation Framework review (22 Oct) [22] | BNP, DB, ING, SG, BPCE, DZ, RBI | securitisation | Watch |
| PRA CP14/26 SM&CR phase 2 (22 Oct) [23] | HSBC, Barclays | governance, conduct | Watch |

Note: Moody's data carries no metric for these channels, so no name is given a position.

**Names**

Seven names taken from the checked list. Resolved for this run: BPCE (FR), DZ BANK AG (DE), Raiffeisen Bank International AG (AT); all hold current Moody's ratings. Saved as banks-europe-own.json.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (18): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (Basel AML/CFT, PRA Digest); sanctions notices (FINMA, Commission); periodic list (ECB); appointments (EBA, Commission); consumer material and NGFS declaration (EBA); advice to the Commission (EBA); moved deadlines (EBA); other firms (PRA credit unions, FINMA ETF, assurance standards).
- FSB 2026 G-SIB list not found on fsb.org on 15 Nov 2026; the 27 Nov 2025 list is used. BPCE's record has no Q2 2026 data.
- Scope is judged for each group at home: EU subsidiaries of HSBC, Barclays and UBS are not counted under EU items.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · CET1 ratio, seven G-SIBs · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Groep Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, shown … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays overall capital requirement for CET1 · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 … · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · BPCE: LQ returned Q4 2024 without CET1 or LCR; Q2 2026 returned no data · BPCE · 2024-12-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 · LCR, nine banks · 2026-06-30
[12] Web · Basel Framework (LEV, LCR, NSF standards) · 2026-11-15 · https://www.bis.org/basel_framework/
[13] Web · EBA outlines next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[14] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[16] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[18] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[19] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[20] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[21] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[22] Web · Commission welcomes political agreement on review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[23] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Dashboard: Regulatory watch tab updated 15 Nov 2026, 22:57 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-11-coop-names/dashboard/dashboard.html. Not published to the private link in this session.
