**Earnings: Vodafone, recap** (H1 FY27 (six months to 30 Sep 2026), results call 10 Nov 2026; 1 name)

Vodafone (Baa2 senior unsecured, stable) raised FY27 guidance at its H1 results on 10 Nov 2026, but company-reported net debt rose by EUR 8.1bn to EUR 33.5bn after the VodafoneThree buyout and Safaricom stake; Moody's-adjusted debt/EBITDA of 3.25x (FY to Mar 2026) is 0.05x below the 3.3x downgrade trigger. [1][2][3][4]

**Results against the credit view**

- (Guidance): Guidance raised: management said the top of the former FY27 ranges is now the midpoint, which implies about 7% organic adjusted EBITDA growth and 21% adjusted free cash flow growth. Europe guidance unchanged; the absolute ranges are not in the excerpts returned. [5]
- (H1 delivery): Company-reported: group service revenue +6.4% in Q2 and adjusted EBITDA +6.4% in H1; Germany EBITDA -3.2%, of which 2 points from a provision of about EUR 100m after an ECJ ruling. No half-year comparison with Moody's forecasts is possible: they are fiscal-year only. [4][5]
- (Net debt): Company-reported net debt EUR 33,473m at 30 Sep 2026 against EUR 25,411m at 31 Mar 2026. Drivers: acquisitions and disposals EUR 6,957m (VodafoneThree EUR 5,019m, 15% of Safaricom EUR 1,379m, net debt acquired EUR 537m), free cash outflow EUR 845m, dividends EUR 544m, buybacks EUR 92m. [2]
- (Liquidity): Cash and short-term investments EUR 8.4bn (EUR 12.4bn at 31 Mar 2026); undrawn revolving facilities EUR 7.6bn, maturing 2028 (USD 4.0bn) and 2031 (EUR 4.1bn). Moody's notes the facilities carry no financial covenants or MAC clauses. [2][6]
- (Refinancing): Company-reported gross debt rose to EUR 42.7bn from EUR 38.6bn, mainly new bonds (+EUR 2.3bn) and bank loans (+EUR 1.2bn); current borrowings EUR 6.8bn. The company caps debt maturing in any one calendar year. [2][7]
- (Capex): Capital additions EUR 3,320m in H1 against EUR 2,800m a year earlier; management does not guide to any material cut in German capital intensity. Equity for the OXG fibre JV will be phased; up to EUR 1.2bn is the analyst's figure, not the company's. [2][5]
- (Returns, other): Interim dividend 2.306 eurocents, +2.5%. A non-cash German impairment, about three-quarters from a higher discount rate (8% against 7.5%), left an H1 loss to owners of EUR 4,789m. [2][5]

**Against Moody's triggers**

| Metric | Moody's-adjusted, FY to 31 Mar 2026 | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x [3] | below 2.5x [4] | fails to remain below 3.3x, sustained [4] | 0.05x to downgrade level; 0.75x to upgrade level [3][4] |
| RCF / Net debt | 33.1% [3] | above 25%, sustained [4] | towards 18%, sustained [4] | upgrade level already met, by 8.1 points; 15.1 points to downgrade level [3][4] |

Note: Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade on "a failure to turn around its German operations". Moody's forecasts for FY27: debt/EBITDA 3.1x, RCF/net debt 29.4%. [4]

**What it means for the rating and outlook**

- (Position): Debt/EBITDA is 0.05x below the 3.3x downgrade level; RCF/net debt is above both levels. The stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt around 30% and net leverage in the lower half of the company's 2.25x-2.75x target. [3][4]
- (Timing): The credit opinion (21 Oct 2026) and the affirmation (13 Oct 2026) predate these results. The Moody's-adjusted figures are for the year to 31 Mar 2026; company-reported net debt has risen EUR 8.1bn since then, mainly from the VodafoneThree buyout and the Safaricom stake. [2][4][6]
- (Moody's view): The opinion says the rating is constrained by "reduced financial flexibility following the buyout of VodafoneThree"; the opinion text returned does not mention Safaricom. Moody's has published no comment on the H1 results; its latest action is the 13 Oct 2026 affirmation. [4][6]

**Notes**

- Recap chosen because Moody's holds the H1 FY27 call of 10 Nov 2026, within the last 21 days.
- Company-reported net debt and gross debt are Vodafone's own measures, not Moody's-adjusted debt; they are shown beside the Moody's figures, not compared as the same measure.

**Sources**

[1] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-15
[2] Moody's (searchCompanyFilings) · Vodafone Group Plc Interim Report 2026 - Q4 · Interim report, half-year to 30 Sep 2026 (titled 'Interim Report 2026 - Q4'), submission … · 2026-09-30
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted): Debt / EBITDA, RCF / Net Debt, fiscal year ended 31 … · Vodafone Group Plc · 2026-03-31
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections Summary, Upgrade, Downgrade, Outlook, Key indicators · 2026-10-21
[5] Moody's (searchCompanyFilings) · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call · Earnings call transcript: Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, … · 2026-11-10
[6] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action · 2026-10-13
[7] Moody's (searchCompanyFilings) · Vodafone Group Plc Annual Report 2026 - Q1 · Annual report, fiscal year to 31 Mar 2026 (titled 'Annual Report 2026 - Q1'), submission … · 2026-03-31

Earnings tab updated 2026-11-15 22:51 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review-earn-vodafone/dashboard/dashboard.html (not published as an Artifact in this run).
