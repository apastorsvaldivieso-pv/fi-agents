**Regulatory watch: Banks Europe, own list, 30 days** (30 days, 16 Oct to 15 Nov 2026; 12 names)

Twelve new measures in 30 days; only the Basel G-SIB changes reach a Moody's metric, covering eight of your twelve banks on CET1.

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported) | vs median 14.01% (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% (Q2 2026) [1] | -1.04 [1] | 10.51%, 30 Sep 2025, older [2] | +2.46 pp (older) [1][2] | Weaker third |
| ING Groep | 13.07% (Q2 2026) [1] | -0.94 [1] | 11.03% MDA trigger, 31 Dec 2025, older [3] | +2.04 pp (older) [1][3] | Weaker third |
| Societe Generale | 13.2% (Q2 2026) [1] | -0.81 [1] | 10.26%, against 31 Mar 2026 [4] | +2.94 pp [1][4] | Middle |
| Deutsche Bank | 13.92% (Q2 2026) [1] | -0.09 [1] | not stated | not stated | Middle |
| HSBC Holdings | 14.1% (Q2 2026) [1] | +0.09 [1] | not stated | not stated | Middle |
| Barclays | 14.3% (Q2 2026) [1] | +0.29 [1] | 12.2%, 31 Dec 2025, older [5] | +2.10 pp (older) [1][5] | Middle |
| UBS Group | 14.38% (Q2 2026) [1] | +0.37 [1] | 10.83% going-concern, 30 Jun 2026 [6] | +3.55 pp [1][6] | Stronger third |
| Groupe Credit Agricole | 17.23% (Q2 2026) [7] | +3.22 [1][7] | total not stated | +6.7 pp, bank-stated, 31 Mar 2026 [8] | Stronger third |

Note: Basel says the revisions "will require banks" to report average G-SIB indicators; the G-SIB buffer falls only on banks on the FSB list (27 Nov 2025; no 2026 list yet). Out of scope: Danske Bank, KBC Group, Banco Sabadell, Swedbank (not on the list). Ranked by level: only 3 names have a current requirement. Issuer on your list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [8][9][10][11]

**Who it hits: G-SIB methodology review, banking-union exposures (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported) | vs median | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% (Q2 2026) [1] | not ranked | 10.51%, 30 Sep 2025, older [2] | +2.46 pp (older) [1][2] | list too short to rank |
| ING Groep | 13.07% (Q2 2026) [1] | not ranked | 11.03%, 31 Dec 2025, older [3] | +2.04 pp (older) [1][3] | list too short to rank |
| Societe Generale | 13.2% (Q2 2026) [1] | not ranked | 10.26%, against 31 Mar 2026 [4] | +2.94 pp [1][4] | list too short to rank |
| Deutsche Bank | 13.92% (Q2 2026) [1] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% (Q2 2026) [7] | not ranked | total not stated | +6.7 pp, bank-stated, 31 Mar 2026 [8] | list too short to rank |

Note: Consultation; the page names no group. The treatment concerns cross-border exposures within the banking union, so only banking-union G-SIBs are shown (our reading). Out of scope: HSBC, Barclays, UBS (outside the banking union); Danske Bank, KBC Group, Banco Sabadell, Swedbank (not on the FSB list of 27 Nov 2025). [9][12]

**What changed**

- [NEW] **FINMA, 10 Nov** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published, aligning it with the revised AMLA and AMLO; in force 1 Jan 2027. [13]
- [NEW] **PRA, 10 Nov** (Final): PS20/26 completes the large exposures reforms: the substitution approach becomes mandatory and internal models for securities financing exposure values are removed. Takes effect 1 Jan 2028. [14]
- [NEW] **Basel Committee, 9 Nov** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book: model validation, stress testing, embedded gains and losses, earnings indicators. Comments by 9 Feb 2027. [15]
- [NEW] **EBA, 9 Nov** (Other): 2027 EU-wide stress test methodology final, with "more than 55%" fewer data points and a first separate climate module; launch end-Jan 2027, results end-Jul 2027. [16]
- [NEW] **EBA, 6 Nov** (Other): Supervisory reporting simplification: first reference date moves to Dec 2027; liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final report due Dec 2026. [17]
- [NEW] **EBA, 5 Nov** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10), aligned with CRD VI; application date not stated. *Why it matters:* Moody's calls them credit positive, mostly for smaller banks, as larger banks already apply them (11 Nov). [18][19]
- [NEW] **Basel Committee, 5 Nov** (Consultation): Consequential amendments moving cross-references and some application guidance from the Basel Framework into the consolidated guidelines. Comments by 21 Dec 2026. [20]
- [NEW] **FINMA, 4 Nov** (Consultation): Revision of Circular 2019/2 "Interest rate risks - banks": recalibrated Basel shock scenarios and more weight on earnings effects. Comments by 15 Jan 2027. [21]
- [NEW] **European Commission, 22 Oct** (Legislative): Provisional agreement on the securitisation framework review, making the CRR treatment of securitisations "more risk sensitive". Formal adoption pending; Council aims for end-2026. [22]
- [NEW] **PRA, 22 Oct** (Consultation): CP14/26 SM&CR Phase 2: pre-approval removed for almost half of Senior Manager Functions and Certification Regime ended for about 7,700 individuals. Comments by 22 Jan 2027. [23]
- [NEW] **Basel Committee, 16 Oct** (Final): G-SIB indicators to be reported on average values, not year-end, by 1 Jan 2030; leverage exposure disclosure threshold up to EUR 350 billion from 1 Jan 2027. *Why it matters:* Changes how G-SIB scores, and so the buffer, are measured. [10]
- [NEW] **Basel Committee, 16 Oct** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the banking union to the G-SIB framework. Comments by 14 Jan 2027. [12]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| Basel: IRRBB Pillar 2 guidance (consultation) | all 12, once home rules apply it | interest rate risk in the banking book: no field | Watch |
| FINMA: Circular 2019/2 interest rate risk (consultation) | UBS | interest rate risk in the banking book: no field | Watch |
| Basel: consolidated guidelines amendments (consultation) | all 12, once home rules apply it | none (cross-references only) | Watch |
| EBA: 2027 EU-wide stress test | scope not known: sample not named (9 EU/EEA names) | stress testing: no field | Watch |
| EBA: supervisory reporting timelines | 9 EU/EEA names | reporting: no field | Watch |
| EBA: internal governance guidelines (final) | 9 EU/EEA names | governance: no field | Watch |
| EU: securitisation framework (political agreement) | 9 EU/EEA names | securitisation: no field | Watch |
| PRA: PS20/26 large exposures (final) | HSBC, Barclays | large exposures: no field | Watch |
| PRA: CP14/26 SM&CR (consultation) | HSBC, Barclays | governance: no field | Watch |
| FINMA: AML Ordinance (final) | UBS | AML: no field | Watch |

Note: Moody's data carries no field for these channels. EU/EEA names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, Danske Bank, KBC Group, Banco Sabadell, Swedbank. Scope is judged at group level; EU subsidiaries of HSBC, Barclays and UBS are not counted.

**Your list**

HSBC (GB), BNP Paribas (FR), Deutsche Bank (DE), UBS (CH), Barclays (GB), ING (NL), Societe Generale (FR), Credit Agricole (FR), and four names resolved in Moody's for this run: Danske Bank A/S (DK), KBC Group N.V. (BE), Banco de Sabadell, S.A. (ES), Swedbank AB (SE). All twelve resolved.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (21 entries): speeches, interviews, blogs and newsletters (ECB, SRB, FINMA, Basel, PRA); sanctions notices; periodic lists and statistics; appointments; consumer material; advice or reports to other authorities; a moved EBA deadline; measures for credit unions, fund providers or auditors.
- The Basel window-dressing page carries a "Forthcoming" label while its text says the Committee has finalised the amendments; shown as final.
- Moody's research found no comment in the window on the G-SIB changes, securitisation or IRRBB.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, 12 names in one call · Bank financials, latest quarter · 2026-06-30
[2] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, CET1 capital … · 2025-09-30
[3] Moody's (searchCompanyFilings) · ING stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Groep Form 20-F 2025, MDA trigger level for … · 2025-12-31
[4] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, CET1 … · 2026-03-31
[5] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F 2025, overall capital … · 2025-12-31
[6] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Group AG second quarter 2026 report, required … · 2026-06-30
[7] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 … · Groupe Credit Agricole · 2026-06-30
[8] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated distance · bank sector file, pulled 15 Nov 2026: Credit Agricole first quarter 2026 results slides: … · 2026-03-31
[9] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[10] Web · Basel Committee, Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[11] Moody's financials (getEntityFinancials_v2) · Credit Agricole S.A., Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · Credit Agricole S.A. · 2026-06-30
[12] Web · Basel Committee, Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[13] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · PRA PS20/26, Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · Basel Committee, Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[16] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[17] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[18] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[19] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[20] Web · Basel Committee, Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[21] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[22] Web · Commission welcomes political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[23] Web · PRA CP14/26, Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper


Regulatory watch tab updated 15 Nov 2026, 22:58 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html (not published as an Artifact in this run).
