**Regulatory watch: Banks Europe, 7 days** (8 Nov to 15 Nov 2026 (7 days, both ends included); 15 names)

Four new items in the week, none on a metric Moody's data carries: the PRA finalised the rest of its large-exposures changes for UK banks (in force 1 Jan 2028), and the Basel Committee is consulting on extra Pillar 2 guidance for interest rate risk in the banking book. [1][2]

**What changed**

- [NEW] **PRA, 10 Nov** (Final): PS20/26 finalises the remaining large-exposures proposals from CP14/24: no internal models for securities financing exposure values, a reduced and time-limited trading book allowance, and a higher intragroup limit of 350% of Tier 1. Takes effect 1 January 2028. Channel: large exposures. *Why it matters:* Changes concentration limits for HSBC, Barclays and Lloyds; Moody's data carries no large-exposures metric. [1]
- [NEW] **FINMA, 10 Nov** (Final): FINMA published its partially revised Anti-Money Laundering Ordinance, in force 1 January 2027, and narrowed the correspondent banking rules to clients with direct access to the correspondent bank's accounts. Channel: AML. *Why it matters:* A compliance and conduct-risk item for UBS, with no capital or liquidity metric attached. [3]
- [NEW] **Basel Committee, 9 Nov** (Consultation): Proposed extra Pillar 2 guidance on interest rate risk in the banking book: model validation, stress testing, embedded gains and losses in securities portfolios, earnings indicators and new supervisory reporting. Comments by 9 February 2027. Channel: interest rate risk in the banking book. *Why it matters:* Could raise supervisory scrutiny of banks with large unrealised securities losses once finalised and applied at home. [2]
- [NEW] **EBA, 9 Nov** (Final): Final methodology, with draft templates, for the 2027 EU-wide stress test, cutting requested data by more than 55% and adding a climate module that does not affect core results. Launch end of January 2027, results end of July 2027. Channel: stress testing. *Why it matters:* Sets the timetable for stress-test results that feed into banks' Pillar 2 guidance. [4]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26, large exposures (final) [1] | HSBC, Barclays, Lloyds (UK groups) | Large exposures to capital | Watch |
| FINMA AML Ordinance (final) [3] | UBS (Swiss group) | None: AML | Watch |
| Basel IRRBB Pillar 2 guidance (consultation) [2] | All 15, once home countries apply it | IRRBB measures (EVE, NII sensitivity) | Watch |
| EBA 2027 stress test methodology (final) [4] | Scope not known: banks in the EBA sample; the 11 EU/EEA groups on the list are candidates | Stress-test capital depletion | Watch |

Note: Moody's data carries no metric for these channels, so no name is positioned. Scope by issuer: PRA rules cover UK groups, FINMA Swiss groups, EBA EU/EEA groups. The EBA page says its methodology defines the sample but gives no names; the sample was not read. The Basel page states no narrower scope. Moody's had published no comment on these four items by 15 Nov. [5]

**Notes**

- Left out (8 in the window): speeches and news (SRB, 10-13 Nov); a newsletter (ECB, 11 Nov); communication between authorities (ECB written overview to the Eurogroup, 9 Nov); consumer material (EBA factsheet, 9 Nov); not a measure for banks (EBA support for the NGFS declaration, 13 Nov; Commission dialogue summary, 11 Nov); appointments (Commission stakeholder group, 9 Nov); addressed to other firms (Commission limited assurance standards consultation, 12 Nov).
- No item maps to a Moody's metric, so no financials call was made and no name is ranked.
- The ECB Banking Supervision press feed was last built on 6 Nov; an ECB item from 7-15 Nov could be missing from it. A search of the ECB site found no press release in the window.

**Sources**

[1] Web · PRA: PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[2] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[3] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[4] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[5] Moody's (searchAllDocuments) · Moody's research search, 9-15 Nov 2026 · Banking, Europe and United Kingdom, published 9-15 Nov 2026, keywords IRRBB / EBA 2027 … · 2026-11-15

Regulatory watch tab updated 15 Nov 2026 22:53 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html (not published as an Artifact in this run).
