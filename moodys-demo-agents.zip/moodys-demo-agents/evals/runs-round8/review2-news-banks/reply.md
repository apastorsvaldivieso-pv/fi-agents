**Daily sector news: Banks, Europe, 7 days** (168h (7 days) from 8 Nov 2026 22:49 UTC to 15 Nov 2026 22:49 UTC; 15 names)

UniCredit expects the last approvals for control of Commerzbank by end-November; Credit Agricole opened talks to merge CA Italia with Banco BPM, which Moody's says has no immediate rating implications; HSBC refinanced USD 1.5bn of AT1. [1][2][3]

**Top this week**

- **UniCredit / Commerzbank** (Deals): After Q3 results (reported 9 Nov) UniCredit raised its 2026 net profit ambition to well above EUR 11.5bn and expects the remaining Commerzbank approvals by end-November; it sold USD 3.5bn of senior non-preferred bonds on 13 Nov. *Why it matters:* Moody's says UniCredit's baa2 BCA, on review for upgrade, could rise once it controls and consolidates Commerzbank; senior ratings stay capped by Italy's rating. [1][4][5][6][7]
- **Credit Agricole S.A.** (Deals): On 9 Nov Credit Agricole proposed talks to merge Credit Agricole Italia with Banco BPM; Banco BPM's board opened discussions on 13 Nov, its chairman saying there is a lot of work to do. *Why it matters:* Moody's said on 13 Nov the talks likely have no immediate rating implications for CASA, Groupe Credit Agricole, Banco BPM or CA Italia, and could ultimately be positive for Banco BPM. [2][8]
- **HSBC Holdings plc** (Funding): HSBC issued USD 1.5bn of 7.625% perpetual AT1 on 13 Nov, meeting the new-issue condition of its tender for up to USD 1.5bn of 6.000% AT1 callable from 22 May 2027. *Why it matters:* Moody's positive outlook on HSBC's A3 senior debt rests on strong capital and funding; one stated upgrade route is loss-absorbing capital beyond what the group has announced. [3][9]

**Macro**

- Markets were still pricing two more ECB rate hikes (15 Nov); US and euro-area bond yields rose on 13 Nov. [10][11]

**Sector**

- (Moody's research): Moody's said the EBA's revised internal governance guidelines are credit positive for EU banks, more so for smaller ones (11 Nov). It also said Greek competition proposals are unlikely to erode the big four Greek banks' deposit franchises (13 Nov; not on the list). [12][13]
- (Rating actions): Subsidiaries only, not on the list: Moody's upgraded Intesa's Slovak unit VUB's deposit ratings to A1 (12 Nov) and assigned Baa1 issuer ratings to UniCredit Bank Czech Republic and Slovakia, affirming A2 deposits (9 Nov). The search returned no rating action on the 15 listed groups. [14][15]
- (Outlook): Latest Moody's global banks outlook is stable (3 Dec 2025). Country outlooks: Germany and Finland positive; UK, France, Switzerland, Netherlands, Italy and Spain stable (Feb-Mar 2026). [16][17][18][19][20][21][22]

**By name**

| Name | Moody's rating | This week |
|---|---|---|
| BNP Paribas | A1 LT Issuer Rating, stable [23] | No material credit news. |
| HSBC Holdings plc | A3 Senior Unsecured, positive [23] | USD 1.5bn 7.625% AT1 issued; tender for 6.000% AT1 (Top). [3] |
| Credit Agricole S.A. | A1 LT Issuer Rating, stable [23] | Banco BPM merger talks opened (Top). [2] |
| Barclays PLC | Baa1 LT Issuer Rating, stable [23] | No material credit news. |
| Societe Generale | A1 LT Issuer Rating, negative [23] | No material credit news. |
| Deutsche Bank AG | A1 LT Issuer Rating, positive [23] | BaFin fined it EUR 8m (11 Nov) over Postbank migration failings. [24] |
| UBS Group AG | A2 Senior Unsecured, stable [23] | Swiss capital proposal goes to parliamentary commission 23-24 Nov; single source, unconfirmed. [25] |
| ING Groep N.V. | Baa1 Senior Unsecured, stable [23] | OCBC reported near a USD 1.5bn deal for ING's Asian private-banking assets; single source, unconfirmed. [26] |
| Lloyds Banking Group plc | A3 Senior Unsecured, stable [23] | Filed indenture for USD 1.25bn and USD 1.5bn senior callable notes (13 Nov). [27] |
| UniCredit S.p.A. | A3 Senior Unsecured, stable; BCA and junior/subordinated ratings on review for upgrade [6][23] | Commerzbank approvals, FY26 ambition, USD 3.5bn SNP (Top). [1][4][5] |
| Intesa Sanpaolo S.p.A. | A3 LT Issuer Rating, stable [23] | Moody's credit opinion update (12 Nov); GBP 500m green SNP; criticised 2027 budget bank levies (no cost given). [28][29][30] |
| Banco Bilbao Vizcaya Argentaria, S.A. | A2 LT Issuer Rating, stable [23] | EUR 1bn AT1 placed (12 Nov); filed for USD 2.05bn notes (13 Nov). [31][32] |
| CaixaBank, S.A. | A2 LT Issuer Rating, stable [23] | Green senior preferred bond, EUR 1bn per SeeNews (10 Nov). [33] |
| Commerzbank AG | A2 LT Issuer Rating, stable [23] | UniCredit plans EGM once in control; reaffirmed at least EUR 3.4bn 2026 net profit. [34] |
| Nordea Bank Abp | Aa3 Senior Unsecured, stable [23] | Danish court AML verdict (2012-15), fine about EUR 20m (9 Nov). [35][36] |

Note: Rating class as Moody's returned it per name; outlook is on that rating.

**Notes**

- Window is 7 days to the run time, as asked; news searches covered 8 Nov 22:49 to 15 Nov 22:49 UTC, Moody's document searches whole days 8-15 Nov.
- Nordea fine: sources differ (EUR 20m Daily Finland, EUR 21m SeeNews, USD 23m Dow Jones).
- Dropped as older news retold in the window: Q3 results of BNP Paribas, HSBC and Lloyds, and BNP's EUR 1.3bn buyback (announced 28 Oct).

**Sources**

[1] Moody's (searchNews) · UniCredit's Orcel Sets November Deadline (Ad Hoc News) · 2026-11-15
[2] Moody's (searchNews) · Moody's says Credit Agricole's offer to merge its Italian subsidiary with Banco … · 2026-11-13
[3] Moody's (searchNews) · HSBC Holdings plc announces satisfaction of the new issue condition (PR … · 2026-11-13
[4] Moody's (searchNews) · UniCredit stock: Results and US bond issue shape weekly focus (Ad Hoc News) · 2026-11-14
[5] Moody's (searchNews) · UniCredit returns to US market with USD 3.5bn Senior Non-Preferred issuance … · 2026-11-13
[6] Moody's (searchAllDocuments) · Moody's Ratings places UniCredit S.p.A. on review for upgrade · PR_526711 · 2026-07-21
[7] Moody's (getCreditOpinion) · UniCredit S.p.A.: Update following placement of ratings on review for upgrade · PBC_1490860, upgrade factors and outlook · 2026-07-30
[8] Moody's (searchNews) · Credit Agricole: Bpm gives go-ahead to talks (MarketScreener) · 2026-11-13
[9] Moody's (getCreditOpinion) · HSBC Holdings plc: Update to credit analysis · PBC_1491170, upgrade factors and outlook · 2026-09-29
[10] Moody's (searchNews) · Markets still pricing in two more ECB rate hikes (WN) · 2026-11-15
[11] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Dow Jones via … · 2026-11-13
[12] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[13] Moody's (searchAllDocuments) · Banks - Greece: competition commission's proposals unlikely to erode big four … · PBC_1502178 · 2026-11-13
[14] Moody's (searchAllDocuments) · Moody's upgrades Vseobecna uverova banka's deposit ratings to A1 · PR_531483 · 2026-11-12
[15] Moody's (searchAllDocuments) · Moody's assigns Baa1 issuer ratings to UniCredit Bank Czech Republic and … · PR_530435 · 2026-11-09
[16] Moody's (searchAllDocuments) · Banks - Global: 2026 Outlook - Stable · PBC_1462959 · 2025-12-03
[17] Moody's (searchAllDocuments) · Banking System Outlook - Germany: Outlook turns positive · PBC_1470410 · 2026-02-09
[18] Moody's (searchAllDocuments) · Banking System Outlook - Finland: Outlook moves positive · PBC_1475274 · 2026-03-09
[19] Moody's (searchAllDocuments) · Banking System Outlook - United Kingdom: Outlook remains stable · PBC_1463131 · 2026-02-10
[20] Moody's (searchAllDocuments) · Banking System Outlook - France: Outlook stable · PBC_1470906 · 2026-02-09
[21] Moody's (searchAllDocuments) · Banking System Outlook - Switzerland: Outlook stable · PBC_1468651 · 2026-02-11
[22] Moody's (searchAllDocuments) · Banking System Outlooks - Netherlands, Italy, Spain: stable · PBC_1470890 (NL), PBC_1469157 (IT), PBC_1471281 (ES) · 2026-02-11
[23] Moody's ratings (getEntityRatings) · Moody's ratings, coverage list · 2026-11-15
[24] Moody's (searchNews) · Deutsche Bank AG: BaFin imposes administrative fines · 2026-11-14
[25] Moody's (searchNews) · UBS Matures Ten ETN Lines as Bern Weighs Softer Capital Yardstick (Ad Hoc News) · 2026-11-14
[26] Moody's (searchNews) · ING Groep stock in focus as OCBC nears Asian private-bank deal (Ad Hoc News) · 2026-11-13
[27] Moody's (searchNews) · Lloyds Banking Group files supplemental indenture for senior callable notes … · 2026-11-13
[28] Moody's (searchAllDocuments) · INTESA SANPAOLO S.P.A.: Update to credit analysis · PBC_1501726 · 2026-11-12
[29] Moody's (searchNews) · Intesa Sanpaolo places GBP 500 million Green Senior Non-Preferred Bond … · 2026-11-13
[30] Moody's (searchNews) · Intesa criticises Italy for bank levies in 2027 budget, says ECB may intervene … · 2026-11-12
[31] Moody's (searchNews) · BBVA places EUR 1 billion of a 'CoCo' (Contify) · 2026-11-12
[32] Moody's (searchNews) · Banco Bilbao files documents for proposed USD 2.05 billion note offering … · 2026-11-13
[33] Moody's (searchNews) · Caixabank raises EUR 1bn through green bond (SeeNews) · 2026-11-10
[34] Moody's (searchNews) · Commerzbank Faces a February Reckoning (Ad Hoc News) · 2026-11-14
[35] Moody's (searchNews) · Nordea receives verdict in case about anti-money laundering measures from 2012 … · 2026-11-09
[36] Moody's (searchNews) · Nordea fined EUR 20m for inadequate anti-money laundering measures (Daily … · 2026-11-09

Daily sector news tab updated 15 Nov 2026 22:53 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review2-news-banks/dashboard/dashboard.html (not published to the private link in this run).
