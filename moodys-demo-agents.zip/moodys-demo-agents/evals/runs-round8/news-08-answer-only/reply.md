**European telecoms, sector news brief: 7 days to 15 Nov 2026**
Window: 8 Nov 2026 00:00 UTC to 15 Nov 2026 22:51 UTC (about 191h, whole calendar days because Moody's document search filters by day). 15 names from the checked Telecoms Europe list.

**Headline:** Two Nordic operators made acquisitions. Telia agreed to buy Telavox's Nordic enterprise customer base for SEK 3.8bn [2], and Telenor took majority control of Bahnhof [3]. Telefonica raised its full-year guidance [4].

## Top this week

1. **Telia: SEK 3.8bn enterprise acquisition (agreed 12 Nov).** Telia signed a binding agreement to buy Telavox's Nordic enterprise customer base for SEK 3.8bn, plus a possible SEK 0.2bn earn-out, and to license Telavox's UCaaS platform [2]. The customer base brings about SEK 1.1bn of annual revenue [2]. *Why it matters:* Moody's stable outlook assumes adjusted gross debt/EBITDA stays below 3.0x and RCF/net debt above 22% [5]. The sources do not say how the deal is funded.

2. **Telenor: control of Bahnhof (completed 11 Nov, mandatory offer open).** Telenor Sverige bought 57.5% of Bahnhof's shares and 87.9% of the votes [3], reported at about USD 363m [3]. It then launched a mandatory cash offer at SEK 62 per share and now holds about 66.9% of shares and 90.6% of votes. Bahnhof's independent committee recommends that shareholders accept [3]. *Why it matters:* Moody's positive outlook (Baa1 [1]) includes "no M&A transaction beyond the GlobalConnect Group deal" [6].

3. **Telefonica: Q3 results and higher guidance (12 Nov).** Q3 net income was EUR 802m, against EUR 276m a year earlier [4]. Revenue was EUR 8.43bn, up 4.8% (2.2% at constant currency) [4]. Guidance for adjusted EBITDA, operating cash flow after leases and free cash flow went up [4]. *Why it matters:* the stable outlook expects Moody's-adjusted net leverage to fall sustainably below 3.75x, and 3.75x or above is a downgrade trigger [7].

## Macro
- Euro-area and US bond yields rose on 13 Nov [8]. Headlines on 15 Nov said markets still price in two more ECB rate hikes [8].

## Sector
- The search found no Moody's rating actions on European telecoms published in the window.
- Odido Group Holding (not on the list): Moody's says new notes funding Apax's purchase of the company will raise leverage, but credit quality is unchanged (Issuer Comment, 11 Nov) [9].
- Latest Moody's sector outlook: Telecommunications – Global, **stable**, published 27 Oct 2026 [10]. It cites solid demand and lower capital intensity.

## By name

| Name | Moody's rating, outlook | Credit news in window |
|---|---|---|
| Deutsche Telekom | A3 Senior Unsecured, stable [1] | No material credit news. Q3 results and guidance came out on 5 Nov, before the window. |
| Orange | Baa1 LT Issuer, stable [1] | No material credit news. |
| Vodafone Group | Baa2 Senior Unsecured, stable [1] | Half-year results raised full-year profit and cash-flow guidance [11]. Single source, unconfirmed. Dividend ex-date is 19 Nov [11]. |
| Telefonica | Baa3 Senior Unsecured, stable [1] | See Top 3 [4]. |
| Swisscom | A2 LT Issuer, stable [1] | No material credit news. Q3 results came out before the window. |
| Telekom Austria | A3 LT Issuer, stable [1] | No material credit news. |
| Proximus | A3 Senior Unsecured, stable [1] | No material credit news. Q3 results came out on 30 Oct. |
| Telenor | Baa1 Senior Unsecured, positive [1] | See Top 2 [3]. |
| Telia | Baa1 Senior Unsecured, stable [1] | See Top 1 [2]. Separately, Latvia's ordered buyout of Telia's LMT and Tet stakes is due by 17 Nov [12]. |
| TIM | Baa3 LT Issuer, positive [1] | 9M net loss attributable to shareholders was EUR 205m, against EUR 109m [13]. 2026 targets kept [13]. |
| PPF Telecom | Baa2 LT Issuer, stable [1] | The search returned no news. |
| BT Group (rated at British Telecommunications) | Baa2 LT Issuer, stable [1] | H1 sales were GBP 8,753m, net income GBP 809m and the interim dividend 2.50p [14]. Aggregator sources only. |
| Iliad | Ba1 Senior Unsecured, stable [1] | No material credit news. |
| VMED O2 UK | B1 CFR, on review for downgrade [1] | The search returned no news. The CFR and PDR have been on review for downgrade since 22 Oct [15]. |
| Altice France | Caa1 Senior Secured Bank Credit Facility, positive [1] | No material credit news. |

*Notes:* Several articles in the window retold results published before it (Deutsche Telekom, Swisscom, Proximus); they are not reported as new. BT's pension valuation (deficit GBP 2.7bn) was announced on 5 Nov, before the window [14]. Ratings are the rating class each tool returned.

## Sources
1. Moody's, getEntityRatings, rating histories (years: 1) for the 15 names (British Telecommunications Limited for BT), 15 Nov 2026
2. Moody's, searchNews: Telia Company release "Telia to acquire Telavox's Nordic enterprise customer base…" (202611120738CONTIFY_NEWS____0069709181) and Telecomlead (202611120703CONTIFY_NEWS____0069708735), 12 Nov 2026
3. Moody's, searchNews: NewsWeb/Oslo Børs, Bahnhof committee recommends acceptance (msg 686452), 13 Nov 2026; Cision, Telenor Sverige offer supplement, 13 Nov 2026; Marketline Deals, "Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million", 11 Nov 2026
4. Moody's, searchNews: RTT News, "Telefonica Q3 Net Income Soars…", 12 Nov 2026; Seeking Alpha, "Telefónica raises EBITDA and free cash flow outlook…", 12 Nov 2026
5. Moody's, getCreditOpinion: Telia Company AB, Update to credit analysis (PBC_1472649), 2 Mar 2026
6. Moody's, getCreditOpinion: Telenor ASA, Update following change in outlook to positive (PBC_1474480), 24 Feb 2026
7. Moody's, getCreditOpinion: Telefonica S.A., Update to credit analysis (PBC_1482849), 27 May 2026
8. Moody's, searchNews (macro): Morningstar/Dow Jones, "U.S., Eurozone Bond Yields Rise…", 13 Nov 2026; WN, "Markets still pricing in two more ECB rate hikes", 15 Nov 2026
9. Moody's, searchAllDocuments: Odido Group Holding B.V., Issuer Comment (PBC_1502046), 11 Nov 2026
10. Moody's, searchAllDocuments: Telecommunications – Global outlook (PBC_1496503), 27 Oct 2026
11. Moody's, searchNews: Kalkine Media, "FTSE 100 Vodafone (LSE:VOD) Publishes Half-Year Results", 13 Nov 2026; Simply Wall St, Vodafone dividend article, 14 Nov 2026
12. Moody's, searchNews: LETA, LMT/Tet buyout deadline, 13 Nov 2026
13. Moody's, searchNews: CE Noticias Financieras, "Telecom Italia's losses soar by 88% through September", 12 Nov 2026; Ad Hoc News, "Telecom Italia stock keeps 2026 outlook…", 12 Nov 2026
14. Moody's, searchNews: Simply Wall St, "Will Dividend Growth Guidance Change BT Group's Narrative", 12 Nov 2026; Contify, "BT Group announces triennial pension valuation" (release dated 5 Nov), 14 Nov 2026
15. Moody's, searchAllDocuments: Rating Action, "Moody's Ratings places VMED O2's and affiliated entities' ratings on review for downgrade" (PR_531559), 22 Oct 2026

Dashboard not updated: no folder to write to, scripts cannot run and publishing is not available in this session.
