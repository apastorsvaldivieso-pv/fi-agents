**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in 30 days. The one on a Moody's metric: the Basel Committee finalised G-SIB window-dressing rules and consulted on the G-SIB methodology (16 Oct); among the eight covered G-SIBs, BNP Paribas (CET1 12.97%) and ING (13.07%) sit in the weaker third. [1][2]

**Who it hits: G-SIB window-dressing amendments (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51%, 30 Sep 2025, older [3] | 2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger, 31 Dec 2025, older [4] | 2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26%, 31 Mar 2026 [5] | 2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated [6] |  | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated [6] |  | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2%, 31 Dec 2025, older [7] | 2.10 pp [2][7] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern, 30 Jun 2026 [8] | 3.55 pp [2][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [9] | +3.22 [2][9] | total not stated [10] | 6.7 pp bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers G-SIBs on the FSB list of 27 Nov 2025. Averaged reporting falls on every bank in the BCBS assessment sample; the buffer effect only on listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: 3 of 8 have a current requirement. Issuer on list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), bank-stated 2.6 pp above SREP (31 Mar 2026). [2][10][11]

**Who it hits: G-SIB methodology review, consultation (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51%, 30 Sep 2025, older [3] | 2.46 pp [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% MDA trigger, 31 Dec 2025, older [4] | 2.04 pp [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26%, 31 Mar 2026 [5] | 2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated [6] |  | list too short to rank |
| Groupe Credit Agricole | 17.23% [9] | not ranked | total not stated [10] | 6.7 pp bank-stated, 31 Mar 2026 [10] | list too short to rank |

Note: The page states no scope. The consulted change concerns cross-border exposures within the European Banking Union, so we take the covered names to be the banking-union G-SIBs on the FSB list (our judgment). Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. Credit Agricole S.A., the issuer on the list: CET1 11.3% (Q2 2026). [2][11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the rest of the UK large exposures package: no internal models for securities financing transactions, mandatory credit risk mitigation substitution, a trading book excess allowance of up to 85% of Tier 1. Effective 1 January 2028. *Why it matters:* Large exposures channel; no Moody's metric. [12]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published, with the Swiss banks' due diligence code (VSB 27) recognised as a minimum standard. In force 1 January 2027. *Why it matters:* AML channel; no Moody's metric. [13]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, embedded gains and losses, earnings indicators) and a new supervisory reporting requirement. Comments by 9 February 2027. *Why it matters:* IRRBB channel; no Moody's metric. [14]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test cuts requested data by more than 55% and adds a separate climate module that does not affect core results. Launch end of January 2027, results end of July 2027. *Why it matters:* Stress testing channel; no Moody's metric. [15]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: final report due December 2026, first reference date December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. *Why it matters:* Reporting channel; no Moody's metric. [16]
- [NEW] **EBA** (Final): Revised internal governance guidelines under CRD VI, with more proportionate requirements; application date not stated on the page. Moody's Sector Comment of 11 Nov 2026 calls them credit positive, with greater effect on smaller banks. *Why it matters:* Governance channel; no Moody's metric. [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments repointing Basel Framework cross-references to the new consolidated guidelines and moving some application guidance chapters into them. Comments by 21 December 2026. *Why it matters:* No channel in the map; mapped to watch by our judgment. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 'Interest rate risks - banks' updates shock scenarios to the Basel Committee's July 2024 recalibration, with more weight on earnings effects. Comments by 15 January 2027. *Why it matters:* IRRBB channel; no Moody's metric. [20]
- [NEW] **European Commission** (Legislative step): Parliament and Council reached political agreement on the Securitisation Framework review, amending the Securitisation Regulation and the CRR's securitisation capital treatment. Awaits technical finalisation and formal approval. *Why it matters:* Securitisation channel; no Moody's metric. [21]
- [NEW] **PRA** (Consultation): CP14/26 proposes the largest SM&CR reforms since launch, moving most Senior Manager approvals to notification and dropping certification fitness assessments. Comments by 22 January 2027. *Why it matters:* Governance channel; no Moody's metric. [22]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be reported and disclosed as averages over the year, not year-end values, by 1 January 2030; the reporting threshold rises from 200 billion EUR to 350 billion EUR from 1 January 2027. *Why it matters:* Changes how the G-SIB buffer is measured, so capital channel (CET1). [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review asks whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework. Comments by 14 January 2027. *Why it matters:* Capital channel (CET1), via the G-SIB buffer. [23]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (final) [12] | HSBC, Barclays, Lloyds | Large exposures: no field | Watch |
| FINMA AML Ordinance (final) [13] | UBS | AML: no field | Watch |
| BCBS IRRBB Pillar 2 guidance (consultation) [14] | All 15, once applied at home | IRRBB: no field | Watch |
| EBA 2027 stress test methodology (final) [15] | Scope not known: sample not named; EU/EEA names: BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | Stress testing: no field | Watch |
| EBA reporting simplification (next steps) [16] | BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | Reporting: no field | Watch |
| EBA internal governance guidelines (final) [17] | BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | Governance: no field | Watch |
| BCBS consolidated guidelines amendments (consultation) [19] | All 15, once applied at home | None (cross-references) | Watch |
| FINMA Circular 2019/2 interest rate risk (consultation) [20] | UBS | IRRBB: no field | Watch |
| EU Securitisation Framework review (political agreement) [21] | BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | Securitisation: no field | Watch |
| PRA CP14/26 SM&CR review (consultation) [22] | HSBC, Barclays, Lloyds | Governance: no field | Watch |

Note: Moody's bank data has no field for these channels, so no name is given a position.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out: speeches, blogs, newsletters, sanctions notices, statistics, lists, an appointment, consumer material, advice to the Commission, moved deadlines, and papers for credit unions, auditors or funds.
- G-SIB scope: FSB list of 27 Nov 2025 (no 2026 list found on fsb.org). Stated requirements are at the dates shown; older ones are not ranked.
- Moody's research search found no comment in the window on the G-SIB, securitisation, stress test or IRRBB items.

**Sources**

[1] Web · BCBS, Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · Bank financials, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Q3 2025 report, as of 30 Sep 2025 · 2025-09-30
[4] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Groep 2025 Form 20-F, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale Q1 2026 results, as of 31 Mar 2026 · 2026-03-31
[6] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: HSBC, Deutsche Bank 2025 Form 20-F (no total stated) · 2025-12-31
[7] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays 2025 Form 20-F, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Q2 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, explicit period · Groupe Credit Agricole · 2026-06-30
[10] Moody's (searchCompanyFilings) · Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, as of 31 … · 2026-03-31
[11] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · PRA, PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA, Partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · BCBS, Interest rate risk in the banking book - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA, 2027 EU-wide stress test methodology · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA, Next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA, Revised guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · EBA's revised governance guidelines are credit positive for small EU banks … · PBC_1502042 · 2026-11-11
[19] Web · BCBS, Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA, Consultation on revised Circular 2019/2 Interest rate risks - banks · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · European Commission, Political agreement on Securitisation Framework review · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · PRA, CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[23] Web · BCBS, Global systemically important banks - methodology review (consultative) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
