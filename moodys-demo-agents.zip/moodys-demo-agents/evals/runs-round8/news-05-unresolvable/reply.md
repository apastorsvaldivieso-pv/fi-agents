**Daily sector news: Vodafone, Orange** (72h to 15 Nov 2026 22:49 UTC (from 12 Nov 2026 22:49 UTC); 2 names)

No Moody's rating action or research on European telecoms in the window; the only material item is Vodafone's raised full-year guidance, reported by a single aggregator and not yet confirmed.

**Macro**

- Headlines point to the Bank of England raising rates further in 2027, and euro area bond yields rose on 13 Nov. [1]

**Sector**

- The searches returned no Moody's rating actions and no Moody's research on European telecoms published in the window. [2]
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable, published 27 Oct 2026: solid demand and declining capital intensity offset modest growth, refinancing pressure and structural risks. [3]

**By name**

| Name | Moody's rating | News |
|---|---|---|
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr), stable; affirmed 13 Oct 2026 [4] | Half-year results: raised full-year profit and cash flow guidance, organic service revenue growth; no figures in the returned text. Dividend declared, ex-dividend 19 Nov, paid 3 Feb; amount not given. Single source, unconfirmed. [5] |
| Orange | Baa1 LT Issuer Rating, stable [4] | No material credit news. |

Note: Vodafone items come only from Kalkine Media (13-15 Nov) and Simply Wall St (14 Nov); the search returned no company release, and the returned text does not give the results date.

**Unresolved names:** Zzyzx Fakecorp Holdings (no match in Moody's; the name search returned no results and no candidates, searched without a country filter as the home country is unknown). Not guessed, not included.

**Notes**

- Dropped as not credit news for the groups: Vodacom financial-services plans and 5G roll-out (subsidiary), Credit Agricole's 6.04% Schedule 13G stake in Vodafone (passive filing), Vodafone Idea Q2 results (Indian associate), Orange Jordan union agreement (subsidiary).
- Most results returned for Orange were unrelated items about places named Orange; none concerned Orange S.A.'s credit.

**Sources**

[1] Moody's (searchNews) · Macro headlines · Forex Factory 'BOE likely to raise rates further in 2027' (15 Nov, … · 2026-11-15
[2] Moody's (searchAllDocuments) · Moody's actions and research in the window · Rating Action and research document types, Telecommunications, Europe, 12-15 Nov 2026: no … · 2026-11-15
[3] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 · 2026-10-27
[4] Moody's ratings (getEntityRatings) · 2026-11-15
[5] Moody's (searchNews) · Vodafone half-year results and dividend (aggregator articles) · Kalkine Media, 'FTSE 100 Vodafone (LSE:VOD) Publishes Half-Year Results', … · 2026-11-13

Daily sector news tab updated 15 Nov 2026 22:51 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html. Not published to the private link in this run.
