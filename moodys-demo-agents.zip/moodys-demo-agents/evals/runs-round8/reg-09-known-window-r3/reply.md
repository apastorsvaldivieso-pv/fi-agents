**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Twelve new regulatory items in 16 Oct-15 Nov 2026; only the Basel Committee's G-SIB package maps to a Moody's metric, and among the eight G-SIBs on the list BNP Paribas and ING have the lowest CET1. [1][2]

**Who it hits: G-SIB window-dressing standard and methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median of ranked names (14.01%) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [1] | -1.04 pp [1] | 10.51% (30 Sep 2025, older) [3] | 2.46 pp (older) [1][3] | Weaker third |
| ING Groep N.V. | 13.07% [1] | -0.94 pp [1] | 11.03% MDA trigger (31 Dec 2025, older) [4] | 2.04 pp (older) [1][4] | Weaker third |
| Societe Generale | 13.2% [1] | -0.81 pp [1] | 10.26% (vs 31 Mar 2026) [5] | 2.94 pp [1][5] | Middle |
| Deutsche Bank AG | 13.92% [1] | -0.09 pp [1] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [1] | +0.09 pp [1] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [1] | +0.29 pp [1] | 12.2% (31 Dec 2025, older) [6] | 2.10 pp (older) [1][6] | Middle |
| UBS Group AG | 14.38% [1] | +0.37 pp [1] | 10.83% going-concern (30 Jun 2026) [7] | 3.55 pp [1][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [8] | +3.22 pp [1][8] | total not stated [9] | 6.7 pp bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Both apply to G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025; no 2026 list yet). Score reporting covers a wider sample. Ranked by level: three names have a current requirement. Issuer on list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [1][9][10]

**What changed**

- [NEW] **PRA** (Final): PS20/26 removes internal models for SFT exposure values, makes credit risk mitigation substitution mandatory and sets a single higher NCLEG limit of 350% of Tier 1 capital for trading book exposures. Takes effect 1 January 2028. [11]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published, aligning it with the amended AML Act ahead of the FATF evaluation; correspondent banking provisions clarified. In force 1 January 2027. [12]
- [NEW] **Basel Committee** (Consultation): Consults on additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, controls, embedded gains and losses in securities portfolios, earnings indicators. Comments by 9 February 2027. [13]
- [NEW] **EBA** (Final): Final 2027 EU-wide stress test methodology cuts requested data by "more than 55%" (headline; the text says 55%) and adds a separate climate module that does not affect core results. Launch end-January 2027, results end-July 2027. [14]
- [NEW] **EBA** (Other): Next steps on the supervisory reporting simplification package: final report December 2026, first reference date December 2027, with liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. [15]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, with a more proportionate, risk-based approach; application date not stated. Moody's (11 Nov 2026) calls the revisions credit positive for EU banks, more so for small ones. *Why it matters:* Stronger board oversight and risk control support credit, with the effect building gradually. [16][17]
- [NEW] **Basel Committee** (Consultation): Consults on consequential amendments so the Basel Framework cross-refers to the new consolidated guidelines, moving some application guidance chapters there. Comments by 21 December 2026. [18]
- [NEW] **FINMA** (Consultation): Consults on partially revised Circular 2019/2 "Interest rate risks - banks", updating banking book interest rate shocks to the Basel Committee's July 2024 recalibration. Consultation until 15 January 2027. [19]
- [NEW] **PRA** (Consultation): CP14/26 proposes removing pre-approval for almost half of Senior Manager Functions and annual fitness and propriety reassessment for certified roles. Comments by 22 January 2027; implementation expected H2 2027. [20]
- [NEW] **European Commission** (Other): Political agreement on the Securitisation Framework review, making the CRR treatment of securitisations "more risk sensitive"; awaits technical finalisation and formal approval, targeted by end-2026. No capital parameters given on the page. [21]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: consults on incorporating the previously agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework. Comments by 14 January 2027. *Why it matters:* Changes how G-SIB scores, and so G-SIB buffers, are measured. [22]
- [NEW] **Basel Committee** (Final): Final G-SIB window-dressing standard: score indicators reported as averages over the year, by 1 January 2030; reporting threshold raised to "350 billion EUR" of leverage exposure from 1 January 2027. *Why it matters:* Year-end-only balance sheet management can no longer lower G-SIB scores and buffers. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (final, 10 Nov) | HSBC, Barclays, Lloyds | Large exposures (no field) | Watch [11] |
| FINMA AML Ordinance (final, 10 Nov) | UBS | AML (no field) | Watch [12] |
| Basel IRRBB Pillar 2 guidance (consultation, 9 Nov) | All 15, once home rules apply it | IRRBB (no field) | Watch [13] |
| EBA 2027 stress test methodology (final, 9 Nov) | EU/EEA banks in the sample; sample not given on the page (scope not known) | Stress testing (no field) | Watch [14] |
| EBA reporting simplification next steps (6 Nov) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Reporting (no field) | Watch [15] |
| EBA internal governance guidelines (final, 5 Nov) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Governance (no field) | Watch [16] |
| Basel consolidated guidelines amendments (consultation, 5 Nov) | All 15, once home rules apply it | None (cross-references) | Watch [18] |
| FINMA IRRBB Circular 2019/2 (consultation, 4 Nov) | UBS | IRRBB (no field) | Watch [19] |
| PRA CP14/26 SM&CR phase 2 (consultation, 22 Oct) | HSBC, Barclays, Lloyds | Governance (no field) | Watch [20] |
| EU securitisation framework review (political agreement, 22 Oct) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Securitisation (no field) | Watch [21] |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (21 entries): speeches, blogs, newsletters, statistics, lists, appointments, sanctions, consumer material, a moved deadline, advice to another authority, and items for credit unions, funds or auditors.
- SRB's listing went back only to 6 Nov; search found no SRB item for 16 Oct-5 Nov. FINMA's IRRBB page names no bank categories. CET1 is as reported, not Moody's-adjusted.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all 15 names · Bank financials, 15 names · 2026-06-30
[2] Web · Basel Committee, Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger for CET1 · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, shown … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, Groupe Credit Agricole … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP · bank sector file, pulled 15 Nov 2026: Credit Agricole first quarter 2026 results slides, … · 2026-03-31
[10] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · PRA PS20/26, Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[12] Web · FINMA, partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · Basel Committee, IRRBB - additional Pillar 2 guidance (consultative) · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[14] Web · EBA, 2027 EU-wide stress test methodology · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · EBA, next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[16] Web · EBA, revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[17] Moody's (searchAllDocuments) · EBA's revised governance guidelines are credit positive for small EU banks · PBC_1502042 · 2026-11-11
[18] Web · Basel Committee, Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA, consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · PRA CP14/26, Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[21] Web · European Commission, political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · Basel Committee, Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review

Regulatory watch tab updated at 2026-11-15T22:59:07Z. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r3/dashboard/dashboard.html. Dashboard not published: Artifact publishing was skipped for this run.
