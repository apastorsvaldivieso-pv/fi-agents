**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

The EBA's revised internal governance guidelines (final, 5 Nov) cover 11 of your 15 banks, every EU/EEA group; HSBC, Barclays, Lloyds and UBS are outside at group level. Moody's carries no governance metric, so no bank is ranked; Moody's calls the guidelines credit positive, mostly for smaller banks. [1][2][3]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names (pp) | Stated CET1 requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [4] | -1.04 [4][5] | 10.51%, 30 Sep 2025, older [6] | 2.46 pp (older) [4][6] | Weaker third |
| ING Groep N.V. | 13.07% [4] | -0.94 [4][5] | 11.03% (MDA trigger), 31 Dec 2025, older [7] | 2.04 pp (older) [4][7] | Weaker third |
| Societe Generale | 13.20% [4] | -0.81 [4][5] | 10.26%, shown against 31 Mar 2026 [8] | 2.94 pp [4][8] | Middle |
| Deutsche Bank AG | 13.92% [4] | -0.09 [4][5] | not stated | n/a | Middle |
| HSBC Holdings plc | 14.10% [4] | +0.09 [4][5] | not stated | n/a | Middle |
| Barclays PLC | 14.30% [4] | +0.29 [4][5] | 12.2%, 31 Dec 2025, older [9] | 2.10 pp (older) [4][9] | Middle |
| UBS Group AG | 14.38% [4] | +0.37 [4][5] | 10.83% (going-concern), 30 Jun 2026 [10] | 3.55 pp [4][10] | Stronger third |
| Groupe Credit Agricole | 17.23% [5] | +3.22 [4][5] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [11] | Stronger third |

Note: Every bank in the Basel G-SIB assessment sample reports under the amendments; the G-SIB buffer falls only on FSB-listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Issuer on the list, Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026). [4][11][12]

**Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names (pp) | Stated CET1 requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [4] | not ranked | 10.51%, 30 Sep 2025, older [6] | 2.46 pp (older) [4][6] | list too short to rank |
| ING Groep N.V. | 13.07% [4] | not ranked | 11.03% (MDA trigger), 31 Dec 2025, older [7] | 2.04 pp (older) [4][7] | list too short to rank |
| Societe Generale | 13.20% [4] | not ranked | 10.26%, shown against 31 Mar 2026 [8] | 2.94 pp [4][8] | list too short to rank |
| Deutsche Bank AG | 13.92% [4] | not ranked | not stated | n/a | list too short to rank |
| Groupe Credit Agricole | 17.23% [5] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [11] | list too short to rank |

Note: The consultation concerns cross-border exposures within the European Banking Union and names no banks; mapped by our judgment to the five banking-union G-SIBs on the list. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. [12][13]

**What changed**

- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published; in force 1 January 2027, with the revised bank due-diligence code (VSB 27) recognised as a minimum standard. Channel: AML. [14]
- [NEW] **PRA** (Final): PS20/26 completes the large exposures changes: internal models for securities financing exposures removed, credit risk mitigation substitution made mandatory. Effective 1 January 2028. Channel: large exposures. [15]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test cuts requested data by more than 55% and adds a climate module outside the core results. Launch end January 2027, results end July 2027. Channel: stress testing. [16]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: first reference date for new requirements postponed to December 2027, liquidity, encumbrance, benchmarking and ESG reporting to December 2028. Final report due December 2026. Channel: reporting. [17]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10) align with CRD VI and DORA, add proportionality, and cover third-country branches; they apply two months after translation into all EU languages, on a consolidated and sub-consolidated basis. Channel: governance. *Why it matters:* Moody's (11 Nov): credit positive for EU banks, with the larger effect on smaller banks because large banks already largely comply. [1][2][3]
- [NEW] **FINMA** (Consultation): Consultation on revised Circular 2019/2 "Interest rate risks – banks" adopts the Basel Committee's recalibrated interest rate shocks. Comments by 15 January 2027. Channel: interest rate risk in the banking book. [18]
- [NEW] **PRA** (Consultation): CP14/26, Senior Managers and Certification Regime phase 2: notification instead of pre-approval for about half of senior manager functions, certification assessments removed. Comments by 22 January 2027. Channel: governance, conduct. [19]
- [NEW] **European Commission** (Legislative): Provisional political agreement on the Securitisation Framework review, including more risk-sensitive CRR treatment of securitisations. Needs formal adoption; no application date stated. Channel: securitisation. [20]
- [NEW] **Basel Committee** (Consultation): Consults on bringing the agreed treatment of European Banking Union cross-border exposures into the G-SIB methodology. Comments by 14 January 2027. Channel: G-SIB buffer (CET1). [13]
- [NEW] **Basel Committee** (Final): G-SIB stock indicators to be reported as averages over the year, not year-end values, to stop window-dressing; implementation 1 January 2030. Reporting threshold rises to EUR 350 billion from 2027. Channel: G-SIB buffer (CET1). [13]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EBA internal governance guidelines (final, 5 Nov) | BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Governance: no Moody's field | Watch |
| PRA SM&CR review, CP14/26 (consultation, 22 Oct) | HSBC, Barclays, Lloyds | Governance, conduct: no field | Watch |
| EBA reporting simplification, new dates (6 Nov) | The same 11 EU/EEA names | Reporting: no field | Watch |
| EBA 2027 stress test methodology (9 Nov) | Scope not known: sample not named (EU/EEA names only) | Stress testing: no field | Watch |
| EU securitisation review, political agreement (22 Oct) | The same 11 EU/EEA names | Securitisation: no field | Watch |
| PRA large exposures, PS20/26 (final, 10 Nov) | HSBC, Barclays, Lloyds | Large exposures: no field | Watch |
| FINMA interest rate risk circular (consultation, 4 Nov) | UBS | IRRBB: no field | Watch |
| FINMA AML Ordinance (final, 10 Nov) | UBS | AML: no field | Watch |

Note: EBA guidelines: addressed to competent authorities and CRD institutions, so they cover EU/EEA groups. Out of scope at group level: HSBC, Barclays, Lloyds (GB, PRA) and UBS (CH, FINMA); their EU subsidiaries are covered but not counted here. Credit Agricole is covered through the group and Credit Agricole S.A. alike. [2]

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (20 entries): speeches, interviews and commentary (ECB, SRB, FINMA); sanctions notices (FINMA, Commission); periodic list and reports between authorities (ECB); advice to an authority, moved consultation deadlines, an appointment, consumer material and a COP31 statement (EBA); a newsletter and credit-union papers (PRA); other Commission news not addressed to banks.
- The FSB's 2026 G-SIB list was not published by 15 Nov 2026; the 27 Nov 2025 list is used. Basel Committee dates and deadlines are taken from its 16 Oct press release, which covers both measures.
- Stated CET1 requirements are each bank's own total from filings held in Moody's; older figures are shown but not ranked. Local minimums can be higher than Basel standards.

**Sources**

[1] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[2] Web · EBA/GL/2026/10 Final report on Guidelines on internal governance (addressees, … · 2026-11-05 · https://www.eba.europa.eu/sites/default/files/2026-11/3c8b1810-c335-499a-803f-6d795ce3d196/Final%20report%20on%20Guidelines%20on%20internal%20governance.pdf
[3] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[4] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · Bank financials, coverage list · 2026-06-30
[5] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, Groupe Credit Agricole record · Groupe Credit Agricole · 2026-06-30
[6] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, as of 30 Sep … · 2025-09-30
[7] Moody's (searchCompanyFilings) · ING MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, as of … · 2026-03-31
[9] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[10] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[11] Moody's (searchCompanyFilings) · Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, as of 31 … · 2026-03-31
[12] Web · FSB 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[13] Web · Basel Committee finalises measures to address window-dressing in the G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[14] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[15] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[16] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[17] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[18] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[19] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[20] Web · The Commission welcomes the political agreement reached on the review of the … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
