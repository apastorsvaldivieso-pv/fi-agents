import json
def c(v,src=None,tone=None):
    d={"v":v}
    if src: d["src"]=src
    if tone: d["tone"]=tone
    return d
EU11="BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea"
cols=["Name","CET1 ratio (as reported), Q2 2026","vs median of ranked names (pp)","Stated CET1 requirement (date)","Distance to requirement","Position"]
R={
 "bnp":["BNP Paribas",c("12.97%",["s12"]),None,c("10.51%, 30 Sep 2025, older",["s16"]),c("2.46 pp (older)",["s12","s16"])],
 "ing":["ING Groep N.V.",c("13.07%",["s12"]),None,c("11.03% (MDA trigger), 31 Dec 2025, older",["s17"]),c("2.04 pp (older)",["s12","s17"])],
 "sg":["Societe Generale",c("13.20%",["s12"]),None,c("10.26%, shown against 31 Mar 2026",["s14"]),c("2.94 pp",["s12","s14"])],
 "db":["Deutsche Bank AG",c("13.92%",["s12"]),None,"not stated","n/a"],
 "hsbc":["HSBC Holdings plc",c("14.10%",["s12"]),None,"not stated","n/a"],
 "bar":["Barclays PLC",c("14.30%",["s12"]),None,c("12.2%, 31 Dec 2025, older",["s18"]),c("2.10 pp (older)",["s12","s18"])],
 "ubs":["UBS Group AG",c("14.38%",["s12"]),None,c("10.83% (going-concern), 30 Jun 2026",["s15"]),c("3.55 pp",["s12","s15"])],
 "gca":["Groupe Credit Agricole",c("17.23%",["s13"]),None,"total not stated",c("6.7 pp, bank-stated, 31 Mar 2026",["s19"])],
}
med={"bnp":"-1.04","ing":"-0.94","sg":"-0.81","db":"-0.09","hsbc":"+0.09","bar":"+0.29","ubs":"+0.37","gca":"+3.22"}
tone={"bnp":"weaker","ing":"weaker","sg":"middle","db":"middle","hsbc":"middle","bar":"middle","ubs":"stronger","gca":"stronger"}
srcmed={"gca":["s12","s13"]}
t1=[]
for k in ["bnp","ing","sg","db","hsbc","bar","ubs","gca"]:
    r=list(R[k]); r[2]=c(med[k],srcmed.get(k,["s12","s13"])); r.append({"tone":tone[k],"v":""}); t1.append(r)
t2=[]
for k in ["bnp","ing","sg","db","gca"]:
    r=list(R[k]); r[2]="not ranked"; r.append("list too short to rank"); t2.append(r)
run={
"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"2026-11-15T22:56:07Z",
"scope":{"sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15,"label":"Banks Europe, 30 days"},
"status":"ok",
"headline":"The EBA's revised internal governance guidelines (final, 5 Nov) cover 11 of your 15 banks, every EU/EEA group; HSBC, Barclays, Lloyds and UBS are outside at group level. Moody's carries no governance metric, so no bank is ranked; Moody's calls the guidelines credit positive, mostly for smaller banks.",
"headline_src":["s5","s6","s20"],
"sections":[
 {"title":"Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t1,
  "note":"Every bank in the Basel G-SIB assessment sample reports under the amendments; the G-SIB buffer falls only on FSB-listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Issuer on the list, Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026).",
  "note_src":["s11","s12","s19"]},
 {"title":"Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t2,
  "note":"The consultation concerns cross-border exposures within the European Banking Union and names no banks; mapped by our judgment to the five banking-union G-SIBs on the list. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs.",
  "note_src":["s1","s11"]},
 {"title":"What changed","type":"items","items":[
  {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance published; in force 1 January 2027, with the revised bank due-diligence code (VSB 27) recognised as a minimum standard. Channel: AML.","why":"","src":["s10"]},
  {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 completes the large exposures changes: internal models for securities financing exposures removed, credit risk mitigation substitution made mandatory. Effective 1 January 2028. Channel: large exposures.","why":"","src":["s9"]},
  {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology for the 2027 EU-wide stress test cuts requested data by more than 55% and adds a climate module outside the core results. Launch end January 2027, results end July 2027. Channel: stress testing.","why":"","src":["s8"]},
  {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on supervisory reporting simplification: first reference date for new requirements postponed to December 2027, liquidity, encumbrance, benchmarking and ESG reporting to December 2028. Final report due December 2026. Channel: reporting.","why":"","src":["s7"]},
  {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance (EBA/GL/2026/10) align with CRD VI and DORA, add proportionality, and cover third-country branches; they apply two months after translation into all EU languages, on a consolidated and sub-consolidated basis. Channel: governance.","why":"Moody's (11 Nov): credit positive for EU banks, with the larger effect on smaller banks because large banks already largely comply.","src":["s5","s6","s20"]},
  {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consultation on revised Circular 2019/2 \"Interest rate risks – banks\" adopts the Basel Committee's recalibrated interest rate shocks. Comments by 15 January 2027. Channel: interest rate risk in the banking book.","why":"","src":["s4"]},
  {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26, Senior Managers and Certification Regime phase 2: notification instead of pre-approval for about half of senior manager functions, certification assessments removed. Comments by 22 January 2027. Channel: governance, conduct.","why":"","src":["s3"]},
  {"flag":"NEW","tag":"Legislative","name":"European Commission","text":"Provisional political agreement on the Securitisation Framework review, including more risk-sensitive CRR treatment of securitisations. Needs formal adoption; no application date stated. Channel: securitisation.","why":"","src":["s2"]},
  {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consults on bringing the agreed treatment of European Banking Union cross-border exposures into the G-SIB methodology. Comments by 14 January 2027. Channel: G-SIB buffer (CET1).","why":"","src":["s1"]},
  {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"G-SIB stock indicators to be reported as averages over the year, not year-end values, to stop window-dressing; implementation 1 January 2030. Reporting threshold rises to EUR 350 billion from 2027. Channel: G-SIB buffer (CET1).","why":"","src":["s1"]}
 ]},
 {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":[
  ["EBA internal governance guidelines (final, 5 Nov)",EU11,"Governance: no Moody's field",{"tone":"watch","v":""}],
  ["PRA SM&CR review, CP14/26 (consultation, 22 Oct)","HSBC, Barclays, Lloyds","Governance, conduct: no field",{"tone":"watch","v":""}],
  ["EBA reporting simplification, new dates (6 Nov)","The same 11 EU/EEA names","Reporting: no field",{"tone":"watch","v":""}],
  ["EBA 2027 stress test methodology (9 Nov)","Scope not known: sample not named (EU/EEA names only)","Stress testing: no field",{"tone":"watch","v":""}],
  ["EU securitisation review, political agreement (22 Oct)","The same 11 EU/EEA names","Securitisation: no field",{"tone":"watch","v":""}],
  ["PRA large exposures, PS20/26 (final, 10 Nov)","HSBC, Barclays, Lloyds","Large exposures: no field",{"tone":"watch","v":""}],
  ["FINMA interest rate risk circular (consultation, 4 Nov)","UBS","IRRBB: no field",{"tone":"watch","v":""}],
  ["FINMA AML Ordinance (final, 10 Nov)","UBS","AML: no field",{"tone":"watch","v":""}]],
  "note":"EBA guidelines: addressed to competent authorities and CRD institutions, so they cover EU/EEA groups. Out of scope at group level: HSBC, Barclays, Lloyds (GB, PRA) and UBS (CH, FINMA); their EU subsidiaries are covered but not counted here. Credit Agricole is covered through the group and Credit Agricole S.A. alike.",
  "note_src":["s6"]}
],
"sources":[
 {"id":"s1","kind":"web","title":"Basel Committee finalises measures to address window-dressing in the G-SIB framework and consults on G-SIB methodology review","date":"2026-10-16","url":"https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib"},
 {"id":"s2","kind":"web","title":"The Commission welcomes the political agreement reached on the review of the Securitisation Framework","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
 {"id":"s3","kind":"web","title":"PRA CP14/26 Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
 {"id":"s4","kind":"web","title":"FINMA consultation on partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
 {"id":"s5","kind":"web","title":"EBA publishes revised Guidelines on internal governance","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
 {"id":"s6","kind":"web","title":"EBA/GL/2026/10 Final report on Guidelines on internal governance (addressees, scope, date of application)","date":"2026-11-05","url":"https://www.eba.europa.eu/sites/default/files/2026-11/3c8b1810-c335-499a-803f-6d795ce3d196/Final%20report%20on%20Guidelines%20on%20internal%20governance.pdf"},
 {"id":"s7","kind":"web","title":"EBA outlines next steps on supervisory reporting simplification and extends implementation timelines","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
 {"id":"s8","kind":"web","title":"EBA streamlines the 2027 EU-wide stress test","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
 {"id":"s9","kind":"web","title":"PRA PS20/26 Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
 {"id":"s10","kind":"web","title":"FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
 {"id":"s11","kind":"web","title":"FSB 2025 List of Global Systemically Important Banks (G-SIBs)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
 {"id":"s12","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026","title":"Bank financials, coverage list","date":"2026-06-30"},
 {"id":"s13","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026, Groupe Credit Agricole record","title":"Groupe Credit Agricole financials","date":"2026-06-30"},
 {"id":"s14","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, as of 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
 {"id":"s15","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: UBS second quarter 2026 report, as of 30 Jun 2026","title":"UBS required going-concern CET1","date":"2026-06-30"},
 {"id":"s16","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 requirement","date":"2025-09-30"},
 {"id":"s17","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025","title":"ING MDA trigger level","date":"2025-12-31"},
 {"id":"s18","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025","title":"Barclays overall CET1 requirement","date":"2025-12-31"},
 {"id":"s19","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, as of 31 Mar 2026","title":"Credit Agricole distance to SREP requirement","date":"2026-03-31"},
 {"id":"s20","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042, Sector Comment","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"}
],
"unresolved":[],
"notes":[
 "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
 "Left out (20 entries): speeches, interviews and commentary (ECB, SRB, FINMA); sanctions notices (FINMA, Commission); periodic list and reports between authorities (ECB); advice to an authority, moved consultation deadlines, an appointment, consumer material and a COP31 statement (EBA); a newsletter and credit-union papers (PRA); other Commission news not addressed to banks.",
 "The FSB's 2026 G-SIB list was not published by 15 Nov 2026; the 27 Nov 2025 list is used. Basel Committee dates and deadlines are taken from its 16 Oct press release, which covers both measures.",
 "Stated CET1 requirements are each bank's own total from filings held in Moody's; older figures are shown but not ranked. Local minimums can be higher than Basel standards."
],
"meta":{"calls":{"moodys":5,"web":22}}
}
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
