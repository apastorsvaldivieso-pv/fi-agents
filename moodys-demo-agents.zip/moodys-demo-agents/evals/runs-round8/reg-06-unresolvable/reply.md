**Regulatory watch: BNP, Deutsche Bank, 30 days** (16 Oct to 15 Nov 2026 (30 days); 2 names)

On 16 Oct the Basel Committee finalised G-SIB window-dressing amendments and opened a consultation on the banking-union treatment of G-SIB scores; both cover BNP Paribas and Deutsche Bank on the capital channel. Ten other items in the window carry no Moody's metric. [1][2]

**Who it hits: G-SIB window-dressing amendments and G-SIB methodology review (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | not ranked | 10.51% CET1 capital requirement, 30 Sep 2025 (older) [4] | 2.46 pp (against older requirement) [3][4] | list too short to rank |
| Deutsche Bank AG | 13.92% [3] | not ranked | not stated [5] | not stated | list too short to rank |

Note: Both banks are on the FSB G-SIB list of 27 Nov 2025 and headquartered in the banking union. The final amendments apply to "banks participating in the G-SIB assessment exercise"; the G-SIB buffer falls only on listed banks. The consultation asks whether to incorporate "the treatment of cross-border exposures within the EBU"; it names no banks, so coverage here is read from the scope rules. [6][7]

**What changed**

- [NEW] **PRA** (Final): PS20/26 amends the Large Exposures Framework (Part 2), effective 1 January 2028; firms may apply for new permissions from 1 July 2027. Applies to PRA-authorised UK banks and building societies. Large exposures channel. [8]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published after consultation; in force 1 January 2027. AML channel. [9]
- [NEW] **EBA** (Final): Final methodology and draft templates for the 2027 EU-wide stress test, with "more than 55%" reduction in requested data. Launch end of January 2027, publication end of July 2027; the sample may still change. Stress testing channel. [10]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book; comments by 9 February 2027. IRRBB channel. [11]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: first reference date for new requirements moves to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028. Final report on the ITS due December 2026. Reporting channel. [12]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, final and awaiting translation; application date not stated. Governance channel. *Why it matters:* Moody's calls the revisions credit positive for EU banks, with a greater effect on smaller banks (11 Nov 2026). [13][14]
- [NEW] **Basel Committee** (Consultation): Consequential amendments aligning Basel Framework cross-references with the consolidated guidelines; comments by 21 December 2026. No channel-map row: treated as watch by own judgment. [15]
- [NEW] **FINMA** (Consultation): Consultation on partially revised Circular 2019/2 "Interest rate risks - banks"; comments by 15 January 2027. IRRBB channel. [16]
- [NEW] **European Commission** (Other): Provisional political agreement on the Securitisation Regulation and CRR review; formal approval pending, Council aims to finalise by end-2026, in force on publication. Securitisation channel. [17]
- [NEW] **PRA** (Consultation): CP14/26, Senior Managers and Certification Regime review, phase 2; comments by 22 January 2027, implementation expected H2 2027. Governance and conduct channel. [18]
- [NEW] **Basel Committee** (Final): G-SIB stock indicators to be reported as yearly averages, not year-end values, by 1 January 2030; reporting threshold raised from EUR 200 billion to EUR 350 billion from 2027. Capital buffers channel. [1][6]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to incorporate the treatment of cross-border exposures within the European Banking Union; comments by 14 January 2027. Capital buffers channel. [2][6]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EBA 2027 stress test methodology [10] | scope not known (sample set by the methodology, no banks named) | stress test results | Watch |
| EBA reporting timelines [12] | BNP Paribas, Deutsche Bank | none | Watch |
| EBA internal governance guidelines [13] | BNP Paribas, Deutsche Bank | none | Watch |
| EU securitisation agreement [17] | BNP Paribas, Deutsche Bank | securitisation exposures | Watch |
| Basel IRRBB Pillar 2 guidance [11] | BNP Paribas, Deutsche Bank, once applied in the EU | IRRBB measure | Watch |
| Basel consolidated guidelines amendments [15] | BNP Paribas, Deutsche Bank, once applied in the EU | none | Watch |
| PRA PS20/26, PRA CP14/26 [8][18] | none (UK firms only) | large exposures; none | Watch |
| FINMA Circular 2019/2, AMLO-FINMA [9][16] | none (Swiss firms only) | IRRBB measure; none | Watch |

**Unresolved names:** Zzyzx Fakecorp Bank (no match in Moody's (findEntity: name search produced no results); home country unknown). Not guessed, not included.

**Notes**

- Left out (21 entries): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (Basel AML/CFT, PRA Digest); advice between authorities (EBA Taxonomy, ECB to Eurogroup); sanctions notices (Commission, FINMA); credit-union and other non-bank measures (PRA CP15/26, DP2/26; FINMA Bitcoin ETF; Commission assurance standards); periodic lists, statistics, appointments, consumer material, a moved EBA consultation deadline, statements.
- The FSB's 2026 G-SIB list was not found on fsb.org on 15 Nov 2026; the 27 Nov 2025 list is used.
- ECB Banking Supervision published no press release in the window: its latest is dated 15 Oct 2026, a day before the window.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · BNP Paribas, Deutsche Bank AG · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · Deutsche Bank stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Deutsche Bank Annual report on Form 20-F for 2025, … · 2025-12-31
[6] Web · Basel Committee media release: window-dressing measures and G-SIB methodology … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[7] Web · FSB: 2025 List of Global Systemically Important Banks · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[8] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[9] Web · FINMA: partially revised Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[10] Web · EBA: 2027 EU-wide stress test streamlined · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[11] Web · Basel Committee: IRRBB - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[12] Web · EBA: next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[13] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[14] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[15] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[16] Web · FINMA: consultation on Circular 2019/2 Interest rate risks - banks · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[17] Web · European Commission: political agreement on the Securitisation Framework review · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[18] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 2026-11-15 22:55 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html (not published as an Artifact in this run).
