**Daily sector news: Telecoms Europe, 7 days** (168h (7 days), 8 Nov 2026 22:49 UTC to 15 Nov 2026 22:49 UTC; 15 names)

Telia agreed a SEK 3.8bn purchase of Telavox's Nordic enterprise base and Telenor took control of Bahnhof, while Telefonica raised guidance; the search returned no Moody's rating action on the list in the window. [1]

**Top this week**

- **Telia Company AB** (Deal): Telia agreed (12 Nov) to buy Telavox's Nordic enterprise customer base for SEK 3.8bn plus up to SEK 0.2bn earn-out; the base brings about SEK 1.1bn of annual revenue. Latvia's buyout of Telia's LMT and Tet stakes is due by 17 Nov, per LMT. *Why it matters:* Moody's downgrade triggers: RCF/adjusted net debt below 22% and debt/EBITDA towards 3.0x; funding is not stated. [1][2][3][4]
- **Telenor ASA** (Deal): Telenor Sverige completed the purchase of 57.5% of Bahnhof's shares (87.9% of votes) and runs a mandatory cash offer at SEK 62 per share; by 13 Nov it held about 66.9% of shares and 90.6% of votes. *Why it matters:* Moody's positive outlook includes no M&A beyond the GlobalConnect deal and could return to stable on debt-funded acquisitions. [5][6][7][8]
- **Telefonica S.A.** (Results): Q3 results (12 Nov): net income EUR 802m against EUR 276m a year earlier; revenue EUR 8.43bn, up 4.8% (2.2% at constant currency); adjusted net income EUR 629m, down 1%. Guidance raised for adjusted EBITDA, operating cash flow after leases and free cash flow. *Why it matters:* Moody's stable outlook expects adjusted net leverage to fall sustainably below 3.75x, its downgrade level; the articles give no leverage figure. [9][10][11]

**Macro**

- Moody's 2027 global credit conditions outlook (9 Nov): credit will weaken as higher rates and energy costs counter the AI tailwind. [12]
- Euro area bond yields moved both ways over the week (dip on 12 Nov, rise on 13 Nov, headlines only). [13][14]

**Sector**

- The search returned no Moody's rating actions on European telecoms in the window; research found was on issuers not on the list (Odido, Nokia).
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable (27 Oct 2026), as solid demand and declining capital intensity offset a broad range of risks. [15]

**By name**

| Name | Moody's rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom AG | A3 (Senior Unsecured), Stable [16] | No material credit news. |
| Orange | Baa1 (LT Issuer Rating), Stable [16] | No material credit news. |
| Vodafone Group Plc | Baa2 (Senior Unsecured), Stable [16] | H1 results: guidance for earnings and free cash flow raised, no figures given; single source, unconfirmed. [17] |
| Telefonica S.A. | Baa3 (Senior Unsecured), Stable [16] | Q3 results, guidance raised (see Top). |
| Swisscom AG | A2 (LT Issuer Rating), Stable [16] | No material credit news. |
| Telekom Austria AG | A3 (LT Issuer Rating), Stable [16] | No material credit news. |
| Proximus SA de droit public | A3 (Senior Unsecured), Stable [16] | No material credit news. |
| Telenor ASA | Baa1 (Senior Unsecured), Positive [16] | Took control of Bahnhof (see Top). |
| Telia Company AB | Baa1 (Senior Unsecured), Stable [16] | Telavox purchase; Latvian stakes buyout (see Top). |
| TIM S.p.A. | Baa3 (LT Issuer Rating), Positive [16] | 9M results: net loss to shareholders EUR 205m against EUR 109m a year earlier, despite revenue and EBITDA growth; 2026 targets kept. [18][19] |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer Rating), Stable [16] | No material credit news. |
| BT Group Plc | Baa2 (LT Issuer Rating, British Telecommunications Limited), Stable [16] | No material credit news. |
| Iliad S.A. | Ba1 (Senior Unsecured), Stable [16] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 (Corporate Family Rating), under review for downgrade [16] | No news in the window. B1 CFR and B1-PD rating on review for downgrade since 22 Oct. [20] |
| Altice France SAS | Caa1 (Senior Secured Bank Credit Facility), Positive [16] | No material credit news. |

**Notes**

- Moody's document searches filter by whole calendar days, so they cover 8 to 15 Nov 2026.
- Left out as not new: Deutsche Telekom Q3 (5 Nov), Proximus Q3 (30 Oct), BT H1 results and pension valuation (release dated 5 Nov), retold in the window. Left out as not group credit: Vodafone Idea and Vodacom results, a passive 13G stake in Vodafone, tenders and contract awards.
- The Iliad news search returned only unrelated articles matching the word 'Iliad'; PPF Telecom and VMED O2 searches returned no news.

**Sources**

[1] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base (Telia release) · 2026-11-12
[2] Moody's (searchNews) · Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion (Telecomlead) · 2026-11-12
[3] Moody's (searchNews) · Buyout of Telia's shares in LMT and Tet to be implemented by 17 Nov (LETA) · 2026-11-13
[4] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649, FactorsLeadingToDowngrade · 2026-03-02
[5] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof and Launches Mandatory Cash Offer (The … · 2026-11-11
[6] Moody's (searchNews) · Bahnhof board committee recommends Telenor Sverige's offer; Telenor holds about … · 2026-11-13
[7] Moody's (searchNews) · Telenor Sverige supplement to offer document, SEK 62 per share (Cision) · 2026-11-13
[8] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480, RatingOutlook · 2026-02-24
[9] Moody's (searchNews) · Telefonica Q3 Net Income Soars As Revenue Rise (RTT News) · 2026-11-12
[10] Moody's (searchNews) · Telefonica raises EBITDA and free cash flow outlook after Q3 results (Seeking … · 2026-11-12
[11] Moody's (getCreditOpinion) · Telefonica S.A.: Update to credit analysis · PBC_1482849, RatingOutlook and FactorsLeadingToDowngrade · 2026-05-27
[12] Moody's (searchAllDocuments) · Credit Conditions - Global: 2027 Outlook · PBC_1491648 (Outlook) · 2026-11-09
[13] Moody's (searchNews) · Euro zone bond yields dip as traders mull inflation, interest rate outlook … · 2026-11-12
[14] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Dow Jones via … · 2026-11-13
[15] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 (Outlook) · 2026-10-27
[16] Moody's ratings (getEntityRatings) · Moody's ratings, first 10 names, Moody's ratings, last 5 names · 2026-11-15
[17] Moody's (searchNews) · FTSE 100 Vodafone Lifts Its Outlook for the Year (Kalkine Media) · 2026-11-15
[18] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September (CE Noticias Financieras) · 2026-11-12
[19] Moody's (searchNews) · Telecom Italia keeps 2026 outlook after stronger 9M growth (Ad Hoc News) · 2026-11-12
[20] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559 (Rating Action) · 2026-10-22

Daily sector news tab updated at 15 Nov 2026 22:52 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review2-news-telecoms/dashboard/dashboard.html. Not published to a link in this session.
