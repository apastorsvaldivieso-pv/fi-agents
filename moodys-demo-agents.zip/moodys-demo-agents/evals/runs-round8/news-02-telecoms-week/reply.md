**Daily sector news: Telecoms Europe, 7 days** (168h (7 days) to 15 Nov 2026 22:49 UTC, from 8 Nov 2026 22:49 UTC; 15 names)

Telia agreed a SEK 3.8bn purchase of Telavox's Nordic enterprise base, Telenor lifted its Bahnhof stake to 66.9% and Telefonica raised guidance; Moody's took no rating action on the list in the window. [1][2][3][4]

**Top this week**

- **Telia Company AB** (Deal): Binding agreement (12 Nov) to buy Telavox's Nordic enterprise customer base for SEK 3.8bn plus a potential SEK 0.2bn earn-out, with a multi-year licence for its communications platform. The base brings about SEK 1.1bn of annual revenue. *Why it matters:* Moody's downgrade triggers are RCF/adjusted net debt below 22% and adjusted debt/EBITDA moving towards 3.0x. [1][5][6]
- **Telenor ASA** (Deal): Telenor Sverige completed the purchase of 57.5% of Bahnhof and now holds about 66.9% of shares and 90.6% of votes (13 Nov); its mandatory offer of SEK 62 per share, recommended by Bahnhof's independent committee, runs for the rest. *Why it matters:* Moody's positive outlook includes no M&A beyond the GlobalConnect deal and could return to stable on debt-funded acquisitions. [2][7][8][9]
- **Telefonica S.A.** (Results): Q3 results (12 Nov): net income EUR 802m vs EUR 276m; revenue EUR 8.43bn, up 4.8% (2.2% at constant FX); adjusted net income EUR 629m, down 1%. Guidance raised for adjusted EBITDA, operating cash flow after leases and free cash flow; the articles give no leverage figure. *Why it matters:* Moody's stable outlook expects adjusted net leverage to fall sustainably below 3.75x, the level at which it could downgrade. [3][10][11]

**Macro**

- Euro zone bond yields moved both ways: down on 12 Nov as traders weighed inflation and the rate outlook, up on 13 Nov alongside US yields. [12][13]
- US October inflation came in above forecasts; the headline says the Fed is eyeing a December hike (15 Nov). [14]

**Sector**

- **Odido Group Holding B.V.** (Issuer Comment, not on the list): Moody's (11 Nov): new notes to fund the Apax acquisition raise leverage, which it expects slightly above 5.5x before falling toward 5x in 2028; credit quality unchanged. [15]
- **Nokia Oyj** (Credit Opinion, not on the list): Moody's (10 Nov, after the upgrade to Baa3) notes that European operators still struggle to raise revenue per user, limiting pricing power. [16]
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable, 27 Oct 2026, on solid demand, modest EBITDA growth and declining capital intensity. [17]
- The searches returned no Moody's rating action on European telecoms dated 8-15 Nov.

**By name**

| Name | Rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured (Fgn Curr), stable [4] | No material credit news in the window; Q3 results and guidance raise date from 5 Nov, before it. [18] |
| Orange | Baa1 LT Issuer Rating, stable [4] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr), stable [4] | Half-year results: full-year profit and cash flow guidance raised, with organic service revenue growth; the articles give no figures. [19] |
| Telefonica S.A. | Baa3 Senior Unsecured (Dom Curr), stable [4] | Q3 results and guidance raise, see Top this week. [3][10] |
| Swisscom AG | A2 LT Issuer Rating (Dom Curr), stable [4] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating, stable [4] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (Dom Curr), stable [4] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured (Fgn Curr), positive [4] | Bahnhof stake raised to 66.9%, see Top this week. [2] |
| Telia Company AB | Baa1 Senior Unsecured (Fgn Curr), stable [4] | Telavox deal, see Top. LMT (Latvia) says the government-ordered buyout of Telia's stakes in LMT and Tet will be done by 17 Nov; no amount given. [20] |
| TIM S.p.A. | Baa3 LT Issuer Rating (Dom Curr), positive [4] | 9M results (11 Nov): net loss attributable EUR 205m vs EUR 109m a year earlier; revenue and EBITDA grew; 2026 targets kept. [21][22] |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (Dom Curr), stable [4] | No material credit news (search returned no articles). |
| BT Group Plc | Baa2 LT Issuer Rating at British Telecommunications Limited, stable [4] | No material credit news in the window; H1 results and pension valuation date from 5 Nov, before it. [23] |
| Iliad S.A. | Ba1 Senior Unsecured (Dom Curr), stable [4] | No material credit news (search returned only unrelated articles). |
| VMED O2 UK Holdings Limited | B1 Corporate Family Rating (Fgn Curr), on review for downgrade [4][24] | CFR and B1-PD PDR on review for downgrade since 22 Oct. An FT report, cited by Kalkine on 12 Nov, says it is nearing a deal to use BT's network: single source, unconfirmed. [24][25] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (Fgn Curr), positive [4] | No material credit news. |

Note: Ratings and outlooks as of 15 Nov 2026; none of the 15 names had a rating action dated inside the window. [4]

**Notes**

- Moody's document searches filter by whole calendar days, so they cover 8-15 Nov 2026 inclusive.
- Dropped as not credit news: share-price items, tenders, a passive 6.04% Credit Agricole stake filing in Vodafone, subsidiary news (Vodacom, Sparkle, Openreach board) and Vodafone Idea's results.
- Iliad's news search matched the word 'Iliad' in unrelated stories; no article on the company was returned.

**Sources**

[1] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base (Telia release via … · 2026-11-12
[2] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · 2026-11-13
[3] Moody's (searchNews) · Telefonica raises EBITDA and free cash flow outlook after Q3 results (Seeking … · 2026-11-12
[4] Moody's ratings (getEntityRatings) · 2026-11-15
[5] Moody's (searchNews) · Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion (Telecomlead) · 2026-11-12
[6] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649, FactorsLeadingToDowngrade · 2026-03-02
[7] Moody's (searchNews) · Telenor Sverige supplement to the offer document for Bahnhof (Cision) · 2026-11-13
[8] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof and Launches Mandatory Cash Offer (The … · 2026-11-11
[9] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480, RatingOutlook · 2026-02-24
[10] Moody's (searchNews) · Telefonica Q3 Net Income Soars As Revenue Rise (RTT News) · 2026-11-12
[11] Moody's (getCreditOpinion) · Telefonica S.A.: Update to credit analysis · PBC_1482849, RatingOutlook and FactorsLeadingToDowngrade · 2026-05-27
[12] Moody's (searchNews) · Euro zone bond yields dip as traders mull inflation, interest rate outlook … · 2026-11-12
[13] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Morningstar) · 2026-11-13
[14] Moody's (searchNews) · US inflation exceeds forecasts in October, killing rate-cut talk as Fed eyes … · 2026-11-15
[15] Moody's (searchAllDocuments) · Odido Group Holding B.V.: New notes issuance increases leverage but credit … · PBC_1502046 · 2026-11-11
[16] Moody's (searchAllDocuments) · Nokia Oyj: Update following upgrade to Baa3, outlook positive · PBC_1499082 · 2026-11-10
[17] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 · 2026-10-27
[18] Moody's (searchNews) · Deutsche Telekom's Profit Growth Outpaces Revenue (Ad Hoc News; Q3 release of 5 … · 2026-11-05
[19] Moody's (searchNews) · FTSE 100 Vodafone (LSE:VOD) Publishes Half-Year Results (Kalkine Media) · 2026-11-13
[20] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet to be … · 2026-11-13
[21] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September (CE Noticias Financieras) · 2026-11-12
[22] Moody's (searchNews) · Telecom Italia stock keeps 2026 outlook after stronger 9M growth (Ad Hoc News) · 2026-11-12
[23] Moody's (searchNews) · BT Group announces triennial pension valuation (release dated 5 Nov, via … · 2026-11-05
[24] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559 · 2026-10-22
[25] Moody's (searchNews) · Could BT Group Land a Virgin Media O2 Network Deal After Shares Surged? … · 2026-11-12

Daily sector news tab updated 15 Nov 2026 22:54 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html (not published to a private link in this session).
