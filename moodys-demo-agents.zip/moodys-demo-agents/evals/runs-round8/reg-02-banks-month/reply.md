**Regulatory watch: Banks Europe, 30 days** (16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in 30 days. The Basel Committee finalised G-SIB window-dressing amendments; among the eight G-SIBs on the list, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios at Q2 2026. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (as reported, Q2 2026) | vs median of ranked names (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% (30 Sep 2025, older) [3] | +2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger (31 Dec 2025, older) [4] | +2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.20% [2] | -0.81 [2] | 10.26% (31 Mar 2026) [5] | +2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [2] | +0.29 [2] | 12.2% (31 Dec 2025, older) [6] | +2.10 pp [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern (30 Jun 2026) [7] | +3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [2] | +3.22 [2] | total not stated | +6.7 pp bank-stated, 31 Mar 2026, phased-in [8] | Stronger third |

Note: Reporting applies to banks 'participating in the G-SIB assessment exercise'; the buffer falls on FSB-listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB list, 27 Nov 2025). The methodology review concerns banking-union exposures; its page names no banks. Ranked by level: three current requirements. Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026). [1][2][8][9]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises large exposures changes: trading book excess allowance cut to up to 85% of Tier 1 for no more than 10 business days, a single NCLEG limit of 350% of Tier 1, and no internal models for SFT exposure values. Takes effect 1 January 2028. *Why it matters:* Large exposures: no Moody's metric; covers HSBC, Barclays, Lloyds. [10]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance published, clarifying correspondent banking and ownership-structure rules ahead of the FATF evaluation. In force 1 January 2027. *Why it matters:* AML channel; covers UBS. [11]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book: model validation, stress testing, embedded gains and losses in securities, earnings indicators. Comments by 9 February 2027. *Why it matters:* IRRBB: no Moody's metric. [12]
- [NEW] **EBA** (Final methodology): 2027 EU-wide stress test methodology published; required data points reduced by 55% (headline: more than 55%), with a new climate module that does not affect core results. Launch end of January 2027, results end of July 2027. *Why it matters:* Stress testing: the page does not list the sample. [13]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: first reference date December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Final ITS report due December 2026. [14]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, with lighter mapping of duties and simpler conflict-of-interest rules. Application date not stated on the page. Moody's (11 Nov 2026): credit positive for EU banks, more so for smaller banks. [15][16]
- [NEW] **Basel Committee** (Consultation): Consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving application guidance chapters. Comments by 21 December 2026. [17]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on banks' interest rate risk, adopting the Basel Committee's July 2024 recalibrated shock scenarios and more weight on earnings effects. Comments by 15 January 2027. *Why it matters:* IRRBB; covers UBS. [18]
- [NEW] **European Commission** (Legislative step): Provisional political agreement on the Securitisation Framework review, including more risk-sensitive CRR treatment of securitisations. Awaits formal adoption; enters into force on publication; Council aims to finish by end-2026. *Why it matters:* Securitisation: no Moody's metric; the page gives no capital figures. [19]
- [NEW] **PRA** (Consultation): CP14/26, SM&CR Phase 2: pre-approval removed for almost half of Senior Manager Functions and the Certification Regime removed. Comments by 22 January 2027; depends on the Financial Services and Markets Bill 2026. [20]
- [NEW] **Basel Committee** (Final): G-SIB window-dressing amendments: banks in the G-SIB assessment exercise report stock indicators as year averages, not year-end values, by 1 January 2030. The reporting threshold rises from EUR 200 billion to EUR 350 billion from 2027. *Why it matters:* Changes how G-SIB scores, and so G-SIB buffers, are measured. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 January 2027. *Why it matters:* Capital channel via G-SIB scores; see the table note. [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| IRRBB Pillar 2 guidance (BCBS, consultation) | All 15, once home rules apply it | IRRBB measure: none | Watch |
| Circular 2019/2 interest rate risks (FINMA, consultation) | UBS | IRRBB measure: none | Watch |
| Consolidated guidelines amendments (BCBS, consultation) | All 15, once home rules apply it | none | Watch |
| 2027 EU-wide stress test (EBA) | Scope not known: EU banks in the EBA sample, not listed on the page | stress test results: none | Watch |
| Supervisory reporting simplification (EBA) | 11 EU banks (all but HSBC, Barclays, Lloyds, UBS) | none | Watch |
| Internal governance guidelines (EBA, final) | 11 EU banks | none | Watch |
| Securitisation Framework review (EU, political agreement) | 11 EU banks | securitisation exposure: none | Watch |
| Large exposures PS20/26 (PRA, final) | HSBC, Barclays, Lloyds | large exposures: none | Watch |
| SM&CR Phase 2 (PRA, consultation) | HSBC, Barclays, Lloyds | none | Watch |
| AMLO-FINMA (FINMA, final) | UBS | none | Watch |

Note: Scope by home supervisor; Basel standards apply once home rules adopt them.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- FSB 2026 G-SIB list not found on fsb.org at run time; the 27 Nov 2025 list is used.
- Left out (24): speeches, interviews, blogs (ECB, SRB, FINMA); newsletters (BCBS, ECB, PRA); sanctions (EC, FINMA); credit-union papers (PRA); EBA advice, appointment, deadline extension, consumer factsheet; ECB entity list; other non-measures.
- No Moody's comment found on the G-SIB, securitisation or stress-test items.

**Sources**

[1] Web · Basel Committee finalises measures to address window-dressing in the G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, CET1 capital … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING Groep stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, MDA trigger level for CET1, as … · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, CET1 … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays PLC stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, overall CET1 requirement … · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS Group AG stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, required … · 2026-06-30
[8] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. stated distance to SREP … · bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, distance to … · 2026-03-31
[9] Web · FSB 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[10] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[11] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[12] Web · BCBS consultative document: Interest rate risk in the banking book - additional … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[13] Web · EBA streamlines 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[14] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[15] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[16] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[17] Web · BCBS consultative document: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[18] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[19] Web · Commission welcomes political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[20] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 2026-11-15T22:56Z. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html (not published as an Artifact in this run).
