**Daily sector news: Proximus, Telekom Austria, Swisscom** (24h to 15 Nov 2026 22:49 UTC (from 14 Nov 2026 22:49 UTC); 3 names)

Nothing material for Telecoms (Proximus, Telekom Austria, Swisscom), Europe, in the last 24h.

Dashboard: "Daily sector news" tab updated 15 Nov 2026 22:50 UTC, at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-04-quiet/dashboard/dashboard.html
