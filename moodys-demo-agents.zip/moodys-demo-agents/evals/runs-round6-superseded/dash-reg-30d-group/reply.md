**Regulatory watch: European banks, last 30 days (16 Oct to 15 Nov 2026)**

I found 12 regulatory items in the window. One of them is new since the last run.

**New: ECB revised SREP liquidity and funding risk methodology (11 Nov 2026, final, applies from 2027).** It changes how supervisors score liquidity in SREP. It does not change the 100% LCR minimum. Eleven banking-union names on the list are in scope. Ranked by LCR headroom over 100% (Q2 2026, Moody's data):
- **Least headroom:** BNP Paribas 134.77%, Groupe Credit Agricole 135.75%, ING 137%
- **Middle:** Intesa Sanpaolo, UniCredit, Deutsche Bank, Commerzbank, BBVA
- **Most headroom:** Societe Generale 146.41%, Nordea 156%, CaixaBank 192.99%
- **Out of scope:** HSBC, Barclays, Lloyds (PRA) and UBS (FINMA)

**Basel Committee G-SIB package (16 Oct 2026).** This combines a final rule and a consultation:
- **Final rule:** indicators are averaged over the year, to be in place by 1 Jan 2030.
- **Consultation:** a review of the G-SIB methodology, with comments due 14 Jan 2027.

The table holds the eight FSB-listed G-SIBs and ranks them by CET1 level. They are ranked by level because only three have a current stated requirement.
- **Weaker third:** BNP Paribas 12.97% and ING 13.07%
- **Stronger third:** UBS 14.38% and Groupe Credit Agricole 17.23%

No 2026 FSB list was on fsb.org yet, so the 2025 list was used.

**Ten items have no Moody's metric and are tagged watch:**
- PRA large exposures PS20/26
- FINMA AML Ordinance
- EBA 2027 stress test
- Basel IRRBB Pillar 2 guidance
- EBA reporting next steps
- EBA internal governance guidelines (Moody's calls these credit positive, mainly for smaller EU banks, in a Sector Comment of 11 Nov 2026)
- Basel consolidated guidelines
- FINMA IRRBB circular consultation
- PRA SM&CR Phase 2 consultation
- EU securitisation political agreement

Twenty-one other publications were left out. They were speeches, newsletters, sanctions notices, appointments, or material addressed to other kinds of firm. They are listed in the tab's notes.

The positions show where each name sits among the names a rule covers. They are not an estimate of impact.

The Regulatory watch tab ("Banks Europe, 30 days") was updated at 21:27 UTC on 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/dash-reg-30d-group/dashboard/dashboard.html`. This was a test run, so the page was not published as an Artifact.
