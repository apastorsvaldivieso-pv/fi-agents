**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, both days included)**

I found 11 items at the primary regulators. One is new to the running list this run: the Basel Committee's consultation on consequential amendments to the Basel Framework (5 Nov). The other ten were already on the list.

**Who it hits: G-SIB window-dressing package (Basel Committee, 16 Oct) · CET1 ratio, Q2 2026**
Only this item maps to a Moody's metric. It covers the 8 names on the list that are on the FSB G-SIB list of 27 Nov 2025. I found no 2026 list on fsb.org yet.

| Name | CET1 | vs median | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | -2.26 | total not stated | 2.6 pp, bank-stated, 31 Mar 2026 | Weaker third |
| BNP Paribas | 12.97% | -0.59 | 10.51% (30 Sep 2025, older) | 2.46 pp, older | Weaker third |
| ING Groep | 13.07% | -0.49 | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp, older | Middle |
| Societe Generale | 13.20% | -0.36 | 10.26% (31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | +0.36 | not stated | not stated | Middle |
| HSBC | 14.10% | +0.54 | not stated | not stated | Middle |
| Barclays | 14.30% | +0.74 | 12.2% (31 Dec 2025, older) | 2.10 pp, older | Stronger third |
| UBS Group | 14.38% | +0.82 | 10.83% Swiss going-concern (30 Jun 2026) | 3.55 pp | Stronger third |

- **Why it's ranked by CET1 level, not headroom:** only 3 of the 8 banks have a current stated requirement, and ranking by headroom needs six.
- **Out of scope** (not G-SIBs): Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea.
- **Status:** the window-dressing amendments are final, with averaging of G-SIB indicators to be in place by 1 Jan 2030. The methodology review is still a consultation, with comments due 14 Jan 2027.

**What changed (newest first)**
- **PRA PS20/26, Large Exposures Part 2** (final, 10 Nov): takes effect 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **FINMA, revised Anti-Money Laundering Ordinance** (final, 10 Nov): in force 1 Jan 2027. Covers UBS.
- **Basel Committee, additional Pillar 2 guidance on interest rate risk in the banking book** (consultation, 9 Nov): comments due 9 Feb 2027.
- **EBA, 2027 EU-wide stress test methodology** (final, 9 Nov): launches end January 2027, results end July 2027.
- **EBA, next steps on reporting simplification** (6 Nov): first reference date December 2027.
- **EBA, revised Guidelines on internal governance** (final, 5 Nov). Moody's called them credit positive for small EU banks (Sector Comment, 11 Nov 2026).
- **NEW: Basel Committee, consolidated guidelines consequential amendments** (consultation, 5 Nov): comments due 21 Dec 2026. The channel map has no row for it.
- **FINMA, Circular 2019/2 on interest rate risks** (consultation, 4 Nov): runs until 15 Jan 2027.
- **PRA CP14/26, review of the Senior Managers and Certification Regime, Phase 2** (consultation, 22 Oct): responses due 22 Jan 2027.
- **European Commission, Securitisation Framework review** (political agreement, 22 Oct): not yet adopted.
- **Basel Committee, G-SIB package** (16 Oct): covered in the table above.

All items except the G-SIB package are on watch: Moody's data has no metric for their channels, so no bank is given a position on them. The tab lists which names each one covers.

The 27 left-out entries (speeches, newsletters, sanctions notices, appointments, credit-union papers and similar) are listed with their reasons in the tab's notes.

Positions show where each bank sits relative to the other banks the rule covers, on the stated metric. They are not an estimate of impact.

The Regulatory watch tab was updated at 20:21 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/dash-reg-30d/dashboard/dashboard.html`. This was a test run, so the page was not published to the private link.
