**BNP Paribas: earnings preview**

Moody's has one numeric trigger for BNP Paribas. An upgrade needs return on assets of 0.6% or above, and net income / tangible assets was 0.4% at June 2026. Every other trigger is worded. Moody's holds no earnings call transcript for BNP Paribas, so I used the latest results filing. That filing is the FY2025 annual report (to 31 Dec 2025), which is older than the June 2026 figures Moody's already holds.

**Rating and outlook**
A1 LT Issuer Rating, outlook stable. Last action: affirmed 31 Aug 2026. Credit opinion dated 2 Sep 2026.

**What to watch against Moody's triggers**

| Metric | Latest Moody's value | Upgrade trigger | Downgrade trigger | Room to upgrade |
|---|---|---|---|---|
| Return on assets (net income / tangible assets) | 0.4% (Jun 2026) | 0.6% and above | no number stated | 0.2 pp below |

The opinion says "return on assets" and its key indicators table reports net income / tangible assets. I have assumed they are the same measure.

Worded triggers, quoted from the opinion of 2 Sep 2026:
- Upgrade: "if the group manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management on its path to improving its return on assets to levels of 0.6% and above, limiting any sudden and significant increase in problem loans and risk provisioning."
- Upgrade: an upgrade of France's rating, "through a recovery of the previous government support uplift."
- Downgrade: "if the bank maintained lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics", or "a marked increase in risk appetite, loss incidents or a material risk management failure."
- Downgrade: "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile."
- Senior unsecured only: lower if growth in senior unsecured and lower-ranking debt relative to tangible banking assets "falls short of our current expectations" and the government support uplift does not offset it.
- Outlook (stable): "very stable and highly predictable profitability and sound risk profile". Moody's also expects BNP to adapt its liability structure to EU depositor preference.

**Sector metrics to watch**

| Metric | Latest (period) | Basis | Bears on |
|---|---|---|---|
| Net interest margin | 0.9% (Jun 2026) | Moody's-adjusted | Profitability / ROA trigger |
| Net income / tangible assets | 0.4% (Jun 2026) | Moody's-adjusted | Upgrade: ROA 0.6% |
| Cost of risk | not in Moody's data | | Asset quality (worded) |
| CET1 ratio | 12.97% (Q2 2026) | As reported | Capital buffers (worded) |
| TCE / RWA | 13.7% (Jun 2026) | Moody's-adjusted | Capital (worded) |
| Leverage ratio (fully loaded) | not in Moody's data | | Regulatory leverage (worded) |
| Problem loans / gross loans | 2.9% (Jun 2026) | Moody's-adjusted | Asset quality (worded) |
| Impaired loans / gross loans | 2.93% (Q2 2026) | As reported | Asset quality (worded) |
| Reserves / impaired loans | 57.7% (Q2 2026) | As reported | Provisioning (worded) |
| Cost / income | 60.6% (Jun 2026) | Moody's-adjusted | Profitability (worded) |
| LCR | 134.77% (Q2 2026) | As reported | Liquidity (worded) |
| NSFR | 108.63% (Q2 2026) | As reported | Funding (worded) |
| HQLA / tangible banking assets | 15.9% (Jun 2026) | Moody's-adjusted | Liquidity (worded) |
| Loans / customer deposits | 82.3% (Q2 2026) | As reported | Deposits, funding |
| Gross loans / due to customers | 85.8% (Jun 2026) | Moody's-adjusted | Deposits, funding |

**What the latest filing says** (company-reported, not Moody's-adjusted)
- The annual report for FY2025 (to 31 Dec 2025) gives net income attributable to shareholders of EUR 12,225m, against EUR 11,688m in 2024. Cash returned to shareholders was EUR 13,342m, against EUR 8,756m.
- The excerpts from the annual report have no forward guidance. The targets below come from the Q3 2025 interim filing, which carries a press release of 16 Sep 2025: ROTE of 12% in 2026, which closes the 2022–2026 plan; a ROTE ambition of 13% in 2028; CET1 expected at 12.5% by end-2027; and a new 2027–2030 plan due in early 2027. ROTE is the company's measure and is not Moody's ROA.
- CET1 was 12.5% at 30 Sep 2025, after deducting a 2025 dividend accrual of EUR 2.3bn.
- The 12-month average LCR was 133% at Sep 2025. That is a EUR 99bn surplus over the requirement, on EUR 398bn of average liquid assets.

**Moody's expectations**
The opinion's key indicators table has no forecast columns for BNP Paribas.

The latest period in Moody's data is Q2 2026. Moody's data does not show whether later results are out.

I updated the Earnings tab of the dashboard at 20:07 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html`. I skipped the Artifact publish because this is a test run.
