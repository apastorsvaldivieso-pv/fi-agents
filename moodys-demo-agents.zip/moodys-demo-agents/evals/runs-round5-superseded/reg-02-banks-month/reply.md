**Regulatory watch: European banks, 17 Oct to 15 Nov 2026 (30 days)**

I found eleven regulatory items. None of them falls on a metric that Moody's financial data carries, so no bank gets a headroom ranking this time. Every item is shown as `watch`, along with the banks on the list that it covers.

**What changed (newest first)**

| Date | Body | Item | Status | Key date | Covers on the list |
|---|---|---|---|---|---|
| 10 Nov | PRA | PS20/26, Large Exposures Framework Part 2 | Final | Effective 1 Jan 2028 | HSBC, Barclays, Lloyds |
| 10 Nov | FINMA | Revised FINMA Anti-Money Laundering Ordinance | Final | In force 1 Jan 2027 | UBS |
| 9 Nov | Basel Committee | IRRBB: additional Pillar 2 guidance | Consultation | Comments by 9 Feb 2027 | All 15, once each home jurisdiction applies it |
| 9 Nov | EBA | Final methodology for the 2027 EU-wide stress test (far fewer data points) | Final | Starts end-Jan 2027, results end-Jul 2027 | EU banks in the EBA sample. The page does not name the sample |
| 6 Nov | EBA | Supervisory reporting simplification: next steps and longer timelines | Other | First reference date Dec 2027. Liquidity, encumbrance, benchmarking and ESG reporting move to Dec 2028 | 11 EU names |
| 5 Nov | EBA | Revised internal governance Guidelines (CRD VI) | Final | Application date not stated | 11 EU names |
| 5 Nov | Basel Committee | Consolidated guidelines: consequential amendments (cross-references only) | Consultation | Comments by 21 Dec 2026 | All 15 |
| 4 Nov | FINMA | Circular 2019/2, interest rate risks for banks | Consultation | Comments by 15 Jan 2027 | UBS |
| 22 Oct | European Commission | Political agreement on the Securitisation Framework review (including CRR treatment) | Political agreement | Formal adoption pending, target end-2026 | 11 EU names |
| 22 Oct | PRA | CP14/26, SM&CR review phase 2 | Consultation | Comments by 22 Jan 2027 | HSBC, Barclays, Lloyds |
| 22 Oct | EBA | Four consultation deadlines moved to 26 Oct (including the ITS on depositor information) | Other | 26 Oct 2026 | 11 EU names |

The 11 EU names are BNP Paribas, Crédit Agricole S.A., Société Générale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea.

**Moody's view:** Moody's has commented on only one of these items. Its Sector Comment of 11 Nov 2026 calls the EBA governance guidelines credit positive for EU banks, with a bigger effect on smaller banks. I searched for Moody's research on the IRRBB guidance, the securitisation deal, the PRA large-exposure rules and the stress test and found nothing.

**Why there are no rankings:** The items fall under interest rate risk in the banking book, governance, AML, large exposures, securitisation, reporting and stress testing. Moody's financial data has no field for any of these. So I did not make the financials call, and no bank is given a position.

**Worth knowing:**
- On 16 Oct the Basel Committee finalised amendments to the G-SIB framework on window dressing and opened a consultation on reviewing the G-SIB methodology. That is one day before the 30-day window, so these are not counted as items here.
- 37 publications from the same period were left out: speeches, interviews, newsletters, sanctions notices, consumer material, items for credit unions, and advice from one authority to another. Each one, with its reason, is listed in the dashboard notes.

The Regulatory watch tab is refreshed (updated 2026-11-15 20:15 UTC):
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`
This is a test run, so the dashboard was not published to the Artifact link.
