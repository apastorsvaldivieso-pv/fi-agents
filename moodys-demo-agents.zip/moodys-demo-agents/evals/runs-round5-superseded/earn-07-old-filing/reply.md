**BNP Paribas, earnings recap (Q3 2026, reported 28 Oct 2026)**

Moody's holds no call transcript for BNP Paribas. The latest results filing it holds is the 2025 annual report (period end 31 Dec 2025), which is **older than the Q3 2026 results**. So the recap below rests mainly on Moody's own comment on the quarter and Moody's data. Rating: **A1 LT Issuer Rating, stable**. The one numeric trigger is Net Income / Tangible Assets of 0.6% for an upgrade. The latest Moody's figure is 0.4% (06-26).

**Results against the credit view**
- **Q3 2026 (Moody's Issuer Comment, 28 Oct 2026):** net income was EUR3.5bn, up 13.5% year on year. Return on RWA was 169 bp, return on assets 43 bp and return on tangible equity 13.0%. These are Moody's calculations, excluding exceptional items. Moody's says cost of risk was moderate and on target, revenue grew faster than costs, and the bank did sizable pre-funding for 2027.
- **Guidance:** beat or miss can't be shown. There's no transcript, the filing excerpts give no guidance, and the opinion's key indicators table has no Moody's forecast columns.
- **Filing (company-reported, FY2025, older than the latest results):**
  - Total assets were EUR2,792,981m at 31 Dec 2025, against EUR2,704,908m a year earlier.
  - Cash outflow from transactions with shareholders was EUR13,342m in 2025, against EUR8,756m in 2024.
  - The excerpts give no net debt (a bank doesn't report one), no undrawn facilities and no maturities.
  - The interim filing Moody's holds is from Q3 2025, which is older still, so I didn't use it.
- **Liquidity (Moody's data, Q2 2026, as reported):**
  - LCR was 134.77%, NSFR 108.63% and loans/deposits 82.30%.
  - HQLA / tangible banking assets was 15.9% at 06-26, down from 18.2% at 12-25 (Moody's key indicator).

**Against Moody's triggers**
| Metric | Latest | Upgrade | Downgrade | Room |
|---|---|---|---|---|
| Net Income / Tangible Assets | 0.4% (06-26) | return on assets ≥0.6% | worded | 0.2 pp below |

The downgrade triggers are worded, not numeric:
- lower capital buffers or higher regulatory leverage, together with weaker asset quality or profitability;
- a rise in risk appetite or a risk-management failure;
- worse operating conditions together with a significant weakening of funding and liquidity.

**Sector metrics (latest Moody's data)**
- **As reported, Q2 2026:** CET1 12.97%, impaired loans 2.93%, reserves / impaired loans 57.68%. The leverage ratio is not in Moody's data.
- **Moody's key indicators, 06-26:** TCE/RWA 13.7%, NIM 0.9%, cost/income 60.6%, problem loans 2.9%.

**What it means for the rating and outlook**
- Rating: A1 stable, affirmed 31 Aug 2026. BCA is baa1, plus three notches of LGF uplift and no government support notch.
- The credit opinion (2 Sep 2026) predates these results. Its outlook rests on "very stable and highly predictable profitability and sound risk profile". Moody's commented on the Q3 results on 28 Oct 2026.
- On profitability, the Q3 return on assets of 43 bp and the 06-26 ratio of 0.4% both sit below the 0.6% upgrade level.
- Company net debt is not a bank measure, so I can't compare it with Moody's figures.

Sources: Moody's credit opinion PBC_1491623 (2 Sep 2026); ratings RTNG_91000; Bank Focus financials, Q2 2026; Issuer Comment PBC_1499674 (28 Oct 2026); searchCompanyFilings, 2025 annual report (31 Dec 2025, pp. 5–6).

The Earnings tab of the dashboard is updated (20:08 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-07-old-filing/dashboard/dashboard.html`. Artifact publish was skipped for this test run.
