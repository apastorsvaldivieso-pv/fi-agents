**Regulatory watch: European banks, 30 days (17 Oct to 15 Nov 2026)**

**Names**

| Name | Country |
|---|---|
| BNP Paribas | FR |
| Deutsche Bank AG | DE |

Unresolved: **Zzyzx Fakecorp Bank**. Moody's returned no match for this name, so it is left out of everything below.

**Summary:** I found ten regulatory items in the window. None of them falls on a channel where Moody's has a metric, so neither bank gets a position and I made no financials call. Six of the items cover BNP Paribas and Deutsche Bank. The other four are UK (PRA) or Swiss (FINMA) rules, which cover neither bank.

**Items that cover BNP Paribas and Deutsche Bank** (all marked `watch`; Moody's data has no metric for these)

- **EBA, 9 Nov, final:** the 2027 EU-wide stress test methodology. It asks for far less data and adds a first climate module. The test launches at the end of January 2027 and results come out at the end of July 2027. The page does not name the banks in the sample.
- **Basel Committee, 9 Nov, consultation:** extra Pillar 2 guidance on interest rate risk in the banking book (IRRBB), plus a supervisory reporting regime. Comments are due by 9 Feb 2027.
- **EBA, 6 Nov, next steps after consultation:** simpler supervisory reporting, with later dates. The first reference date moves to December 2027. Liquidity, asset encumbrance, benchmarking and ESG reporting move to December 2028.
- **EBA, 5 Nov, final:** revised internal governance guidelines (EBA/GL/2026/10). Moody's (11 Nov 2026) calls them credit positive for EU banks, with more effect on smaller banks.
- **Basel Committee, 5 Nov, consultation:** technical amendments to cross-references in the consolidated guidelines. Comments are due by 21 Dec 2026.
- **European Commission, 22 Oct, political agreement:** the securitisation framework review, which makes the capital treatment of securitisations under the CRR more risk-sensitive. Formal adoption is still pending.

**Items that cover neither bank:** PRA PS20/26 on large exposures (final, effective 1 Jan 2028); PRA CP14/26 on SM&CR phase 2 (consultation); FINMA's revised Anti-Money Laundering Ordinance (in force 1 Jan 2027); FINMA's consultation on its IRRBB circular.

**Just outside the window:** on 16 Oct the Basel Committee finalised its G-SIB window-dressing amendments and opened a consultation on the G-SIB methodology. Both banks are G-SIBs. Ask if you want the window widened by one day to include these.

The dashboard's Regulatory watch tab was updated at 20:16 UTC on 15 Nov 2026:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html`
This was a test run, so the dashboard was not published as an Artifact.
