**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, both ends included)**

I found 11 regulatory items for the 15 banks on your coverage list. Ten were already on the running list from earlier runs. One is new: a Basel Committee consultation published on 5 Nov.

**Who it hits: G-SIB window-dressing standard (Basel Committee, 16 Oct) · CET1 ratio**
This is the only item that maps to a Moody's metric. On the capital channel it covers the 8 G-SIBs on your list. Names are ranked by CET1 level, not headroom, because only 3 of the 8 have a current stated requirement.

| Bank | CET1 (Q2 2026) | Stated requirement | Distance | Position |
|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | bank states its distance only (31 Mar 2026) | +2.6 pp (bank-stated) | Weaker third |
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | +2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% (31 Dec 2025, older) | +2.04 pp | Middle |
| Societe Generale | 13.20% | 10.26% (31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | – | Middle |
| HSBC | 14.10% | not stated | – | Middle |
| Barclays | 14.30% | 12.2% (31 Dec 2025, older) | +2.10 pp | Stronger third |
| UBS | 14.38% | 10.83% (30 Jun 2026) | +3.55 pp | Stronger third |

Out of scope, because they are not on the FSB G-SIB list of 27 Nov 2025: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. I found no 2026 FSB list yet. Positions show relative position among the names the rule covers. They are not an estimate of impact.

**What changed (newest first)**
- **PRA, final, 10 Nov:** PS20/26 on large exposures (Part 2). Takes effect 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **FINMA, final, 10 Nov:** revised Anti-Money Laundering Ordinance. In force 1 Jan 2027. Covers UBS.
- **EBA, final, 9 Nov:** 2027 EU-wide stress test methodology, asking for more than 55% less data. The exercise launches end Jan 2027 and results are due end Jul 2027.
- **Basel Committee, consultation, 9 Nov:** additional Pillar 2 guidance on interest rate risk in the banking book. Comments due 9 Feb 2027.
- **EBA, next steps, 6 Nov:** supervisory reporting simplification. First reference date is Dec 2027, with some reporting deferred to Dec 2028.
- **EBA, final, 5 Nov:** revised internal governance guidelines. Moody's Sector Comment of 11 Nov calls them credit positive, more so for small EU banks.
- **Basel Committee, consultation, 5 Nov (NEW):** consequential amendments that repoint Basel Framework cross-references to the new consolidated guidelines. Comments due 21 Dec 2026.
- **FINMA, consultation, 4 Nov:** revised Circular 2019/2 on interest rate risks for banks. Open until 15 Jan 2027. Covers UBS.
- **PRA, consultation, 22 Oct:** CP14/26, phase 2 of the SM&CR review. Responses due 22 Jan 2027.
- **European Commission, 22 Oct:** political agreement on the Securitisation Framework review. It applies once published in the Official Journal.
- **Basel Committee, 16 Oct:** final G-SIB window-dressing standard, implemented by 1 Jan 2030, plus a consultation on the G-SIB methodology review. Comments due 14 Jan 2027.

The other 10 items have no Moody's metric behind them. They are marked "watch" with the names each covers, and no bank gets a position on them. I left out 22 entries from the regulators' listings: speeches, newsletters, sanctions notices, an appointment, consumer material and papers addressed to other kinds of firm. They are grouped by reason in the tab's notes.

The Regulatory watch tab is updated (20:27 UTC, 15 Nov 2026):
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/dash-reg-30d-final/dashboard/dashboard.html`
This was a test run, so the dashboard was not published to the private link.
