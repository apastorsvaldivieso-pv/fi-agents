**Regulatory watch: European banks, 17 Oct to 15 Nov 2026 (30 days)**

**EBA revised Guidelines on internal governance: who it hits**

The EBA published them on 5 Nov 2026 as final guidelines, still awaiting translation. They bring the 2021 guidelines into line with CRD VI and DORA. The changes: a mapping of duties for board members and key function holders, simpler conflict-of-interest rules, a governance framework for third-country branches, and new chapters on how transparent the corporate structure is, the supervisory function, and IT and business continuity. The EBA pages leave the application date and compliance deadline blank and say "not yet applicable". I couldn't read the final report PDF to confirm the date. ([EBA press release](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and), [EBA status page](https://www.eba.europa.eu/activities/single-rulebook/regulatory-activities/internal-governance/guidelines-internal-governance-under-crd))

- **Covered (11 EU groups):** BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea.
- **Not covered (4):** HSBC, Barclays and Lloyds (home supervisor is the PRA) and UBS (FINMA). Their EU subsidiaries and EU branches fall under the guidelines locally, but scope here is judged for each group at its home.
- **No ranking:** Moody's data has no governance metric, so the item is marked `watch` and no bank gets a position.
- **Moody's view:** Moody's Sector Comment of 11 Nov 2026 (PBC_1502042) calls the revision credit positive for EU banks because it strengthens board oversight, accountability and risk control. Moody's expects the bigger effect at smaller banks, because large banks already apply most of it, and expects the benefits to build gradually.

Governance for your UK names: the PRA's **CP14/26 (SM&CR review, phase 2)**, 22 Oct, is a consultation with comments due by 22 Jan 2027. It covers HSBC, Barclays and Lloyds. ([PRA](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper))

**Everything else in the window (all `watch`, none maps to a Moody's metric)**

| Date | Item | Status | Covers |
|---|---|---|---|
| 10 Nov | PRA PS20/26, large exposures part 2. Implementation 1 Jan 2028 | Final | HSBC, Barclays, Lloyds |
| 10 Nov | FINMA Anti-Money Laundering Ordinance. In force 1 Jan 2027 | Final | UBS |
| 9 Nov | Basel Committee, IRRBB Pillar 2 guidance. Comments by 9 Feb 2027 | Consultation | All 15, once applied at home |
| 9 Nov | EBA 2027 EU-wide stress test methodology. Launch end Jan 2027 | Final | Scope not known (the page doesn't name the sample) |
| 6 Nov | EBA reporting simplification. First reference date moves to Dec 2027 | Next steps | 11 EU groups |
| 5 Nov | Basel Committee, consolidated guidelines amendments. Comments by 21 Dec 2026 | Consultation | All 15 |
| 4 Nov | FINMA Circular 2019/2, interest rate risks. Comments by 15 Jan 2027 | Consultation | UBS |
| 22 Oct | EC political agreement on the Securitisation Framework, including CRR changes | Legislative step, not yet adopted | 11 EU groups |
| 22 Oct | EBA extends four consultation deadlines to 26 Oct 2026 | Dates only | 11 EU groups |

Nothing in the window from the ECB or the SRB counted as an item: they published speeches, interviews and reports only. I left out 20 other entries because they aren't rules addressed to banks; the run file lists them with reasons. I skipped the financials call because no item maps to a metric.

Dashboard: the Regulatory watch tab was updated at 2026-11-15 20:16 UTC. Local page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-03-no-metric/dashboard/dashboard.html`. This was a test run, so it wasn't published to the Artifact link.
