import json, subprocess
now = subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
banks = [("BNP Paribas","FR",134.77,"FR662042449"),("HSBC Holdings plc","GB",134,"GB00617987"),("Credit Agricole S.A.","FR",141.29,"FR784608416"),
("Barclays PLC","GB",157.7,"GB00048839"),("Societe Generale","FR",146.41,"FR552120222"),("Deutsche Bank AG","DE",140.12,"DEFEB13216"),
("UBS Group AG","CH",177.28,"CHCHE395345924"),("ING Groep N.V.","NL",137,"NL33231073"),("Lloyds Banking Group plc","GB",144,"GBSC095000"),
("UniCredit S.p.A.","IT",140,"IT00348170101"),("Intesa Sanpaolo S.p.A.","IT",137.6,"IT00799960158"),("Banco Bilbao Vizcaya Argentaria, S.A.","ES",142,"ESA48265169"),
("CaixaBank, S.A.","ES",192.99,"ESA08663619"),("Commerzbank AG","DE",141,"DEFEB13190"),("Nordea Bank Abp","FI",156,"FI28583949")]
sources=[{"id":"w0","kind":"web","title":"Basel Framework (LEV, LCR, NSF standards): LCR minimum 100%","date":"2023-03-30","url":"https://www.bis.org/basel_framework/"}]
sid={}
for i,(n,c,v,b) in enumerate(banks,1):
    sid[n]="m%d"%i
    sources.append({"id":"m%d"%i,"kind":"moodys","tool":"getEntityFinancials_v2","ref":"Basel III Liquidity Coverage Ratio (LCR) (as reported), LQ = Q2 2026 (period end 30 Jun 2026)","title":n+" financials","date":"2026-06-30","url":"https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/"+b})
ranked=sorted(banks,key=lambda x:x[2])
vals=[x[2] for x in ranked]; med=vals[len(vals)//2]
k=len(ranked)//3
rows=[]
for i,(n,c,v,b) in enumerate(ranked):
    tone="least" if i<k else ("most" if i>=len(ranked)-k else "middle")
    s=sid[n]
    rows.append([n,{"v":"%g%%"%v,"src":[s]},{"v":"%+.2f pp"%(v-med),"src":[s]},{"v":"100% (Basel III minimum)","src":["w0"]},{"v":"%.2f pp"%(v-100),"src":[s,"w0"]},{"tone":tone,"v":""}])
web=[("w1","Basel Committee: Interest rate risk in the banking book - additional Pillar 2 guidance (consultative)","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"),
("w2","Basel Committee: Consolidated guidelines - consequential amendments (consultative)","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"),
("w3","EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% reduction in requested data","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"),
("w4","EBA: next steps on supervisory reporting simplification and extended implementation timelines","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"),
("w5","EBA: revised Guidelines on internal governance","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"),
("w6","EBA: The EBA extends some consultation deadlines due to website maintenance","2026-10-22","https://www.eba.europa.eu/publications-and-media/press-releases/eba-extends-some-consultation-deadlines-due-website-maintenance"),
("w7","European Commission: political agreement on the review of the Securitisation Framework","2026-10-22","https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"),
("w8","PRA: PS20/26 - Amendments to the Large Exposures Framework - Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"),
("w9","PRA: CP14/26 - Review of the SM&CR - Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"),
("w10","FINMA: partially revised FINMA Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"),
("w11","FINMA: consultation on partially revised Circular 2019/2 'Interest rate risks - banks'","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/")]
for i,t,d,u in web: sources.append({"id":i,"kind":"web","title":t,"date":d,"url":u})
sources.append({"id":"m16","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042, Sector Comment","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"})
EU="BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank AG, Commerzbank AG, ING Groep N.V., UniCredit S.p.A., Intesa Sanpaolo S.p.A., BBVA, CaixaBank, Nordea Bank Abp"
UK="HSBC Holdings plc, Barclays PLC, Lloyds Banking Group plc"
items=[
 {"flag":"Asked","tag":"Liquidity · LCR","name":"Asked by user","text":"You asked for the liquidity channel. No regulatory change to the LCR requirement was found at the seven primary regulators between 17 Oct and 15 Nov 2026. The only liquidity-related step in the window is a reporting one: the EBA moved liquidity reporting changes under its reporting simplification to December 2028 (see the EBA item of 6 Nov); that changes templates and dates, not the LCR minimum.","why":"Shown so each bank's distance to the 100% LCR minimum is visible; it is not a rule change.","src":["w4","w0"]},
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26, Large Exposures Framework Part 2 (10 Nov 2026): banks must apply substitution to exposures reduced by credit risk mitigation, the internal model option for SFT exposure values is removed and trading book allowances are tightened. Applies from 1 Jan 2028. Channel: large exposures (no Moody's metric).","why":"Concentration limits for UK groups tighten from 2028; Moody's data carries no large-exposures metric, so no position is given.","src":["w8"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance (10 Nov 2026), aligning with the revised AMLA ahead of the FATF evaluation; in force 1 Jan 2027 with a four-month transition for self-regulation. Channel: AML (no Moody's metric).","why":"Compliance and conduct risk for Swiss banks; no balance-sheet metric moves.","src":["w10"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consultation on additional Pillar 2 guidance for interest rate risk in the banking book (9 Nov 2026): model risk and validation, stress testing, controls, embedded gains and losses in securities portfolios, earnings indicators, and new supervisory information reporting. Comments by 9 Feb 2027. Channel: IRRBB (no Moody's metric).","why":"Could raise supervisory scrutiny of unrealised securities losses and earnings sensitivity; Moody's data carries no IRRBB metric.","src":["w1"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology for the 2027 EU-wide stress test (9 Nov 2026), with more than 55% fewer data points and a separate climate module that does not affect core results. Launch end-January 2027, results end-July 2027. Channel: stress testing and reporting, mapped to watch by our judgment (no channel-map row).","why":"Stress test results feed supervisors' capital guidance; this step changes the data request, not any requirement.","src":["w3"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on supervisory reporting simplification after the ITS consultation (6 Nov 2026): final report due December 2026, first reference date moved to December 2027, and liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Channel: reporting (no Moody's metric).","why":"Lower reporting burden and later dates; no change to any prudential requirement.","src":["w4"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance (5 Nov 2026), aligned with CRD VI: duty mapping for management body members and key function holders, a governance framework for third-country branches, and simpler conflict-of-interest rules. Application date not stated on the page. Channel: governance (no Moody's metric). Moody's view: Sector Comment of 11 Nov 2026 calls the revisions credit positive, with a greater effect on smaller banks.","why":"Moody's states a positive credit direction; the large banks on this list have already been adopting the guidelines, per that comment.","src":["w5","m16"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consultation on consequential amendments from the consolidated guidelines (5 Nov 2026): cross-references in the Basel Framework repointed and some application-guidance chapters moved. Comments by 21 Dec 2026. Channel: framework structure, mapped to watch by our judgment (no channel-map row).","why":"Editorial and structural; no requirement changes stated on the page.","src":["w2"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consultation on partially revised Circular 2019/2 'Interest rate risks - banks' (4 Nov 2026), applying the Basel Committee's July 2024 recalibrated shock scenarios and giving more weight to earnings effects. Consultation until 15 Jan 2027; effective date not stated. Channel: IRRBB (no Moody's metric).","why":"Swiss IRRBB measurement changes; Moody's data carries no IRRBB metric.","src":["w11"]},
 {"flag":"NEW","tag":"Other","name":"European Commission","text":"Provisional political agreement on the review of the Securitisation Framework (22 Oct 2026), including CRR changes to make the prudential treatment of securitisations more risk-sensitive. Formal adoption by Parliament and Council still to come, no dates; the Council aims to finish by end-2026. Not yet final. Channel: securitisation (no Moody's metric).","why":"Could change capital relief from securitisation and SRT for EU banks once adopted; the page gives no figures.","src":["w7"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26, Review of the Senior Managers and Certification Regime, Phase 2 (22 Oct 2026): notification instead of pre-approval for some senior roles and removal of the Certification Regime. Comments by 22 Jan 2027; depends on the Financial Services and Markets Bill 2026. Channel: governance (no Moody's metric).","why":"Governance and accountability regime for UK banks; no balance-sheet metric moves.","src":["w9"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Four EBA consultations (DGS investment of available financial means, information exchange ITS, depositor information ITS, MiCA fines methodology) had their deadlines moved to 26 Oct 2026 because of website maintenance (22 Oct 2026). Channel: deposit protection and conduct, mapped to watch by our judgment (no channel-map row).","why":"Date change only.","src":["w6"]},
]
watch=[
 ["PRA PS20/26 Large exposures (final, 10 Nov)",UK,"Large exposures metric (none in Moody's data)",{"tone":"watch","v":"watch"}],
 ["FINMA AML Ordinance (final, 10 Nov)","UBS Group AG","none (AML)",{"tone":"watch","v":"watch"}],
 ["BCBS IRRBB Pillar 2 guidance (consultation, 9 Nov)","All 15 names, once home jurisdictions apply it","IRRBB metric (none in Moody's data)",{"tone":"watch","v":"watch"}],
 ["EBA 2027 stress test methodology (final, 9 Nov)","Scope not known: EU banks in the EBA sample; sample not checked ("+EU+")","none (stress test)",{"tone":"watch","v":"watch"}],
 ["EBA reporting simplification next steps (6 Nov)",EU,"none (reporting)",{"tone":"watch","v":"watch"}],
 ["EBA internal governance guidelines (final, 5 Nov)",EU,"none (governance)",{"tone":"watch","v":"watch"}],
 ["BCBS consolidated guidelines amendments (consultation, 5 Nov)","All 15 names, once home jurisdictions apply it","none (framework structure)",{"tone":"watch","v":"watch"}],
 ["FINMA Circular 2019/2 interest rate risks (consultation, 4 Nov)","UBS Group AG","IRRBB metric (none in Moody's data)",{"tone":"watch","v":"watch"}],
 ["EU Securitisation Framework (political agreement, 22 Oct)",EU,"securitisation exposure / SRT (none in Moody's data)",{"tone":"watch","v":"watch"}],
 ["PRA CP14/26 SM&CR Phase 2 (consultation, 22 Oct)",UK,"none (governance)",{"tone":"watch","v":"watch"}],
 ["EBA consultation deadline extension (22 Oct)",EU+" (to the extent the consultations address banks)","none",{"tone":"watch","v":"watch"}],
]
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"sector":"Banks","region":"Europe","window":"30 days, 17 Oct to 15 Nov 2026","names":15,"label":"Banks Europe, 30 days, liquidity asked"},
 "status":"ok",
 "headline":"No change to the LCR in the 30 days to 15 Nov 2026; on Q2 2026 data HSBC (134%) and BNP Paribas (134.77%) sit closest to the 100% minimum, about 34 pp above it, and none of the 11 items found touches a Moody's metric.",
 "headline_src":[sid["HSBC Holdings plc"],sid["BNP Paribas"],"w0"],
 "sections":[
  {"title":"Who it hits: Liquidity, asked (no change in window) · LCR","type":"table",
   "columns":["Name","LCR, Q2 2026 (as reported)","vs median of ranked names (pp)","Stated requirement","Distance to requirement","Position"],
   "rows":rows,"note":"All 15 names in scope: the 100% LCR minimum applies to every bank on the list (Basel III; EU CRR, PRA and FINMA rules). No names out of scope. Median 141.29% (Credit Agricole S.A.).","note_src":[sid["Credit Agricole S.A."],"w0"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch,
   "note":"EU items cover the 11 EU/EEA groups; PRA items the 3 UK groups; FINMA items UBS only. A subsidiary supervised elsewhere is not counted."}
 ],
 "sources":sources,"unresolved":[],
 "notes":["Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "The LCR minimum shown is the Basel III 100% standard; local rules can be higher.",
  "Left out (20 entries in the window): BCBS AML/CFT supervisory newsletter (newsletter); EBA NGFS declaration support (statement, not a rule), consumer factsheet (consumer material), Taxonomy disclosures advice (advice to the Commission), Vice-Chair appointment (appointment); ECB eight speeches and interviews, Eurogroup written overview (report to another body), list of supervised entities (periodic list); SRB blog, speeches and dialogue news; Commission sustainability assurance consultation (addressed to auditors), competitiveness dialogue summary, tokenisation nominations, sanctions statements, sustainable investment data (statistics); PRA CP15/26 and DP2/26 (credit unions), Regulatory Digest (newsletter); FINMA sanctions notices, a speech, Bitcoin ETF approval (addressed to a fund).",
  "Basel Committee news listing showed nothing in the window (newest entry 16 Oct 2026, the day before it starts).",
  "Moody's view checked for four items (IRRBB, securitisation, PRA large exposures, EBA stress test): only the EBA governance guidelines drew a Moody's comment in the window."],
 "meta":{"calls":{"moodys":5,"web":23}}}
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
