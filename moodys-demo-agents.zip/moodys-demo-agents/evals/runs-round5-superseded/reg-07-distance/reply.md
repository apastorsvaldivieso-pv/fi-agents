**Regulatory watch: European banks, 30 days (17 Oct to 15 Nov 2026)**

Nothing in the window changes the LCR. As you asked, I've still included the liquidity channel. It is marked "Asked" and shows each bank's distance to the 100% Basel III minimum.

**Who it hits: liquidity (asked, no change in window) · LCR, Q2 2026, as reported (Moody's financials)**

| Name | LCR | Distance to 100% | Position |
|---|---|---|---|
| HSBC Holdings plc | 134% | 34.00 pp | Least headroom |
| BNP Paribas | 134.77% | 34.77 pp | Least headroom |
| ING Groep N.V. | 137% | 37.00 pp | Least headroom |
| Intesa Sanpaolo | 137.6% | 37.60 pp | Least headroom |
| UniCredit | 140% | 40.00 pp | Least headroom |
| Deutsche Bank | 140.12% | 40.12 pp | Middle |
| Commerzbank | 141% | 41.00 pp | Middle |
| Credit Agricole S.A. | 141.29% | 41.29 pp | Middle |
| BBVA | 142% | 42.00 pp | Middle |
| Lloyds Banking Group | 144% | 44.00 pp | Middle |
| Societe Generale | 146.41% | 46.41 pp | Most headroom |
| Nordea | 156% | 56.00 pp | Most headroom |
| Barclays | 157.7% | 57.70 pp | Most headroom |
| UBS Group | 177.28% | 77.28 pp | Most headroom |
| CaixaBank | 192.99% | 92.99 pp | Most headroom |

All 15 banks are in scope. The median is 141.29%. Local rules can set a minimum above 100%.

**What changed: 11 items, newest first. None of them maps to a Moody's metric, so they are all "watch".**
- **PRA, 10 Nov, final:** PS20/26 on large exposures (Part 2). Applies from 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **FINMA, 10 Nov, final:** revised Anti-Money Laundering Ordinance. In force 1 Jan 2027. Covers UBS.
- **Basel Committee, 9 Nov, consultation:** additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB). Comments by 9 Feb 2027.
- **EBA, 9 Nov, final methodology:** the 2027 EU-wide stress test asks for more than 55% less data. Launches end-January 2027.
- **EBA, 6 Nov:** next steps on simplifying supervisory reporting. The first reference date moves to December 2027, and liquidity reporting moves to December 2028. This changes reporting only, not the LCR minimum.
- **EBA, 5 Nov, final:** revised guidelines on internal governance. Moody's said on 11 Nov that they are credit positive, more so for smaller banks.
- **Basel Committee, 5 Nov, consultation:** consequential amendments from the consolidated guidelines. Comments by 21 Dec 2026.
- **FINMA, 4 Nov, consultation:** revised Circular 2019/2 on interest rate risks for banks. Consultation runs until 15 Jan 2027.
- **European Commission, 22 Oct:** provisional political agreement on the review of the securitisation framework. It is not final yet.
- **PRA, 22 Oct, consultation:** CP14/26, phase 2 of the Senior Managers and Certification Regime review. Comments by 22 Jan 2027.
- **EBA, 22 Oct:** four consultation deadlines moved to 26 Oct.

I left out 20 other entries in the window: speeches, newsletters, sanctions notices, consumer material and items addressed to credit unions. The reason for each is in the notes.

The Regulatory watch tab is updated (20:14 UTC, 15 Nov 2026). Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html`. I did not publish it to the shared link in this run.

*Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.*
