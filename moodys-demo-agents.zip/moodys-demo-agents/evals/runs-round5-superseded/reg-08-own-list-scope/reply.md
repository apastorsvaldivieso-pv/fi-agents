**Regulatory watch: your 12 banks, 30 days to 15 Nov 2026 (17 Oct to 15 Nov)**

**Your list**

| Name | Country |
|---|---|
| HSBC Holdings plc | GB |
| BNP Paribas | FR |
| Deutsche Bank AG | DE |
| UBS Group AG | CH |
| Barclays PLC | GB |
| ING Groep N.V. | NL |
| Societe Generale | FR |
| Credit Agricole S.A. | FR |
| Danske Bank A/S | DK |
| KBC Group N.V. | BE |
| Banco de Sabadell, S.A. | ES |
| Swedbank AB | SE |

All 12 resolved, so nothing is unresolved. Eight came from the checked European banks list. I looked up Danske, KBC, Sabadell and Swedbank in Moody's and confirmed each has a rating. The list is saved as your own list, and the standard list is unchanged.

**Headline:** I found 11 regulatory items in the window. None of them touches a metric Moody's carries (CET1, leverage, LCR, NSFR, asset quality, loans/deposits, RWA density). So no bank gets a headroom ranking this time. Every item is marked "watch", with the names it covers.

**What changed (newest first, all new to the running list)**
- **PRA, final, 10 Nov:** PS20/26, large exposures part 2. Internal models are removed for securities-financing exposure values, and credit risk mitigation substitution becomes mandatory. The trading-book excess allowance for third-party exposures drops to 85% of Tier 1 for up to 10 business days. Effective 1 Jan 2028. *Covers HSBC and Barclays.*
- **FINMA, final, 10 Nov:** revised Anti-Money Laundering Ordinance, in force 1 Jan 2027. *Covers UBS.*
- **Basel Committee, 9 Nov:** additional Pillar 2 guidance on interest rate risk in the banking book. The page would not open, so its status and dates are not confirmed. *Covers all 12 once their home jurisdictions apply it.*
- **EBA, final, 9 Nov:** methodology for the 2027 EU-wide stress test, with requested data cut by more than 55% and a climate module added. Launch is end-January 2027, results end-July 2027. *Scope is not known for the 9 EU/EEA names because the sample is not named.*
- **EBA, 6 Nov:** next steps on simplifying supervisory reporting. Final report in Dec 2026, first reference date Dec 2027, and some templates pushed to Dec 2028. *Covers the 9 EU/EEA names.*
- **EBA, final, 5 Nov:** revised internal governance guidelines (CRD VI). Moody's Sector Comment of 11 Nov calls them credit positive for EU banks, more so for smaller ones. *Covers the 9 EU/EEA names.*
- **Basel Committee, 5 Nov:** consequential amendments to the Basel Framework for the consolidated guidelines. The document could not be read, so its status is not confirmed. *Covers all 12 once applied at home.*
- **FINMA, consultation, 4 Nov:** Circular 2019/2 on interest rate risk, adopting the Basel shocks recalibrated in 2024. Comments are due by 15 Jan 2027. *Covers UBS.*
- **European Commission, 22 Oct:** political agreement on the Securitisation Framework review, including CRR changes to securitisation capital. It still needs formal adoption, targeted for end-2026. *Covers the 9 EU/EEA names.*
- **PRA, consultation, 22 Oct:** CP14/26, phase 2 of the Senior Managers and Certification Regime (SM&CR) reform. Comments are due by 22 Jan 2027. *Covers HSBC and Barclays.*
- **EBA, 22 Oct:** four consultation deadlines extended to 26 Oct (deposit guarantee schemes, depositor information, information exchange, MiCA fines). *Covers the EU/EEA names only through the depositor-information standard.*

**Scope across your list:** EU and EBA items cover BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske, KBC, Sabadell and Swedbank. They do not cover HSBC and Barclays (PRA) or UBS (FINMA). PRA items cover only HSBC and Barclays, and FINMA items cover only UBS.

**Things to know**
- Two Basel Committee G-SIB items, the methodology review consultation and the window-dressing amendments, are dated 16 Oct. That is one day before this 30-day window, so they are not shown. If you want them in, I can rerun from 16 Oct.
- The ECB's press feed only returned speeches for this period, and a site search found no ECB press release in the window. ECB items could still be missing.
- 37 other entries were left out: speeches, sanctions notices, newsletters, consumer material, appointments, papers for credit unions, and so on. The dashboard notes list them with the reason for each.

The Regulatory watch tab was updated at 20:15 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html`. It was not published to a link in this test run.
