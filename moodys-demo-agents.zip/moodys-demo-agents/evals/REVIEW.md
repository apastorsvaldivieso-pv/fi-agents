# The source review: a standing test for all three agents

The script checks test form, sourcing and rules. They cannot tell whether an answer is right or complete. This review can: a separate reader takes a fresh answer and re-pulls everything from the source. **Run it whenever a skill changes**, for the agent whose skill changed, and before showing an agent to a client after any change.

Each review reports three counts, so runs can be compared:

- **Wrong**: a stated fact that the source contradicts.
- **Missing**: a material item, in the source and inside the window, that the answer does not have.
- **Unsupported**: a claim that no source the reader can find supports.

The target is zero wrong and zero unsupported. Results go in `evals/results/`, one file per review, with the date.

## How to run one

1. **A fresh run.** A new session follows `evals/RUNNER.md` with a case id that starts `review-` (for example `review-news-telecoms`) and the prompt below. Use Claude Opus 5.5, the model the skills are built for.
2. **A separate reader.** A second new session, which has not seen the run being made, gets the reader brief below, filled in for that run. It re-pulls from Moody's (and, for the regulatory watch, from the regulators' own pages) and does not rely on the answer's own sources.
3. **Record the counts** next to the last review's, and list each finding.
4. **Do not fix anything from the findings until the person who owns the agents has seen them.**

## Prompts

| Agent | Prompt for the fresh run |
|---|---|
| News brief | "Run the sector news brief for European telecoms for the last 7 days." and the same for European banks |
| Regulatory watch | "Run the regulatory watch for European banks for the last 30 days." |
| Earnings | "Earnings recap for <an issuer that reported in the last three weeks>." |

## Reader brief (all agents)

> You are reviewing the output of a credit agent as a sceptical credit analyst who covers these names would: looking for anything wrong, anything material that is missing, and anything claimed that the source does not support. Do not edit any file. Pull the evidence yourself; do not trust the answer's own sources.
>
> What to review: `<run folder>/reply.md` (what the user saw in the chat) and `<run folder>/dashboard/data/<agent>.json` (the same content with its sources; `scope.window` gives the exact window). The names and their Moody's entity IDs are in `plugin/skills/coverage-list/lists/<list>.json`.
>
> Report in under 500 words, findings first, in four groups: WRONG (what the answer says, what the source says), MISSING (the item, its date, its source), UNSUPPORTED (the claim you could not find), MINOR (wording, labels, anything else). If a group is empty, say "none found". End with one line: how many facts you checked and how many calls you made. Do not pad: if the answer is right, say so plainly.

Then add the checks for the agent.

### News brief

Tools: `getEntityRatings`, `searchNews`, `searchAllDocuments`, `getCreditOpinion`. No web.

1. **Ratings**: re-pull every name's rating, class, outlook or review status and last action date. Flag any mismatch, and any Moody's action inside the window the brief does not mention. Where the brief says ratings are under review, check which ratings and which direction against the rating action.
2. **Moody's research**: search for rating actions, issuer comments, sector comments, credit opinions and outlooks in the window on the names and the sector. Flag anything missed or misdescribed. Check the outlooks cited are the latest, and that the brief does not say something does not exist when a search simply did not return it.
3. **Claims**: find every deal size, stake, date, results figure and guidance change in Moody's news for that name in the window. Flag a figure that differs, an event outside the window, and anything you cannot find.
4. **Results in full**: for each name that reported in the window, check the brief gives profit or loss with any impairment, the guidance change, and leverage or net debt (capital and distributions for a bank), not only the favourable half.
5. **Omissions**: for each name, search its news in the window against the checklist in `plugin/skills/sector-news-brief/materiality.md`. Flag any item on the checklist that the brief left out.
6. **"Why it matters"**: check every fact in each such line against a source: Moody's trigger or outlook wording in the credit opinion, a Moody's figure, or the item's article. Flag any that has none.
7. **Wording and entities**: flag an investment opinion, a forecast of a rating action, a description stronger than the source's, and an item about a different company or a subsidiary presented as the group.

### Regulatory watch

Tools: `getEntityFinancials_v2`, `searchAllDocuments`, web search and page fetch limited to the regulator sites in `plugin/skills/sector-metrics/sectors/banks.md`.

1. **Items**: open each regulator's own listing for the window and each item's page. Check date, body, status (consultation or final), effective date or deadline, and that every figure keeps the regulator's own qualifier. Flag any rule, guideline, consultation or policy statement addressed to banks inside the window that the answer does not show or name as left out.
2. **Scope**: for each table, check that every name ranked is one the measure in the table's heading covers, using `plugin/skills/sector-metrics/sectors/banks-scope.md` and the regulator's own document. Check names out of scope are named as such.
3. **Figures**: re-pull the metric for every name in each table with the full field list in `banks.md`, at the period the answer states. Check values, the median, each distance, and that the thirds are right. Check Credit Agricole is measured as the group.
4. **Requirements**: check each stated requirement and its date against the table in `banks-scope.md`.
5. **Moody's view**: check any Moody's comment quoted exists, with its title, date and direction.
6. **Wording**: flag any estimate of impact, any position given without a Moody's metric, and a consultation described as final.

### Earnings

Tools: `getCreditOpinion`, `getEntityRatings`, `getEntityFinancials_v2`, `searchCompanyFilings`, `searchAllDocuments`. No web.

1. **Credit view**: re-pull the rating, class, outlook and last action; the upgrade and downgrade triggers and outlook wording; Moody's forecasts, and the latest rating action's text. Check every one quoted, and the opinion's date.
2. **Trigger table**: re-pull the Moody's-adjusted metrics and their period. Recompute the room to each trigger.
3. **Company figures**: search the call transcript and the results report for every company-reported figure in the answer (guidance, growth rates, net debt and its drivers, liquidity, facilities, maturities, capex, dividends, buybacks). Check each figure, its period and that it is labelled company-reported; check a figure an analyst stated is labelled as the analyst's.
4. **Omissions**: search the results report for a loss, an impairment, a covenant or liquidity warning, a change to financial policy or a large deal that the answer leaves out.
5. **What it means**: check the statement on whether the opinion predates the results, what the opinion says about the cause of any change in net debt, and whether Moody's has commented on the results.
6. **Wording**: flag a Moody's ratio recomputed from company figures, a comparison with consensus, a forecast of a rating action and any view on the bonds or shares.

## Record

| Date | Agent | Run | Wrong | Missing | Unsupported | File |
|---|---|---|---|---|---|---|
| 15 Nov 2026 | News brief | telecoms, 7 days | 3 | 6 | 4 | `results/news-review.md` |
| 15 Nov 2026 | News brief | banks, 7 days | 4 | 5 | 3 | `results/news-review.md` |
| 15 Nov 2026, after the seven news fixes | News brief | telecoms, 7 days | 2 | 3 | 2 | `results/news-review-2.md` |
| 15 Nov 2026, after the seven news fixes | News brief | banks, 7 days | 2 | 2 | 1 | `results/news-review-2.md` |
| 15 Nov 2026 | Regulatory watch | banks, 30 days | 1 | 0 | 0 | `results/reg-review.md` |
| 15 Nov 2026 | Earnings | Vodafone recap | 1 | 6 | 1 (not verified) | `results/earnings-review.md` |
| 15 Nov 2026, after the fixes from the source reviews | News brief | telecoms, 7 days | 2 | 1 | 0 | `results/news-review-3.md` |
| 15 Nov 2026, after the fixes from the source reviews | News brief | banks, 7 days | 2 | 1 | 0 | `results/news-review-3.md` |
| 15 Nov 2026, after the fixes from the source reviews | Regulatory watch | banks, 30 days | 0 | 0 | 0 | `results/reg-review-2.md` |
| 15 Nov 2026, after the fixes from the source reviews | Earnings | Vodafone recap | 1 | 4 | 0 | `results/earnings-review-2.md` |
| 16 Nov 2026, after the last round of fixes | News brief | telecoms, 7 days | 2 | 2 | 0 | `results/news-review-4.md` |
| 16 Nov 2026, after the last round of fixes | News brief | banks, 7 days | 1 | 1 | 1 | `results/news-review-4.md` |
| 16 Nov 2026, after the last round of fixes | Earnings | Vodafone recap | 0 | 3 | 0 | `results/earnings-review-3.md` |

Counting rules used by the readers, so later reviews compare like with like: count each distinct item once; an item the answer names as left out counts as missing only if the reason it gives is false; a figure the answer says was not returned, but which the source does carry for that name, counts as missing once; a missing rating class, a heading, or a date that the answer's own source leaves unclear is minor, not wrong.
