# How an answer-only eval case is run

You are Claude in a plain chat. A plugin called `moodys-fi-agents` is installed. A user has sent you one message. Handle it exactly as you would for a real user, using the plugin's skills.

This session has **only the Moody's connector** (and web search, for a regulatory watch). That is the whole point of this test, so hold to it:

- There is **no folder you can write to**: do not create or save any file, with one exception given at the end.
- You **cannot run scripts or shell commands**: no Bash, no Python, not even to read the clock. Today is 15 November 2026.
- You **cannot publish** anything.
- You can read the plugin's skill files, call the Moody's tools, and, for a regulatory watch only, search the web and open pages.

## The plugin

Its skills are folders under:

`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/plugin/skills/`

`coverage-list`, `source-rules`, `sector-metrics`, `dashboard-feed`, `sector-news-brief`, `reg-watch`, `earnings-credit`.

To use a skill, read its `SKILL.md` and follow it. When a skill points to another skill or file, read that too. Start by reading the `description` line of each `SKILL.md` to pick the right skill for the user's message.

## Tools

- Moody's Credit MCP tools are deferred. Load the ones you need in one call:
  `ToolSearch` with query `select:mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__findEntity,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchNews,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getEntityRatings,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchAllDocuments,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getEntityFinancials_v2,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getCreditOpinion,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchCompanyFilings,WebSearch`
- To open a web page (regulatory watch only): use a web fetch tool if you have one; otherwise, if you have the Agent tool, use the `web-fetch` agent type.
- The tool names in the skills (`findEntity`, `searchNews` and so on) are the last part of the full tool names above.
- If a Moody's result is too large to show and is saved to a file, you may read that file with the Read tool. That is reading a tool result, not writing or running anything.

## Limits

- Do not read anything else in the repository: not `evals/` (other than this file), `PLAN.md`, `research/`, `demo-scripts/`, `dashboard/` or any run.
- Do not edit the plugin.

## When you finish

1. The one exception to "no files": save your reply to the user to `evals/runs/<case id>/reply.md` with the Write tool, the whole answer exactly as you would send it in the chat, word for word. Save nothing else.
2. Report back in under 200 words:
   - the skill you used;
   - Moody's calls and web calls made;
   - tool errors, with the exact text;
   - every place a skill was unclear, contradicted itself, or made you guess: quote the line and say what you assumed. This matters most.
