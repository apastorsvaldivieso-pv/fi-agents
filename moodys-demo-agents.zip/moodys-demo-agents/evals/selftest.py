#!/usr/bin/env python3
"""Prove the checks catch what they claim to catch.

One clean run file passes every check. Then one defect is planted per check, and that
check (and only that check) must fail. A check that approves everything is worse than
no check. Figures in the clean file are real Moody's values pulled on 15 Nov 2026.

    python3 evals/selftest.py
"""
import copy, json, os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import checks

FIN = "getEntityFinancials_v2"
banks = [("Groupe Credit Agricole", "135.75"), ("ING Groep N.V.", "137"), ("BNP Paribas", "134.77"),
         ("Deutsche Bank AG", "140.12"), ("UBS Group AG", "177.28"), ("Barclays PLC", "157.7")]
order = sorted(banks, key=lambda b: float(b[1]))
tone = {order[0][0]: "least", order[1][0]: "least", order[-1][0]: "most", order[-2][0]: "most"}
GOV = "https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"
KEY = "recall:reg-banks-2026-10-16_2026-11-15:1"

CLEAN = {
    "schema": "fi-dashboard/1", "agent": "reg-watch", "title": "Regulatory watch", "updated_at": "2026-11-15T13:00:00Z",
    "scope": {"sector": "Banks", "region": "Europe", "window": "30 days to 15 Nov 2026", "names": 6, "label": "Self-test"},
    "status": "ok", "headline": "One consultation touches liquidity; one final guideline has no Moody's metric.",
    "sections": [
        {"title": "Who it hits: liquidity for G-SIBs (asked) · LCR", "type": "table",
         "columns": ["Name", "LCR (Q2 2026)", "vs median of ranked names", "Stated requirement", "Distance to requirement", "Position"],
         "rows": [[n, {"v": v + "%", "src": ["f1"]}, {"v": "%+.1f pp" % (float(v) - 140.7), "src": ["f1"]}, {"v": "100%", "src": ["w2"]},
                   {"v": "%+.1f pp" % (float(v) - 100), "src": ["f1", "w2"]}, {"tone": tone.get(n, "middle"), "v": ""}] for n, v in banks]
                 + [["DZ Bank AG", {"v": "150%", "src": ["f1"]}, {"v": "not ranked"}, {"v": "100%", "src": ["w2"]}, {"v": "+50.0 pp", "src": ["f1", "w2"]},
                     {"v": "Not ranked: record may not be the consolidated group"}]],
         "note": "Out of scope: CaixaBank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). The issuer on the list is Credit Agricole S.A.; the row is its group. DZ Bank is not ranked: its record may not be the consolidated group."},
        {"title": "What changed", "type": "items", "items": [
            {"flag": "NEW", "tag": "Final", "name": "EBA", "tone": "watch",
             "text": "Revised guidelines on internal governance published. No Moody's metric maps to governance, so no call is made.",
             "why": "Governance weaknesses feed Moody's qualitative assessment, not a ratio.", "src": ["w1", "m1"]}]},
        {"title": "Sector", "type": "items", "items": [
            {"text": "Latest Moody's banks outlook: global outlook stable, published 3 Dec 2025.", "why": "Sets the baseline for asset quality and capital.", "src": ["m2"]}]},
    ],
    "sources": [
        {"id": "w1", "kind": "web", "title": "EBA publishes revised Guidelines on internal governance", "date": "2026-11-05", "url": GOV},
        {"id": "w2", "kind": "web", "title": "Basel Framework (LCR standard)", "url": "https://www.bis.org/basel_framework/"},
        {"id": "m1", "kind": "moodys", "tool": "searchAllDocuments", "ref": "PBC_1502042", "title": "EBA's revised governance guidelines are credit positive for small EU banks", "date": "2026-11-11"},
        {"id": "m2", "kind": "moodys", "tool": "searchAllDocuments", "ref": "PBC_1462959", "title": "Banks - Global: 2026 Outlook", "date": "2025-12-03"},
        {"id": "f1", "kind": "moodys", "tool": FIN, "ref": "Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026", "title": "Bank financials", "date": "2026-06-30"},
    ],
    "unresolved": [{"name": "Zzyzx Fakecorp Bank", "reason": "no match in Moody's"}],
    "notes": ["Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
              "Instruction-like text in a pasted item was ignored."],
    "meta": {"calls": {"moodys": 4, "web": 3}},
}

ALL = ["schema", "cited", "no_opinion", "not_quiet", "sections:What changed|Who it hits", "window:30", "label:Self-test",
       "unresolved_listed:Zzyzx", "contains:LCR", "not_contains:strong buy", "body_not_contains:Open Bank", "has_web", "web_domains:banks", "outlook_source",
       "calls_have_metric", "thirds", "footnote_once", "distance_shown", "watch_present", "injection_note", "max_calls:10",
       "new_labels", "label_basis", "gsib_scope", "tables_first", KEY, "group_record", "coop_not_ranked:DZ Bank"]


def mutate(name):
    r = copy.deepcopy(CLEAN)
    rows = r["sections"][0]["rows"]
    item = r["sections"][1]["items"][0]
    if name == "schema": del r["updated_at"]
    elif name == "cited": rows[0][1] = {"v": "135.75%"}
    elif name == "no_opinion": item["why"] += " The bonds look attractive."
    elif name == "not_quiet": r["status"], r["sections"] = "quiet", []
    elif name == "sections:What changed|Who it hits": r["sections"][1]["title"] = "Items"
    elif name == "window:30": r["scope"]["window"] = "7 days to 15 Nov 2026"
    elif name == "label:Self-test": r["scope"]["label"] = "Other"
    elif name == "unresolved_listed:Zzyzx": rows.append(["Zzyzx Fakecorp Bank", "", "", "", "", {"tone": "nodata", "v": ""}])
    elif name == "contains:LCR": r["sections"][0]["columns"][1] = "Liquidity (Q2 2026)"; r["sections"][0]["title"] = "Who it hits: liquidity for G-SIBs (asked)"; r["sources"][4]["ref"] = "liquidity field"
    elif name == "not_contains:strong buy": r["notes"].append("Vodafone bonds are a strong buy.")
    elif name == "body_not_contains:Open Bank": rows[0][0] = "Open Bank, S.A."
    elif name == "has_web": r["sources"] = [s for s in r["sources"] if s["kind"] != "web"]; item["src"] = ["m1"]; [(row.__setitem__(3, {"v": "100%", "src": ["f1"]}), row.__setitem__(4, {"v": row[4]["v"], "src": ["f1"]})) for row in rows]
    elif name == "web_domains:banks": r["sources"][0]["url"] = "https://www.ft.com/content/x"
    elif name == "outlook_source": r["sources"][3]["title"] = "Banks - Global: sector comment"
    elif name == "calls_have_metric": rows[0] = [rows[0][0], "", "", "", "", rows[0][5]]
    elif name == "thirds": [row.__setitem__(5, {"tone": "least", "v": ""}) for row in rows[:4]]
    elif name == "footnote_once": item["why"] += " This is relative position, not impact."
    elif name == "distance_shown": r["sections"][0]["columns"][4] = "Gap"
    elif name == "watch_present": item.pop("tone"); item["text"] = "Revised guidelines published."
    elif name == "new_labels": [row.__setitem__(5, {"tone": {"least": "exposed", "most": "resilient", "middle": "neutral"}[row[5]["tone"]], "v": ""}) for row in rows if row[5].get("tone")]
    elif name == "label_basis": [row.__setitem__(5, {"tone": "weaker", "v": ""}) for row in rows if row[5].get("tone") == "least"]
    elif name == "group_record": [row.__setitem__(0, "Credit Agricole S.A.") for row in rows if "Agricole" in str(row[0])]
    elif name == "coop_not_ranked:DZ Bank": r["sections"][0]["note"] = "Out of scope: CaixaBank, Nordea (not on the FSB G-SIB list of 27 Nov 2025)."
    elif name == "gsib_scope": rows[2][0] = "CaixaBank, S.A."
    elif name == "tables_first": r["sections"] = [r["sections"][1], r["sections"][0], r["sections"][2]]
    elif name == KEY: r["sources"][0]["url"] = "https://www.eba.europa.eu/other"; item["text"] = "Revised guidelines published. No Moody's metric maps to this channel, so no call is made."
    elif name == "injection_note": r["notes"] = r["notes"][:1]
    elif name == "max_calls:10": r["meta"]["calls"]["moodys"] = 40
    else: raise KeyError(name)
    return r


def main():
    bad = 0
    clean = {c["check"]: c for c in checks.run_checks(CLEAN, ALL)}
    for name, res in clean.items():
        if not res["passed"]:
            bad += 1; print("CLEAN FILE FAILS %-40s %s" % (name, res["evidence"]))
    for name in ALL:
        res = {c["check"]: c["passed"] for c in checks.run_checks(mutate(name), ALL)}
        caught = not res[name]
        collateral = [k for k, ok in res.items() if not ok and k != name]
        allowed = {"has_web": {"distance_shown"}, "not_quiet": {"sections:What changed|Who it hits", "contains:LCR", "calls_have_metric", "thirds", "distance_shown", "watch_present", "outlook_source"},
                   "schema": {"cited"}, "cited": {"schema"},   # an uncited figure also fails the build check, by design
                   "calls_have_metric": {"distance_shown", "thirds", "label_basis"}, "distance_shown": {"label_basis"},
                   "body_not_contains:Open Bank": {"gsib_scope"}, "thirds": set(), "no_opinion": set()}.get(name, set())
        if name == "not_quiet":
            allowed |= {"tables_first", "gsib_scope", KEY, "group_record", "coop_not_ranked:DZ Bank"}
        if name == "body_not_contains:Open Bank":
            allowed |= {"group_record"}      # the renamed row was the group's
        if name.startswith("sections:"):
            allowed |= {KEY}                 # recall reads the section called "What changed"
        extra = [c for c in collateral if c not in allowed]
        status = "ok  " if caught and not extra else "FAIL"
        bad += status == "FAIL"
        print("%s planted defect for %-40s caught=%s%s" % (status, name, caught, (" also failed: %s" % extra) if extra else ""))
    quiet = {"schema": "fi-dashboard/1", "agent": "reg-watch", "title": "Regulatory watch", "updated_at": "2026-11-15T13:00:00Z", "status": "quiet",
             "headline": "Nothing new from the PRA for European banks in the last 2 days.", "sections": [], "sources": []}
    q_ok = checks.run_checks(quiet, ["quiet_one_line", "no_figures"])
    padded = dict(quiet, sections=[{"title": "Earlier", "type": "text", "text": "Last month the PRA consulted on capital."}])
    q_bad = checks.run_checks(padded, ["quiet_one_line"])
    figs = dict(quiet, headline="Leverage is 3.25x.")
    f_bad = checks.run_checks(figs, ["no_figures"])
    for label_, ok in (("quiet one-liner passes", all(c["passed"] for c in q_ok)), ("padded quiet run caught", not q_bad[0]["passed"]), ("figure in a stopped run caught", not f_bad[0]["passed"])):
        bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    # Checks that need files beside the run: the running list, an earlier run, and a results filing.
    tmp = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp, "dashboard", "data", "items"))
    lst = os.path.join(tmp, "dashboard", "data", "items", "reg-watch-banks-europe.json")
    def save_list(extra_item=False):
        its = [{"url": GOV, "decision": "show", "published": "2026-11-05", "title": "EBA governance"}]
        if extra_item:
            its.append({"url": "https://www.bis.org/publications/x", "decision": "show", "published": "2026-11-09", "title": "A listed item the run dropped"})
        json.dump({"items": its}, open(lst, "w"))
    checks.CTX["dir"] = tmp
    save_list(); ok1 = checks.run_checks(CLEAN, ["shows_list_items"])[0]["passed"]
    save_list(True); ok2 = not checks.run_checks(CLEAN, ["shows_list_items"])[0]["passed"]
    prev = os.path.join(tmp, "prev.json")
    earlier = copy.deepcopy(CLEAN); earlier["sections"][1]["items"][0]["src"] = ["m1"]      # the earlier run did not show this page
    json.dump(earlier, open(prev, "w")); ok3 = checks.run_checks(CLEAN, ["new_not_in:" + prev])[0]["passed"]
    json.dump(CLEAN, open(prev, "w")); ok4 = not checks.run_checks(CLEAN, ["new_not_in:" + prev])[0]["passed"]
    recap = {"schema": "fi-dashboard/1", "agent": "earnings-credit", "title": "Earnings", "updated_at": "2026-11-15T13:00:00Z", "headline": "Recap.",
             "sections": [{"title": "Results", "type": "text", "text": "Company-reported net debt was EUR 33,473 million.", "src": ["c1"]}],
             "sources": [{"id": "c1", "kind": "moodys", "tool": "searchCompanyFilings", "ref": "half-year report, submitted 2026-11-10, page 12", "title": "Vodafone Group Plc Interim Report"}]}
    ok5 = checks.run_checks(recap, ["filing_source"])[0]["passed"]
    only_call = copy.deepcopy(recap); only_call["sources"][0].update(title="Vodafone H1 FY27 earnings call transcript", ref="call of 10 Nov 2026")
    ok6 = not checks.run_checks(only_call, ["filing_source"])[0]["passed"]
    # The running-list script itself: a known item keeps its decision and is new only once.
    tool = os.path.join(checks.ROOT, "plugin", "skills", "reg-watch", "scripts", "items.py")
    lst2, found = os.path.join(tmp, "l.json"), os.path.join(tmp, "f.json")
    def add(items):
        json.dump(items, open(found, "w"))
        out = subprocess.run([sys.executable, tool, "add", "--list", lst2, "--from", "2026-10-16", "--to", "2026-11-15", "--found", found], capture_output=True, text=True)
        return json.loads(out.stdout)
    a1 = add([{"url": "https://www.finma.ch/de/news/2026/11/20261110-mm-gwv-finma/", "body": "FINMA", "title": "AML", "published": "2026-11-10", "decision": "show"}])
    a2 = add([{"url": "https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/", "body": "FINMA", "title": "AML", "published": "2026-11-10", "decision": "left out", "reason": "changed"},
              {"url": GOV, "body": "EBA", "title": "Governance", "published": "2026-11-05", "decision": "show"}])
    ok7 = a1["new_in_this_run"] == 1 and a2["new_in_this_run"] == 1 and len(a2["show"]) == 2 and not a2["left_out"] and [i["new"] for i in a2["show"]] == [True, False]
    for label_, ok in (("listed items all shown passes", ok1), ("listed item missing from the run caught", ok2), ("NEW on a new item passes", ok3),
                       ("NEW on an item shown before caught", ok4), ("results filing cited passes", ok5), ("transcript alone caught", ok6),
                       ("running list keeps decisions and flags new once", ok7)):
        bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    # The answer the user reads in the chat: rendered from the clean run, then one defect planted per check.
    import importlib.util as _u
    _spec = _u.spec_from_file_location("answer", os.path.join(checks.ROOT, "plugin", "skills", "dashboard-feed", "scripts", "answer.py"))
    answer = _u.module_from_spec(_spec); _spec.loader.exec_module(answer)
    good = answer.render(CLEAN) + "\nDashboard not updated: this session cannot run scripts.\n"
    names = ["answer_sourced", "answer_from_run", "answer_length:400", "dashboard_line"]
    def grade(text):
        checks.CTX["reply"] = text
        res = {c["check"]: c["passed"] for c in checks.run_checks(CLEAN, names)}
        checks.CTX["reply"] = None
        return res
    first_fig = next(l for l in good.splitlines() if l.startswith("| ") and "[" in l)
    planted = {
        "answer_sourced": good.replace(first_fig, checks.REF.sub("", first_fig)),
        "answer_from_run": good.replace("**What changed**", "Leverage rose to 9.99x.[1]\n\n**What changed**"),
        "answer_length:400": good.replace("**What changed**", ("padding " * 400) + "\n\n**What changed**"),
        "dashboard_line": good.replace("Dashboard not updated: this session cannot run scripts.", ""),
    }
    base = grade(good)
    for name in names:
        ok = base[name] and not grade(planted[name])[name] and all(v for k, v in grade(planted[name]).items() if k != name)
        bad += not ok; print("%s answer check %-22s passes clean, catches its planted defect" % ("ok  " if ok else "FAIL", name))
    # The two regulatory watch facts, and the over-limit line.
    said = good.replace("**What changed**", ("padding " * 400) + "\n\nThis brief runs over the two-minute limit (900 words against 600): no material item was cut to fit.\n\n**What changed**")
    stress = good.replace("**What changed**", "- EBA cut the stress-test data request by more than 55%. [1]\n\n**What changed**")
    tests = [("over the limit and says so passes", lambda: grade_one(said, "answer_length_or_said:400")),
             ("over the limit and silent caught", lambda: not grade_one(planted["answer_length:400"], "answer_length_or_said:400")),
             ("qualifier kept passes", lambda: grade_one(stress, "qualifier:55%|more than 55%")),
             ("qualifier dropped caught", lambda: not grade_one(stress.replace("more than 55%", "55%"), "qualifier:55%|more than 55%"))]
    def grade_one(text, name):
        checks.CTX["reply"] = text
        res = checks.run_checks(CLEAN, [name])[0]["passed"]
        checks.CTX["reply"] = None
        return res
    for label_, fn in tests:
        ok = fn(); bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    cons = copy.deepcopy(CLEAN)
    cons["sections"][0]["title"] = "Who it hits: G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · LCR"
    ok_a = checks.run_checks(CLEAN, ["heading_measure"])[0]["passed"]
    ok_b = not checks.run_checks(cons, ["heading_measure"])[0]["passed"]      # the table lists UBS and Barclays
    for label_, ok in (("heading with the right measure passes", ok_a), ("heading naming a measure its names are not right for caught", ok_b)):
        bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    # A results line carries the figures, or says which it lacks.
    def with_line(line):
        return good.replace("**What changed**", line + "\n\n**What changed**")
    full = "- **Vodafone** (Results): H1 results (10 Nov): net loss EUR 3.6bn after a EUR 4.85bn Germany impairment; guidance raised; net debt EUR 33.5bn. [1]"
    half = "- **Vodafone** (Results): H1 results (10 Nov): guidance raised to EUR 13.2bn. [1]"
    said = "- **Vodafone** (Results): H1 results (10 Nov): net loss EUR 3.6bn; leverage not in the sources returned. [1]"
    pointer = "| Vodafone Group Plc | Baa2 (Senior Unsecured), stable [1] | H1 results, guidance raised (Top item). [1] |"
    other = "| VMED O2 UK Holdings Limited | B1 CFR, on review for downgrade [1] | No news returned under the name. Its owner's results (12 Nov) cite a GBP 800m cost plan. [1] |"
    for label_, text_, want in (("a row with no news of its own, naming its owner's results, passes", other, True), ("a table row that points to the top item passes", pointer, True), ("results line in full passes", full, True), ("results line with the favourable half only caught", half, False),
                                ("results line that says what was not returned passes", said, True)):
        ok = grade_one(with_line(text_), "results_full") == want
        bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    # A recap gives the profit or loss for the period as money, not only per share.
    money = "- **Results** (Company-reported): loss for the period of EUR 3,597m against a profit of EUR 1,052m. [1]"
    share = "- **Results** (Company-reported): basic loss per share of 20.75 eurocents. [1]"
    for label_, text_, want in (("recap with the loss in euros passes", money, True), ("recap with only a loss per share caught", share, False)):
        ok = grade_one(with_line(text_), "recap_profit") == want
        bad += not ok; print("%s %s" % ("ok  " if ok else "FAIL", label_))
    print("\n%s" % ("All checks proved against planted defects." if not bad else "%d problems" % bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
