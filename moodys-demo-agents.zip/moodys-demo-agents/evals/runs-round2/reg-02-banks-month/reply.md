**Regulatory watch: European banks, 30 days to 15 Nov 2026 (16 Oct to 15 Nov)**

**Headline:** The Basel Committee finalised its G-SIB window-dressing rules and opened a consultation on the G-SIB methodology, with comments due 14 Jan 2027. That touches the capital-buffer channel. On CET1, Crédit Agricole S.A., CaixaBank, BBVA, BNP Paribas and Intesa Sanpaolo sit lowest in the list.

**What changed** (all NEW, since this is the first run; dates taken from the regulators' own pages)

1. **Basel Committee, final rule plus a consultation (16 Oct).** Banks in the G-SIB assessment must report stock indicators as averages over the year instead of year-end values, by 1 Jan 2030. The G-SIB reporting threshold in the leverage exposure measure rises from EUR 200bn to EUR 350bn from 2027. The methodology consultation, which includes cross-border exposures within the Banking Union, closes 14 Jan 2027. *Channel: capital buffers → CET1.* I found no Moody's comment on it in the window.
2. **Basel Committee, IRRBB Pillar 2 guidance, consultation (9 Nov).** Covers model risk, stress testing, embedded gains and losses, and new supervisory reporting. Comments are due 9 Feb 2027. *Watch.* IRRBB has no row in the channel map, and Moody's data carries no IRRBB metric (EVE or NII sensitivity), so I made no call on any name.
3. **EBA, revised internal governance guidelines, final (5 Nov).** No application date is stated. *Watch*, because governance has no Moody's metric. **Moody's view** (Sector Comment, 11 Nov): credit positive for small EU banks, with limited near-term effect on large banks.
4. **EBA, supervisory reporting simplification next steps (6 Nov).** The final ITS is due in December 2026. The first reference date moves to Dec 2027, and liquidity, encumbrance, benchmarking and ESG reporting move to Dec 2028. *Watch.*
5. **EBA, technical advice on Taxonomy disclosures (29 Oct).** This is advice, not a rule. *Watch.*
6. **Basel Committee, technical consultation on consolidated-guidelines cross-references (5 Nov).** Comments are due 21 Dec 2026. *Watch.*

**Who it hits: capital buffers (CET1 ratio as reported, Q2 2026; list median 13.60%)**

| Name | CET1 | vs median | Call |
|---|---|---|---|
| Crédit Agricole S.A. | 11.30% | -2.30 pp | exposed |
| CaixaBank | 12.33% | -1.27 pp | exposed |
| BBVA | 12.90% | -0.70 pp | exposed |
| BNP Paribas | 12.97% | -0.63 pp | exposed |
| Intesa Sanpaolo | 13.00% | -0.60 pp | exposed |
| ING Groep | 13.07% | -0.53 pp | neutral |
| Société Générale | 13.20% | -0.40 pp | neutral |
| Lloyds Banking Group | 13.60% | +0.00 pp | neutral |
| Deutsche Bank | 13.92% | +0.32 pp | neutral |
| HSBC Holdings | 14.10% | +0.50 pp | neutral |
| UniCredit | 14.26% | +0.66 pp | resilient |
| Barclays PLC | 14.30% | +0.70 pp | resilient |
| UBS Group | 14.38% | +0.78 pp | resilient |
| Commerzbank | 14.38% | +0.78 pp | resilient |
| Nordea Bank | 15.70% | +2.10 pp | resilient |

There is no distance to a minimum: CET1 requirements are firm-specific, and no Moody's document in this run states them. Source: Moody's `getEntityFinancials_v2` (Bank Focus), period end 30 Jun 2026.

*Calls show relative position within this list on the stated metric. They are not an estimate of impact.*

**Notes**
- **Coverage:** the checked banks-europe list of 15 names, all resolved. Banco Santander is not on the list because its rated record returns no financials.
- **Just outside the window:** PRA/FCA PS19/26 on high-LTI lending (14 Oct) and the ECB's IFRS 18 reporting release (15 Oct).
- **Left out:** the FINMA/SRB search found nothing new. Two EBA items (CSD prudential RTS, and the joint-decisions ITS consultation) were not opened.

**Dashboard:** the Regulatory watch tab was updated at 2026-11-15 13:05 UTC. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`. It was not published to the Artifact link because this is a test run.
