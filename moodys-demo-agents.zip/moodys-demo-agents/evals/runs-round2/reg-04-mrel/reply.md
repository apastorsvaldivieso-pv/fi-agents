**Regulatory watch, European banks: MREL (window 8 to 15 Nov 2026)**

**Short answer:** I can't name banks that would be exposed to tighter MREL from Moody's data. Moody's financials have no MREL or TLAC field, so there is no Moody's metric to rank the 15 banks on. All 15 stay on **watch**, with no call. Using CET1 or leverage as a stand-in would be my own guess, and it would not show how much MREL headroom each bank has.

**What changed this week:** Nothing on MREL. I searched the SRB, EBA, ECB, European Commission, Bank of England/PRA, FINMA and BIS sites and found no MREL consultation, final rule or decision published in the window.

**Background (outside the window, so not new):**
- **Bank of England, External MRELs 2026** (published 16 Apr 2026). These are the published requirements, not the banks' actual resources against them: Barclays 25.5% of RWAs, Lloyds Banking Group 21.0% of RWAs, HSBC Group 23.2% of RWAs. The Bank says it plans to stop publishing individual firms' MRELs from 2027. ([page](https://www.bankofengland.co.uk/financial-stability/resolution/mrels-2026))
- **Moody's, 27 Mar 2026** (PBC_1479424): the EBA's impact assessment shows EU banks have largely met their final MREL requirements. Moody's calls this credit positive for loss absorption and for senior creditors. ([doc](https://www.moodys.com/research/doc--PBC_1479424))
- **Moody's, 27 Jul 2026** (PBC_1489046): the European Commission's reform plan aims to make the MREL framework "more predictable". That points to simplification, not tightening. ([doc](https://www.moodys.com/research/doc--PBC_1489046))

**What would let us make a call:** each bank's MREL resources and requirement, as a share of RWAs and of leverage exposure. These come from the banks' Pillar 3 / MREL disclosures, the SRB, and the Bank of England tables (which stop after 2026). Moody's data doesn't carry them. If you want, I can pull each bank's disclosed MREL figures from its filings, name by name, and label them as company-reported.

Dashboard: the Regulatory watch tab was updated at 13:03 UTC on 15 Nov 2026 as a quiet run. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html` (not published as an Artifact in this test run).

Sources: [Bank of England, External MRELs 2026](https://www.bankofengland.co.uk/financial-stability/resolution/mrels-2026); [Moody's PBC_1479424](https://www.moodys.com/research/doc--PBC_1479424); [Moody's PBC_1489046](https://www.moodys.com/research/doc--PBC_1489046)
