**BNP Paribas: earnings preview**

I ran this as a **preview**. You didn't say preview or recap, and Moody's holds no earnings call transcript for BNP Paribas, so nothing shows results already out.

**Rating and outlook.** BNP Paribas is rated A1 (LT Issuer Rating) with a stable outlook. The last action was an affirmation on 31 Aug 2026. The credit opinion is dated 2 Sep 2026. Moody's ties the stable outlook to the bank's "very stable and highly predictable profitability and sound risk profile". It also expects the bank to adapt its liability structure to the EU general depositor preference without a material rise in loss severity for senior unsecured debt.

**What to watch against Moody's triggers**

| Metric | Latest Moody's value | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Return on assets (Moody's Net Income / Tangible Assets) | 0.4% (Jun 2026) | 0.6% and above, with lower financial leverage and disciplined risk management | No number stated | 0.2 pp below the upgrade level |

This is the only trigger Moody's states as a number. The opinion's table has no "return on assets" row, so the closest measure, Net Income / Tangible Assets, stands in for it. Treat the match as approximate.

**Worded triggers (quoted), with the nearest Moody's metric**
- Downgrade: "lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics". CET1 is 12.97% (as reported, Q2 2026). TCE / RWA is 13.7% (Moody's, Jun 2026). Problem loans / gross loans is 2.9% (Moody's, Jun 2026) and has stayed between 2.8% and 2.9% since Dec 2022. The fully loaded leverage ratio is not in Moody's data.
- Downgrade: "a marked increase in risk appetite, loss incidents or a material risk management failure". No metric covers this.
- Downgrade: "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile". LCR is 134.77% and NSFR 108.63% (as reported, Q2 2026). Loans / deposits is 82.3%. Moody's HQLA / tangible banking assets was 15.9% at Jun 2026, down from 18.2% at Dec 2025.
- Downgrade (senior unsecured only): this applies if the growth in senior unsecured and lower-ranking debt relative to tangible banking assets "falls short of our current expectations" and a weaker loss-given-failure outcome can't be offset by a one-notch government support uplift. Moody's data has no MREL or TLAC field.
- Upgrade: an upgrade of France's sovereign rating could restore the previous government support uplift.

**What management guided on the last call.** Moody's has no earnings call transcript for BNP Paribas, so there's no guidance to report from Moody's data.

**Moody's expectations.** The opinion's key indicators table has no forecast columns, only historical figures from Dec 2022 to Jun 2026.

Sources: Moody's credit opinion "BNP Paribas: Update following ratings affirmation" (PBC_1491623, 2 Sep 2026); Moody's rating history (LT Issuer Rating); Moody's Bank Focus financials (Q2 2026).

The Earnings tab of the dashboard was updated at 13:07 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html`. I didn't publish it to the Artifact link because this is a test run.
