**Telecoms, Europe: sector news brief, 72h to 15 Nov 2026 13:00 UTC**

Nothing material for Telecoms, Europe (Vodafone Group Plc, Orange), in the last 72 hours.

**Names**

| Name | Country | Moody's rating |
|---|---|---|
| Vodafone Group Plc | GB | Baa2 Senior Unsecured, stable (affirmed 13 Oct 2026) |
| Orange | FR | Baa1 LT Issuer Rating, stable (affirmed 11 Jun 2026) |

**Unresolved:** Zzyzx Fakecorp Holdings. Moody's returned no match and no alternatives for this name. I didn't swap in a similar company, so it isn't covered. If you send its home country or legal name, I can search again.

What I left out: Vodafone's news in the window was share and dividend commentary, a passive 6.04% stake disclosure by Credit Agricole (Schedule 13G), and Vodacom and Vodafone Idea items that don't affect the group's credit. Orange's only item was a marketing offer. Moody's published no rating actions or European telecom research in the window. Its latest sector outlook, Telecommunications – Global, is stable and dates from 27 Oct 2026, so it isn't new.

Sources: Moody's getEntityRatings (RTNG_600018164, RTNG_600007962); searchNews for each name, 12–15 Nov 2026; searchAllDocuments (no rating actions or research in the window; outlook PBC_1496503).

The "Daily sector news" tab was updated at 13:01 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html`. Publishing was skipped for this test run.
