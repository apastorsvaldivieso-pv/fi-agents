**BNP Paribas: earnings preview (credit view)**

You didn't say preview or recap, so I ran a **preview**. Moody's holds no earnings call transcript for BNP Paribas at all, so there was nothing to recap from.

**Rating and outlook**
A1 LT Issuer Rating, **outlook stable**. It was last affirmed on 31 Aug 2026 (also affirmed on 21 Apr 2026 and 18 Nov 2025) and downgraded to A1 on 17 Dec 2024. The credit opinion is dated 2 Sep 2026. Moody's says the stable outlook reflects "very stable and highly predictable profitability and sound risk profile". It also reflects Moody's expectation that the bank adapts its liabilities to the EU general depositor preference without a material rise in loss severity for senior unsecured debt.

**What to watch against Moody's triggers**

| Metric | Latest (period) | Upgrade trigger | Downgrade trigger | Room to upgrade |
|---|---|---|---|---|
| Return on assets (Moody's key indicator: Net Income / Tangible Assets) | 0.4% (06-26) | 0.6% and above | No number stated | 0.2 pp below |

Only one trigger has a number. The rest are worded:
- **Upgrade:** "if the group manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management on its path to improving its return on assets to levels of 0.6% and above, limiting any sudden and significant increase in problem loans and risk provisioning."
- **Upgrade:** a France sovereign upgrade could restore "the previous government support uplift."
- **Downgrade:** "if the bank maintained lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics", or "a marked increase in risk appetite, loss incidents or a material risk management failure."
- **Downgrade:** "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile."
- **Downgrade (senior unsecured only):** if issuance of senior unsecured and lower-ranking debt relative to tangible banking assets "falls short of our current expectations" and the government support uplift cannot offset the weaker loss-given-failure result, for example after a France downgrade.

**Latest metrics on the results watch-list**
- *As reported, Q2 2026:* CET1 12.97%, LCR 134.77%, NSFR 108.63%.
- *Bank Focus standard format, Q2 2026:* impaired loans / gross loans 2.93%, reserves / impaired loans 57.68%, loans / deposits 82.30%, RWA / total assets 25.79%.
- *Fully loaded leverage ratio:* not in Moody's data.
- *Moody's key indicators, 06-26:* TCE / RWA 13.7%, problem loans / gross loans 2.9% (unchanged since 2022), PPI / average RWA 2.8%, cost / income 60.6%, NIM 0.9%.

**What management guided on the last call**
Moody's has no earnings call transcript for BNP Paribas, so I have no guidance points. I didn't look for one on the web.

**Moody's expectations**
The key indicators table in the opinion only has historical columns (back to 12-22). It has no Moody's forecasts.

Notes: the trigger says "return on assets". I compared it with Moody's Net Income / Tangible Assets key indicator, but the opinion doesn't name the ratio. The Q2 2026 data is the latest Moody's holds and can lag the bank's reported results by a quarter.

Sources: getEntityRatings (RTNG_91000); Credit Opinion PBC_1491623 (2 Sep 2026); getEntityFinancials_v2 (Bank Focus, Q2 2026); searchCompanyFilings (transcript: not found).

The Earnings tab of the FI Credit Monitor has been updated (2026-11-15 13:01 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html`. The Artifact publish step was skipped because this is a test run.
