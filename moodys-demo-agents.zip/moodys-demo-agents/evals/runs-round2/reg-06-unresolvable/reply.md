**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

**Names**

| Name | Country | Source |
|---|---|---|
| BNP Paribas | FR | checked coverage list |
| Deutsche Bank AG | DE | checked coverage list |

**Unresolved: Zzyzx Fakecorp Bank.** Moody's returned no match and no candidates, so I did not substitute another bank. If it is a real issuer, send me its home country or legal name and I will try again.

**What changed** (primary regulator pages only; all new, since this is the first run)

1. **Basel Committee, G-SIB framework (16 Oct): final rule plus consultation.** Banks in the G-SIB assessment must report stock indicators as averages over the year rather than year-end values, which ends year-end window dressing. Implementation is by 1 Jan 2030. The reporting threshold rises from EUR 200bn to EUR 350bn of leverage exposure from 2027. A separate consultation on the methodology, including cross-border exposures within the Banking Union, closes 14 Jan 2027. *Channel: G-SIB buffer, which feeds the CET1 requirement.* I found no Moody's comment in the window. [BIS](https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib)
2. **Basel Committee, IRRBB Pillar 2 guidance (9 Nov): consultation.** Covers model validation, stress testing, embedded securities losses and earnings indicators, and adds new "Supervisory Information" reporting. Comments are due 9 Feb 2027. *Watch:* Moody's data has no IRRBB metric, so no call on any name. [BIS](https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance)
3. **EBA, revised internal governance guidelines (5 Nov): final.** These reflect CRD VI, with more proportionality and less detail than the consultation draft. The press release gives no application date. *Watch:* Moody's data has no governance field. In a Sector Comment on 11 Nov (PBC_1502042), Moody's calls the guidelines credit positive for small EU banks, with less effect on large banks that already follow them. [EBA](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and)

**Who it hits: capital buffers (G-SIB)**

| Name | CET1 (as reported, Q2 2026) | vs two-name median (13.45%) | Distance to minimum | Call |
|---|---|---|---|---|
| BNP Paribas | 12.97% | -0.48 pp | firm-specific requirement, not stated by Moody's | no call |
| Deutsche Bank AG | 13.92% | +0.48 pp | firm-specific requirement, not stated by Moody's | no call |
| Zzyzx Fakecorp Bank | not resolved | | | nodata |

There is no exposed, neutral or resilient call because two names are too few to rank; the method needs at least six. Source: Moody's getEntityFinancials_v2, Q2 2026.

**Notes**
- I dropped the Basel Committee's consequential amendments for its consolidated guidelines (5 Nov, cross-reference housekeeping) as not credit-relevant.
- SRB, the Commission and ECB Banking Supervision had no capital, liquidity or MREL rule in the window.
- I did not search PRA or FINMA, since neither bank is UK- or Swiss-based.

The dashboard's "Regulatory watch" tab was updated at 13:03 UTC on 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html`. This was a test run, so it was not published as an Artifact.
