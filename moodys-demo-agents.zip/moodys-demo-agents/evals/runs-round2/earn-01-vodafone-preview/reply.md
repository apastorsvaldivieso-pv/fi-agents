**Vodafone Group Plc: earnings preview**

Vodafone already reported. Moody's has the transcript of the Half Year 2027 earnings call from 10 Nov 2026, so I've kept this as the preview you asked for. I can run a recap of those results instead if that's more useful.

**Rating and outlook**
Vodafone is rated Baa2 (Senior Unsecured, foreign currency) with a stable outlook. Moody's affirmed the rating on 13 Oct 2026, and the credit opinion is dated 21 Oct 2026. The stable outlook assumes Moody's-adjusted debt/EBITDA stays below 3.3x and RCF/net debt stays around 30%. It also assumes trends in Germany at least stabilise and the company stays in the lower half of its own net leverage target range.

**What to watch against Moody's triggers** (Moody's-adjusted, FY to 31 Mar 2026)

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room to upgrade | Room to downgrade |
|---|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to remain below 3.3x (sustained) | 0.75x | 0.05x |
| RCF / Net Debt | 33.1% | above 25% (sustained) | declines towards 18% (sustained) | already 8.1 pp above | 15.1 pp |

Worded triggers, quoted from the opinion:
- Upgrade: "underlying revenue and operating performance improve sustainably, particularly in Germany"
- Downgrade: "Vodafone's operating performance deteriorates, including a failure to turn around its German operations"

**What management guided on the last call** (Half Year 2027 earnings call, 10 Nov 2026; all figures company-reported)
- **FY27 guidance raised.** At the midpoint of the new ranges, organic adjusted EBITDA grows 7% and adjusted free cash flow about 21%. The midpoint of the new ranges is the top of the old ones. The euro ranges themselves were not in the transcript excerpts.
- **Europe and Germany.** Europe guidance is unchanged after absorbing an EBITDA hit of about EUR 100m from the European Court of Justice ruling in Germany. Management said "we still have much more to do in Germany" and announced another 2,300 job cuts there.
- **Capex.** Management said not to expect any material reduction in capital intensity in Germany. Investment in the cable network and fibre continues.
- **Costs.** The programme targets over EUR 2bn of gross annual savings and over EUR 1bn net in Europe. Over EUR 200m of net savings is expected this fiscal year.
- **OXG fibre joint venture.** Société Générale replaced Altice as Vodafone's partner. An analyst on the call put Vodafone's possible equity injections at up to EUR 1.2bn. Management said the JV will be funded with a mix of debt and equity, and any equity from Vodafone will be spread over the build.

Guidance on net debt, leverage and liquidity was not in the transcript excerpts.

**Moody's expectations** (key indicators table in the credit opinion)

| | FY2026 | 2027F | 2028F | 2029F |
|---|---|---|---|---|
| Debt / EBITDA | 3.3x | 3.1x | 3.0x | 2.9x |
| RCF / Net Debt | 33.1% | 29.4% | 30.9% | 31.7% |
| (EBITDA − CAPEX) / Interest | 2.4x | 2.6x | 2.8x | 3.0x |
| Net Debt / EBITDA | 2.5x | 2.6x | 2.5x | 2.4x |

Notes:
- The credit opinion (21 Oct) was written before these results.
- The opinion's table rounds FY2026 debt/EBITDA to 3.3x. The room to triggers above uses the unrounded 3.25x from Moody's adjusted financials.
- Company guidance is a different basis from Moody's-adjusted metrics, so the two are not compared directly.

Sources: Moody's credit opinion PBC_1496608 (21 Oct 2026); Moody's rating history; Moody's-adjusted key indicators (FY to Mar 2026); Half Year 2027 earnings call transcript (10 Nov 2026).

The Earnings tab is updated (15 Nov 2026, 13:01 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html`. This test run skipped the Artifact publish step.
