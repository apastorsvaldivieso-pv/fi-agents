**European telecoms: week to 15 Nov 2026, 13:00 UTC** (window: 168h from 8 Nov 13:00 UTC; 15 names, checked coverage list)

**Top this week**
1. **Vodafone (Baa2 Senior Unsecured, stable).** H1 results: full-year profit and cash flow guidance raised, with organic service revenue growth across the group. The half showed an impairment-driven loss and a small interim dividend increase. *Why it matters:* higher cash flow guidance supports debt reduction and RCF / net debt. The impairment is non-cash and does not change leverage.
2. **Telefonica (Baa3 Senior Unsecured, stable).** Q3 results on 12 Nov: guidance raised for adjusted EBITDA, operating cash flow after leases and free cash flow, led by Spain and Brazil. Q3 net income was EUR 802m, against EUR 276m a year earlier. *Why it matters:* higher EBITDA and FCF guidance supports debt reduction and RCF / net debt at the Baa3 level.
3. **Telenor (Baa1 Senior Unsecured, positive outlook).** Telenor completed the purchase of a 57.5% stake in Swedish broadband provider Bahnhof and now holds about 66.9% of shares and 90.6% of votes. A mandatory cash offer at SEK 62 per share runs for the remaining shares. *Why it matters:* it is a cash outflow while the outlook is positive. The sources do not give the deal size against Telenor's leverage.

**Macro**
- Moody's 2027 global credit conditions outlook (9 Nov) says credit will weaken as higher rates and energy costs outweigh the AI tailwind. This weighs most on refinancing for the high-yield names on the list: VMED O2, Altice France and Iliad.
- Euro area bond yields rose on 13 Nov. French October inflation picked up on energy prices, which keeps bets on an ECB rate hike alive. Higher yields make it more expensive to refinance upcoming maturities.

**Sector**
- Moody's published no rating actions and no sector research on European telecoms in the week, so ratings and outlooks on the list are unchanged.
- The latest Moody's sector outlook (Telecommunications – Global, 27 Oct 2026) is **stable**. Solid demand and lower capital intensity offset refinancing pressure and structural risks.

**By name**
| Name | Rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom | A3 (Sr Unsec FC), stable | No material credit news. Its Q3 results and guidance raise were on 5 Nov, before the window. |
| Orange | Baa1 (LT Issuer), stable | No material credit news. |
| Vodafone | Baa2 (Sr Unsec FC), stable | Raised full-year profit and cash flow guidance at H1. Impairment-driven loss for the half. |
| Telefonica | Baa3 (Sr Unsec DC), stable | Raised guidance for EBITDA, OpCF after leases and FCF at Q3. |
| Swisscom | A2 (LT Issuer DC), stable | No material credit news. |
| Telekom Austria | A3 (LT Issuer), stable | No material credit news. |
| Proximus | A3 (Sr Unsec DC), stable | No material credit news. |
| Telenor | Baa1 (Sr Unsec FC), positive | Took majority control of Bahnhof (about 66.9%). Mandatory cash offer under way. |
| Telia | Baa1 (Sr Unsec FC), stable | Per LMT, the Latvian government buyout of Telia's stakes in LMT and Tet is on track for the 17 Nov deadline. |
| TIM | Baa3 (LT Issuer DC), positive | No material credit news. |
| PPF Telecom | Baa2 (LT Issuer DC), stable | No material credit news. |
| BT Group | Baa2 (LT Issuer, at British Telecommunications Ltd), stable | No material credit news. Its H1 results and pension valuation were on 5 Nov, before the window. |
| Iliad | Ba1 (Sr Unsec DC), stable | No material credit news. |
| VMED O2 UK | B1 (CFR FC), on review for downgrade | No material credit news. The ratings have been on review for downgrade since 22 Oct, so this is not new. |
| Altice France | Caa1 (Sr Sec Bank Facility FC), positive | No material credit news. |

Sources: Moody's Credit MCP only (news, ratings, research). Every item cites its source in the dashboard.

The **Daily sector news** tab is updated (13:03 UTC, 15 Nov). Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html`. This test run skips publishing to the Artifact link.
