# How a stand-alone agent is tested

You are Claude in the Claude app. One plugin is installed: `moodys-<agent>`, where `<agent>` is the agent named at the end of this file's instructions to you. It holds one agent and nothing else. A user has sent you one message. Handle it exactly as you would for a real user, using the plugin's skills.

## The plugin

Its one skill is the folder:

`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/agents/<agent>/plugin/skills/<agent>/`

To use it, read its `SKILL.md` and follow it. When it points to another file, that file is inside the same folder (under `shared/`): read it there. Everything the agent needs is in that one folder.

**This run tests that the folder is complete on its own.** Do not read anything under `moodys-demo-agents/plugin/` or under another agent's folder in `agents/`. If a file the skill points to is not inside this agent's folder, do not look for it elsewhere: carry on as the skill says for something that is not available, and report the missing path, word for word, at the end.

## Tools

- Moody's Credit MCP tools are deferred. Load the ones you need in one call:
  `ToolSearch` with query `select:mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__findEntity,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchNews,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getEntityRatings,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchAllDocuments,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getEntityFinancials_v2,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__getCreditOpinion,mcp__afbbdbc7-ceea-4626-ab98-f00f7acfff2c__searchCompanyFilings,WebSearch`
- To open a web page: use a web fetch tool if you have one; otherwise, if you have the Agent tool, use the `web-fetch` agent type; otherwise follow what the skill says to do when pages cannot be opened.
- The tool names in the skills (`findEntity`, `searchNews` and so on) are the last part of the full tool names above.

## Where this run lives

Your working folder for this run is `evals/runs/<case id>/` inside `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/`. Create it. Every path a skill gives relative to the working folder (`dashboard/data/...`, `dashboard/dashboard.html`) is inside that folder.

This is a test run, so two things differ from a normal run:
- **Skip the Artifact publish step** in `dashboard-feed`. Do everything else.
- In the run file's `meta.calls`, record how many Moody's calls and web calls (searches plus pages opened) you made.

## Limits

- Do not read anything else in the repository: not `evals/` (other than this file), `PLAN.md`, `research/`, `demo-scripts/` or other runs.
- Do not edit the plugin.
- If a tool result is saved to a file because it is too large, read only the parts you need.

## When you finish

1. Save your reply to the user to `evals/runs/<case id>/reply.md`: the whole answer exactly as you would send it in the chat, word for word. That file is what gets graded, because the answer in the chat is what a client sees.
2. Report back in under 200 words:
   - the skill you used and the run's status (ok, quiet, stopped);
   - Moody's calls and web calls made;
   - tool errors, with the exact text;
   - every place a skill was unclear, contradicted itself, or made you guess: quote the line and say what you assumed. This matters most.
