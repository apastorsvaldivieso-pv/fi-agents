#!/usr/bin/env python3
"""Pass/fail checks on a saved run: the answer given in the chat (reply.md) and the checked run file behind it. No model needed.

    python3 evals/checks.py                      run every case that has a saved run
    python3 evals/checks.py reg-watch            one agent
    python3 evals/checks.py reg-watch reg-02     one case

A case lives in evals/<agent>.json. Its run is expected at
evals/runs/<case id>/dashboard/data/<agent>.json. Each check returns pass or fail with the
evidence. The yes/no expectations that need a reader are graded separately and recorded
in evals/results/. Standard library only.
"""
import glob, importlib.util, json, os, re, sys
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    "build_dashboard", os.path.join(ROOT, "plugin", "skills", "dashboard-feed", "scripts", "build_dashboard.py"))
bd = importlib.util.module_from_spec(spec); spec.loader.exec_module(bd)
spec2 = importlib.util.spec_from_file_location(
    "items", os.path.join(ROOT, "plugin", "skills", "reg-watch", "scripts", "items.py"))
items_mod = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(items_mod)
CTX = {"dir": None, "reply": None}   # folder of the run being checked, and (tests only) the answer text

LOW, MID, HIGH = {"exposed", "least", "weaker"}, {"neutral", "middle"}, {"resilient", "most", "stronger"}
RANKED = LOW | MID | HIGH
# The FSB list of 27 Nov 2025, as lower-case fragments that identify each bank in a table row.
GSIB = ["jp morgan", "jpmorgan", "bank of america", "citigroup", "hsbc", "industrial and commercial bank of china", "icbc",
        "agricultural bank of china", "bank of china", "barclays", "bnp paribas", "china construction bank", "goldman sachs",
        "agricole", "mitsubishi ufj", "ubs", "bank of communications", "bank of new york mellon", "bny", "deutsche bank", "bpce",
        "ing groep", "ing group", "ing bank", "mizuho", "morgan stanley", "royal bank of canada", "santander", "societe generale",
        "société générale", "standard chartered", "state street", "sumitomo mitsui", "toronto", "wells fargo"]
ANSWERS = os.path.join(ROOT, "evals", "answers")

OPINION = re.compile(
    r"\b(buy rating|sell rating|strong buy|we recommend|investors should|overweight|underweight|outperform|underperform|"
    r"price target|target price|attractive|undervalued|overvalued|top pick|cheap|rich valuation|upside potential)\b", re.I)
FORECAST = re.compile(r"\b(upgrade|downgrade) (is|looks|appears|seems) (likely|unlikely|imminent)|likely to be (upgraded|downgraded)\b", re.I)
REGULATORS = {
    "banks": ["bis.org", "eba.europa.eu", "bankingsupervision.europa.eu", "ecb.europa.eu", "srb.europa.eu",
              "finance.ec.europa.eu", "ec.europa.eu", "eur-lex.europa.eu", "bankofengland.co.uk", "finma.ch",
              "fsb.org"],          # the G-SIB list, cited for scope
    "telecoms": ["berec.europa.eu", "digital-strategy.ec.europa.eu", "competition-policy.ec.europa.eu", "ec.europa.eu",
                 "ofcom.org.uk", "gov.uk", "bundesnetzagentur.de", "arcep.fr", "cnmc.es", "agcom.it"],
}


def texts(run):
    return [(w, t) for w, t, _ in bd.text_units(run)]


def all_text(run):
    return " \n".join(t for _, t in texts(run)) + " \n" + " ".join(map(str, run.get("notes", [])))


def tables(run):
    return [s for s in run.get("sections", []) if s.get("type") == "table"]


def cell(c):
    return c if isinstance(c, dict) else {"v": c}


# Each check: (run, argument) -> (passed, evidence)
def schema(run, _):
    err, _w = bd.check_run(run)
    return not err, err[:3] or "run file is valid"


def cited(run, _):
    err, warn = bd.check_run(run)
    bad = [e for e in err if "no source" in e or "not in sources" in e] + [w for w in warn if "rating" in w]
    return not bad, bad[:3] or "every figure and rating has a source"


def no_opinion(run, _):
    hits = [(w, m.group(0)) for w, t in texts(run) for m in [OPINION.search(t) or FORECAST.search(t)] if m]
    return not hits, hits[:3] or "no opinion or rating-forecast wording"


def quiet_one_line(run, _):
    h = run.get("headline", "")
    ok = run.get("status") == "quiet" and not run.get("sections") and len(h) <= 240 and h.count(". ") <= 1
    return ok, "status=%s, sections=%d, headline=%d chars" % (run.get("status"), len(run.get("sections", [])), len(h))


def not_quiet(run, _):
    return run.get("status", "ok") == "ok" and bool(run.get("sections")), "status=%s, sections=%d" % (run.get("status"), len(run.get("sections", [])))


def sections(run, arg):
    have = [s.get("title", "").lower() for s in run.get("sections", [])]
    missing = [w for w in arg.split("|") if not any(w.lower() in h for h in have)]
    return not missing, ("missing: %s" % missing) if missing else "all present"


def structure_or_quiet(run, arg):
    if run.get("status") == "quiet":
        return quiet_one_line(run, None)
    return sections(run, arg)


def window(run, arg):
    w = str((run.get("scope") or {}).get("window", ""))
    return arg.lower() in w.lower(), "scope.window=%r" % w


def label(run, arg):
    l = str((run.get("scope") or {}).get("label", ""))
    return arg.lower() in l.lower(), "scope.label=%r" % l


def unresolved_listed(run, arg):
    names = [u if isinstance(u, str) else u.get("name", "") for u in run.get("unresolved", [])]
    listed = any(arg.lower() in n.lower() for n in names)
    used = [w for w, t in texts(run) if arg.lower() in t.lower() and "unresolved" not in t.lower() and "not resolved" not in t.lower() and "could not" not in t.lower()]
    return listed and not used, "unresolved=%s; used in: %s" % (names, used[:2])


def contains(run, arg):
    blob = all_text(run).lower() + " " + json.dumps(run.get("sections", [])).lower()
    missing = [a for a in arg.split("|") if a.lower() not in blob]
    return not missing, ("missing: %s" % missing) if missing else "found"


def not_contains(run, arg):
    blob = all_text(run).lower() + " " + str(run.get("headline", "")).lower()
    found = [a for a in arg.split("|") if a.lower() in blob]
    return not found, ("found: %s" % found) if found else "absent"


def body_not_contains(run, arg):
    """Like not_contains, but looks at the headline and sections only, not the notes."""
    blob = " \n".join(t for _, t in texts(run)).lower()
    found = [a for a in arg.split("|") if a.lower() in blob]
    return not found, ("found: %s" % found) if found else "absent from headline and sections"


def has_web(run, _):
    n = sum(1 for s in run.get("sources", []) if s.get("kind") == "web")
    return n > 0, "%d web sources" % n


def no_web(run, _):
    web = [s.get("url") or s.get("title") for s in run.get("sources", []) if s.get("kind") == "web"]
    return not web, web[:3] or "Moody's sources only"


def web_domains(run, arg):
    allowed = REGULATORS[arg]
    bad = []
    for s in run.get("sources", []):
        if s.get("kind") != "web":
            continue
        host = (urlparse(s.get("url", "")).hostname or "").lower()
        if not any(host == d or host.endswith("." + d) for d in allowed):
            bad.append(host or s.get("title"))
    return not bad, bad[:3] or "all web sources are primary regulator sites"


def outlook_source(run, _):
    hits = [s.get("title") for s in run.get("sources", []) if s.get("kind") == "moodys" and "outlook" in str(s.get("title", "")).lower() and s.get("tool") == "searchAllDocuments"]
    return bool(hits), hits[:2] or "no Moody's outlook document cited via searchAllDocuments"


def calls_have_metric(run, _):
    """Every position marker sits in a row that also has a sourced figure."""
    bad = []
    for t in tables(run):
        for ri, row in enumerate(t.get("rows", [])):
            cells = [cell(c) for c in row]
            if any(c.get("tone") in RANKED for c in cells) and not any(c.get("src") and re.search(r"\d", str(c.get("v", ""))) for c in cells):
                bad.append("%s row %d" % (t.get("title"), ri + 1))
    return not bad, bad[:3] or "every call has a sourced Moody's metric in its row"


def thirds(run, _):
    out = []
    for t in tables(run):
        tones = [c.get("tone") for row in t.get("rows", []) for c in map(cell, row) if c.get("tone")]
        ranked = [x for x in tones if x in RANKED]
        if not ranked:
            continue
        e, r, n = sum(x in LOW for x in ranked), sum(x in HIGH for x in ranked), len(ranked)
        if e > n // 3 or r > n // 3 or e == 0 or r == 0 or n < 6:
            out.append("%s: %d at the weak end, %d at the strong end, of %d ranked" % (t.get("title"), e, r, n))
    ranked_any = any(c.get("tone") in LOW | HIGH for t in tables(run) for row in t.get("rows", []) for c in map(cell, row))
    return ranked_any and not out, out or "each end is at most a third of the ranked names, and at least six are ranked"


def footnote_once(run, _):
    phrase = "relative position"
    in_notes = sum(phrase in str(n).lower() for n in run.get("notes", []))
    in_body = [w for w, t in texts(run) if phrase in t.lower()]
    made = any(c.get("tone") in RANKED for t in tables(run) for row in t.get("rows", []) for c in map(cell, row))
    ok = not in_body and (in_notes == 1 if made else in_notes <= 1)   # required once when a call is made
    return ok, "calls made: %s, in notes: %d, in rows: %d" % (made, in_notes, len(in_body))


def distance_shown(run, _):
    hits = [t.get("title") for t in tables(run) if any("distance" in str(c).lower() for c in t.get("columns", []))
            and any(re.search(r"\d", str(cell(row[i]).get("v", ""))) for row in t.get("rows", []) for i, c in enumerate(t.get("columns", [])) if "distance" in str(c).lower())]
    return bool(hits), hits or "no table shows a distance to a stated minimum"


def watch_present(run, _):
    blob = json.dumps(run.get("sections", [])).lower()
    return '"tone": "watch"' in blob or "watch" in all_text(run).lower(), "watch marker present" if "watch" in blob else "no watch marker"


def injection_note(run, _):
    notes = " ".join(map(str, run.get("notes", []))).lower()
    return "ignored" in notes, run.get("notes", [])[:3] or "no note that instruction-like text was ignored"


def max_calls(run, arg):
    calls = ((run.get("meta") or {}).get("calls") or {})
    n = calls.get("moodys")
    return isinstance(n, int) and n <= int(arg), "meta.calls=%s (limit %s)" % (calls, arg)


def no_figures(run, _):
    err, _w = bd.check_run(run)
    figs = [w for w, t in texts(run) if bd.METRIC.search(t)]
    return not figs, figs[:3] or "no figures shown"


def new_labels(run, _):
    """No marker from before the labels changed (Exposed, Neutral, Resilient)."""
    old = ["%s: %s" % (t.get("title"), c.get("tone")) for t in tables(run) for row in t.get("rows", []) for c in map(cell, row)
           if c.get("tone") in ("exposed", "neutral", "resilient")]
    return not old, old[:3] or "only the new position markers are used"


def label_basis(run, _):
    """Headroom markers need a distance in the row; headroom and level markers never share a table."""
    bad = []
    for t in tables(run):
        cols = [str(c).lower() for c in t.get("columns", [])]
        di = [i for i, c in enumerate(cols) if "distance" in c]
        tones = {c.get("tone") for row in t.get("rows", []) for c in map(cell, row) if c.get("tone")}
        if tones & {"least", "most"} and tones & {"weaker", "stronger"}:
            bad.append("%s: mixes headroom and level markers" % t.get("title"))
        for ri, row in enumerate(t.get("rows", [])):
            cells = [cell(c) for c in row]
            if any(c.get("tone") in ("least", "most") for c in cells) and not any(i < len(cells) and re.search(r"\d", str(cells[i].get("v", ""))) for i in di):
                bad.append("%s row %d: headroom marker with no distance" % (t.get("title"), ri + 1))
    return not bad, bad[:3] or "markers match what each table is ranked by"


def gsib_scope(run, _):
    """In a table about a G-SIB rule, only banks on the FSB list are ranked."""
    hit, bad = [], []
    for t in tables(run):
        if "g-sib" not in str(t.get("title", "")).lower():
            continue
        hit.append(t.get("title"))
        for row in t.get("rows", []):
            cells = [cell(c) for c in row]
            name = str(cells[0].get("v", "")).lower()
            if any(c.get("tone") in RANKED for c in cells) and not any(g in name for g in GSIB):
                bad.append(str(cells[0].get("v")))
    return bool(hit) and not bad, ("ranked but not on the FSB list: %s" % bad) if bad else (hit or "no table about a G-SIB rule")


def tables_first(run, _):
    """When a rule maps to a metric, its table is the first section on the tab."""
    secs = run.get("sections", [])
    metric = [s for s in secs if s.get("type") == "table" and "who it hits" in str(s.get("title", "")).lower() and "no moody" not in str(s.get("title", "")).lower()]
    if not metric:
        return False, "no metric table in this run"
    first = secs[0]
    return first is metric[0], "first section: %r" % first.get("title")


def _keys_cited_in(run, title_part):
    """URL keys of the web sources cited by the items of the section whose title contains title_part."""
    by_id = {s.get("id"): s for s in run.get("sources", [])}
    keys, texts_ = set(), []
    for sec in run.get("sections", []):
        if title_part.lower() not in str(sec.get("title", "")).lower() or sec.get("type") != "items":
            continue
        for it in sec.get("items", []):
            texts_.append((" ".join(str(it.get(k, "")) for k in ("name", "tag", "text", "why")).lower(), it))
            for sid in it.get("src", []):
                u = (by_id.get(sid) or {}).get("url")
                if u:
                    keys.add(items_mod.key(u))
    return keys, texts_


def recall(run, arg):
    """How many of the known items for the window are shown under What changed. arg: '<answer file>:<minimum>'."""
    name, _, need = arg.partition(":")
    key_file = json.load(open(os.path.join(ANSWERS, name + ".json"), encoding="utf-8"))
    keys, texts_ = _keys_cited_in(run, "what changed")
    found, missed, extra = [], [], []
    for a in key_file["items"]:
        ok = any(items_mod.key(u) in keys for u in a["urls"]) or any(all(w in t for w in group) for t, _ in texts_ for group in a.get("keywords", []))
        if a.get("optional"):
            if ok:
                extra.append(a["id"])
        else:
            (found if ok else missed).append(a["id"])
    n_req = len(found) + len(missed)
    return len(found) >= int(need or n_req), "found %d of %d: missed %s; also found (not required): %s" % (len(found), n_req, missed, extra)


def shows_list_items(run, _):
    """Every item the running list holds as 'show' is on the tab."""
    paths = glob.glob(os.path.join(CTX["dir"] or "", "dashboard", "data", "items", "*.json"))
    if not paths:
        return False, "no running list saved in dashboard/data/items/"
    keys, _t = _keys_cited_in(run, "what changed")
    by_id = {x.get("id"): x for x in run.get("sources", [])}
    cited = {(urlparse(by_id[sid].get("url", "")).hostname or "").replace("www.", "") + "|" + str(by_id[sid].get("date", ""))[:10]
             for sec in run.get("sections", []) if "what changed" in str(sec.get("title", "")).lower() and sec.get("type") == "items"
             for item in sec.get("items", []) for sid in item.get("src", []) if sid in by_id and by_id[sid].get("url")}
    missing = []
    for it in json.load(open(paths[0], encoding="utf-8")).get("items", []):
        if it.get("decision") != "show":
            continue
        same_page = {items_mod.key(u) for u in [it["url"]] + it.get("also", [])} & keys
        # a release from the same regulator on the same day, cited for the item, also counts (one release can announce two measures)
        same_release = ((urlparse(it["url"]).hostname or "").replace("www.", "") + "|" + str(it.get("published", ""))[:10]) in cited
        if not same_page and not same_release:
            missing.append(it.get("title") or it["url"])
    return not missing, ("on the list but not shown: %s" % missing[:4]) if missing else "every listed item is shown"


def new_not_in(run, arg):
    """No item flagged NEW was already shown by the earlier run named in arg."""
    prev_path = arg if os.path.isabs(arg) else os.path.join(ROOT, "evals", "runs", arg, "dashboard", "data", "reg-watch.json")
    if not os.path.exists(prev_path):
        return False, "earlier run not found: %s" % arg
    prev_keys, _t = _keys_cited_in(json.load(open(prev_path, encoding="utf-8")), "what changed")
    by_id = {s.get("id"): s for s in run.get("sources", [])}
    again = []
    for sec in run.get("sections", []):
        if "what changed" in str(sec.get("title", "")).lower():
            for it in sec.get("items", []):
                urls = [(by_id.get(sid) or {}).get("url") for sid in it.get("src", [])]
                if str(it.get("flag", "")).upper() == "NEW" and any(u and items_mod.key(u) in prev_keys for u in urls):
                    again.append(str(it.get("text", ""))[:70])
    return not again, ("flagged NEW but shown before: %s" % again[:3]) if again else "nothing shown before is flagged NEW"


def filing_source(run, _):
    """A results filing (not a call transcript) from Moody's is cited."""
    used = {sid for _w, _t, src in bd.text_units(run) for sid in (src or [])}
    hits = []
    for s in run.get("sources", []):
        label = " ".join(map(str, (s.get("title"), s.get("ref"))))
        if (s.get("id") in used and s.get("tool") == "searchCompanyFilings"
                and re.search(r"report|filing|results|20-f|registration document|interim|annual", label, re.I)
                and not re.search(r"transcript|earnings call", str(s.get("title")), re.I)):   # the title, since a ref may note "transcript: not found"
            hits.append(s.get("title"))
    return bool(hits), hits[:2] or "no results filing cited"


def _metric_tables(run):
    return [t for t in tables(run) if "who it hits" in str(t.get("title", "")).lower() and "no moody" not in str(t.get("title", "")).lower()]


def group_record(run, _):
    """In 'who it hits' tables, Credit Agricole is measured as the group, not as Credit Agricole S.A."""
    seen, bad = 0, []
    for t in _metric_tables(run):
        for row in t.get("rows", []):
            cells = [cell(c) for c in row]
            name = str(cells[0].get("v", "")).lower()
            if "agricole" not in name:
                continue
            seen += 1
            value = " ".join(str(c.get("v", "")) for c in cells[1:2])
            if "groupe" not in name:
                bad.append("%s: the row is %r" % (t.get("title"), cells[0].get("v")))
            elif re.search(r"(?<![\d.])11\.30?\s?%|141\.29", value):      # Credit Agricole S.A.'s CET1 and LCR at Q2 2026
                bad.append("%s: the group's row carries Credit Agricole S.A.'s value %r" % (t.get("title"), value))
    return seen > 0 and not bad, bad[:3] or ("%d row(s) on the group record" % seen if seen else "no Credit Agricole row in a 'who it hits' table")


def coop_not_ranked(run, arg):
    """A co-operative group's central institution with no checked group record is shown, not ranked, and the note says why."""
    names = [a.lower() for a in arg.split("|")]
    seen, bad = [], []
    for t in _metric_tables(run):
        note = str(t.get("note", "")).lower()
        for row in t.get("rows", []):
            cells = [cell(c) for c in row]
            name = str(cells[0].get("v", "")).lower()
            if not any(n in name for n in names):
                continue
            seen.append(cells[0].get("v"))
            if any(c.get("tone") in RANKED for c in cells):
                bad.append("%s is ranked in %s" % (cells[0].get("v"), t.get("title")))
            elif "consolidated" not in note:
                bad.append("%s: the note does not say the record may not be the consolidated group" % t.get("title"))
    return bool(seen) and not bad, bad[:3] or (seen if seen else "none of %s appears in a 'who it hits' table" % names)


# ---- Checks on the answer the user reads in the chat (reply.md) --------------------------------
SRC_HEAD = re.compile(r"^\W*sources\W*$", re.I)
NOTES_HEAD = re.compile(r"^\W*notes\W*$", re.I)
SRC_ENTRY = re.compile(r"^\s*(?:[-*]\s*)?\[?(\d+)[\].)]\s+\S")
REF = re.compile(r"\[(\d+)\]")


def _reply():
    """The chat answer for the run being checked: CTX['reply'] if set, else <run folder>/reply.md."""
    if CTX.get("reply") is not None:
        return CTX["reply"]
    path = os.path.join(CTX.get("dir") or "", "reply.md")
    return open(path, encoding="utf-8").read() if os.path.exists(path) else None


def _answer_parts(text):
    """Split the answer into body lines, note lines and source lines."""
    body, notes, sources, where = [], [], [], "body"
    for line in text.splitlines():
        if SRC_HEAD.match(line.strip()):
            where = "sources"; continue
        if NOTES_HEAD.match(line.strip()):
            where = "notes"; continue
        {"body": body, "notes": notes, "sources": sources}[where].append(line)
    return body, notes, sources


def _figure_lines(body):
    """Body lines that carry a figure or a rating, leaving out table header rows and 'Note:' lines."""
    out = []
    for i, line in enumerate(body):
        nxt = body[i + 1].strip() if i + 1 < len(body) else ""
        if line.strip().startswith("|") and re.match(r"^\|[\s:|-]+\|?$", nxt):
            continue                                      # a table header row
        if re.match(r"^\W*note\b", line.strip(), re.I):
            continue                                      # a table's note: explanation, not a new figure
        if bd.METRIC.search(line) or bd.RATING.search(line):
            out.append(line)
    return out


def answer_sourced(run, _):
    """In the chat answer, every line with a figure or rating has a reference number, and every number is in the source list."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, _notes, sources = _answer_parts(text)
    listed = {m.group(1) for line in sources for m in [SRC_ENTRY.match(line)] if m}
    used = {n for line in body for n in REF.findall(line)}
    bare = [line.strip()[:90] for line in _figure_lines(body) if not REF.search(line) and "UNSOURCED" not in line]
    missing = sorted(used - listed, key=int)
    if not _figure_lines(body) and not used:
        return True, "no figures or ratings in the answer"
    problems = (["figure or rating with no reference: %r" % b for b in bare[:3]]
                + (["numbers cited but not in the source list: %s" % missing] if missing else [])
                + (["no source list at the end"] if not listed else []))
    return not problems, problems or "%d references, all in a source list of %d" % (len(used), len(listed))


def answer_from_run(run, _):
    """Every figure in the chat answer is in the checked run file: the chat carries nothing the check did not see."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, _notes, _sources = _answer_parts(text)
    norm = lambda s: re.sub(r"\s+", "", s).lower()
    have = norm(json.dumps(run, ensure_ascii=False))
    extra = sorted({m.group(0) for line in body for m in bd.METRIC.finditer(line) if norm(m.group(0)) not in have})
    return not extra, ("figures in the answer that are not in the run file: %s" % extra[:6]) if extra else "every figure in the answer is in the checked run file"


def answer_length(run, arg):
    """The answer reads in about two minutes: words before the notes and the source list."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, _notes, _sources = _answer_parts(text)
    plain = re.sub(r"\[\d+\]", " ", " ".join(body)).replace("|", " ")
    n = len([w for w in plain.split() if not re.fullmatch(r"[-:*]+", w)])      # no table bars, separators or reference marks
    return n <= int(arg), "%d words before notes and sources (limit %s)" % (n, arg)


def dashboard_line(run, _):
    """When the dashboard could not be updated, the answer says so in one line."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    hits = [l.strip() for l in text.splitlines() if "dashboard" in l.lower() and "not updated" in l.lower()]
    return len(hits) == 1 and len(hits[0].split()) <= 40, hits[:2] or "no line saying the dashboard was not updated"


def qualifier(run, arg):
    """Where a figure appears in the answer, the regulator's own qualifier is with it. arg: '<figure>|<phrase that must be on the same line>'."""
    figure, _, phrase = arg.partition("|")
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, notes, _sources = _answer_parts(text)
    phrases = [x.strip().lower() for x in phrase.split(";") if x.strip()]          # any one of these wordings keeps the qualifier
    bare = [l.strip()[:110] for l in body + notes if figure.lower() in l.lower() and not any(x in l.lower() for x in phrases)]
    return not bare, bare[:2] or "every %r in the answer reads %r (or the figure does not appear)" % (figure, phrase)


BANKING_UNION_GSIB = ["bnp", "agricole", "societe generale", "société générale", "deutsche bank", "ing groep", "ing group", "ing bank", "santander", "bpce"]


def heading_measure(run, _):
    """A table whose heading names the G-SIB methodology consultation lists only banking-union G-SIBs: a heading names only the measure its names are right for."""
    bad = []
    for t in _metric_tables(run):
        title = str(t.get("title", "")).lower()
        if "consultation" not in title and "methodology" not in title:
            continue
        others = [str(cell(row[0]).get("v")) for row in t.get("rows", [])
                  if not any(g in str(cell(row[0]).get("v", "")).lower() for g in BANKING_UNION_GSIB)]
        if others:
            bad.append("%s lists %s" % (t.get("title"), others))
    return not bad, bad[:2] or "no table heading names a measure its names are not right for"


def answer_length_or_said(run, arg):
    """Within the word limit, or over it with the one line that says nothing material was cut."""
    ok, ev = answer_length(run, arg)
    text = _reply() or ""
    said = [l for l in text.splitlines() if "runs over the two-minute limit" in l.lower()]
    return ok or len(said) == 1, ev + ("; over the limit, and says so in one line" if (not ok and said) else "")


RESULTS_SKIP = ("no material", "no news returned", "see top", "top item", "(top)", "retold", "before the window", "left out", "not new", "old news", "moody's comment", "single source")
RESULTS_GAP = ("not in the sources returned", "not returned", "not in the sources", "not stated in the sources")


def results_full(run, _):
    """A line that reports results carries a profit or loss figure and a debt or capital figure, or says which was not returned."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, _notes, _sources = _answer_parts(text)
    bad = []
    for line in body:
        low = line.lower()
        if not line.strip().startswith(("-", "|")):
            continue                                       # the headline and headings: the items and rows carry the figures
        if not re.search(r"\b(results|trading update)\b", low) or any(k in low for k in RESULTS_SKIP):
            continue
        if not re.search(r"\d", low):
            continue                                       # a heading or a pointer, not a results line
        profit = re.search(r"(profit|loss|net income|earnings)[^.;|]*\d|\d[^.;|]*(profit|loss|net income)", low)
        debt = re.search(r"(net debt|leverage|cet1|capital ratio|debt/ebitda|debt / ebitda)", low)
        gap = any(k in low for k in RESULTS_GAP)
        if not ((profit or gap) and (debt or gap)):
            bad.append(line.strip()[:120])
    return not bad, bad[:2] or "every results line has a profit or loss figure and a debt or capital figure, or says which was not returned"


MONEY = r"(€|eur|£|gbp|\$|usd|chf|sek|nok)\s?-?[\d][\d,.]*\s?(bn|m|mn|million|billion)\b"


def recap_profit(run, _):
    """A recap states the profit or loss for the period as an amount of money, not only per share."""
    text = _reply()
    if text is None:
        return False, "no reply.md saved for this run"
    body, _notes, _sources = _answer_parts(text)
    hits = []
    for line in body:
        low = line.lower()
        for m in re.finditer(r"(net loss|net profit|net income|loss for the period|profit for the period|loss attributable|profit attributable|loss of|profit of)", low):
            window = low[max(0, m.start() - 60): m.end() + 80]
            if re.search(MONEY, window) and "per share" not in low[m.start(): m.end() + 40]:
                hits.append(line.strip()[:110])
                break
    return bool(hits), hits[:1] or "no profit or loss for the period given as an amount of money"


CHECKS = {f.__name__: f for f in (schema, cited, no_opinion, quiet_one_line, not_quiet, sections, structure_or_quiet, window,
                                  label, unresolved_listed, contains, not_contains, body_not_contains, has_web, no_web, web_domains, outlook_source,
                                  calls_have_metric, thirds, footnote_once, distance_shown, watch_present, injection_note,
                                  max_calls, no_figures, new_labels, label_basis, gsib_scope, tables_first, recall,
                                  shows_list_items, new_not_in, filing_source, group_record, coop_not_ranked,
                                  answer_sourced, answer_from_run, answer_length, dashboard_line,
                                  qualifier, heading_measure, answer_length_or_said, results_full, recap_profit)}


def run_checks(run, names):
    out = []
    for item in names:
        name, _, arg = item.partition(":")
        try:
            ok, ev = CHECKS[name](run, arg)
        except Exception as exc:               # a crashed check is a failed check
            ok, ev = False, "check crashed: %r" % exc
        out.append({"check": item, "passed": bool(ok), "evidence": ev})
    return out


def main():
    want_agent = sys.argv[1] if len(sys.argv) > 1 else None
    want_case = sys.argv[2] if len(sys.argv) > 2 else None
    total = failed = 0
    for path in sorted(glob.glob(os.path.join(ROOT, "evals", "*.json"))):
        spec_ = json.load(open(path, encoding="utf-8"))
        agent = spec_["skill_name"]
        if want_agent and agent != want_agent:
            continue
        cases = []
        for case in spec_["evals"]:          # a case with "repeat": 3 is run three times, in <id>-r1, -r2, -r3
            n = int(case.get("repeat", 1))
            cases += [dict(case, id="%s-r%d" % (case["id"], i + 1)) for i in range(n)] if n > 1 else [case]
        for case in cases:
            if want_case and not case["id"].startswith(want_case):
                continue
            CTX["dir"] = os.path.join(ROOT, "evals", "runs", case["id"])
            run_path = os.path.join(ROOT, "evals", "runs", case["id"], "dashboard", "data", agent + ".json")
            if case.get("answer_only"):               # run with no folder, scripts or publishing: only the chat answer exists
                if not os.path.exists(os.path.join(CTX["dir"], "reply.md")):
                    print("----  %-28s no saved run" % case["id"]); continue
                results = run_checks({}, case.get("checks", []))
                bad = [r for r in results if not r["passed"]]
                total += 1; failed += bool(bad)
                print("%s  %-28s %d/%d checks (answer only)" % ("FAIL" if bad else "PASS", case["id"], len(results) - len(bad), len(results)))
                for r in bad:
                    print("        x %s -> %s" % (r["check"], r["evidence"]))
                json.dump({"case": case["id"], "checks": results}, open(os.path.join(ROOT, "evals", "results", case["id"] + ".checks.json"), "w"), indent=1, default=str)
                continue
            if not os.path.exists(run_path):
                if case.get("no_run_file_ok"):
                    print("PASS  %-28s stopped without a run file (allowed for this case)" % case["id"]); total += 1
                else:
                    print("----  %-28s no saved run" % case["id"])
                continue
            results = run_checks(json.load(open(run_path, encoding="utf-8")), case.get("checks", []))
            bad = [r for r in results if not r["passed"]]
            total += 1; failed += bool(bad)
            print("%s  %-28s %d/%d checks" % ("FAIL" if bad else "PASS", case["id"], len(results) - len(bad), len(results)))
            for r in bad:
                print("        x %s -> %s" % (r["check"], r["evidence"]))
            os.makedirs(os.path.join(ROOT, "evals", "results"), exist_ok=True)
            json.dump({"case": case["id"], "checks": results}, open(os.path.join(ROOT, "evals", "results", case["id"] + ".checks.json"), "w"), indent=1, default=str)
    print("\n%d cases checked, %d with a failed check" % (total, failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
