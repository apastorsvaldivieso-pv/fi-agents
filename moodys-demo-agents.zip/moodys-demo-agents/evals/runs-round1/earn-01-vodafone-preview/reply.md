**Vodafone Group Plc: earnings preview (credit view)**

This is a preview, as you asked. Vodafone reported H1 FY27 results on 10 Nov 2026, five days ago, and Moody's already holds that call transcript. If you meant those results, I can run a recap instead.

**Rating and outlook**
- Moody's rates Vodafone Baa2 (Senior Unsecured, foreign currency), outlook stable. The rating was affirmed on 13 Oct 2026.
- The credit opinion is dated 21 Oct 2026, so it was written before the H1 results.
- Moody's says the stable outlook assumes debt/EBITDA stays below 3.3x, RCF/net debt stays around 30%, net leverage stays in the lower half of the company's target range, and liquidity stays excellent.

**What to watch against Moody's triggers** (Moody's-adjusted, fiscal year ended 31 Mar 2026)

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to stay below 3.3x on a sustained basis | **0.05x** to the downgrade trigger; 0.75x from the upgrade level |
| RCF / Net Debt | 33.08% | stays above 25% on a sustained basis | declines towards 18% on a sustained basis | 15.1 pts above 18%; the 25% upgrade level is already met |

Triggers set out in words in the credit opinion (quoted):
- Upgrade: "underlying revenue and operating performance improve sustainably, particularly in Germany"
- Downgrade: "Vodafone's operating performance deteriorates, including a failure to turn around its German operations"

**What management guided on the last call** (H1 FY27 earnings call, 10 Nov 2026; company-reported)
1. **Guidance raised.** FY27 group guidance went up. Management said the midpoint of the new ranges implies organic growth "accelerating to 7% for adjusted EBITDA and 21% for adjusted free cash flow". It repeated its medium-term aim of double-digit organic growth in adjusted free cash flow. The call excerpts give no euro amounts for the ranges.
2. **Germany.** Europe guidance was reconfirmed, even though the European Court of Justice ruling cut EBITDA by about EUR 100m. Germany's H1 EBITDA fell 3.2%, and about 2 points of that came from the provision. Management does not expect the class action to end before late calendar 2027, at the earliest, and has not included a cash outflow for it in this year's cash flow guidance.
3. **Capex.** "I would not guide to any material reduction of our capital intensity in Germany." Fibre roll-out on the cable network continues within the existing capex budget.
4. **OXG fibre joint venture.** Société Générale has replaced Altice as Vodafone's partner. An analyst said Vodafone may have to put in up to EUR 1.2bn of equity. Management did not confirm the figure. It said funding will be a mix of debt and equity, with any equity from Vodafone phased over the build.
5. **Costs and portfolio.**
   - Cost targets: more than EUR 2bn of gross annual savings and more than EUR 1bn of net opex savings, the net figure being 13% of Europe EBITDA. Management expects more than EUR 200m of net savings this fiscal year and has announced another 2,300 job cuts in Germany.
   - Portfolio: in H1 Vodafone took full ownership of VodafoneThree and raised its Safaricom stake.

The call excerpts gave no guidance on net debt or the net leverage target.

**Moody's expectations** (key indicators, credit opinion of 21 Oct 2026)

| | FY2026 | FY2027F | FY2028F | FY2029F |
|---|---|---|---|---|
| Debt / EBITDA | 3.3x | 3.1x | 3.0x | 2.9x |
| RCF / Net Debt | 33.1% | 29.4% | 30.9% | 31.7% |
| (EBITDA - CAPEX) / Interest | 2.4x | 2.6x | 2.8x | 3.0x |
| Net Debt / EBITDA | 2.5x | 2.6x | 2.5x | 2.4x |

**What to watch:**
- **Debt/EBITDA.** It has only 0.05x of room to the 3.3x downgrade trigger, and Moody's forecasts it falling to 3.1x in FY27. EBITDA growth, the timing of OXG equity and the effect of the VodafoneThree buyout on debt decide where it lands.
- **Germany.** Its turnaround is a trigger in words, for both an upgrade and a downgrade.

Company-reported guidance is a different measure from Moody's-adjusted ratios and has not been converted into them. Moody's data has no consensus figures, so there is no comparison with consensus.

Sources: Moody's credit opinion PBC_1496608 (21 Oct 2026); Moody's rating history, Senior Unsecured - Fgn Curr (last action 13 Oct 2026); Moody's-adjusted key indicators, fiscal year ended 31 Mar 2026; Half Year 2027 Vodafone Group earnings call transcript (10 Nov 2026).

The dashboard's Earnings tab was updated at 12:55 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html`. The Artifact publish step was skipped because this is a test run.
