**European telecoms: credit news brief, last 7 days** (8 Nov 12:54 UTC to 15 Nov 12:54 UTC, 15 names)

Moody's took no rating actions on the list this week. The main credit news: Telefonica raised its 2026 guidance, Telenor took control of Bahnhof, and Latvia is buying out Telia's Baltic stakes.

**Top this week**
1. **Telefonica (Baa3 Senior Unsecured, stable).** At Q3 results on 12 Nov it raised full-year guidance for adjusted EBITDA, operating cash flow after leases and free cash flow, helped by Spain and Brazil. Reported Q3 net income was EUR 802m, against EUR 276m a year earlier. *Why it matters:* more internally generated cash for paying down debt, which supports leverage and RCF / net debt.
2. **Telenor (Baa1 Senior Unsecured, positive outlook).** It closed the purchase of 57.5% of Swedish broadband provider Bahnhof and made a mandatory cash offer of SEK 62 a share for the rest. It now holds about 66.9% of the shares and 90.6% of the votes. Bahnhof's independent committee recommends shareholders accept. *Why it matters:* the deal is paid in cash, so its size against leverage matters while the outlook is positive.
3. **Telia (Baa1 Senior Unsecured, stable).** According to LMT, the Latvian government's buyout of Telia's stakes in LMT and Tet is on track for its 17 Nov deadline. *Why it matters:* the proceeds could reduce net debt, but Telia's Baltic business gets smaller. The terms and what Telia does with the money will decide the effect on leverage.

**Macro**
- Moody's 2027 global credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs offset the AI tailwind. This puts most pressure on the leveraged names: Altice France, VMED O2 and Iliad.
- French October inflation rose because of energy prices, so markets still expect a possible ECB rate hike. That would make refinancing euro debt more expensive.
- UK price data may strengthen the Bank of England's case for another rate rise. This matters most for VMED O2.

**Sector**
- No Moody's rating actions on European telecoms were published in the window.
- Moody's Issuer Comment on Odido (11 Nov; Odido is not on the list): new notes funding Apax's acquisition of the company increase leverage, but Moody's sees its credit quality as unchanged. Odido competes with KPN in the Netherlands.
- Latest Moody's sector outlook: Telecommunications – Global, **stable**, published 27 Oct 2026 (before the window). Solid demand, modest EBITDA growth and falling capital intensity offset refinancing pressure and structural risks.

**By name**
| Name | Moody's rating, outlook | This week |
|---|---|---|
| Deutsche Telekom | A3 Senior Unsecured, stable | No material credit news. This week's coverage repeated the 5 Nov Q3 release (before the window); the share buyback continued. |
| Orange | Baa1 LT Issuer, stable | No material credit news. |
| Vodafone Group | Baa2 Senior Unsecured, stable | No material credit news. |
| Telefonica | Baa3 Senior Unsecured, stable | Raised 2026 guidance (see above). |
| Swisscom | A2 LT Issuer, stable | No material credit news. |
| Telekom Austria | A3 LT Issuer, stable | No material credit news. |
| Proximus | A3 Senior Unsecured, stable | No material credit news. |
| Telenor | Baa1 Senior Unsecured, positive | Took control of Bahnhof (see above). |
| Telia | Baa1 Senior Unsecured, stable | Latvian buyout of its LMT and Tet stakes (see above). |
| TIM | Baa3 LT Issuer, positive | No material credit news. |
| KPN | Ratings withdrawn (WR) since 18 Dec 2024 | No material credit news. |
| BT Group Plc | No Moody's rating found for this entity | BT and its pension scheme agreed the 30 June 2026 valuation: the deficit fell to GBP 2.7bn from GBP 3.7bn and the funding level rose to 92.3% from 91.0% (company-reported). The release is dated 5 Nov, so the announcement may predate the window. |
| Iliad | Ba1 Senior Unsecured, stable | No material credit news. |
| VMED O2 UK Holdings | B1 CFR, **on review for downgrade** since 22 Oct | Nothing new in the window. The review is still open. |
| Altice France | Caa1 Senior Secured bank facility, positive | No material credit news. |

Notes:
- Two names on the checked list have no current Moody's rating in the data: KPN (ratings withdrawn) and BT Group Plc. I kept both as they are and did not replace either with another entity.
- Searches for several names mostly returned share-price blurbs or unrelated items. I left out share-price stories, small contract awards and subsidiary-only stories.

The Daily sector news tab is updated as of 15 Nov 2026, 12:56 UTC. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html`. In this test run I did not publish it to the private link.
