**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

Six publications from the primary regulators in the window. Only the Basel Committee's G-SIB package maps to a Moody's metric. Moody's has commented on one item, the EBA governance guidelines, and calls them credit positive.

**What changed** (all NEW; this is the first run)

| Date | Body | Status | What | Channel |
|---|---|---|---|---|
| 16 Oct | Basel Committee | Final + consultation | Stock indicators for the G-SIB assessment move to year averages to end window-dressing (implementation by 1 Jan 2030). The reporting threshold rises from EUR 200bn to EUR 350bn of leverage exposure from 2027. A consultation on the Banking Union cross-border treatment closes 14 Jan 2027. | Capital buffers, leverage |
| 22 Oct | PRA | Consultation | CP14/26: Phase 2 of the SM&CR review. The search result gives a 22 Jan 2027 deadline; I did not open the CP page. | Governance (watch) |
| 5 Nov | Basel Committee | Consultation | Consequential amendments to fit the new consolidated guidelines. Comments close 21 Dec 2026. | Technical (watch) |
| 5 Nov | EBA | Final | Revised internal governance guidelines (EBA/GL/2026/10), aligned with CRD VI and DORA. The PDF could not be read, so the application date is not confirmed. | Governance (watch) |
| 6 Nov | EBA | Other | Next steps on reporting simplification: final report in Dec 2026, first reference date Dec 2027, liquidity, ESG and some other templates in Dec 2028. | Reporting (watch) |
| 10 Nov | PRA | Final | PS20/26 Large Exposures Part 2: mandatory substitution, the trading-book excess allowance cut to 85% of Tier 1, NCLEG limit of 350% of Tier 1. Effective 1 Jan 2028. | Large exposures (watch, no Moody's metric) |

**Moody's view:** In a Sector Comment of 11 Nov 2026, Moody's calls the EBA's revised governance guidelines credit positive, mainly for smaller EU banks, since large banks already largely comply. Moody's published nothing in the window on the other five items.

**Who it hits: G-SIB package**

- **CET1 ratio** (as reported, Q2 2026; list median 13.4%):
  - Exposed: Credit Agricole SA 11.3%, CaixaBank 12.33%, BBVA 12.9%, BNP Paribas 12.97%.
  - Resilient: Nordea 15.7%, Commerzbank 14.38%, Barclays 14.3%, UniCredit 14.26%.
  - The rest are neutral.
  - No distance to minimum is shown because CET1 requirements are firm-specific.
- **Fully loaded leverage ratio** (Q2 2026; list median 4.9%; Basel minimum 3%):
  - Exposed: Credit Agricole SA 3.7% (+0.7 pp), ING 4.2%, Societe Generale 4.3%.
  - Resilient: BBVA 6.0%, Intesa Sanpaolo 5.74%, CaixaBank 5.5%.
  - Not in Moody's data: BNP Paribas, Lloyds, UniCredit, Commerzbank, Nordea.
- **UBS**: Moody's latest period is Q3 2018, so UBS is shown in the tables but left out of both rankings.

The calls show each bank's position within this list on the stated metric. They are not an estimate of impact.

Dashboard: the Regulatory watch tab was updated at 12:57 UTC on 15 Nov 2026. The local page is `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`. It was not published to the private link because this is a test run.
