**Regulatory watch: European banks, 9 to 15 Nov 2026**

I found four regulatory items in the window. None of them falls on a channel that Moody's data has a metric for, so I haven't made an exposed, neutral or resilient call on any of the 15 names. All four are new, because this is the first run.

**What changed**

| Body | Item | Status | Date / deadline | Channel |
|---|---|---|---|---|
| Basel Committee | Pillar 2 guidance on interest rate risk in the banking book (IRRBB): model risk, stress testing, embedded gains and losses, earnings indicators, plus new supervisory reporting | Consultation | Published 9 Nov; comments due 9 Feb 2027 | IRRBB |
| PRA | PS20/26, Large Exposures Framework Part 2: mandatory substitution for credit risk mitigation, no internal models for SFT exposure values, revised trading book and intragroup limits (higher intragroup limit 350% of Tier 1) | Final | Published 10 Nov; applies from 1 Jan 2028 (permission applications from 1 Jul 2027) | Large exposures |
| FINMA | Partially revised AML Ordinance (AMLO-FINMA), ahead of the FATF evaluation; narrows correspondent-banking scope, expands ownership-transparency notes | Final | Published 10 Nov; in force 1 Jan 2027 | AML |
| EBA | 2027 EU-wide stress test methodology: more than 55% fewer data points, first climate module (outside core results) | Final methodology | Published 9 Nov; launch end-Jan 2027, results end-Jul 2027 | No row in the channel map. I put it under supervisory reporting myself |

I found no Moody's research on any of the four in the window.

**Who it hits: no Moody's metric (watch)**
- IRRBB guidance: watch. Moody's data has no IRRBB metric.
- PRA large exposures: watch. It applies to PRA-authorised firms. On the list, that means HSBC, Barclays and Lloyds. Moody's data can't show which other groups' UK subsidiaries are in scope.
- FINMA AML: watch. It applies to Swiss institutions; on the list, that is UBS.
- EBA stress test: watch. Moody's data can't tell which banks are in the sample.

Because no item maps to a metric, I didn't run the financials call.

**Left out (not rules, or no bearing on bank credit):**
- EBA: consumer factsheet; NGFS statement
- ECB: written overview for the Eurogroup
- SRB: speeches and news
- European Commission: sustainability assurance call for feedback; competitiveness dialogue summary; tokenisation nominations

The EBA governance guidelines (5 Nov) and other early-November items fall just before the window.

The "Regulatory watch" tab is updated as of 15 Nov 2026, 13:25 UTC: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html`. This is a test run, so I didn't publish it to the shared link.
