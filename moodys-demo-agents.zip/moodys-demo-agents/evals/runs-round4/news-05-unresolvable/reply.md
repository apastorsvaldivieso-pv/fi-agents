**Telecoms, Europe: 72h to 15 Nov 2026 13:07 UTC**

Nothing material for Telecoms, Europe, in the last 72h.

**Names covered**

| Name | Country |
|---|---|
| Vodafone Group Plc | GB |
| Orange | FR |

**Could not be resolved:** Zzyzx Fakecorp Holdings. Moody's has no match for this name, and the search returned no candidates. I left it out rather than swap in a similar company. If you have the issuer's full legal name or home country, send it and I'll look it up again.

What I left out: Vodafone dividend timing and share-price commentary, a passive 13G shareholding filing, Vodacom and Vodafone Idea stories that don't affect the group's credit, and an Orange Travel promotion. Moody's published no rating actions or sector research on European telecoms in the window.

The Daily sector news tab was updated at 15 Nov 2026 13:08 UTC: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html`. It wasn't published to the private link because this is a test run.
