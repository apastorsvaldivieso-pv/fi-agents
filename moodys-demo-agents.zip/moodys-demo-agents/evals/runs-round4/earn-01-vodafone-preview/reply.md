**Vodafone Group Plc: earnings preview** (Moody's data as of 15 Nov 2026)

**Note: the half-year results are already out.** Moody's has the H1 FY27 earnings call from 10 Nov 2026. This preview treats that call as the latest guidance and looks ahead to the full-year results (FY to Mar 2027). I can run a recap of the H1 results if you want one. The credit opinion (21 Oct 2026) was written before these results.

**Rating and outlook.** Baa2, Senior Unsecured (foreign currency), outlook stable. Last action: affirmation on 13 Oct 2026. Credit opinion dated 21 Oct 2026. The stable outlook assumes Moody's-adjusted debt/EBITDA below 3.3x, RCF/net debt around 30%, Germany at least stabilising, net leverage in the lower half of the company's target range, and excellent liquidity.

**Where Vodafone sits against Moody's triggers** (Moody's-adjusted, FY to 31 Mar 2026)

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room to upgrade | Room to downgrade |
|---|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to remain below 3.3x (sustained) | 0.75x above 2.5x | 0.05x below 3.3x |
| RCF / Net Debt | 33.1% | higher than 25% (sustained) | towards 18% (sustained) | already met, by 8.1pp | 15.1pp above 18% |

Triggers stated in words, quoted from the credit opinion:
- Upgrade: "underlying revenue and operating performance improve sustainably, particularly in Germany".
- Downgrade: "Vodafone's operating performance deteriorates, including a failure to turn around its German operations".
- Moody's says it recognises the company's robust cash balance and short-term investments when it analyses gross leverage.

**Sector metrics to watch**
- Service revenue growth: group service revenue grew 6.4% in Q2 FY27 (company-reported). The excerpts did not include a breakdown by market. Germany bears on the worded triggers.
- Revenue: EUR 40,461m (Moody's-adjusted, FY Mar-2026).
- EBITDA: EUR 15,762m (Moody's-adjusted, FY Mar-2026). Group adjusted EBITDA grew 6.4% organically in H1 FY27 (company-reported). This feeds Debt / EBITDA.
- Capex: (EBITDA - CAPEX) / interest expense was 2.39x (Moody's-adjusted, FY Mar-2026). Moody's data did not return the capex amount.
- Net debt: total debt EUR 51,278m and net long-term debt EUR 42,280m (Moody's-adjusted, FY Mar-2026). The company's own leverage target was not in the transcript excerpts.
- Free cash flow, liquidity and maturities, and spectrum payments: not in Moody's data. Dividends and buybacks were not in the transcript excerpts.
- M&A: Vodafone took full ownership of VodafoneThree (UK) in July and raised its stake in Safaricom in June (company-reported).

**What management guided on the last call** (Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 Nov 2026)
1. **Guidance raised.** Vodafone upgraded its FY27 group guidance. Management said the midpoint of the new ranges implies roughly 7% organic growth in adjusted EBITDA and roughly 21% in adjusted free cash flow. The excerpts did not include the absolute ranges.
2. **Europe and Germany.** The Europe outlook was reconfirmed after absorbing an EUR 100m EBITDA hit from the ECJ ruling in Germany. Germany's H1 EBITDA trend was -3.2%, of which 2 points came from the related provision. The CEO said "we still have much more to do in Germany". Germany appears in both the upgrade and downgrade triggers.
3. **Costs.** Management expects more than EUR 200m of net cost reduction this fiscal year, as part of over EUR 1bn of net European opex savings. It announced 2,300 further role cuts in Germany.
4. **Capex.** Management said it would not guide to any material reduction in German capital intensity.
5. **OXG fibre JV.** Société Générale has replaced Altice as Vodafone's partner. An analyst on the call put Vodafone's possible equity injections at up to EUR 1.2bn; that figure is the analyst's. Management said any equity would be phased over the build.

**Moody's expectations** (key indicators table, credit opinion of 21 Oct 2026)

| | FY2026 | FY2027F | FY2028F | FY2029F |
|---|---|---|---|---|
| Revenue (EUR bn) | 40.5 | 43.7 | 45.1 | 46.0 |
| Debt / EBITDA | 3.3x | 3.1x | 3.0x | 2.9x |
| RCF / Net Debt | 33.1% | 29.4% | 30.9% | 31.7% |
| (EBITDA - CAPEX) / Interest | 2.4x | 2.6x | 2.8x | 3.0x |
| Net Debt / EBITDA | 2.5x | 2.6x | 2.5x | 2.4x |

Moody's-adjusted ratios and company-reported figures from the call measure different things, so I have not compared them directly. Moody's data has no consensus figures.

Sources: Moody's Credit Opinion PBC_1496608 (21 Oct 2026); getEntityRatings, Senior Unsecured rating history; getEntityFinancials_v2 key indicators, adjusted, FY to 31 Mar 2026; earnings call transcript dated 10 Nov 2026.

Dashboard: the Earnings tab was updated at 13:13 UTC on 15 Nov 2026 under "Vodafone, preview". Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html` (not published as an Artifact in this run).
