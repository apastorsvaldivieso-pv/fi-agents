I couldn't find "Zzyzx Fakecorp Holdings" in Moody's data, so I haven't built an earnings preview.

- A name search in Moody's (no country filter, alternatives requested) returned no entity and no other candidates: "Name search produced no results".
- I haven't swapped in a company with a similar name. Nothing was saved and the dashboard is unchanged.

To try again, send me any of these:
- the issuer's exact legal name, or the name of the group's rated entity;
- its home country;
- a ticker, LEI or Moody's entity ID.

Once I can match it to a Moody's-rated entity, I'll run the preview: its rating and outlook, the latest metrics against Moody's upgrade and downgrade triggers, and what management guided on the last call.
