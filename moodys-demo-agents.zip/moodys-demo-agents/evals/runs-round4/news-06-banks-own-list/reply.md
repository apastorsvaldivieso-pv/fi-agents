**European banks: sector news brief, last 72 hours** (12 Nov 13:18 UTC to 15 Nov 2026 13:18 UTC)

Your names:

| Name | Country |
|---|---|
| Banco Santander, S.A. (Spain) | ES |
| BNP Paribas | FR |
| UniCredit S.p.A. | IT |

All three resolved, none unresolved. For Santander, Moody's first match was Open Bank, S.A. (a subsidiary), so I used the group entity instead.

**Top, last 72 hours**
1. **UniCredit: USD 3.5 billion US bond issue (13 Nov).** UniCredit is back in the US dollar market with a multi-tranche deal. *Why it matters:* it can still raise wholesale dollar funding while it absorbs a large acquisition, which supports liquidity and refinancing flexibility.
2. **UniCredit and Commerzbank: control steps.** Press reports (13-14 Nov) say UniCredit expects unconditional EU merger clearance by 16 Nov. Once the remaining approvals are in and the offer settles, it plans a Commerzbank EGM to elect the supervisory board. *Why it matters:* taking control changes UniCredit's scale, how it uses capital and its integration risk. Moody's has UniCredit's ratings under review.

**Macro**
- UK: reports that the Bank of England may raise rates further in 2027, and that UK price data may strengthen the case. *Higher UK rates would help bank margins but put more pressure on what borrowers can afford.*
- Euro area: government bond yields rose on 13 Nov, and reports flagged a possible upgrade of Italy's sovereign rating. *Italy's sovereign rating and yields feed straight into Italian banks' funding costs, so this matters for UniCredit.*
- ECB: presidential contender Knot warned that the ECB cannot replace sound fiscal policy. *This points to limits on central-bank support for sovereign spreads, which drive bank funding costs.*

**Sector (Moody's)**
- Rating action, not on your list: Moody's upgraded the deposit ratings of VUB (Intesa Sanpaolo's Slovak subsidiary) to A1 from A2 and changed the outlook to stable from positive (12 Nov). *The action ties VUB's standalone assessment to Intesa's under a single-point-of-entry resolution approach.*
- Sector Comment, not on your list: Greek banks. Moody's says the competition commission's proposals are unlikely to weaken the big four banks' deposit franchises, and deposit costs would rise only gradually (13 Nov). *Sticky deposit costs support margins as rates fall.*
- Latest Moody's outlooks: global banks 2026 stable (3 Dec 2025); Spain banking system stable (9 Feb 2026); Italy banking system stable (9 Feb 2026). The search did not return an outlook for the French banking system. None of these outlooks changed in the window.

**By name**

| Name | Moody's rating | Last 72 hours |
|---|---|---|
| Banco Santander, S.A. (Spain) | A1 LT Issuer Rating, stable (affirmed 22 Oct 2026) | No material credit news. |
| BNP Paribas | A1 LT Issuer Rating, stable (affirmed 31 Aug 2026) | No material credit news. |
| UniCredit S.p.A. | A3 Senior Unsecured (foreign currency), ratings under review | USD 3.5bn US bond; Commerzbank control steps (see Top). |

I left out items that are not credit news: BNP Paribas's Q3 results and buyback (announced 28 Oct, before the window), a share sale by its real-estate fund arm, a 13F filing, and share-price and analyst-target stories for all three names. Moody's document search works in whole days, so the VUB action on 12 Nov may fall just before the window starts.

The "Daily sector news" dashboard tab was updated at 13:19 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-06-banks-own-list/dashboard/dashboard.html`. Your three-name list is saved as `banks-europe-own.json`. It sits beside the full banks list and does not replace it.
