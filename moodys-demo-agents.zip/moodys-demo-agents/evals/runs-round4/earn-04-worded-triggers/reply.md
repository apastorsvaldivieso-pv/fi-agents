**BNP Paribas, earnings preview**

I ran this as a preview. You didn't specify preview or recap, and Moody's has no earnings call transcript for BNP Paribas, so there's no recent call to recap.

**Rating and outlook**
A1 LT Issuer Rating, stable outlook. The last action was an affirmation on 31 Aug 2026 (it was downgraded to A1 on 17 Dec 2024). The credit opinion is dated 2 Sep 2026. Moody's ties the stable outlook to "very stable and highly predictable profitability and sound risk profile". It also expects the bank to adapt its liability structure to EU general depositor preference without a material rise in loss severity for senior unsecured debt.

**What to watch against Moody's triggers**
Return on assets is the only trigger with a number:

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Return on assets (net income / tangible assets) | 0.4%, Jun 2026 | 0.6% and above | No number stated | 0.2 pp below the upgrade level |

The other triggers are worded. Quoted from the 2 Sep 2026 opinion:
- *Upgrade:* "if the group manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management on its path to improving its return on assets to levels of 0.6% and above, limiting any sudden and significant increase in problem loans and risk provisioning"
- *Upgrade:* an upgrade of France's rating, "through a recovery of the previous government support uplift".
- *Downgrade:* "if the bank maintained lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics". Also "a marked increase in risk appetite, loss incidents or a material risk management failure".
- *Downgrade:* "a material deterioration in operating conditions in the bank's main markets, beyond our current expectations, accompanied by a significant weakening of its funding and liquidity profile".
- *Downgrade (senior unsecured only):* if the build-up of senior unsecured and lower-ranking debt against tangible banking assets "falls short of our current expectations" and the weaker loss-given-failure result can't be offset by recovering a one-notch government support uplift (for example, if France is downgraded).

**Sector metrics to watch**

| Metric | Latest | Basis | Trigger it bears on |
|---|---|---|---|
| Net interest margin | 0.9%, Jun 2026 | Moody's-adjusted | Profitability (ROA upgrade level, downgrade wording) |
| Cost of risk | not in Moody's data | | Asset quality, provisioning |
| CET1 ratio | 12.97%, Q2 2026 | Reported | "lower regulatory capital buffers" |
| Planned distributions | not in Moody's data | | Capital buffers |
| Leverage ratio (fully loaded) | not in Moody's data | | "sustained higher regulatory leverage" / lower financial leverage |
| TCE / RWA | 13.7%, Jun 2026 | Moody's-adjusted | Capital buffers |
| Problem loans / gross loans | 2.9%, Jun 2026 | Moody's-adjusted | Problem loans, asset quality |
| Impaired loans / gross customer loans | 2.93%, Q2 2026 | Reported | Asset quality |
| Reserves / impaired loans | 57.68%, Q2 2026 | Reported | Provisioning |
| Cost / income | 60.6%, Jun 2026 | Moody's-adjusted | Profitability |
| LCR | 134.77%, Q2 2026 | Reported | Funding and liquidity |
| NSFR | 108.63%, Q2 2026 | Reported | Funding and liquidity |
| HQLA / tangible banking assets | 15.9%, Jun 2026 | Moody's-adjusted | Funding and liquidity |
| Gross loans / due to customers | 85.8%, Jun 2026 | Moody's-adjusted | Deposits, funding |
| Gross loans / customer deposits | 82.30%, Q2 2026 | Reported | Deposits, funding |

**What management guided on the last call**
I can't report guidance from the last call because Moody's holds no earnings call transcript for BNP Paribas.

**Moody's expectations**
There are no forecasts to show. The key indicators table in the credit opinion has actuals only, from Dec 2022 to Jun 2026.

Notes: The upgrade trigger says "return on assets". I've read that as Moody's net income / tangible assets, the closest key indicator. Moody's data didn't return the fully loaded leverage ratio for BNP Paribas, and there are no consensus figures or results date in Moody's data.

Sources: Moody's credit opinion PBC_1491623 (2 Sep 2026); LT Issuer Rating history RTNG_91000; Bank Focus financials, Q2 2026; Moody's transcript search (not found).

The Earnings tab is updated ("BNP Paribas, preview", 15 Nov 2026 13:13 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html`. This was a test run, so the dashboard wasn't published as an Artifact.
