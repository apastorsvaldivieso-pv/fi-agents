**European telecoms: the last 7 days** (8 Nov 13:07 UTC to 15 Nov 13:07 UTC, 15 names)

Two Nordic operators bought assets this week. Moody's took no rating action on any name on the list.

**Top this week**
1. **Telia (Baa1 Senior Unsecured, stable)** signed a binding deal on 12 Nov to buy Telavox's Nordic enterprise customer base for SEK 3.8bn, plus up to SEK 0.2bn earn-out. The base brings about SEK 1.1bn of annual revenue. Separately, Latvia says its buyout of Telia's LMT and Tet stakes will happen by 17 Nov. *Why it matters:* the purchase uses cash and the Baltic sale brings cash in. Telia has not said how it will fund the deal, so the net effect on leverage is not yet known.
2. **Telenor (Baa1 Senior Unsecured, positive)** bought 57.5% of Swedish broadband provider Bahnhof on 11 Nov, valued at about USD 363m, and now has about 66.9% of the shares through its mandatory cash offer at SEK 62 per share. *Why it matters:* the outlook is positive, so spending on acquisitions bears directly on Telenor's leverage headroom.
3. **Telefonica (Baa3, stable) and Vodafone (Baa2, stable) raised their cash flow guidance.** Telefonica (Q3, 12 Nov) raised its guidance for adjusted EBITDA, operating cash flow after leases and FCF. Q3 revenue was EUR 8.43bn and net income EUR 802m. Vodafone raised its full-year profit and cash flow guidance with its half-year results. *Why it matters:* more cash flow supports debt reduction, especially at Telefonica's Baa3 level.

**Macro**
- Moody's 2027 global credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs outweigh the boost from AI investment. This bears most on lower-rated, highly leveraged telecom issuers.
- French October inflation rose on energy, keeping bets on an ECB rate hike alive. Euro-area yields rose on 13 Nov, which pushes up refinancing costs.

**Sector**
- No Moody's rating actions on European telecoms in the window.
- Latest Moody's global telecoms outlook (27 Oct 2026): **stable**. Solid demand and falling capital intensity offset the risks, including refinancing pressure.

**By name**

| Name | Rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom | A3 (Sr Unsec), stable | No material credit news. |
| Orange | Baa1 (LT Issuer), stable | No material credit news. |
| Vodafone | Baa2 (Sr Unsec), stable | Raised full-year profit and cash flow guidance. |
| Telefonica | Baa3 (Sr Unsec), stable | Raised guidance for EBITDA, operating cash flow after leases and FCF with Q3. |
| Swisscom | A2 (LT Issuer), stable | No material credit news. |
| Telekom Austria | A3 (LT Issuer), stable | No material credit news. |
| Proximus | A3 (Sr Unsec), stable | No material credit news. |
| Telenor | Baa1 (Sr Unsec), positive | Took control of Bahnhof; mandatory offer for the remaining shares under way. |
| Telia | Baa1 (Sr Unsec), stable | Telavox base for SEK 3.8bn plus earn-out; LMT and Tet buyout due by 17 Nov. |
| TIM | Baa3 (LT Issuer), positive | 9M (11 Nov): kept its 2026 targets; 9M net loss EUR 205m. Owner Poste Italiane set up a EUR 600m data-centre fund that includes TIM's sites. |
| PPF Telecom | Baa2 (LT Issuer), stable | No material credit news. |
| BT Group (rated at British Telecommunications Ltd) | Baa2 (LT Issuer), stable | No material credit news. |
| Iliad | Ba1 (Sr Unsec), stable | No material credit news. |
| VMED O2 UK | B1 (CFR), on review for downgrade | Nothing new; the review opened on 22 Oct is still open. |
| Altice France | Caa1 (Sr Sec Bank Credit Facility), positive | No material credit news. |

**Before the window:** Deutsche Telekom's Q3 results and guidance raise, and BT's half-year results and pension valuation, both came out on 5 Nov, just before the window opened. Proximus reported Q3 on 30 Oct. I left them out of the brief because they are not this week's news. I can do a short catch-up on them if you'd like.

The dashboard's "Daily sector news" tab was updated at 13:09 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html`. This was a test run, so it was not published as a link.
