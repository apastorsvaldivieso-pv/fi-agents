**Regulatory watch: European banks, 30 days to 15 Nov 2026 (16 Oct to 15 Nov)**

Six items in the window. Only one touches a metric Moody's tracks: the Basel Committee's G-SIB package, which maps to CET1. The other five are on watch because Moody's data has no metric for them. This is the first run, so every item is marked NEW.

**What changed** (regulators' own pages)
1. **Basel Committee, 16 Oct (final rule plus consultation).** Final rule: G-SIB indicators will be reported as averages over the year instead of year-end values, which stops banks window-dressing their scores. It applies by 1 Jan 2030. Separately, the reporting threshold rises from EUR 200bn to EUR 350bn from 2027. The consultation asks whether to bring Banking Union cross-border exposures into the G-SIB methodology; comments are due by 14 Jan 2027. Channel: the G-SIB buffer, so CET1.
2. **EBA internal governance guidelines, 5 Nov (final).** Aligns the guidelines with CRD VI and DORA. Moody's (Sector Comment, 11 Nov) calls this credit positive for EU banks, more so for small banks. Watch.
3. **EBA 2027 EU-wide stress test methodology, 9 Nov (final methodology).** The data request is 55% smaller and a climate module is added. The test launches in Jan 2027 and results come out in Jul 2027. Watch; I mapped this one by judgment because the channel map has no row for stress tests.
4. **EBA supervisory reporting simplification, 6 Nov (update; the final ITS is due in Dec 2026).** New reporting requirements start from Dec 2027, and liquidity and ESG reporting move to Dec 2028. Watch.
5. **PRA PS20/26 large exposures, 10 Nov (final, effective 1 Jan 2028).** The substitution approach becomes mandatory, internal models are no longer allowed for securities financing transactions, and the trading-book allowance falls to 85% of Tier 1. Watch. It covers the UK names on the list.
6. **PRA CP14/26 SM&CR phase 2, 22 Oct (consultation, comments due 22 Jan 2027).** Watch.

**Who it hits: G-SIB buffer channel, CET1 (as reported, Q2 2026; list median 13.60%)**
- Exposed: Credit Agricole S.A. 11.30%, CaixaBank 12.33%, BBVA 12.90%, BNP Paribas 12.97%, Intesa Sanpaolo 13.00%
- Neutral: ING 13.07%, Societe Generale 13.20%, Lloyds 13.60%, Deutsche Bank 13.92%, HSBC 14.10%
- Resilient: UniCredit 14.26%, Barclays 14.30%, UBS 14.38%, Commerzbank 14.38%, Nordea 15.70%

Calls show where each bank sits within this list on CET1. They are not an estimate of impact. The rule applies only to G-SIBs, and Moody's data doesn't show which of these 15 are G-SIBs, so the whole list is ranked. CET1 requirements are set bank by bank and no Moody's document here states them, so there is no distance to minimum.

**Gaps:** I couldn't read the ECB press-release listing. Its home page and search showed no press release in the window. I found no FINMA publications listing, and no FINMA rule turned up. Items left out because they don't bear on bank credit: EBA advice on Taxonomy disclosures, and PRA papers on credit unions.

Dashboard: the Regulatory watch tab was updated at 13:13 UTC on 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`. This was a test run, so nothing was published as an Artifact.
