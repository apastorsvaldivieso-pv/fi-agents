**Regulatory watch: European banks, 8 to 15 Nov 2026 (MREL asked)**

**Short answer: I can't name banks that would be exposed to a tighter MREL from Moody's data.** Moody's bank financials have no MREL or TLAC field. Each bank's requirement is also set individually by its resolution authority (SRB, Bank of England or FINMA). Ranking the 15 names on CET1 or leverage instead would be a stand-in, not an MREL call, so all 15 stay on **watch** for this channel.

**What changed on MREL this week: nothing.** None of the primary regulators published an MREL rule, consultation or decision between 8 and 15 Nov. The only related items were the SRB Chair's speech at the 10th MREL Workshop on 10 Nov ([SRB](https://www.srb.europa.eu/en/content/keynote-speech-srb-chair-dominique-laboureix-10th-mrel-workshop-mrel-ten-workshops-later)) and the Commission's first banking-competitiveness dialogue on 11 Nov ([Commission](https://finance.ec.europa.eu/news/summary-first-dialogue-competitiveness-eu-banking-sector-2026-11-11_en)). That dialogue summary doesn't mention MREL.

**Moody's view:** current policy points to simpler MREL rules, not tighter ones.
- The Commission's July 2026 plans would make MREL more predictable and bring it closer to the international TLAC standard. Moody's called the package moderately credit positive overall. *(Moody's Sector In-Depth "EU bank reforms support capital mobility, but could ease some requirements", 27 Jul 2026, PBC_1489046)*
- Moody's also said that aligning MREL with TLAC would be credit negative if it reduced the amount of bail-inable debt in the EU banking system. *(Moody's Sector In-Depth "European regulators put more resolve into bank resolution", 14 Sep 2026, PBC_1491385)*

**Other changes this week (all on watch, because Moody's has no metric for them):**

| Item | Status | Date | Channel |
|---|---|---|---|
| [Basel Committee: IRRBB, additional Pillar 2 guidance](https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance) | Consultation, comments due 9 Feb 2027 | 9 Nov | Interest rate risk in the banking book |
| [EBA: 2027 EU-wide stress test methodology](https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data) | Final methodology, draft templates; launch end Jan 2027 | 9 Nov | No row in the channel map (my mapping) |
| [PRA PS20/26: large exposures, part 2](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement) | Final, effective 1 Jan 2028 | 10 Nov | Large exposures (UK firms) |
| [FINMA: revised AML ordinance](https://www.finma.ch/de/news/2026/11/20261110-mm-gwv-finma/) | Final, effective 1 Jan 2027 | 10 Nov | AML (Swiss institutions) |

None of these items maps to a metric in Moody's data, so I didn't pull bank financials and made no exposed, neutral or resilient call on any name.

**Gaps in what I checked:** I couldn't read the ECB Banking Supervision press-release listing. Search found no ECB supervisory release in the window. For the Commission and FINMA I checked search results and the item pages, not their full listings.

**If you want an MREL exposure ranking,** it would need each bank's MREL or TLAC ratio and its requirement. Those come from the banks' Pillar 3 disclosures, not from Moody's data. I can rank the list on CET1 or leverage instead, but that answers a capital question, not an MREL one.

The Regulatory watch tab was updated at 13:20 UTC on 15 Nov 2026:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html`
(Artifact publish skipped for this test run.)
