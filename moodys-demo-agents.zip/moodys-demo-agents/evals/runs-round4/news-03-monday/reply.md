**European telecoms: sector news brief**
Window: the Monday catch-up, 72h to 15 Nov 2026 13:18 UTC. You asked for Monday 16 Nov, but my clock still shows Sunday 15 Nov, so I searched up to now. Anything published between now and Monday morning is not covered.

**Top this weekend**
1. **Telefonica (Baa3 Senior Unsecured, stable)**: Telefonica reported Q3 results on Thu 12 Nov and raised its full-year guidance for adjusted EBITDA, operating cash flow after leases and free cash flow, led by Spain and Brazil. Nine-month net profit was EUR 464m, against a EUR 1.08bn loss a year earlier. Revenue rose 2.8% (company-reported figures). *Why it matters:* higher guided free cash flow supports deleveraging. Moody's has not yet updated its adjusted leverage for this. The release came on the window's first day, and the sources don't give a time, so it may fall a few hours before the window starts.
2. **Telia (Baa1 Senior Unsecured, stable)**: On 13 Nov LMT said Latvia's buyout of Telia's stakes in LMT and Tet is on track for the 17 Nov deadline. The price isn't given. *Why it matters:* when the sale closes, Telia gets cash, which bears on net debt and RCF / net debt. The size is unknown.

**Macro**
- Headlines on 15 Nov expect the Bank of England to raise rates further in 2027. *Why it matters:* refinancing costs rise for sterling issuers, most of all the leveraged ones (VMED O2 UK).
- Euro area government bond yields rose on 13 Nov. *Why it matters:* new euro issuance gets more expensive.

**Sector**
- Moody's published no rating actions and no sector or issuer research on European telecoms in the window.
- Moody's latest sector outlook is Telecommunications – Global, stable (27 Oct 2026). Solid demand, lower capital intensity and modest EBITDA growth support cash flow and leverage, against refinancing pressure and structural risks.

**By name**
| Name | Moody's rating | In the window |
|---|---|---|
| Deutsche Telekom | A3 Sr Unsec, stable | No material credit news. Weekend articles only recap the 5 Nov Q3 results. |
| Orange | Baa1 LT Issuer, stable | No material credit news. |
| Vodafone | Baa2 Sr Unsec, stable | No material credit news. |
| Telefonica | Baa3 Sr Unsec, stable | Q3 results: FY guidance raised (see Top). |
| Swisscom | A2 LT Issuer, stable | No material credit news. |
| Telekom Austria | A3 LT Issuer, stable | No material credit news. |
| Proximus | A3 Sr Unsec, stable | No material credit news. |
| Telenor | Baa1 Sr Unsec, positive | Bahnhof's independent committee recommended Telenor's mandatory cash offer. Telenor holds about 66.9% of the shares and 90.6% of the votes. A small bolt-on, launched 6 Nov. |
| Telia | Baa1 Sr Unsec, stable | LMT and Tet stake buyout on track for 17 Nov (see Top). |
| TIM | Baa3 LT Issuer, positive | No material credit news. |
| PPF Telecom | Baa2 LT Issuer, stable | No material credit news. |
| BT Group (rated at British Telecommunications Ltd) | Baa2 LT Issuer, stable | No material credit news. The pension valuation and H1 results date from 5 Nov. |
| Iliad | Ba1 Sr Unsec, stable | No material credit news. |
| VMED O2 UK | B1 CFR, on review for downgrade since 22 Oct | No material credit news. |
| Altice France | Caa1 Sr Sec Bank Credit Facility, positive | No material credit news. |

I left out share-price items, broker targets, a passive 13G stake filing, tenders and small contracts, and subsidiary-only stories (Vodacom, Sparkle, Orange Jordan).

**Dashboard:** I updated the "Daily sector news" tab at 15 Nov 2026 13:20 UTC: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html`. This is a test run, so it was not published to the Artifact link.
