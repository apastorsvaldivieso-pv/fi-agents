**Regulatory watch: European banks, PRA only, 14 to 15 Nov 2026: quiet.**

The PRA published no rule, guideline, consultation, policy statement or supervisory decision in the window. Both days fell on a weekend.

Sources checked: the [PRA publications feed](https://www.bankofengland.co.uk/rss/prudential-regulation-publications) and the [Bank of England news feed](https://www.bankofengland.co.uk/rss/news). The latest PRA item is PS20/26, Large Exposures Framework Part 2, dated 10 Nov 2026. That falls outside this window, so it is not reported as new. Run a 7-day window if you want it included.

I updated the Regulatory watch tab at 13:19 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-05-quiet/dashboard/dashboard.html`. I didn't publish it to the shared link because this is a test run.
