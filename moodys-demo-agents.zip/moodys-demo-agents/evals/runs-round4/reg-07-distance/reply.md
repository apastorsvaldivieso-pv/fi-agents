**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

**Headline:** Nothing in the last 30 days changed liquidity rules. On Moody's Q2 2026 data, all 15 banks are above the 100% LCR minimum. HSBC (134.0%, +34.0 pp) and BNP Paribas (134.8%, +34.8 pp) are closest to it.

**What changed** (regulator pages, web; all NEW because this is the first run)

| Date | Body | Item | Status | Channel |
|---|---|---|---|---|
| (Asked) | | Liquidity (LCR): no regulatory change found in the window | n/a | Liquidity |
| 16 Oct | Basel Committee | G-SIB anti-window-dressing (year-average indicators, by 1 Jan 2030; reporting threshold EUR 200bn to 350bn from 2027) + G-SIB methodology review | Final + consultation (comments by 14 Jan 2027) | Capital buffers (CET1) |
| 22 Oct | European Commission | Political agreement on the Securitisation Framework review, incl. CRR prudential treatment | Political agreement, not yet adopted | Securitisation: watch |
| 22 Oct | PRA | CP14/26, SM&CR Phase 2 | Consultation (closes 22 Jan 2027; item page not opened) | Governance: watch |
| 4 Nov | FINMA | Circular 2019/2, interest rate risk in the banking book (Basel 2024 shock recalibration) | Consultation (comments by 15 Jan 2027) | IRRBB: watch |
| 5 Nov | EBA | Revised Guidelines on internal governance (CRD VI) | Final | Governance: watch. Moody's (11 Nov): credit positive for small EU banks, little new for large ones |
| 10 Nov | PRA | PS20/26, Large Exposures Part 2 | Final, effective 1 Jan 2028 | Large exposures: watch |
| 10 Nov | FINMA | Partially revised AML Ordinance | Final, in force 1 Jan 2027 | AML: watch |

**Who it hits: Liquidity (LCR), Q2 2026** (minimum 100%, Basel III; local rules can be higher). List median: 141.3%

| Bank | LCR | vs median | Distance to minimum | Call |
|---|---|---|---|---|
| HSBC | 134.0% | -7.3 pp | +34.0 pp | exposed |
| BNP Paribas | 134.8% | -6.5 pp | +34.8 pp | exposed |
| ING | 137.0% | -4.3 pp | +37.0 pp | exposed |
| Intesa Sanpaolo | 137.6% | -3.7 pp | +37.6 pp | exposed |
| UniCredit | 140.0% | -1.3 pp | +40.0 pp | exposed |
| Deutsche Bank | 140.1% | -1.2 pp | +40.1 pp | neutral |
| Commerzbank | 141.0% | -0.3 pp | +41.0 pp | neutral |
| Credit Agricole | 141.3% | 0.0 pp | +41.3 pp | neutral |
| BBVA | 142.0% | +0.7 pp | +42.0 pp | neutral |
| Lloyds | 144.0% | +2.7 pp | +44.0 pp | neutral |
| Societe Generale | 146.4% | +5.1 pp | +46.4 pp | resilient |
| Nordea | 156.0% | +14.7 pp | +56.0 pp | resilient |
| Barclays | 157.7% | +16.4 pp | +57.7 pp | resilient |
| UBS | 177.3% | +36.0 pp | +77.3 pp | resilient |
| CaixaBank | 193.0% | +51.7 pp | +93.0 pp | resilient |

Moody's Q3 2026 update on the European global investment and universal banks (30 Oct) shows a median LCR of 144% for that group, ranging from 132% at HSBC to 179% at UBS. Those are Q3 numbers and the table above uses Q2, so the two do not match exactly.

**Who it hits: Capital buffers (CET1), Q2 2026.** This table comes from the Basel G-SIB item. List median: 13.6%. CET1 requirements differ by bank and no source I used states them, so the table has no distance-to-minimum column. The G-SIB rule applies only to G-SIBs. Moody's data doesn't say which banks on the list are G-SIBs, so the ranking covers all 15.
- Exposed: Credit Agricole 11.30%, CaixaBank 12.33%, BBVA 12.90%, BNP Paribas 12.97%, Intesa Sanpaolo 13.00%
- Neutral: ING 13.07%, Societe Generale 13.20%, Lloyds 13.60%, Deutsche Bank 13.92%, HSBC 14.10%
- Resilient: UniCredit 14.26%, Barclays 14.30%, UBS 14.38%, Commerzbank 14.38%, Nordea 15.70%

**No Moody's metric (watch):** the securitisation review, PRA SM&CR, FINMA IRRBB, EBA governance, PRA large exposures and FINMA AML items. Moody's bank data has no field for any of these.

*The calls show where each bank sits within this list on that metric. They don't estimate the impact of any rule. LCR and CET1 are company-reported ratios as held in Moody's bank data, not Moody's-adjusted figures.*

Notes: The ECB published no supervisory press release in the window; its listing could not be read, and the last release in search results was dated 15 Oct. The SRB put out speeches and blogs only. I left out items with no credit bearing: EBA stress-test data streamlining, EBA reporting timeline, EBA taxonomy advice, and the PRA credit-union papers.

The Regulatory watch tab on the dashboard was updated at 13:21 UTC, 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html`. This was a test run, so nothing was published to the Artifact link.
