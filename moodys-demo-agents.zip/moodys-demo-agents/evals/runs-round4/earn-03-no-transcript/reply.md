**Iliad Holding S.A.S., earnings recap**

I can't give you a full recap. Moody's has no earnings call transcript for Iliad Holding S.A.S., and it hasn't published any comment on the results between 1 Oct and 15 Nov 2026 (no Issuer Comment, Rating Action or Credit Opinion). That means I can't say how results compared with guidance, whether guidance changed, or what the company reported on leverage, liquidity, capex and refinancing. Below is where the issuer stands against Moody's view as of the latest data.

**Rating:** Ba2 (LT Corporate Family Rating), stable outlook. Upgraded from Ba3 on 19 Jun 2026. Credit opinion dated 30 Jun 2026.

**Against Moody's triggers (Moody's-adjusted)**

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 4.20x (LTM 30 Jun 2026); 4.18x (FY2025) | below 3.5x | "remains well above 4.0x" (and FCF weakens significantly) | 0.70x above the upgrade level; 0.20x above 4.0x, but the wording does not put a number on "well above" |
| RCF / Net Debt | 13.99% (LTM 30 Jun 2026) | towards 25% | no number stated | 11.0 pp below the upgrade level |

**Moody's forecasts (credit opinion, 30 Jun 2026)**
- Debt/EBITDA: 4.3x (2026F), 4.0x (2027F), 3.7x (2028F)
- RCF/net debt: 14.5% (2026F), 15.3% (2027F), 16.8% (2028F)
- FCF/debt: 2.1% (2026F), 2.6% (2027F), 3.7% (2028F)

**What it means:** The stable outlook rests on Moody's expecting steady earnings and cash flow growth ahead of the SFR acquisition, then lower leverage once the deal completes. The opinion and the latest adjusted financials (LTM June 2026) both predate any results published since. Leverage is between the two trigger levels and close to Moody's 2026 forecast.

Note: Iliad S.A. (Ba1) is rated separately from Iliad Holding. I used Iliad Holding, as you asked.

The Earnings tab ("Iliad Holding, recap") was updated at 13:18 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html`

Would you like an earnings **preview** for Iliad Holding's next results instead?

*Sources: Moody's credit opinion PBC_1488484 (30 Jun 2026); Moody's rating history, LT CFR; Moody's-adjusted key indicators, LTM 30 Jun 2026; Moody's transcript search (none found); Moody's document search, 1 Oct to 15 Nov 2026 (none found).*
