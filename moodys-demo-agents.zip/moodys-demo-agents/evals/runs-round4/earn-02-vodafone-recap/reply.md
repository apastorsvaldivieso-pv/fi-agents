**Vodafone Group Plc: earnings recap, H1 FY27 (call of 10 Nov 2026)**

Vodafone raised its FY27 group guidance at H1. Moody's-adjusted debt/EBITDA of 3.25x (FY to March 2026) is 0.05x below the 3.3x downgrade trigger. The Baa2 stable affirmation (13 Oct) and the credit opinion (21 Oct) were both published before these results.

**Results against the credit view**
- **Guidance (company-reported):** FY27 group guidance was raised. Management said the midpoint of the new ranges implies organic growth of 7% in adjusted EBITDA and 21% in adjusted free cash flow. A JPMorgan analyst said the upper end of the old ranges is now the midpoint, and management confirmed it had already guided to the upper end in July. Europe guidance was left unchanged. The excerpts did not give the old and new ranges in absolute terms.
- **H1 results (company-reported):**
  - Group service revenue grew 6.4% in Q2, and adjusted EBITDA grew 6.4% in H1.
  - Vodafone Business grew 6.6%. Africa and Türkiye grew at double digits organically.
  - Germany EBITDA fell 3.2% in H1. About 2 percentage points of that came from a provision linked to the European Court of Justice (ECJ) ruling, which hit EBITDA by about EUR 100 million.
  - Vodafone booked a non-cash impairment on Germany. About three-quarters of it came from a higher discount rate (8%, up from 7.5%).
- **Against Moody's forecast:** Moody's forecasts FY2027 revenue of EUR 43.7bn and debt/EBITDA of 3.1x. The company guides in organic growth rates, not on these measures, so the excerpts don't support a beat-or-miss call against Moody's forecast.
- **Leverage:** The transcript excerpts did not include H1 net debt or the company's own leverage ratio. The latest Moody's-adjusted figures (FY to March 2026) are debt/EBITDA 3.25x and RCF/net debt 33.08%.
- **Liquidity (Moody's, 13 Oct 2026):** Moody's calls liquidity excellent:
  - cash of about EUR 4.1bn pro forma for the UK buyout, of which about EUR 1.6bn is restricted
  - EUR 3.4bn of short-term investments
  - EUR 7.5bn of undrawn committed facilities, maturing in 2028 and 2031, with no financial covenants
- **Capex and funding:**
  - **German capex (company-reported):** no material cut to German capital intensity is planned.
  - **OXG fibre JV:** a UBS analyst said Vodafone may have to fund equity injections of up to EUR 1.2bn now that Société Générale has replaced Altice. Management said contributions will be phased over the build.
  - **Safaricom:** a Morgan Stanley analyst said Kenya's High Court declared the sale of the 15% stake void in September. Management's answer was cut off in the excerpts.
  - **Costs:** management expects more than EUR 200m of net opex reduction this fiscal year. An analyst cited about EUR 700m of restructuring costs, which management said were already in the May guidance.
- **Refinancing, maturities, dividends and buybacks:** not in the transcript excerpts.

**Against Moody's triggers** (Moody's-adjusted, FY to 31 Mar 2026)

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room to upgrade | Room to downgrade |
|---|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to remain below 3.3x | 0.75x above the upgrade level | 0.05x |
| RCF / Net Debt | 33.08% | above 25%, sustained | declines towards 18%, sustained | already met, by 8.08 pp | 15.08 pp |

Worded triggers in the credit opinion:
- **Upgrade:** "underlying revenue and operating performance improve sustainably, particularly in Germany".
- **Downgrade:** "a failure to turn around its German operations".
- **Stable outlook assumes:** "at least stabilising trends in Germany", debt/EBITDA below 3.3x, RCF/net debt of around 30%, net leverage in the lower half of the company's target range, and excellent liquidity.

**What it means for the rating and outlook**
- **Rating:** Baa2 Senior Unsecured (foreign currency), stable outlook, affirmed 13 Oct 2026. The credit opinion of 21 Oct 2026 also predates these results.
- **Against the triggers:** On FY March 2026 Moody's-adjusted data, debt/EBITDA is 0.05x below the 3.3x downgrade level and RCF/net debt is 15.08 pp above 18%. Moody's forecasts 3.1x for FY2027.
- **Germany:** It appears in both the worded downgrade trigger and the outlook, and it was still negative at EBITDA level in H1 (company-reported).
- **Moody's comment:** Moody's has not published a comment on these results between 1 Oct and 15 Nov 2026.

Sources:
- Moody's credit opinion PBC_1496608 (21 Oct 2026)
- Rating action PR_528027 (13 Oct 2026)
- Moody's-adjusted key indicators, FY to March 2026
- Half Year 2027 Vodafone Group Earnings Call (10 Nov 2026)

The Earnings tab is updated ("Vodafone, recap", 15 Nov 2026 13:18 UTC): `evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html`. Publishing was skipped for this test run.
