**Daily sector news: European telecoms, Monday brief** (72h to 15 Nov 2026 23:37 UTC (from 12 Nov 23:37 UTC); 15 names)

Telenor Sverige holds about 66.9% of Bahnhof's shares and 90.6% of the votes, and Bahnhof's independent committee now backs its mandatory cash offer; Moody's published no rating action or research on European telecoms in the window. [1]

**Top this weekend**

- **Telenor ASA** (Deal): On 13 Nov Telenor Sverige said it holds about 66.9% of Bahnhof's shares and 90.6% of the votes; Bahnhof's independent committee backs the unconditional mandatory offer of SEK 62 a share in cash (made 6 Nov). No total cost or funding is given. *Why it matters:* Moody's positive outlook includes no M&A beyond the GlobalConnect deal; a more aggressive financial policy in M&A is a stated downgrade factor. [1][2][3]
- **Telia Company AB** (Deal): LMT and Tet must give Latvia's government an outline for buying Telia's 49% stakes in each by 17 Nov, LETA reported on 13 Nov. LMT's vice-president said Telia reaffirmed interest in selling and put the financing at about EUR 0.5bn; no deal is agreed. *Why it matters:* Moody's stable outlook assumes adjusted gross debt/EBITDA below 3.0x and RCF/net debt above 22%; use of proceeds is not stated. [4][5]

**Macro**

- UK: headlines on 15 Nov say the Bank of England faces pressure to raise rates again ahead of UK inflation data. [6]
- Euro area government bond yields rose on 13 Nov. [7]

**Sector**

- The search returned no Moody's rating action and no Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Issuer Profile or Credit Opinion on European telecoms dated 12 to 15 Nov. [8]
- Latest Moody's sector outlook: Telecommunications - Global, stable, published 27 Oct 2026; stronger EBITDA and lower investment support cash flow and leverage. [9]

**By name**

| Name | Moody's rating and outlook | Last 72h |
|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured (Fgn Curr), stable [10] | No material credit news. |
| Orange | Baa1 LT Issuer Rating, stable [10] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr), stable [10] | Interim dividend EUR 0.02306 a share, ex-dividend 19 Nov, paid 3 Feb (Simply Wall St); raised outlook retold by Kalkine. Results date not in the sources returned. [11][12] |
| Telefonica S.A. | Baa3 Senior Unsecured (Dom Curr), stable [10] | No material credit news. |
| Swisscom AG | A2 LT Issuer Rating (Dom Curr), stable [10] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating, stable [10] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (Dom Curr), stable [10] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured (Fgn Curr), positive [10] | Bahnhof offer: see top items. |
| Telia Company AB | Baa1 Senior Unsecured (Fgn Curr), stable [10] | LMT and Tet stakes: see top items. |
| TIM S.p.A. | Baa3 LT Issuer Rating (Dom Curr), positive [10] | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (Dom Curr), stable [10] | No news returned. |
| BT Group Plc | Baa2 LT Issuer Rating (at British Telecommunications Limited), stable [10] | No material credit news. |
| Iliad S.A. | Ba1 Senior Unsecured (Dom Curr), stable [10] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 Corporate Family Rating (Fgn Curr), on review for downgrade [10][13] | No news returned. CFR, PDR and instrument ratings on review for downgrade since 22 Oct. [13] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (Fgn Curr), positive [10] | No news returned. |

Note: Ratings are Moody's ratings as returned, with the class shown; none changed in the window.

**Notes**

- You gave Monday 16 Nov; the clock read 15 Nov 23:37 UTC, so the 72h window runs to that time.
- Telia's agreement to buy Telavox's Nordic business customers (12 Nov) and Telefonica's third-quarter results (12 Nov) came just before the window, so they are not reported as new.
- Articles in the window about Deutsche Telekom and BT retell earlier results and buyback figures; left out as old news.

**Sources**

[1] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · 2026-11-13
[2] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document (Cision) · 2026-11-13
[3] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480, outlook and rating factors · 2026-02-24
[4] Moody's (searchNews) · Buyout of Telia's shares in LMT and Tet to be implemented by 17 November … · 2026-11-13
[5] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649, outlook and rating factors · 2026-03-02
[6] Moody's (searchNews) · BOE likely to raise rates further in 2027 (Forex Factory) · 2026-11-15
[7] Moody's (searchNews) · Eurozone bond yields rise (MSN) · 2026-11-13
[8] Moody's (searchAllDocuments) · Moody's documents search · Rating Action and research types, Telecommunications, Europe, 12-15 Nov 2026: no … · 2026-11-15
[9] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 (Outlook) · 2026-10-27
[10] Moody's ratings (getEntityRatings) · Moody's ratings pull, Moody's ratings pull · 2026-11-15
[11] Moody's (searchNews) · Vodafone Group next dividend (Simply Wall St) · 2026-11-14
[12] Moody's (searchNews) · FTSE 100 Vodafone lifts its outlook for the year (Kalkine Media) · 2026-11-15
[13] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559 (Rating Action) · 2026-10-22

Dashboard: the "Daily sector news" tab was updated at 15 Nov 2026 23:40 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html (not published to the private link in this run).
