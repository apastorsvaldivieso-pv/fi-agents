**Daily sector news: Proximus, Telekom Austria, Swisscom** (24h to 15 Nov 2026 23:37 UTC (from 14 Nov 2026 23:37 UTC); 3 names)

Nothing material for Telecoms, Europe, in the last 24h.

Dashboard: the Daily sector news tab was updated at 15 Nov 2026 23:38 UTC — /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-04-quiet/dashboard/dashboard.html
