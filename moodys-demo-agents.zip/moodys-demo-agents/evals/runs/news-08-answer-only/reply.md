# Weekly sector news: European telecoms

**Window:** 8 Nov 2026 00:00 UTC to 15 Nov 2026 23:40 UTC (about 192h, covering the 7 days asked for; Moody's document searches filter by whole calendar days). 15 names.

**Headline:** Vodafone reported a first-half pre-tax loss of EUR 373m after a EUR 4.85bn German goodwill impairment, and company-reported net debt rose to EUR 33.5bn from EUR 25.4bn [2].

## Top this week

1. **Vodafone: first-half loss, more debt, guidance raised.** H1 FY27 (to 30 Sep 2026, filed 10 Nov) showed a loss before tax of EUR 373m against a EUR 2,113m profit a year earlier. That loss includes a EUR 4.85bn Germany goodwill impairment and UK and German deferred-tax write-downs. Company-reported net debt reached EUR 33.5bn (31 Mar 2026: EUR 25.4bn), driven by the VodafoneThree buyout and the extra Safaricom stake [2]. FY27 guidance was raised: the new midpoint implies organic adjusted EBITDA growth of 7% and adjusted FCF growth of 21%. Germany took a EUR 100m hit to EBITDA from an ECJ-related provision [3].
   *Why it matters:* Moody's stable outlook assumes at least stabilising trends in Germany and Moody's-adjusted debt/EBITDA below 3.3x. Failing to turn Germany around is a stated downgrade trigger [4].

2. **Telefonica: back to profit, guidance up, debt down.** In Q3 results of 12 Nov, the nine-month net profit was EUR 464m (9M 2025: EUR 1.08bn loss), and discontinued operations lost EUR 870m. Company-reported net debt fell EUR 1.6bn to EUR 25.2bn, or 2.63x EBITDAaL. Guidance was raised for adjusted EBITDA (slightly above 2.5%) and FCF (about EUR 3.1bn), while the revenue target was cut to 1–1.5% [5].
   *Why it matters:* Moody's would consider an upgrade at Moody's-adjusted net debt/EBITDA below 3.0x and RCF/net debt above 20%. The company's 2.63x is a different measure from Moody's-adjusted leverage [6].

3. **TIM: wider loss, higher debt, targets kept.** Nine-month results, reported on 12 Nov, showed a net loss of EUR 205m (9M 2025: EUR 109m loss). Non-recurring costs were EUR 314m and EBITDA fell 1.5% to EUR 3.05bn. Adjusted net debt after leases was EUR 7.21bn (Dec 2025: EUR 6.85bn), FCF after leases was EUR 818m, and the 2026 targets were kept. Sparkle is now classified as discontinued [7].
   *Why it matters:* The positive outlook rests on expected earnings growth and positive FCF. An upgrade would need Moody's-adjusted debt/EBITDA below 2.5x and evidence of Poste Italiane synergies [8].

## Macro

- Moody's 2027 global credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs counter the AI tailwind [16].

## Sector

- The search returned no Moody's rating actions on European telecoms in the window. The only Moody's research on a listed name was a Deutsche Telekom issuer profile (9 Nov) [15].
- The latest Moody's sector outlook is Telecommunications – Global: stable (27 Oct 2026), citing solid demand and declining capital intensity against refinancing and structural risks [14].

## By name

| Name | Moody's rating | This week |
|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured, stable [1] | No material credit news. |
| Orange | Baa1 LT Issuer Rating, stable [1] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured, stable [1] | H1 loss, EUR 4.85bn impairment, net debt EUR 33.5bn; guidance raised [2][3] |
| Telefonica S.A. | Baa3 Senior Unsecured, stable [1] | 9M profit EUR 464m; net debt EUR 25.2bn; guidance raised [5] |
| Swisscom AG | A2 LT Issuer Rating, stable [1] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating, stable [1] | No material credit news. |
| Proximus | A3 Senior Unsecured, stable [1] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured, positive [1] | Bought 57.5% of Bahnhof for USD 363m [9]; after an unconditional mandatory offer it holds about 66.9% of shares and 90.6% of votes [10] |
| Telia Company AB | Baa1 Senior Unsecured, stable [1] | Agreed to buy Telavox's Nordic enterprise base for SEK 3.8bn plus up to SEK 200m earn-out [11]. Latvian state buyout of its LMT and Tet stakes due by 17 Nov, no amount stated; single source, unconfirmed [12] |
| TIM S.p.A. | Baa3 LT Issuer Rating, positive [1] | 9M net loss EUR 205m; net debt EUR 7.21bn [7] |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating, stable [1] | No news returned. |
| BT Group Plc (rated at British Telecommunications Ltd) | Baa2 LT Issuer Rating, stable [1] | No material credit news. |
| Iliad S.A. | Ba1 Senior Unsecured, stable [1] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 Corporate Family Rating, under review for downgrade [1] | No news returned. CFR and PDR, and Virgin Media Bristol's Ba3 bank facility, on review for downgrade since 22 Oct [13] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility, positive [1] | No material credit news. |

The ratings pull showed no rating action dated inside the window [1].

## Notes

- Not counted as new, because the events came before the window even though articles appeared inside it: Deutsche Telekom Q3 results (5 Nov), Proximus Q3 results (30 Oct), BT's pension valuation (5 Nov) and Swisscom's results (before 8 Nov).
- Company-reported net debt and leverage figures (Vodafone, Telefonica, TIM) are not Moody's-adjusted and are not comparable with the triggers quoted.

Dashboard not updated: no folder to write to, scripts cannot run and publishing is not available in this session.

## Sources

1. Moody's, getEntityRatings: current ratings and 1-year history for the 15 names (BT at British Telecommunications Limited), pulled 15 Nov 2026.
2. Moody's, searchCompanyFilings: Vodafone Group Plc Interim Report, H1 FY27 (six months to 30 Sep 2026), 6-K submitted 10 Nov 2026.
3. Moody's, searchCompanyFilings: Vodafone Group Plc Half Year 2027 Earnings Call, event date 10 Nov 2026 (company-reported).
4. Moody's, getCreditOpinion: "Vodafone Group Plc: Update following ratings affirmation", PBC_1496608, 21 Oct 2026.
5. Moody's, searchNews: CE Noticias Financieras, "Telefónica reports a profit of 464 million until September...", 12 Nov 2026.
6. Moody's, getCreditOpinion: "Telefonica S.A.: Update to credit analysis", PBC_1482849, 27 May 2026.
7. Moody's, searchNews: CE Noticias Financieras, "Telecom Italia's losses soar by 88% through September", 12 Nov 2026.
8. Moody's, getCreditOpinion: "TIM S.p.A.: Update following rating upgrade to Baa3", PBC_1499423, 19 Oct 2026.
9. Moody's, searchNews: Marketline Deals, "Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million", 11 Nov 2026.
10. Moody's, searchNews: NewsWeb (Oslo Børs), Bahnhof independent board committee recommends acceptance of Telenor Sverige's offer, 13 Nov 2026.
11. Moody's, searchNews: Contify (Telia Company release), 12 Nov 2026; SeeNews Deals, "Telia to buy Telavox's Nordic customer base for USD 380m", 13 Nov 2026.
12. Moody's, searchNews: LETA, "Government's directive regarding buyout of Telia's shares in LMT and Tet to be implemented by November 17 deadline", 13 Nov 2026.
13. Moody's, searchAllDocuments (Rating Action): "Moody's Ratings places VMED O2's and affiliated entities' ratings on review for downgrade", PR_531559, 22 Oct 2026.
14. Moody's, searchAllDocuments (Outlook): "Telecommunications – Global: Outlook stable as solid demand, declining capital intensity offset broad range of risks", PBC_1496503, 27 Oct 2026.
15. Moody's, searchAllDocuments (Issuer Profile): "Deutsche Telekom AG: Key facts and statistics - LTM ended June 2026", PBC_1500087, 9 Nov 2026.
16. Moody's, searchAllDocuments (Outlook): "Credit Conditions – Global: 2027 Outlook", PBC_1491648, 9 Nov 2026.
