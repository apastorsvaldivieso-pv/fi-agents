**Daily sector news: European banks, last 7 days** (168h, 8 Nov 2026 23:37 UTC to 15 Nov 2026 23:37 UTC; 15 names)

UniCredit raised its 2026 profit ambition and expects the last approvals for control of Commerzbank by end-November; Moody's has UniCredit's standalone assessment on review for upgrade tied to that deal. [1][2]

**Top this week**

- **UniCredit / Commerzbank** (Results, M&A): On 9 Nov UniCredit reported Q3 net profit of EUR 3.3bn (+24%), a CET1 ratio of 15% and a EUR 4.5bn interim dividend, and lifted its 2026 net profit ambition to well above EUR 11.5bn; it expects the remaining Commerzbank approvals by late November. *Why it matters:* Moody's says UniCredit's baa2 BCA could be upgraded if it gains control of and consolidates Commerzbank, while its senior ratings stay capped two notches above Italy. [1][2]
- **Italian banks** (Government measure): Italy's 2027 budget plans to collect EUR 5.9bn from the financial sector next year, rising to EUR 12bn through 2029, and spreads over 10 years more than EUR 20bn of tax credits; on 12 Nov Intesa's CEO called parts of it unconstitutional and warned the ECB may intervene. *Why it matters:* Moody's says both Intesa's and UniCredit's standalone assessments are constrained by Italy's Baa2 sovereign rating. [2][3][4]
- **Credit Agricole S.A.** (M&A): Credit Agricole proposed on 9 Nov to merge Credit Agricole Italia with Banco BPM; Banco BPM's board opened talks on 13 Nov. *Why it matters:* Moody's said the talks will likely have no immediate rating implications for CASA or Groupe Credit Agricole. [5][6]

**Macro**

- Most economists in a Reuters poll expect a final ECB deposit rate hike in December, with over a third expecting another in early 2027 as inflation runs at double the 2% target. [7]
- US and euro-area bond yields rose on 13 Nov. [8]

**Sector**

- (Moody's research): Moody's called the EBA's revised internal governance guidelines credit positive for EU banks, mainly smaller ones (11 Nov). Moody's updated its Intesa Sanpaolo credit opinion on 12 Nov. [4][9]
- (Moody's rating actions): Rating actions in the window were on banks not on the list, including Vseobecna uverova banka (Intesa subsidiary) deposits upgraded to A1 and UniCredit Bank Czech Republic and Slovakia assigned Baa1 issuer ratings. [10][11]
- (Sector outlook): Latest Moody's outlooks: global banks stable (3 Dec 2025); stable for France, Italy, Spain, UK, Netherlands, Switzerland (Feb 2026); positive for Germany (9 Feb 2026) and Finland (9 Mar 2026). [12][13][14][15][16][17][18][19][20]

**By name**

| Name | Moody's rating | This week |
|---|---|---|
| BNP Paribas | A1 LT Issuer, stable [21] | No material credit news. |
| HSBC Holdings plc | A3 Senior Unsecured, positive [21] | Issued USD 1.5bn 7.625% AT1 on 13 Nov to fund a tender for up to USD 1.5bn of 6.000% AT1; working on risk transfers on about USD 7bn of corporate loans (Bloomberg). [22][23] |
| Credit Agricole S.A. | A1 LT Issuer, stable [21] | Banco BPM merger talks (Top). [5] |
| Barclays PLC | Baa1 LT Issuer, stable [21] | Priced 8.625% perpetual AT1 (indenture 9 Nov); amount not in the sources returned. [24] |
| Societe Generale | A1 LT Issuer, negative [21] | No material credit news. |
| Deutsche Bank AG | A1 LT Issuer, positive [21] | BaFin fined it EUR 8m on 11 Nov over Postbank migration failings. [25] |
| UBS Group AG | A2 Senior Unsecured, stable [21] | No material credit news. |
| ING Groep N.V. | Baa1 Senior Unsecured, stable [21] | OCBC reported close to buying ING's Asian private bank for USD 1.5bn: single source, unconfirmed. EUR 3.5bn bond, reported on 10 Nov. [26][27] |
| Lloyds Banking Group plc | A3 Senior Unsecured, stable [21] | USD 2.75bn senior notes (2030 and 2032), filed 12 Nov. [28] |
| UniCredit S.p.A. | A3 Senior Unsecured, stable; BCA and junior ratings on review for upgrade [21][29] | Q3 results, Commerzbank (Top); USD 3.5bn senior non-preferred, 13 Nov. [1][30] |
| Intesa Sanpaolo S.p.A. | A3 LT Issuer, stable [21] | Published EUR 34.5bn MPS offer document on 10 Nov; ECB asked for a cautious dividend approach. EUR 1.25bn and GBP 500m senior non-preferred. [31][32][33] |
| Banco Bilbao Vizcaya Argentaria, S.A. | A2 LT Issuer, stable [21] | EUR 1bn 6.5% AT1 (6-K filed 10 Nov); USD 2.05bn senior non-preferred (13 Nov). [34][35] |
| CaixaBank, S.A. | A2 LT Issuer, stable [21] | EUR 1bn 5-year senior preferred green bond, 10 Nov. [36] |
| Commerzbank AG | A2 LT Issuer, stable [21] | EU antitrust clearance of UniCredit's takeover expected, per Reuters sources. [37] |
| Nordea Bank Abp | Aa3 Senior Unsecured, stable [21] | Copenhagen court fined it DKK 155m on 9 Nov over 2012-15 AML controls; cleared on five of seven counts. [38] |

**Notes**

- Moody's ratings shows UniCredit as 'Rating(s) Under Review'; per the 21 Jul rating action, the BCA, junior senior (Baa2), subordinated (Baa3) and preferred (Ba2(hyb)) ratings are on review for upgrade, while A3 deposit and senior unsecured ratings were affirmed with stable outlooks.
- Left out as events before the window: Commerzbank Q3 results (5 Nov), Lloyds and BNP Paribas Q3 results and BNP's buyback launch (October), and the Swiss capital proposal for UBS (reported 4 Nov; committee debate due 23-24 Nov).
- No Moody's rating action on a listed name fell in the window (Intesa affirmed 4 Nov, UBS 2 Nov). Moody's searched: Rating Action, Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Issuer Profile, Credit Opinion.
- Bank figures are company-reported, as given in the cited articles; none are Moody's-adjusted.

**Sources**

[1] Moody's (searchNews) · UniCredit stock lifts outlook as Commerzbank plan advances · Ad Hoc News, UniCredit Q3 2026 results · 2026-11-12
[2] Moody's (getCreditOpinion) · UniCredit S.p.A.: Update following placement of ratings on review for upgrade · PBC_1490860, upgrade/downgrade factors and outlook · 2026-07-30
[3] Moody's (searchNews) · Intesa criticises Italy for bank levies in 2027 budget, says ECB may intervene · Reuters via Yahoo Finance UK · 2026-11-13
[4] Moody's (getCreditOpinion) · INTESA SANPAOLO S.P.A.: Update to credit analysis · PBC_1501726, upgrade/downgrade factors and outlook · 2026-11-12
[5] Moody's (searchNews) · Credit Agricole: Bpm gives go-ahead to talks, confirms strategic value of … · MarketScreener · 2026-11-13
[6] Moody's (searchNews) · Moody's: Credit Agricole's offer to merge its Italian subsidiary with Banco BPM … · PR_533048 Moody's announcement · 2026-11-13
[7] Moody's (searchNews) · ECB set for last rate hike in December but inflation risks keep door open for … · Reuters poll via WMBD · 2026-11-12
[8] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes · Morningstar / Dow Jones · 2026-11-13
[9] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 Sector Comment · 2026-11-11
[10] Moody's (searchAllDocuments) · Moody's upgrades Vseobecna uverova banka's deposit ratings to A1 from A2 · PR_531483 Rating Action · 2026-11-12
[11] Moody's (searchAllDocuments) · Moody's assigns Baa1 issuer ratings to UniCredit Bank Czech Republic and … · PR_530435 Rating Action · 2026-11-09
[12] Moody's (searchAllDocuments) · Banks - Global: 2026 Outlook - Stable · PBC_1462959 Outlook · 2025-12-03
[13] Moody's (searchAllDocuments) · Banking System Outlook - France: stable · PBC_1470906 Outlook · 2026-02-09
[14] Moody's (searchAllDocuments) · Banking System Outlook - Italy: stable · PBC_1469157 Outlook · 2026-02-09
[15] Moody's (searchAllDocuments) · Banking System Outlook - Spain: stable · PBC_1471281 Outlook · 2026-02-09
[16] Moody's (searchAllDocuments) · Banking System Outlook - United Kingdom: stable · PBC_1463131 Outlook · 2026-02-10
[17] Moody's (searchAllDocuments) · Banking System Outlook - The Netherlands: stable · PBC_1470890 Outlook · 2026-02-11
[18] Moody's (searchAllDocuments) · Banking System Outlook - Switzerland: stable · PBC_1468651 Outlook · 2026-02-11
[19] Moody's (searchAllDocuments) · Banking System Outlook - Germany: positive · PBC_1470410 Outlook · 2026-02-09
[20] Moody's (searchAllDocuments) · Banking System Outlook - Finland: positive · PBC_1475274 Outlook · 2026-03-09
[21] Moody's ratings (getEntityRatings) · Moody's ratings, 15 European banks · 2026-11-15
[22] Moody's (searchNews) · HSBC Holdings plc announces the satisfaction of the New Issue Condition in its … · PR Newswire company release · 2026-11-13
[23] Moody's (searchNews) · HSBC Plans SRTs Tied to $7 Billion of US, Asian Corporate Loans · Bloomberg Law · 2026-11-12
[24] Moody's (searchNews) · Barclays PLC Announces 8.625% Perpetual AT1 Securities Pricing Agreement and … · Kalkine Media, Form 6-K · 2026-11-10
[25] Moody's (searchNews) · Deutsche Bank Aktiengesellschaft: BaFin imposes administrative fines · Contify, BaFin release · 2026-11-14
[26] Moody's (searchNews) · ING Groep stock faces US$1.5 billion Asian private-bank deal · Ad Hoc News, citing The Edge Malaysia · 2026-11-12
[27] Moody's (searchNews) · ING Bank N.V. Confirms No Stabilisation Activity After EUR 3.5 Billion … · Kalkine Media, post-stabilisation notice · 2026-11-10
[28] Moody's (searchNews) · Lloyds Banking Group Files Terms for $2.75 Billion Senior Notes · TipRanks, Form 6-K · 2026-11-12
[29] Moody's (searchAllDocuments) · Moody's Ratings places UniCredit S.p.A. on review for upgrade · PR_526711 Rating Action · 2026-07-21
[30] Moody's (searchNews) · UniCredit raises USD 3.5bn via three-part senior bond issue · SeeNews Banking · 2026-11-13
[31] Moody's (searchNews) · ECB urges Intesa to keep 'cautious' dividend policy after MPS acquisition · Reuters via AOL · 2026-11-10
[32] Moody's (searchNews) · Intesa Sanpaolo successfully places EUR 1.25bn Senior Non-Preferred bond · Contify Banking News, company release · 2026-11-09
[33] Moody's (searchNews) · Intesa Sanpaolo places GBP 500 million Green Senior Non-Preferred Bond · MarketScreener, company release · 2026-11-13
[34] Moody's (searchNews) · BBVA Announces EUR 1 Billion AT1 Preferred Securities Issuance at 6.5% · Kalkine Media, Form 6-K · 2026-11-12
[35] Moody's (searchNews) · Banco Bilbao Files Documents for Proposed $2.05 Billion Note Offering · TipRanks, Form 6-K · 2026-11-13
[36] Moody's (searchNews) · Caixabank raises EUR 1bn through green bond · SeeNews Banking · 2026-11-10
[37] Moody's (searchNews) · EU set to clear UniCredit's Commerzbank deal, sources say · Shanghai News, citing Reuters · 2026-11-13
[38] Moody's (searchNews) · Nordea fined EUR 21m in Danish money-laundering controls case · SeeNews Banking · 2026-11-13

Dashboard: the "Daily sector news" tab was updated at 2026-11-16 03:49 UTC. The page is at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review4-news-banks/dashboard/dashboard.html (not published to a link in this run).
