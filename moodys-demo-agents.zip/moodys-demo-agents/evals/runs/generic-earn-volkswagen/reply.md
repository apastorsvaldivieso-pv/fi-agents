**Earnings: Volkswagen, recap** (Half-year results to 30 Jun 2026; Moody's comment searched 2 Oct to 16 Nov 2026; 1 name)

Volkswagen AG (Baa1 LT Issuer Rating, stable): the latest Group results Moody's holds are the H1 2026 report, older than Audi AG's Q3 call of 30 Oct 2026; Moody's-adjusted EBIT margin of 4.57% sits 0.07pp above the 4.5% downgrade trigger. [1][2][3][4][5]

**Results against the credit view**

- (Guidance): Cut in Q2 on China volumes: deliveries -7% to -3% (was flat), sales revenue -3% to 0% (was 0% to +3%). Operating return on sales 4.0-5.5%, Automotive net cash flow EUR 3-6bn and net liquidity EUR 32-34bn unchanged. Company-reported. [4]
- (Against Moody's forecast): Moody's-adjusted LTM Jun 2026 EBIT margin 4.57% is inside Moody's 2026F range of 4.5%-5%; Debt/EBITDA 1.96x is above Moody's 2026F of 1.7x. [1][3]
- (Profit): H1 2026 earnings after tax EUR 3,103m (H1 2025: EUR 4,477m); attributable to Volkswagen AG shareholders EUR 2,574m (EUR 4,005m). Operating result EUR 5,931m (EUR 6,707m), 3.8% of sales (4.2%). US tariffs cost about EUR 1.3bn. Company-reported. [4]
- (Impairments): Impairments in cost of sales EUR 1,571m (EUR 746m), mainly lease assets and ending ID.4 production in the US (EUR 0.5bn with provisions). Financial result EUR -1,158m (EUR -284m) on impairment and measurement effects. Company-reported. [4]
- (Net liquidity): Automotive net liquidity EUR 32.7bn at 30 Jun 2026 (EUR 34.5bn at 31 Dec 2025). Named drivers: net cash flow +EUR 3.2bn, dividends about EUR 2.7bn, hybrid note redemption about EUR 1.7bn; the rest is bond issuance and redemption, not itemised. Company measure, not Moody's-adjusted debt. [4]
- (Capex and captive): Automotive capex EUR 5.5bn (EUR 6.3bn), 3.9% of sales; capitalised development EUR 4.2bn. Financial Services net liquidity EUR -223.8bn (EUR -214.6bn at Dec 2025), direct bank deposits EUR 80.2bn (EUR 68.4bn). Company-reported. [4]
- (Disposal): Agreed sale of 51% of Everllence to Bain Capital, expected cash inflow about EUR 7.4bn, targeted closing by 31 Dec 2026; not in the forecast. Maturities and undrawn facilities were not found in the report excerpts. Company-reported. [4]
- **Audi AG** (Subsidiary call): The only call Moody's holds is Audi AG's Q3 2026 call (30 Oct 2026), not the Group's: Audi cut its full-year return on sales guidance to 3%-5% and net cash flow to EUR 2.5-3.5bn. Company-reported, Audi only. [5]

**Against Moody's triggers**

| Metric (Moody's-adjusted) | Latest (LTM 30 Jun 2026) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| EBIT margin | 4.57% [3] | above 6.5% sustainably [1] | below 4.5% for a prolonged period [1] | 0.07pp above downgrade; 1.93pp short of upgrade [1][3] |
| Debt / EBITDA | 1.96x [3] | below 2x sustainably [1] | above 2.5x for a prolonged period [1] | already met, by 0.04x; 0.54x to downgrade [1][3] |

Note: Worded triggers, quoted: downgrade if "Moody's-adjusted FCF remains negative and/or liquidity weakens"; upgrade if "Moody's-adjusted FCF/debt improves well above mid-single-digit percentages sustainably". FCF/Debt LTM Jun 2026 is 8.60%. [1][3]

**What it means for the rating and outlook**

- The margin is the binding metric: 4.57% against a 4.5% downgrade level, while leverage at 1.96x is inside the upgrade level. The outlook expects VW to "maintain its Industrial EBIT margin at around 4.5% in the next 12-18 months". [1][3]
- The credit opinion of 19 May 2026 predates the H1 results and the guidance cut. Moody's published no comment on these results in the 45 days to 16 Nov 2026. [1][6]
- Company-reported Automotive net liquidity fell EUR 1.8bn in H1, mainly on dividends and the hybrid redemption. On payouts the opinion says "a disciplined approach to shareholder returns should support a gradual improvement in Moody's-adjusted free cash flow". [1][4]
- On China, the cause of the guidance cut, the opinion says VW "continues to face market share pressure in China, its largest single market". Everllence is not in the sections pulled. [1]

**Notes**

- Rating: Baa1 LT Issuer Rating, outlook stable, last action a downgrade on 17 Mar 2025 (getEntityRatings, RTNG_146500).
- Recap built from the H1 2026 report: Moody's holds no Volkswagen Group call transcript, only Audi AG's Q3 call, and no Q3 report. Run again for the Group's nine-month figures once Moody's holds them.
- No sector file exists for autos: the metrics came from the credit opinion's key indicators and the Moody's-adjusted key indicators.
- Company operating return on sales and net liquidity are not the same measures as Moody's-adjusted EBIT margin and debt.

**Sources**

[1] Moody's (getCreditOpinion) · Volkswagen AG credit opinion · PBC_1474693, Volkswagen Aktiengesellschaft: Update to key credit considerations … · 2026-05-19
[2] Moody's ratings (getEntityRatings) · Volkswagen AG ratings · 2026-11-16
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted), LTM 30 Jun 2026 · Volkswagen AG · 2026-06-30
[4] Moody's (searchCompanyFilings) · Volkswagen Group half-yearly financial report · Interim Report 2026 - Q2 (Half-yearly financial report Jan-Jun 2026), submission date … · 2026-06-30
[5] Moody's (searchCompanyFilings) · Audi AG Q3 2026 earnings call · Q3 2026 Audi AG Earnings Call, event date 30 Oct 2026 (filed under Volkswagen AG) · 2026-10-30
[6] Moody's (searchAllDocuments) · Moody's comment search · Issuer Comment, Rating Action, Credit Opinion on Volkswagen AG, 2 Oct to 16 Nov 2026: … · 2026-11-16

Earnings tab updated 2026-11-16 06:36 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/generic-earn-volkswagen/dashboard/dashboard.html (not published as an Artifact in this test run).
