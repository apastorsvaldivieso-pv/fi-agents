**Daily sector news: Vodafone, Orange** (72h, 12 Nov 2026 23:37 UTC to 15 Nov 2026 23:37 UTC; 2 names)

Nothing material for Telecoms, Europe, in the last 72 hours.

**Unresolved names:** Zzyzx Fakecorp Holdings (no match in Moody's: the name search returned no results and no candidates). Not guessed, not included.

**Notes**

- Vodafone's half-year results and guidance upgrade came out on 10 Nov 2026 (half-year 2027 earnings call, Moody's company filings), before this window; articles in the window retell them and the dividend declared with them, so they are not reported as new.
- Searched: news on each name, Moody's rating actions and research (sector comments, in-depth reports, issuer comments and profiles, credit opinions) for European telecoms in the window. The searches returned nothing material and no Moody's action or research.

Dashboard: Daily sector news tab updated 15 Nov 2026 23:39 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html (not published as an Artifact in this run).
