**Earnings: Vodafone, recap** (H1 FY27, six months to 30 Sep 2026; results and call 10 Nov 2026)

**Headline:** Vodafone raised its FY27 guidance at the half year, but its own net debt rose €8.1bn to €33.5bn on the VodafoneThree buyout and the Safaricom deal [5]. Moody's rates it Baa2 with a stable outlook, affirmed on 13 Oct 2026 [2]. Its latest Moody's-adjusted debt/EBITDA is 3.25x (FY to Mar 2026), 0.05x below the 3.3x downgrade trigger [1][3].

### Results against the credit view
- **Guidance raised (company-reported):** FY27 Adjusted EBITDAaL guidance went from €13.0–13.3bn to €13.2–13.4bn, and Adjusted FCF from €2.6–2.9bn to €2.8–3.0bn. Europe EBITDAaL guidance stays at €7.6–7.9bn [5]. Management said the ECJ ruling cost about €100m of EBITDA and was absorbed within the guidance [4].
- **H1 against guidance and Moody's:** Adjusted EBITDAaL was €6,451m, against €5,728m a year earlier (6.4% organic growth). Adjusted FCF was an outflow of €440m, against an outflow of €583m [5]. Moody's forecasts cover full fiscal years, so they cannot be compared with half-year figures [1].
- **Profit or loss (company-reported):** loss before tax of €373m, against a profit of €2,113m in H1 FY26. Basic loss per share was 20.75c, against earnings of 3.38c [5]. The searches did not return the "loss for the period" line itself.
- **One-offs inside it:** a €4.85bn goodwill impairment on Germany, driven by a higher discount rate (8.0%) and an updated plan. Offsetting it in part, a €3,022m gain on revaluing the previously held Safaricom stake [5].
- **Net debt (company measure, not Moody's-adjusted):** €33,473m, against €25,411m at 31 Mar 2026 (an increase of €8,062m). The increase came from acquisitions and disposals (€6,957m), free cash outflow (€845m), equity dividends (€544m), buybacks (€92m) and FX (€98m), less other movements of €474m [5].
- **Liquidity:** cash and short-term investments of €8.4bn (€12.4bn at Mar 2026). Undrawn revolving credit facilities of €7.6bn, maturing in 2028 (US$4.0bn) and 2031 (€4.1bn) [5].
- **Funding, capex and shareholder returns:** bonds rose €2,264m, mainly from new issuance, and bank loans rose €1,195m. The searches did not return the maturity profile. Capital additions were €3,320m (€2,800m a year earlier). The interim dividend is 2.306c (2.25c a year earlier) [5].
- **Legal:** on 15 Sep 2026 Kenya's High Court declared the 15% Safaricom stake purchase void. On 13 Oct the Court of Appeal ordered that the status quo be kept until it hears the appeal. Separately, teleshopping channels are claiming about €239m in Germany [5].

### Against Moody's triggers
| Metric (Moody's-adjusted) | Latest, period | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY Mar 2026 [3] | below 2.5x [1] | fails to stay below 3.3x [1] | 0.75x to upgrade level; 0.05x to downgrade level [1][3] |
| RCF / Net debt | 33.08%, FY Mar 2026 [3] | above 25%, sustained [1] | declines towards 18% [1] | already met, by 8.08pp; 15.08pp to downgrade level [1][3] |

Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade on "a failure to turn around its German operations" [1]. Moody's FY2027 forecasts are 3.1x debt/EBITDA and 29.4% RCF/net debt [1].

### What it means for the rating and outlook
The adjusted metrics sit inside both downgrade triggers. Debt/EBITDA has 0.05x of room [1][3]. The credit opinion (21 Oct 2026) and the rating action (13 Oct 2026) both predate these results, and Moody's has published no comment on them [1][6]. Company net debt has risen €8.1bn since March 2026, the period of the adjusted figures, mainly because of the deals [5]. On the UK deal, Moody's cites "reduced financial flexibility following the buyout of VodafoneThree" [1]. Its stable outlook assumes Vodafone stays "within the lower half of its net leverage target range" of 2.25x–2.75x [1]. The Safaricom acquisition and the Kenyan ruling are not in the sections pulled.

**Notes**
- The filing is titled "Interim Report 2026 - Q4" but is the H1 FY27 results (six months to 30 Sep 2026).
- Company net debt and EBITDAaL are not the same measures as Moody's adjusted debt and EBITDA, so they are shown side by side and never combined.
- Dashboard not updated: this session has no folder to write to and cannot run scripts or publish.

**Sources**
1. Moody's, getCreditOpinion: "Vodafone Group Plc: Update following ratings affirmation", PBC_1496608, 21 Oct 2026 (triggers, outlook, summary, key indicators).
2. Moody's, getEntityRatings: Vodafone Group Plc rating history (Senior Unsecured, foreign currency, Baa2, affirmed 13 Oct 2026, outlook stable), RTNG_600018164, pulled 15 Nov 2026.
3. Moody's, getEntityFinancials_v2: key indicators (adjusted), Debt / EBITDA and RCF / Net Debt, FY ended 31 Mar 2026.
4. Moody's, searchCompanyFilings: "Half Year 2027 Vodafone Group Public Ltd Co Earnings Call", event date 10 Nov 2026.
5. Moody's, searchCompanyFilings: "Vodafone Group Plc Interim Report 2026 - Q4" (H1 FY27 results, six months to 30 Sep 2026), submitted 10 Nov 2026, pp. 3, 4, 10–11, 18, 21, 23, 29.
6. Moody's, searchAllDocuments: "Moody's Ratings affirms Vodafone's ratings; stable outlook", Rating Action PR_528027, 13 Oct 2026.
