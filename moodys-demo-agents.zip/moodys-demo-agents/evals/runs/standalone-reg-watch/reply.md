**Regulatory watch: Banks Europe, 30 days** (16 Oct to 15 Nov 2026; 15 names)

Twelve new regulatory items for European banks between 16 Oct and 15 Nov 2026; only the Basel Committee's G-SIB window-dressing rule maps to a Moody's metric, and among the eight covered G-SIBs BNP Paribas and ING have the lowest CET1 ratios. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2][3] | 10.51%, 30 Sep 2025, older [4] | 2.46 pp [2][4] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2][3] | 11.03% (MDA trigger), 31 Dec 2025, older [5] | 2.04 pp [2][5] | Weaker third |
| Societe Generale | 13.20% [2] | -0.81 [2][3] | 10.26%, 31 Mar 2026 [6] | 2.94 pp [2][6] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2][3] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [2] | +0.09 [2][3] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [2] | +0.29 [2][3] | 12.2% (excl. PRA buffer), 31 Dec 2025, older [7] | 2.10 pp [2][7] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2][3] | 10.83% (going-concern), 30 Jun 2026 [8] | 3.55 pp [2][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [3] | +3.22 [2][3] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Covers banks on the FSB G-SIB list; the page names no banks beyond the framework. The assessment sample reports scores; the buffer falls on listed G-SIBs only. Ranked by level: three of eight have a current requirement. Out of scope (not on the FSB list of 27 Nov 2025): Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea. Listed issuer Credit Agricole S.A.: CET1 11.3%, Q2 2026; 2.6 pp above SREP, 31 Mar 2026. [2][10][11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 amends large exposures: a trading book excess allowance of up to 85% of Tier 1 capital for a maximum of 10 business days, and a single higher limit of 350% of Tier 1 for intragroup trading book exposures, from 1 Jan 2028. [12]
- [NEW] **FINMA** (Final): Final partial revision of the FINMA Anti-Money Laundering Ordinance, in force 1 Jan 2027; correspondent banking rule now applies only to clients with direct access to the correspondent bank's accounts. [13]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test, with more than 55% less requested data (headline; the body says 55%) and a separate climate module that does not affect core results. Launch end of January 2027, results end of July 2027. [14]
- [NEW] **Basel Committee** (Consultation): Consults on additional Pillar 2 guidance for interest rate risk in the banking book (model risk, stress testing, embedded gains and losses, earnings indicators, new supervisory information). Comments by 9 Feb 2027. [15]
- [NEW] **EBA** (Other): Next steps on simplifying supervisory reporting: first reference date moved to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028; at least a one-year implementation period. Final report due December 2026. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under the CRD, with less detail on mapping of duties and simpler conflict-of-interest rules; application date not stated. *Why it matters:* Moody's calls the revisions credit positive for small EU banks, with less effect on large banks that already apply most of them. [17][18]
- [NEW] **Basel Committee** (Consultation): Consults on consequential amendments moving application guidance from the Basel Framework into the consolidated guidelines and updating cross-references. Comments by 21 Dec 2026. [19]
- [NEW] **FINMA** (Consultation): Consults on a partial revision of Circular 2019/2 Interest rate risks - banks, adopting the Basel Committee's recalibrated interest rate shocks and taking greater account of effects on revenues. Consultation until 15 Jan 2027. [20]
- [NEW] **European Commission** (Other): Political agreement on the securitisation framework review: simpler due diligence and transparency rules, and prudential treatment of securitisations under the CRR made more risk sensitive. Awaits formal approval; Council aims to finish by end-2026. [21]
- [NEW] **PRA** (Consultation): CP14/26, phase 2 of the SM&CR review: notification instead of pre-approval for many senior manager roles and removal of the Certification Regime. Comments by 22 Jan 2027; implementation expected H2 2027. [22]
- [NEW] **Basel Committee** (Final): Final G-SIB window-dressing amendments: indicators reported on average values over the year instead of year-end, by 1 Jan 2030; reporting threshold raised from EUR 200 billion to EUR 350 billion of leverage exposure from 1 Jan 2027. *Why it matters:* Changes how G-SIB scores, and so G-SIB buffers, are measured. [1]
- [NEW] **Basel Committee** (Consultation): Consults on whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB methodology. Comments by 14 Jan 2027. The page names no addressees; we read it as covering BNP Paribas, Groupe Credit Agricole, Societe Generale, Deutsche Bank and ING. [10][23]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) [12] | HSBC, Barclays, Lloyds | Large exposures | Watch |
| FINMA AML Ordinance (10 Nov) [13] | UBS | AML | Watch |
| EBA 2027 stress test methodology (9 Nov) [14] | EU banks in EBA sample: scope not known | Stress testing | Watch |
| Basel IRRBB Pillar 2 guidance (9 Nov) [15] | All 15, once applied | IRRBB | Watch |
| EBA reporting simplification (6 Nov) [16] | 11 EU banks | Reporting | Watch |
| EBA internal governance guidelines (5 Nov) [17] | 11 EU banks | Governance | Watch |
| Basel consolidated guidelines amendments (5 Nov) [19] | All 15, once applied | No channel-map row (our judgment) | Watch |
| FINMA Circular 2019/2 IRRBB (4 Nov) [20] | UBS | IRRBB | Watch |
| EU securitisation framework agreement (22 Oct) [21] | 11 EU banks | Securitisation | Watch |
| PRA CP14/26 SM&CR phase 2 (22 Oct) [22] | HSBC, Barclays, Lloyds | Governance | Watch |

Note: Moody's data carries no metric for these channels, so no name is given a position.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- FSB 2026 G-SIB list not yet on fsb.org (16 Nov 2026); the 27 Nov 2025 list is used. Requirements carry their own dates.
- Left out (21): speeches, blogs, news; newsletters; sanctions notices; statistics and lists; credit-union and fund items; EBA advice, factsheet, appointment, moved deadlines.
- Moody's commentary was searched for the G-SIB, securitisation, stress test and IRRBB items; only the EBA governance guidelines had a Moody's comment in the window.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, one call for the coverage … · Bank financials, coverage list · 2026-06-30
[3] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 … · Groupe Credit Agricole · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING Groep N.V. MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Annual report on Form 20-F for 2025, as of 31 … · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, shown … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays PLC stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Annual report on Form 20-F for 2025, as of … · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS Group AG stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides filed under … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Moody's (searchCompanyFilings) · Credit Agricole S.A. stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides, Credit Agricole … · 2026-03-31
[12] Web · PRA PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[16] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · European Commission welcomes political agreement on the review of the … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · PRA CP14/26 - Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[23] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review

Regulatory watch tab updated 2026-11-16 06:20 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/standalone-reg-watch/dashboard/dashboard.html (not published: Artifact publish skipped for this test run).
