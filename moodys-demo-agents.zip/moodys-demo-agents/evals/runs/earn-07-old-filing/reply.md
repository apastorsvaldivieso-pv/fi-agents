**Earnings: BNP Paribas, recap** (Q3 2026 results, reported 28 Oct 2026; 1 name)

BNP Paribas (A1 stable) reported Q3 2026 net income of EUR 3.5bn, up 13.5%, with CET1 at 12.9%; Moody's holds no call transcript, and its latest BNP filings (Q3 2025 interim, FY2025 annual) are older than these results, so the recap rests on Moody's issuer comment of 28 Oct 2026. [1][2]

**Results against the credit view**

- (Profit): Net income was EUR 3.5bn for Q3 2026, up 13.5% on Q3 2025, as stated in Moody's comment (company results; Moody's notes some of its figures are its own calculations). It includes a EUR 81m gain on disposal of financial stakes, which Moody's excludes as exceptional; no impairment or write-down is cited. [2]
- (Guidance): Year-end CET1 target formally raised to more than 13%, from 'CET1 ratio expected at 12.5% by end-2027' in the 16 Sep 2025 release. 2028 guidance reiterated, including cost/income below 56%; cost of risk stayed within the 40bp target. No Moody's forecast columns to measure against. [2][3]
- (Revenue and costs): Group revenue rose 9.5% (CIB +16.6%), operating expenses rose 5.3% to EUR 8.0bn, and cost/income improved 2.3pp to 58.3% (company-reported). [2]
- (Asset quality): Underlying cost of risk was unchanged at 39bp; loan loss provisions EUR 964m (Q3 2025: EUR 905m); doubtful loans 1.6%; Stage 3 coverage 67.3% (Q3 2025: 66.6%) (company-reported). [2]
- (Capital): CET1 ratio 12.9%, close to the more-than-13% target, after a drag of about 15bp from closing the Athlon acquisition (company-reported). The latest stated CET1 requirement in Moody's filings is 10.51%, at 30 Sep 2025. [2][3]
- (Liquidity and funding): HQLA EUR 399bn at 30 Sep 2026; liquidity reserve EUR 495bn (Q3 2025: EUR 481bn); LCR 139% (138%). The EUR 14.0bn 2026 regulatory issuance plan is complete, with about EUR 4bn prefunded for 2027: 126% done by 16 Oct 2026 (company-reported). [2]
- (Distributions): A EUR 1.3bn share buyback launches in November; a Q4 2026 capital gain is expected from the sale of BMCI (Morocco), which Moody's describes as of similar size (company-reported). [2]

**Against Moody's triggers**

| Metric | Latest Moody's value | Upgrade trigger | Downgrade trigger | Room to upgrade trigger |
|---|---|---|---|---|
| Net income / tangible assets (RoA) | 0.4%, Jun 2026 [4] | 0.6% and above [4] | worded, no number | 0.2pp below [4] |

Note: Worded downgrade triggers: 'lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability'; also an upgrade of France's rating could restore government support uplift. [4]

**What it means for the rating and outlook**

- The A1 LT Issuer Rating was affirmed on 31 Aug 2026 with a stable outlook; the credit opinion of 2 Sep 2026 predates these results. Moody's-adjusted RoA was 0.4% in H1 2026 against the 0.6% upgrade level; TCE/RWA was 13.7%. [1][4]
- Reported CET1 moved from 12.97% at Q2 2026 to 12.9% at Q3 2026; the cause given is the Athlon acquisition. Athlon is not in the sections pulled; the opinion cites last year's AXA IM acquisition as growing BNP's footprint in stable markets. [2][4][5]
- Moody's comment of 28 Oct 2026 says the results showed 'strong resilience against the weak operating momentum in its French home market'. [2]

**Notes**

- No earnings call transcript for BNP Paribas in Moody's (searchCompanyFilings: not found). The latest filings Moody's holds are the Q3 2025 interim report (30 Sep 2025) and the FY2025 annual report (31 Dec 2025), both older than the Q3 2026 results; only the dated CET1 requirement and the 2025 guidance were taken from them.
- Q3 2026 figures are company-reported, as given in Moody's issuer comment; Moody's-adjusted figures are from the credit opinion's key indicators (Jun 2026).

**Sources**

[1] Moody's ratings (getEntityRatings) · 2026-08-31
[2] Moody's (searchAllDocuments) · BNP Paribas: Q3 results underscore position of strength amid worsening domestic … · PBC_1499674, Issuer Comment · 2026-10-28
[3] Moody's (searchCompanyFilings) · BNP Paribas third quarter 2025 report · BNP Paribas Interim Report 2025 - Q3 (third amendment to the 2024 URD), period 30 Sep … · 2025-09-30
[4] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation · PBC_1491623, sections Upgrade, Downgrade, Outlook, Key indicators, Summary, Strengths, … · 2026-09-02
[5] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · BNP Paribas financials (Bank Focus) · 2026-06-30

Dashboard: Earnings tab updated 2026-11-15 23:39 UTC, page at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-07-old-filing/dashboard/dashboard.html (not published: Artifact publish skipped for this test run).
