**Daily sector news: European utilities, 72h** (72h, 13 Nov 2026 06:42 UTC to 16 Nov 2026 06:42 UTC; 6 names)

A quiet three days for the six utilities: no Moody's rating action or research in the window, ratings and stable outlooks unchanged, and the only deal item (EDF Invest selling part of its Teréga stake) rests on a single report. [1]

**Top this window**

No item qualifies. The nine-month results of Enel, Iberdrola, E.ON and RWE and the RWE-KKR Vanguard joint venture were announced before the window opened; the one new checklist item (EDF/Teréga) could not be confirmed.

**Macro**

- (UK): Pressure on the Bank of England to raise rates again is building ahead of UK inflation data; reports say the BoE is likely to raise rates further in 2027. [2]
- (FX): The euro softened below 1.1050 against the dollar as traders added to bets on a Fed rate hike (16 Nov). [3]
- (Euro area): Eurostat's second reading put euro-area Q3 2026 GDP growth at 0.4% q/q, down from 0.6% in Q2 (reported 13 Nov). [4]

**Sector**

- (Moody's): The search returned no Moody's rating actions and no Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Issuer Profile or Credit Opinion on European utilities published 13-16 Nov. [5]
- (Outlook): Latest outlook returned: 'Unregulated Electric & Gas Utilities – Europe: 2026 Outlook – Stable' (scope Europe, published 18 Nov 2025). Moody's expects FFO/net debt to stay around 23% over 2025-27. The search returned no separate outlook for regulated networks. [6]

**By name**

| Name | Moody's rating | News |
|---|---|---|
| Enel S.p.A. | Baa1 LT Issuer Rating, stable [1] | No material credit news. Nine-month results came out on 12 Nov, before the window. |
| Iberdrola S.A. | Baa1 LT Issuer Rating, stable [1] | No material credit news. Nine-month results predate the window. |
| Electricite de France | Baa1 LT Issuer Rating, stable [1] | Enagás to buy 18% of Teréga from EDF Invest for EUR 311m, reported on 13 Nov. Single source, unconfirmed. [7] |
| E.ON SE | Baa2 Senior Unsecured (Fgn Curr), stable [1] | No material credit news. Nine-month results came out on 11 Nov, before the window. |
| RWE AG | Baa2 LT Issuer Rating (Dom Curr), stable [1] | No material credit news. Nine-month results and the KKR Vanguard JV close were on 11 Nov, before the window. |
| ENGIE SA | Baa1 LT Issuer Rating, stable [1] | No material credit news. |

**Notes**

- No sector file exists for utilities; the outlook came from a document search for type Outlook.
- Dropped as outside the window or not credit news: results and deals announced 11-12 Nov, RWE battery and hydrogen-turbine projects, ENGIE's Google data-centre MoU and its 35% share in Egypt's Shokeir wind project financing, broker target changes and tenders.
- The EDF/Teréga item was searched once more under EDF's name in the window; nothing confirmed it.

**Sources**

[1] Moody's ratings (getEntityRatings) · Moody's ratings for the six names · 2026-11-16
[2] Moody's (searchNews) · Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms; BOE … · 202611151752ACI_INFOBLOGS_EN_EAHE_10010102 (The Eastern Herald); … · 2026-11-15
[3] Moody's (searchNews) · Euro softens below 1.1050 as traders ramp up Fed rate hike bets · 202611151934AMSPIDERFIN_NEWS_25822_997812 (FXStreet) · 2026-11-16
[4] Moody's (searchNews) · The Ibex 35 rises by 3.36% for the week and reclaims the 20,000 point mark · 202611131754CONTENGEBRZL_GVT_91159522 (CE Noticias Financieras) · 2026-11-13
[5] Moody's (searchAllDocuments) · Moody's actions and research search · documentTypes Rating Action; and Sector Comment, Sector In-Depth, Issuer Comment, Issuer … · 2026-11-16
[6] Moody's (searchAllDocuments) · Unregulated Electric & Gas Utilities – Europe: 2026 Outlook - Stable as … · PBC_1464527 · 2025-11-18
[7] Moody's (searchNews) · The Ibex 35 rises by 3.36% for the week ... (Enagás/Teréga paragraph) · 202611131754CONTENGEBRZL_GVT_91159522 (CE Noticias Financieras) · 2026-11-13

Dashboard updated: "Daily sector news" tab, 16 Nov 2026 06:45 UTC, page at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/generic-news-utilities-2/dashboard/dashboard.html. Not published to the private link in this session.
