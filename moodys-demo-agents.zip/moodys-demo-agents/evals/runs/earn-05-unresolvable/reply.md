I couldn't find "Zzyzx Fakecorp Holdings" in Moody's data, so there's no earnings preview to give.

A Moody's name search for "Zzyzx Fakecorp Holdings" returned no matches at all, rated or unrated. Without a Moody's entity there are no ratings, credit opinion, triggers or transcripts to build a preview from, and I won't swap in a similar-sounding company.

Nothing has been saved and the dashboard has not been updated.

To try again, send me any of these:
- the company's exact legal name, or the name of its rated parent or issuing subsidiary;
- its home country;
- a ticker, LEI or Moody's entity ID.

Sources
[1] Moody's, findEntity: name search for "Zzyzx Fakecorp Holdings", no results, 2026-11-15.
