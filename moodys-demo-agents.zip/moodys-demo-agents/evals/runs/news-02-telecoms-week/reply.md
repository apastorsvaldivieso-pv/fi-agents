**Daily sector news: Telecoms Europe, last 7 days** (168h (7 days), 8 Nov 2026 23:37 UTC to 15 Nov 2026 23:37 UTC; 15 names)

Vodafone booked a EUR 4.85bn German goodwill impairment and net debt rose to EUR 33.5bn even as it raised guidance; Telefonica and TIM also reported, and Telia and Telenor did Nordic deals. [1]

**Top this week**

- [RESULTS] **Vodafone Group Plc** (H1 FY27, 10 Nov): Pre-tax loss of EUR 373m (H1 FY26: EUR 2,113m profit) after a EUR 4.85bn goodwill impairment on Germany; net debt rose to EUR 33.5bn from EUR 25.4bn at 31 March on the VodafoneThree buyout and Safaricom stake. FY adjusted EBITDAaL guidance raised to EUR 13.2-13.4bn. *Why it matters:* Moody's downgrade triggers include a failure to turn around Germany and adjusted gross debt/EBITDA not staying below 3.3x. [1][2][3]
- [RESULTS] **Telefonica S.A.** (Q3, 12 Nov): Nine-month net profit EUR 464m against a EUR 1.08bn loss a year earlier; net financial debt cut to EUR 25.19bn, company leverage 2.63x EBITDAaL. Adjusted EBITDA growth guidance raised to slightly above 2.5%, FCF to about EUR 3.1bn; revenue growth target cut to 1-1.5%. *Why it matters:* Moody's stable outlook expects adjusted net leverage to fall sustainably below 3.75x; company leverage is a different measure. [4][5]
- [RESULTS] **TIM S.p.A.** (9M, 11 Nov): Nine-month net loss widened to EUR 205m from EUR 109m on EUR 314m of non-recurring costs; adjusted net debt after leases rose to EUR 7.21bn from EUR 6.854bn at December. FCF after leases EUR 818m; 2026 targets kept. *Why it matters:* Moody's positive outlook rests on earnings growth and positive FCF; downgrade only if FCF turns persistently negative and leverage stays above 3.0x. [6][7]

**Macro**

- Euro area and US bond yields rose on 13 Nov; UK commentary points to Bank of England rate pressure ahead of an inflation print. [8][9]
- Moody's 2027 credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs counter the AI tailwind. [10]

**Sector**

- (Moody's): The search returned no Moody's rating actions on European telecoms in the window. Research on the list: a Deutsche Telekom issuer profile (9 Nov). [11][12]
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable, 27 Oct 2026 - solid demand and declining capital intensity offset a broad range of risks. [13]

**By name**

| Name | Moody's rating | This week |
|---|---|---|
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr), stable [14] | H1 loss on EUR 4.85bn Germany impairment; net debt EUR 33.5bn; guidance raised (see Top). [1] |
| Telefonica S.A. | Baa3 Senior Unsecured (Dom Curr), stable [14] | Back to profit, debt down, guidance up (see Top). [4] |
| TIM S.p.A. | Baa3 LT Issuer (Dom Curr), positive [14] | 9M loss wider, net debt up, targets kept (see Top). [6] |
| Telia Company AB | Baa1 Senior Unsecured (Fgn Curr), stable [14] | Binding deal (12 Nov) for Telavox's Nordic enterprise base: SEK 3.8bn plus up to SEK 0.2bn earn-out; base has about SEK 1.1bn revenue. Latvia's buyout of Telia's LMT and Tet stakes due by 17 Nov (LETA). [15][16][17] |
| Telenor ASA | Baa1 Senior Unsecured (Fgn Curr), positive [14] | Completed purchase of 57.5% of Bahnhof (reported 11 Nov; USD 363.02m per Marketline); now 66.9% of shares, mandatory offer at SEK 62 a share. [18][19][20] |
| VMED O2 UK Holdings Limited | B1 CFR (Fgn Curr), on review for downgrade [14][21] | No news returned under the name. Review since 22 Oct covers the CFR and B1-PD PDR plus affiliates' instruments. Telefonica's results (12 Nov) cite a GBP 800m-a-year cost plan by 2029. [4][21] |
| BT Group Plc | Baa2 LT Issuer (at British Telecommunications Limited), stable [14] | Half-year results, date not in the sources (reported 12 Nov): sales GBP 8,753m, net income GBP 809m, interim dividend 2.50p. Leverage not in the sources returned. [22] |
| Deutsche Telekom AG | A3 Senior Unsecured (Fgn Curr), stable [14] | No material credit news. |
| Orange | Baa1 LT Issuer, stable [14] | No material credit news. |
| Swisscom AG | A2 LT Issuer (Dom Curr), stable [14] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer, stable [14] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (Dom Curr), stable [14] | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer (Dom Curr), stable [14] | no news returned |
| Iliad S.A. | Ba1 Senior Unsecured (Dom Curr), stable [14] | No material credit news. |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (Fgn Curr), positive [14] | No material credit news. |

Note: Results figures are company-reported, not Moody's-adjusted. Ratings are the roll-up rating Moody's returns, of the class shown.

**Notes**

- Window is 168h to 15 Nov 2026 23:37 UTC. Results released before it (Deutsche Telekom 5 Nov, Proximus 30 Oct, Swisscom's Q3 before 5 Nov) and BT's pension valuation (5 Nov) are not reported as new.
- Research kinds searched: Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Issuer Profile, Credit Opinion. Iliad's news search returned only unrelated articles using the word Iliad.
- Company leverage (net debt/EBITDAaL) is not Moody's-adjusted debt/EBITDA and is not compared with the triggers.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone Group Plc Interim Report (company-reported) · Vodafone Group Plc Interim Report H1 FY27 (period to 30 Sep 2026): income statement, net … · 2026-11-10
[2] Moody's (searchNews) · Vodafone raises full-year earnings forecast after job cuts (Tech in Asia) · 2026-11-10
[3] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, Outlook and downgrade factors · 2026-10-21
[4] Moody's (searchNews) · Telefonica reports a profit of 464 million until September (CE Noticias … · 2026-11-12
[5] Moody's (getCreditOpinion) · Telefonica S.A.: Update to credit analysis · PBC_1482849, Outlook and rating factors · 2026-05-27
[6] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September (CE Noticias Financieras) · 2026-11-12
[7] Moody's (getCreditOpinion) · TIM S.p.A.: Update following rating upgrade to Baa3 · PBC_1499423, Outlook and rating factors · 2026-10-19
[8] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Morningstar) · 2026-11-13
[9] Moody's (searchNews) · Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms · 2026-11-15
[10] Moody's (searchAllDocuments) · Credit Conditions - Global: 2027 Outlook · PBC_1491648 · 2026-11-09
[11] Moody's (searchAllDocuments) · Moody's rating action and research search · Rating Action and research types, Telecommunications, Europe, 8-15 Nov 2026 · 2026-11-15
[12] Moody's (searchAllDocuments) · Deutsche Telekom AG: Key facts and statistics - LTM ended June 2026 · PBC_1500087 · 2026-11-09
[13] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable · PBC_1496503 · 2026-10-27
[14] Moody's ratings (getEntityRatings) · Moody's ratings pull, batch 1, Moody's ratings pull, batch 2 · 2026-11-15
[15] Moody's (searchNews) · Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion (Telecomlead) · 2026-11-12
[16] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base (company release) · 2026-11-12
[17] Moody's (searchNews) · Government's directive on buyout of Telia's shares in LMT and Tet (LETA) · 2026-11-13
[18] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof and Launches Mandatory Cash Offer (The … · 2026-11-11
[19] Moody's (searchNews) · Bahnhof board recommends Telenor Sverige's offer; Telenor holds 66.9% (NewsWeb) · 2026-11-13
[20] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million (Marketline) · 2026-11-11
[21] Moody's (searchAllDocuments) · Moody's places VMED O2's and affiliated entities' ratings on review for … · PR_531559, list of affected ratings · 2026-10-22
[22] Moody's (searchNews) · Will Dividend Growth Guidance Change BT Group's Narrative (Simply Wall St) · 2026-11-12


Dashboard: the "Daily sector news" tab was updated at 2026-11-15 23:42 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html. It was not published to the private link in this run.
