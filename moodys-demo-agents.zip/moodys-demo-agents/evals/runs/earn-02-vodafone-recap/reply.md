**Earnings: Vodafone, recap** (H1 FY27 results (six months to 30 Sep 2026), call of 10 Nov 2026; 1 name)

Vodafone raised FY27 guidance at its H1 results (10 Nov 2026), but company net debt rose €8.1bn to €33.5bn on the VodafoneThree buyout and Safaricom; Moody's-adjusted debt/EBITDA was 3.25x (FY to Mar 2026) against a 3.3x downgrade trigger. [1][2][3]

**Results against the credit view**

- (Guidance): FY27 Adjusted EBITDAaL guidance raised from €13.0-13.3bn to €13.2-13.4bn and Adjusted FCF from €2.6-2.9bn to €2.8-3.0bn; Europe EBITDAaL kept at €7.6-7.9bn (company-reported). Management said Europe absorbed a c.€100m EBITDA hit from the ECJ ruling. [1][4]
- (Profit or loss): Loss for the period of €3,597m (H1 FY26: profit of €1,052m); loss attributable to owners of €4,789m (H1 FY26: profit of €829m), company-reported. [1]
- (One-offs): Inside the loss: a €4,850m goodwill impairment on Germany, mainly from higher German bond yields; income tax of €3,224m including deferred tax asset charges in Germany and the UK; offset by a €3,022m Safaricom remeasurement gain. [1]
- (Net debt): Company net debt €33,473m against €25,411m at 31 Mar 2026, up €8,062m: acquisitions and disposals €6,957m (VodafoneThree 49% €5,019m, Safaricom 15% €1,379m, Safaricom net debt €537m), free cash outflow €845m, dividends €544m, buybacks €92m, FX loss €98m, less other movements of €474m (incl. €908m VodafoneZiggo loan repaid). [1]
- (Liquidity): Cash and short-term investments €8.4bn (€12.4bn at 31 Mar 2026), of which cash €5.0bn; undrawn RCFs €7.6bn, €4.1bn maturing 2031 and US$4.0bn (€3.5bn) 2028. A bond maturity schedule was not in the filing excerpts pulled. [1]
- (Capex and FCF): Capital additions €3,320m (H1 FY26: €2,800m); Adjusted FCF an outflow of €440m (H1 FY26: outflow of €583m). Restructuring and integration costs to peak at c.€0.7bn in FY27; no material cut in German capital intensity guided. [1][4]
- (Shareholder returns): Interim dividend 2.306 eurocents (H1 FY26: 2.25 eurocents), up 2.5%; share buybacks €92m in H1 (H1 FY26: €973m). [1]
- (Legal): Kenya's High Court nullified the 15% Safaricom stake purchase on 15 Sep 2026; the Court of Appeal ordered the status quo kept pending appeal. On the ECJ-related class action, management booked a small provision, with no conclusion expected before late 2027. [1][4]
- (OXG fibre JV): An analyst put possible OXG equity injections at up to €1.2bn (analyst's figure); management said any equity would be phased over the build. [4]

**Against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to Mar 2026 [2] | below 2.5x [3] | fails to stay below 3.3x [3] | 0.75x to upgrade; 0.05x to downgrade [2][3] |
| RCF / Net Debt | 33.08%, FY to Mar 2026 [2] | above 25% sustained [3] | towards 18% [3] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [2][3] |

Note: Moody's forecasts for FY27: debt/EBITDA 3.1x, RCF/net debt 29.4%. Worded triggers: downgrade on a failure to turn around Germany; upgrade on sustained improvement, particularly in Germany. [3]

**What it means for the rating and outlook**

- (Position): Baa2 senior unsecured, stable outlook, affirmed 13 Oct 2026. The latest Moody's-adjusted figures (FY to Mar 2026) sit 0.05x inside the 3.3x debt/EBITDA downgrade level; the outlook assumes debt/EBITDA below 3.3x and RCF/net debt around 30%. [2][3][5]
- (Timing): The rating action (13 Oct) and credit opinion (21 Oct) predate these results; since 31 Mar 2026 company net debt has risen €8.1bn, mainly from the VodafoneThree buyout and Safaricom. [1][3][6]
- (Moody's on the cause): The opinion cites "reduced financial flexibility following the buyout of VodafoneThree" and assumes Vodafone stays "within the lower half of its net leverage target range"; the company reiterated targeting the lower half of 2.25-2.75x. Safaricom: not in the sections pulled. [1][3]
- (Moody's comment): No Moody's comment on these results in the last 45 days. [3][6]

**Notes**

- Transcript and filing figures are company-reported; company net debt is not Moody's-adjusted debt. Moody's FY27 forecasts are full-year leverage ratios and cannot be set against half-year results, so beat or miss is against company guidance only.
- The interim report is titled "Interim Report 2026 - Q4" in Moody's data; it is the H1 FY27 report for the six months to 30 Sep 2026.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone Group Plc H1 FY27 interim report · Interim Report 2026 - Q4 (H1 FY27 results, six months to 30 Sep 2026; Form 6-K … · 2026-09-30
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted): Debt / EBITDA, RCF / Net Debt, FY ending 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[3] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections Summary, Strengths, Challenges, Up/Downgrade factors, Outlook, Key … · 2026-10-21
[4] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, event date 10 Nov 2026 · 2026-11-10
[5] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-10-13
[6] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action · 2026-10-13

Earnings tab updated 15 Nov 2026 23:40 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html (not published as an Artifact in this run).
