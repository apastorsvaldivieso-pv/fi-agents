**Daily sector news: European utilities, 7 days** (168h (7 days) from 9 Nov 2026 06:34 UTC to 16 Nov 2026 06:34 UTC; 6 names)

RWE's net debt reached EUR 17.0bn at end-September and it expects about EUR 12bn by year-end once the KKR offshore joint venture is deconsolidated; Moody's took no rating action on the six names in the week. [1]

**Top this week**

- [NEW] **RWE** (Results / Deal): 9M (11 Nov): adjusted EBITDA EUR 4.6bn (EUR 3.4bn), adjusted net income EUR 1.8bn (EUR 1.3bn); IFRS net income not returned. Net debt EUR 17.0bn at 30 Sep, seen near EUR 12bn at year-end after deconsolidating Vanguard, whose KKR joint venture closed 11 Nov. *Why it matters:* Moody's guidance is FFO/net debt of at least 25%; it may tighten if priority debt at offshore joint ventures or Amprion rises materially. [1][2]
- [NEW] **Enel** (Results): 9M (12 Nov): net financial debt EUR 66.158bn, up 15.7% from end-2025, including about EUR 1.5bn from Italy's Energy Decree; ordinary EBITDA EUR 17.946bn (+4%); reported net income EUR 5.634bn (+7.6%) per Ad Hoc News, EUR 6.846bn per Finanz Nachrichten. Guidance confirmed. *Why it matters:* Moody's stable outlook assumes FFO/net debt of 20%; persistently below 20% could lead to a downgrade. [3][4][5][6]
- [NEW] **E.ON** (Results): 9M results (11 Nov): adjusted EBITDA EUR 7.1bn (flat), adjusted net income EUR 2.2bn (EUR 2.1bn), 2026 guidance of EUR 9.4-9.6bn EBITDA reaffirmed; investment EUR 5.2bn. Basic EPS from continuing operations EUR 1.37 (EUR 0.35). Net debt not in the sources returned. *Why it matters:* Moody's stable outlook expects FFO/net debt of at least 13% and RCF/net debt of at least 8% despite the investment programme. [7][8][9]

**Macro**

- ECB's Nagel says another rate hike is "highly probable" as energy prices push inflation (16 Nov). [10]
- US and euro-area government bond yields rose (13 Nov); Bank of England rate-hike bets are back in focus ahead of UK CPI (16 Nov). [11][12]

**Sector**

- (Moody's): The search returned no Moody's rating actions on European utilities in the window. Research: an update to the credit analysis of Sizewell C Limited (not on the list, 11 Nov) notes that energy affordability concerns are unlikely to abate. [13]
- (Outlook): Latest European utilities outlook returned: Unregulated Electric & Gas Utilities - Europe, 2026 Outlook, stable (18 Nov 2025). The search returned no European regulated-networks outlook. [14]

**By name**

| Name | Moody's rating | This week |
|---|---|---|
| Enel S.p.A. | Baa1 LT Issuer Rating, stable [15] | 9M results (see Top); interim dividend EUR 0.245 (+7%). Kino arbitration award of USD 92.3m against Enel Green Power: single source, unconfirmed. [3][16] |
| Iberdrola S.A. | Baa1 LT Issuer Rating, stable [15] | Finnish approval to acquire control of Caruna: single source, unconfirmed. Reported to weigh selling German solar assets for up to EUR 200m (Bloomberg, unconfirmed). Spain grid investment to double to EUR 6bn in 2027-2030. [17][18][19] |
| Electricite de France | Baa1 LT Issuer Rating, stable [15] | EDF Invest agreed to sell its 18% of Terega to Enagas for EUR 311m (Enagas release, 13 Nov). [20] |
| E.ON SE | Baa2 Senior Unsecured (Fgn Curr), stable [15] | 9M results, guidance reaffirmed (see Top). Press reports that Germany may buy the RWE/E.ON one-third Urenco stake for up to EUR 4bn: unconfirmed. [7][21] |
| RWE AG | Baa2 LT Issuer Rating (Dom Curr), stable [15] | 9M results (see Top): 2026 guidance confirmed towards the upper end, leverage seen below the 3.0x target; Vanguard financing GBP 11.1bn non-recourse cash facilities. Urenco press reports as for E.ON. [1][21][22] |
| ENGIE SA | Baa1 LT Issuer Rating, stable [15] | No material credit news. |

Note: No rating action or outlook change on any of the six names in the window. [15]

**Notes**

- This agent has no prepared utilities file: the outlook was found by adapting the telecoms lookup, and only the third search (no sector filter) returned a European utilities outlook. A 2027 edition may be due; none was returned.
- EDF: the news search on the EDF entity returned one unrelated article; the Terega sale came from a topic search, so EDF news may be under-captured.
- No call transcripts for E.ON or RWE; the latest filings Moody's holds (E.ON Q1 2026, RWE 9M 2025) predate these results and were not used.
- Iberdrola's 9M results (22 Oct) and ENGIE's 9M update (5 Nov) predate the window and are not repeated.

**Sources**

[1] Moody's (searchNews) · RWE increases earnings in first nine months of 2026 (RWE release via Gulf Oil & … · 2026-11-11
[2] Moody's (getCreditOpinion) · RWE AG: Update following affirmation of Baa2 rating · PBC_1492134, outlook and downgrade factors · 2026-08-26
[3] Moody's (searchNews) · Enel nine-month 2026 results release (Targeted News Service) · 2026-11-12
[4] Moody's (searchNews) · Enel stock in focus after nine-month profit rises 6% (Ad Hoc News) · 2026-11-13
[5] Moody's (searchNews) · Enel 9-Month Profit And Revenue Up (Finanz Nachrichten) · 2026-11-12
[6] Moody's (getCreditOpinion) · ENEL S.p.A.: Update to credit analysis · PBC_1482005, outlook and downgrade factors · 2026-05-20
[7] Moody's (searchNews) · E.ON stock: E.ON reaffirms 2026 guidance after nine-month results (Ad Hoc News) · 2026-11-13
[8] Moody's (searchNews) · E.ON SE Reports Earnings Results for the Third Quarter and Nine Months … · 2026-11-11
[9] Moody's (getCreditOpinion) · E.ON SE: Update following affirmation of Baa2 rating · PBC_1488447, outlook section · 2026-07-09
[10] Moody's (searchNews) · ECB's Nagel says another rate hike highly probable (Forex Factory) · 2026-11-16
[11] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Morningstar / … · 2026-11-13
[12] Moody's (searchNews) · Pound To Euro Week-Ahead Forecast: BoE Rate-Hike Bets Back In Focus … · 2026-11-16
[13] Moody's (searchAllDocuments) · Sizewell C Limited: Update to credit analysis · PBC_1498271 (Credit Opinion) · 2026-11-11
[14] Moody's (searchAllDocuments) · Unregulated Electric & Gas Utilities - Europe: 2026 Outlook - Stable · PBC_1464527 (Outlook) · 2025-11-18
[15] Moody's ratings (getEntityRatings) · 2026-11-16
[16] Moody's (searchNews) · Enel to pay $92 million following arbitration ruling on the Kino project (CE … · 2026-11-10
[17] Moody's (searchNews) · Iberdrola takes a step closer to conquering Finland (CE Noticias Financieras) · 2026-11-13
[18] Moody's (searchNews) · Iberdrola is said to weigh sale of German solar assets (MSN, citing Bloomberg) · 2026-11-11
[19] Moody's (searchNews) · Iberdrola Spain to double network investment to EUR 6bn in 2027-2030 (Iberdrola … · 2026-11-10
[20] Moody's (searchNews) · Enagas agrees to acquire an additional 18% stake in Terega (Enagas release) · 2026-11-13
[21] Moody's (searchNews) · Germany Eyes EUR 4 Billion Buyout of RWE and E.ON's Urenco Stake (OilPrice.com, … · 2026-11-13
[22] Moody's (searchNews) · RWE stock: Strong earnings and major UK wind venture advance (Ad Hoc News) · 2026-11-14

Daily sector news tab updated 16 Nov 2026 06:39 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/generic-news-utilities/dashboard/dashboard.html (not published as an Artifact in this run).
