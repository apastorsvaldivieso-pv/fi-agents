**Daily sector news: Santander, BNP Paribas, UniCredit** (72h to 15 Nov 2026 23:37 UTC (from 12 Nov 2026 23:37 UTC); 3 names)

UniCredit raised USD 3.5bn of senior non-preferred notes in the US on 13 Nov, its first US issue since 2021; nothing material for Santander or BNP Paribas. [1]

**Top items, last 72 hours**

- [NEW] **UniCredit** (Funding): On 13 Nov UniCredit issued USD 3.5bn of MREL-eligible senior non-preferred notes in three tranches (initial coupons 5.970% to 6.585%), settling 19 Nov. The company calls it its first US issue since 2021 and the start of 2027 pre-funding. *Why it matters:* The company expects a Baa2 rating from Moody's, the level of UniCredit's junior senior unsecured debt, on review for upgrade since 21 Jul 2026. [1][2][3]

**Macro**

- (UK): Headlines point to pressure on the Bank of England to raise rates again, with UK price data due. [4]
- (Euro area): Euro area bond yields rose on 13 Nov, with Italy flagged for a possible sovereign upgrade (headline only). [5]

**Sector**

- (Moody's): The search returned no Moody's rating action, sector or issuer comment, in-depth, issuer profile or credit opinion on the three listed names in the window.
- **Greek banks (not on the list)** (Research): Moody's said on 13 Nov that the Greek competition commission's proposals are unlikely to erode the big four banks' deposit franchises. [6]
- (Outlook): Latest Moody's outlooks: global banks 2026 stable (3 Dec 2025); Spain, France and Italy banking systems stable (all 9 Feb 2026). [7]

**By name**

| Name | Moody's rating | Last 72 hours |
|---|---|---|
| Banco Santander | A1 LT Issuer Rating, stable [8] | No material credit news. |
| BNP Paribas | A1 LT Issuer Rating, stable [8] | No material credit news. |
| UniCredit | A3 Senior Unsecured, stable; BCA baa2 and junior senior, subordinated and preferred ratings on review for upgrade [2][8] | USD 3.5bn senior non-preferred issue, 13 Nov (above). [1] |

Note: UniCredit's review for upgrade dates from 21 Jul 2026; Moody's ties a BCA upgrade to UniCredit gaining control of and consolidating Commerzbank. [2][3]

**Notes**

- Banco Santander resolved to Banco Santander, S.A. (Spain), Moody's org 383200; the first name match, Open Bank, S.A., is a subsidiary and was rejected. News filed under that record was mostly unrelated; a check on Moody's unrated company record for Santander found nothing material either.
- Left out as older than the window: UniCredit's third-quarter results (9 Nov), Orcel's expectation of the remaining Commerzbank approvals by end-November (Reuters, 9 Nov, retold by automated outlets in the window) and BNP Paribas's third-quarter results and buyback (28 Oct).
- Moody's document searches filter by whole days (12 to 15 Nov); documents dated 12 Nov were treated as before the window.

**Sources**

[1] Moody's (searchNews) · UniCredit USD 3.5bn senior non-preferred issue · UniCredit press release 'UniCredit successfully returns to the US fixed-income market … · 2026-11-13
[2] Moody's (searchAllDocuments) · Moody's Ratings places UniCredit S.p.A. on review for upgrade · Rating Action PR_526711 · 2026-07-21
[3] Moody's (getCreditOpinion) · UniCredit S.p.A.: Update following placement of ratings on review for upgrade · PBC_1490860, sections FactorsLeadingToUpgrade, RatingOutlook · 2026-07-30
[4] Moody's (searchNews) · Bank of England rate headlines · Headlines: 'BOE's case to raise rates again may strengthen on UK price data' (WN), 'BOE … · 2026-11-15
[5] Moody's (searchNews) · Euro area bond yields · Headline: 'Eurozone bond yields rise; Italy might get ratings upgrade' (MSN US) · 2026-11-13
[6] Moody's (searchAllDocuments) · Banks - Greece: Greek competition commission's proposals unlikely to erode big … · Sector Comment PBC_1502178 · 2026-11-13
[7] Moody's (searchAllDocuments) · Banks - Global 2026 Outlook; Banking System Outlooks Spain, France, Italy · Outlook PBC_1462959 (global, 2025-12-03); PBC_1471281 (Spain), PBC_1470906 (France), … · 2026-02-09
[8] Moody's ratings (getEntityRatings) · 2026-11-15

Dashboard: "Daily sector news" tab updated at 2026-11-15 23:40 UTC, page at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-06-banks-own-list/dashboard/dashboard.html (not published to a link in this run).
