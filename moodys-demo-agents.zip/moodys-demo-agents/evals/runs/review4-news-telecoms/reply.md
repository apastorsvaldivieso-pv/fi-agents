**Daily sector news: European telecoms, last 7 days** (168h (7 days) to 15 Nov 2026 23:37 UTC; 15 names)

Vodafone's half-year showed a EUR 4.85bn German impairment and net debt up to EUR 33.5bn alongside raised guidance; Telenor and Telia both bought Nordic assets. Moody's took no rating action on the list in the window. [1]

**Top this week**

- **Vodafone** (Results): H1 FY27 (10 Nov): basic loss per share of 20.75 eurocents vs earnings of 3.38c, after a EUR 4.85bn Germany impairment; net debt rose to EUR 33.5bn from EUR 25.4bn at 31 March on the VodafoneThree buyout and Safaricom. Guidance raised to 7% organic adjusted EBITDA and 21% adjusted FCF growth at the midpoint. *Why it matters:* Moody's names failure to turn Germany around and debt/EBITDA not staying below 3.3x as downgrade factors. [1][2][3]
- **Telenor** (Deal): Telenor Sverige completed the purchase of 57.5% of Bahnhof's shares (87.9% of votes) for about USD 363m and made a mandatory offer of SEK 62 a share for the rest; it held about 66.9% of shares by 13 Nov. *Why it matters:* Moody's positive outlook includes no M&A beyond GlobalConnect and could return to stable on debt-funded acquisitions. [4][5][6][7]
- **Telia** (Deal): Binding agreement on 12 Nov to buy Telavox's Nordic enterprise customer base for SEK 3.8bn plus up to SEK 0.2bn earn-out; the base brings about SEK 1.1bn of annual revenue. Funding not stated in the sources returned. *Why it matters:* Moody's stable outlook expects adjusted gross debt/EBITDA below 3.0x and RCF/net debt above 22%. [8][9][10]

**Macro**

- US and euro-area government bond yields rose on 13 Nov. [11]
- Moody's 2027 credit conditions outlook (9 Nov): credit will weaken as higher rates and energy costs counter the AI tailwind. [12]

**Sector**

- The search returned no Moody's rating actions on European telecoms dated in the window. Research on the list: an issuer profile on Deutsche Telekom (9 Nov, LTM June 2026). [13]
- Latest Moody's sector outlook: Telecommunications - Global, stable (27 Oct 2026), as solid demand and declining capital intensity offset a broad range of risks. [14]

**By name**

| Name | Rating | Last 7 days |
|---|---|---|
| Vodafone Group | Baa2 Senior Unsecured, Stable [15] | H1 loss on EUR 4.85bn Germany impairment; net debt EUR 33.5bn; guidance raised (see Top). [1][2] |
| Telenor | Baa1 Senior Unsecured, Positive [15] | Bahnhof: 57.5% bought, SEK 62 mandatory offer (see Top). [5][6] |
| Telia Company | Baa1 Senior Unsecured, Stable [15] | Telavox base for SEK 3.8bn (see Top). Latvia asked LMT and Tet to propose buying Telia's stakes by 17 Nov; single source, unconfirmed. [8][16] |
| Telefonica | Baa3 Senior Unsecured, Stable [15] | Q3 (12 Nov): net income EUR 802m vs EUR 276m; EBITDA guidance raised to slightly above 2.5%, revenue cut to 1-1.5%; net debt EUR 25.2bn, company-reported 2.63x; EUR 0.15 dividend. [17][18] |
| TIM | Baa3 LT Issuer Rating, Positive [15] | 9M results (reported 12 Nov): net loss attributable EUR 205m vs EUR 109m; 2026 outlook kept. Net debt not in the sources returned. [19][20] |
| VMED O2 UK | B1 CFR, under review for downgrade [15][21] | No news returned. CFR and PDR on review for downgrade since 22 Oct. Telefonica (50% owner) said on 12 Nov it would not inject equity. [18][21] |
| Deutsche Telekom | A3 Senior Unsecured, Stable [15] | No material credit news; Moody's issuer profile published 9 Nov. |
| Orange | Baa1 LT Issuer Rating, Stable [15] | No material credit news. |
| Swisscom | A2 LT Issuer Rating, Stable [15] | No material credit news. |
| Telekom Austria | A3 LT Issuer Rating, Stable [15] | No material credit news. |
| Proximus | A3 Senior Unsecured, Stable [15] | No material credit news. |
| BT Group (British Telecommunications) | Baa2 LT Issuer Rating, Stable [15] | No material credit news. |
| PPF Telecom | Baa2 LT Issuer Rating, Stable [15] | No news returned. |
| Iliad | Ba1 Senior Unsecured, Stable [15] | No material credit news. |
| Altice France | Caa1 Senior Secured Bank Credit Facility, Positive [15] | No material credit news. |

Note: Ratings as returned by Moody's on 15 Nov; no rating action on any listed name is dated in the window. Results figures are company-reported, not Moody's-adjusted. [15]

**Notes**

- Window: 8 Nov 2026 23:37 UTC to 15 Nov 2026 23:37 UTC; Moody's document searches filter by whole days (8-15 Nov).
- Deutsche Telekom (5 Nov), BT (results and pension valuation, 5 Nov) and Proximus (30 Oct) reported before the window; articles retelling those results were not treated as new.
- The Iliad news search returned only unrelated articles matching the word 'Iliad'; Moody's research searched: Sector Comment, Sector In-Depth, Issuer Comment, Issuer In-Depth, Issuer Profile, Credit Opinion.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone Group Plc Interim Report · Vodafone Group Plc interim report H1 FY27 (six months to 30 Sep 2026) · 2026-11-10
[2] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call · Half Year 2027 Vodafone Group earnings call, 10 Nov 2026 · 2026-11-10
[3] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608 · 2026-10-21
[4] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · NewsWeb (Oslo Bors), message 686452 · 2026-11-13
[5] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million · Marketline Deals · 2026-11-11
[6] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document (Bahnhof) · Cision Wire, Telenor Sverige release · 2026-11-13
[7] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480 · 2026-02-24
[8] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base · Contify Telecom News, Telia Company release · 2026-11-12
[9] Moody's (searchNews) · Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion · Telecomlead.com · 2026-11-12
[10] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649 · 2026-03-02
[11] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes · Morningstar (Dow Jones) · 2026-11-13
[12] Moody's (searchAllDocuments) · Credit Conditions - Global: 2027 Outlook · PBC_1491648 · 2026-11-09
[13] Moody's (searchAllDocuments) · Deutsche Telekom AG: Key facts and statistics - LTM ended June 2026 · PBC_1500087 · 2026-11-09
[14] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable · PBC_1496503 · 2026-10-27
[15] Moody's ratings (getEntityRatings) · Moody's ratings · 2026-11-15
[16] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet · LETA Latvian News Agency · 2026-11-13
[17] Moody's (searchNews) · Telefonica Q3 Net Income Soars As Revenue Rise; Revises Annual Growth Outlook · RTT News · 2026-11-12
[18] Moody's (searchNews) · Telefonica SA (Q3 2026) Earnings Call Highlights · Yahoo Finance (GuruFocus), Q3 2026 call highlights · 2026-11-12
[19] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September · CE Noticias Financieras · 2026-11-12
[20] Moody's (searchNews) · Telecom Italia stock keeps 2026 outlook after stronger 9M growth · Ad Hoc News Germany · 2026-11-12
[21] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559 · 2026-10-22

Dashboard: the "Daily sector news" tab was updated at 2026-11-15 23:42 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review4-news-telecoms/dashboard/dashboard.html (not published as a link in this run).
