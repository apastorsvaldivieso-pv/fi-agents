**Regulatory watch: Insurers Europe, 30 days** (17 Oct to 16 Nov 2026 (30 days); 6 names)

Four insurer-relevant regulatory items in the 30 days to 16 Nov 2026, none mapped to a Moody's metric: the biggest for the four EU names is EIOPA's updated risk-free rate documentation, which applies from 30 Jan 2027 with the revised Solvency II framework. [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EIOPA risk-free rate technical documentation (6 Nov), published, applies 30 Jan 2027 [1] | Allianz, AXA, Generali, Munich Re (Solvency II at home) | Solvency II ratio / technical provisions: not in Moody's key indicators | Watch |
| FINMA revised AML Ordinance (10 Nov), final [2] | Zurich (scope for insurers not stated on the page) | AML: no metric | Watch |
| PRA CP14/26 SM&CR Phase 2 (22 Oct), consultation [3] | Aviva | Governance: no metric | Watch |
| EU securitisation framework agreement (22 Oct), provisional [4] | Allianz, AXA, Generali, Munich Re, as EU investors (our reading) | Investment due diligence: no metric | Watch |

Note: Scope is judged at each group's home: Aviva (PRA, Solvency UK) and Zurich (FINMA, SST) are not covered by the EIOPA item; their EU subsidiaries are not counted. Zurich is measured on Zurich Insurance Company Ltd, the rated operating company.

**What changed**

- [NEW] **FINMA** (Final): FINMA published the partially revised Anti-Money Laundering Ordinance (AMLO-FINMA), in force 1 Jan 2027 with a four-month transition for self-regulation; it recognises the Swiss Insurance Association's SRO rules as minimum standards. Channel: AML, no Moody's metric. [2]
- [NEW] **EIOPA** (Published update): EIOPA updated the Solvency II risk-free rate technical documentation, applying from 30 Jan 2027: 2026 liquidity assessment, updated representative portfolios, and COP, HKD and TWD dropped from the relevant currencies. Channel: technical provisions, mapped by our judgment; no Moody's metric. *Why it matters:* Moody's has not commented on it; its Italy (26 Oct) and France (5 Nov) outlooks say the revised Solvency II regime will ease capital requirements for some insurers. [1][5][6]
- [NEW] **PRA** (Consultation): CP14/26 proposes removing pre-approval for about half of Senior Manager Functions (including Chief Actuaries) and replacing certification with reasonable steps for Solvency II firms; it covers about 560 insurance firms. Comments by 22 Jan 2027; implementation proposed for H2 2027. Channel: governance, no metric. [3]
- [NEW] **European Commission** (Legislative step): Parliament and Council reached a provisional agreement on 21 Oct to simplify the Securitisation Regulation, including streamlined due diligence and transparency requirements, and amend the CRR. The page names no insurers; we read insurers as covered as institutional investors. Awaits formal approval. Channel: investments, mapped by our judgment; no metric. [4]

**Names covered**

| Name | Country | Moody's rating |
|---|---|---|
| Allianz SE | DE | Aa2 Insurance Financial Strength, stable [7] |
| AXA SA | FR | Aa2 Insurance Financial Strength, stable [7] |
| Assicurazioni Generali S.p.A | IT | A1 Insurance Financial Strength, stable [7] |
| Zurich Insurance Company Ltd | CH | Aa2 Insurance Financial Strength, stable [7] |
| Aviva Plc | GB | A2 Senior Unsecured, stable [7] |
| Munich Reinsurance Company | DE | Aa2 Insurance Financial Strength, stable [7] |

Note: All six names resolved; none unresolved. Zurich Insurance Group AG, the listed parent, is unrated in Moody's.

**Note**

No insurer sector file exists. Moody's insurer key indicators (financial leverage, earnings coverage, high-risk assets % equity) carry no regulatory solvency ratio, so no item was mapped or ranked. The adjusted financials call returned no data for all six names. [8][9]

**Notes**

- Metrics taken from credit-opinion key indicators, as the sector-metrics rules say for a sector with no file.
- Regulators read: EIOPA, European Commission, PRA, FINMA, IAIS. BaFin, ACPR and IVASS were not checked.
- Left out: EIOPA advice to the Commission (reporting ITS, 12 Nov; Taxonomy disclosures, 30 Oct); speeches; newsletters; sanctions notices; items for banks, credit unions, funds or auditors.

**Sources**

[1] Web · EIOPA updates RFR Technical Documentation to apply from 30 January 2027 · 2026-11-06 · https://www.eiopa.europa.eu/eiopa-updates-rfr-technical-documentation-apply-30-january-2027-2026-11-06_en
[2] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[3] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[4] Web · The Commission welcomes the political agreement reached on the review of the … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[5] Moody's (searchAllDocuments) · Insurance - Italy: Outlook remains stable for life and P&C insurance · PBC_1497953 · 2026-10-26
[6] Moody's (searchAllDocuments) · Insurance - France: P&C and life outlooks stable, but industry faces sovereign … · PBC_1498854 · 2026-11-05
[7] Moody's ratings (getEntityRatings) · Moody's ratings · 2026-11-16
[8] Moody's (getCreditOpinion) · Allianz SE and Aviva Plc credit opinions, key indicators · KeyIndicatorsTable, PBC_1491936 (Allianz, 23 Oct 2026) and PBC_1478464 (Aviva, 2 Jun 2026) · 2026-10-23
[9] Moody's financials (getEntityFinancials_v2) · key_indicators, adjusted, six names, pulled 16 Nov 2026 · Insurer financials (no data returned) · 2026-11-16

Regulatory watch tab updated 16 Nov 2026 06:37 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/generic-reg-insurers/dashboard/dashboard.html (not published as an Artifact in this run).
