**Daily sector news: Telecoms, Europe** (24h, 14 Nov 2026 23:37 to 15 Nov 2026 23:37 UTC; 15 names)

Nothing material for Telecoms, Europe, in the last 24 hours.

**Notes**

- Left out as old news retold: Deutsche Telekom articles in the window repeat its Q3 results, guidance raise and a buyback disclosure dated 9 Nov; a Vodafone article repeats its earlier half-year guidance raise.
- Moody's searched in the window: rating actions, sector and issuer comments, in-depth reports, issuer profiles and credit opinions on European telecoms; the search returned none.

Daily sector news tab updated at 2026-11-15T23:39 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-01-telecoms-default/dashboard/dashboard.html (not published to a link in this session).
