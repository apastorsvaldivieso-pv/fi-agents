**Earnings: Vodafone, preview** (Next results: FY27 full year (year to 31 Mar 2027); 1 name)

Vodafone (Baa2 stable) goes into its FY27 results with Moody's-adjusted debt/EBITDA of 3.25x, 0.05x inside the 3.3x downgrade trigger, after company-reported net debt rose by €8.1 billion to €33.5 billion in H1 on the VodafoneThree and Safaricom deals. [1][2][3][4]

**Rating and outlook**

Baa2 senior unsecured (foreign currency), outlook stable, affirmed 13 Oct 2026. Credit opinion of 21 Oct 2026, which predates the H1 FY27 results of 10 Nov 2026. [1][3]

**What to watch against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to Mar 2026 [2] | below 2.5x [3] | fails to remain below 3.3x [3] | 0.05x to downgrade; 0.75x to upgrade [2][3] |
| RCF / Net debt | 33.1%, FY to Mar 2026 [2] | above 25%, sustained [3] | towards 18%, sustained [3] | already met, by 8.1 pts; 15.1 pts to downgrade [2][3] |

Note: Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade if operating performance deteriorates, "including a failure to turn around its German operations". [3]

**Sector metrics to watch**

- **EBITDA and service revenue**: Moody's-adjusted EBITDA €15,762 million, revenue €40,461 million, FY to Mar 2026. H1 FY27 company-reported organic service revenue growth 5.8%, adjusted EBITDAaL €6.5 billion. *Why it matters:* EBITDA is the denominator of the debt/EBITDA trigger. [2][5]
- **Capex and interest cover**: Moody's-adjusted (EBITDA - capex) / interest 2.39x, FY to Mar 2026; no trigger is stated on it. [2]
- **Net debt and leverage target**: Company-reported net debt €33.5 billion at 30 Sep 2026 against €25.4 billion at 31 Mar 2026: acquisitions €6,957 million, free cash outflow €845 million, dividends €544 million, buybacks €92 million, less other €474 million. Target: lower half of 2.25-2.75x net debt / EBITDAaL. *Why it matters:* The stable outlook assumes the lower half of that company range. [3][4][6]
- **Liquidity**: Cash and short-term investments €8.4 billion (€12.4 billion at 31 Mar 2026); undrawn revolving facilities €7.6 billion, company-reported, 30 Sep 2026. *Why it matters:* The outlook assumes excellent liquidity, and Moody's credits the cash balance when it assesses gross leverage. [3][4]
- **Dividends, spectrum, M&A**: Interim dividend 2.306 eurocents, up 2.5%. Licences and spectrum outflow €21 million in H1. Watch OXG equity funding in Germany and the Greece fibre JV. [4][6]

**What management guided on the last call**

- **FY27 guidance raised**: Adjusted EBITDAaL raised to €13.2-13.4 billion from €13.0-13.3 billion, adjusted free cash flow to €2.8-3.0 billion from €2.6-2.9 billion; midpoints imply 7% and 21% organic growth (call, 10 Nov 2026, and H1 report). *Why it matters:* Higher EBITDA is what moves debt/EBITDA away from the 3.3x trigger. [6][7]
- **Europe and Germany**: Europe EBITDAaL guidance of €7.6-7.9 billion held despite about €100 million hit from the European Court of Justice ruling in Germany; the class action is not expected to end before late 2027. *Why it matters:* Germany is named in both the upgrade and the downgrade triggers. [6][7]
- **Capex**: Management would "not guide to any material reduction of our capital intensity in Germany". [7]
- **OXG fibre JV**: Société Générale replaces Altice as partner. An analyst put Vodafone's equity injections at up to €1.2 billion; management said any equity would be phased over the build. *Why it matters:* Equity injections would add to net debt. [7]
- **Costs**: Over €1 billion of net Europe opex savings targeted, with over €200 million net this fiscal year. [7]

**Moody's expectations**

| Moody's forecast | FY27F | FY28F | FY29F |
|---|---|---|---|
| Debt / EBITDA | 3.1x [3] | 3.0x [3] | 2.9x [3] |
| RCF / Net debt | 29.4% [3] | 30.9% [3] | 31.7% [3] |
| (EBITDA - capex) / Interest | 2.6x [3] | 2.8x [3] | 3.0x [3] |
| Revenue (€ billion) | 43.7 [3] | 45.1 [3] | 46.0 [3] |

Note: Forecasts from the 21 Oct 2026 opinion, before the H1 net debt figure was published. [3]

**Notes**

- Vodafone reported H1 FY27 results on 10 Nov 2026, so this preview is for the FY27 full-year results. A recap of the H1 results is available on request.
- Company net debt and net leverage are Vodafone's own measures and are not the same as Moody's-adjusted debt; the Moody's figures are for the year to 31 Mar 2026 and predate the VodafoneThree buyout and Safaricom stake increase.

**Sources**

[1] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-15
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted), FY ending 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[3] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections Upgrade, Downgrade, Outlook, Key indicators · 2026-10-21
[4] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results (6-K) · Interim Report 2026 - Q4 (H1 FY27 results, period to 30 Sep 2026), submitted 10 Nov 2026, … · 2026-11-10
[5] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results (6-K) · Interim Report 2026 - Q4 (H1 FY27 results, period to 30 Sep 2026), submitted 10 Nov 2026, … · 2026-11-10
[6] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results (6-K) · Interim Report 2026 - Q4 (H1 FY27 results, period to 30 Sep 2026), submitted 10 Nov 2026, … · 2026-11-10
[7] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, event date 10 Nov 2026 · 2026-11-10

Earnings tab updated at 2026-11-15T23:39:18Z. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html
