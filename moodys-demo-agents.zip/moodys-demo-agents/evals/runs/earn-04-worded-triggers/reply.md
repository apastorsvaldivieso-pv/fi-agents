**Earnings: BNP Paribas, preview** (Latest data held by Moody's to 15 Nov 2026; 1 name)

BNP Paribas is A1 stable; its only numeric trigger is return on assets of 0.6% for an upgrade, against 0.4% at June 2026, and the downgrade triggers are worded. Moody's holds no call transcript, and the latest results filing (Q3 2025) is older than Moody's June 2026 data. [1][2][3]

**Rating and outlook**

- LT Issuer Rating A1, outlook stable, affirmed 31 Aug 2026; last downgrade 17 Dec 2024. Credit opinion dated 2 Sep 2026. [1][2]

**What to watch against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Net income / tangible assets (return on assets) | 0.4%, H1 2026 (06-26) [1] | 0.6% and above [1] | No number stated | 0.2 pp below the upgrade level [1] |

Note: Worded triggers, quoted from the opinion: upgrade if the group "manages towards lower financial leverage" with disciplined risk management, or on an upgrade of France. Downgrade if it "maintained lower regulatory capital buffers or sustained higher regulatory leverage" with weaker asset quality or profitability, on a "material risk management failure", or on weaker funding and liquidity. [1]

**Sector metrics to watch**

| Metric | Latest value and period | Basis | Trigger it bears on |
|---|---|---|---|
| Net interest margin | 0.9%, H1 2026 [1] | Moody's-adjusted | Profitability (downgrade, worded); return on assets (upgrade) |
| Cost of risk | 39 bps, 3Q25; target below 40 bps in 2025 and 2026 [3][4] | Company-reported | Asset quality and provisioning (both, worded) |
| CET1 ratio | 12.97%, Q2 2026 [5] | As reported | Regulatory capital buffers (downgrade, worded) |
| CET1 requirement (SREP) | 10.51% at 30 Sep 2025 [6] | Company-reported | Regulatory capital buffers (downgrade, worded) |
| Tangible common equity / RWA | 13.7%, H1 2026 [1] | Moody's-adjusted | Capital (downgrade, worded) |
| Problem loans / gross loans | 2.9%, H1 2026 [1] | Moody's-adjusted | Asset quality (both, worded) |
| Impaired loans / gross loans | 2.93%, Q2 2026 [5] | Reported | Asset quality (both, worded) |
| Cost / income | 60.6%, H1 2026 [1] | Moody's-adjusted | Profitability (downgrade, worded) |
| LCR | 134.77%, Q2 2026 [5] | As reported | Funding and liquidity (downgrade, worded) |
| NSFR | 108.63%, Q2 2026 [5] | As reported | Funding and liquidity (downgrade, worded) |
| Gross loans / customer deposits | 82.3%, Q2 2026 [5] | Reported | Funding (downgrade, worded) |

Note: Planned distributions: the Q3 2025 filing deducts EUR 2.3bn for the 2025 distribution project from capital at 30 Sep 2025; no later figure in the data pulled. [7]

**What the latest filing says (Q3 2025 report, period to 30 Sep 2025)**

- Company-reported: management "confirm[s] the Group's 2026 trajectory": revenue CAGR above 5% and net income CAGR above 7% for 2024-2026, jaws of about +1.5 points a year. [3]
- Company-reported targets: cost of risk below 40 bps in 2025 and 2026; RoTE of 11.5% in 2025, 12% in 2026 and 13% in 2028. [3]
- Company-reported: 3Q25 net income EUR 3,044m, up 6.1%, "in line with the >EUR 12.2bn 2025 target". [4]
- Company-reported: CET1 ratio 12.5% at 30 Sep 2025 against a SREP requirement of 10.51%; LCR 138%; leverage ratio 4.3%. [6]

**Moody's expectations**

The key indicators table in the 2 Sep 2026 opinion has no forecast columns. The outlook text expects BNP Paribas's "very stable and highly predictable profitability and sound risk profile" to continue to support its creditworthiness. [1]

**Notes**

- No earnings call transcript is held by Moody's for BNP Paribas; the latest results filing was used in its place. Moody's also holds the FY2025 annual report (period to 31 Dec 2025), but the excerpts returned held no guidance, so guidance is from the Q3 2025 report, which is older than the June 2026 data above.
- Company-reported CET1 (12.5%, Sep 2025) and the reported Q2 2026 CET1 (12.97%) are different periods; Moody's own capital measure is tangible common equity / RWA.
- Preview chosen because no mode was given and Moody's holds no call transcript from the last 21 days. No consensus comparison: Moody's data has none.

**Sources**

[1] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation · PBC_1491623: triggers, outlook, key indicators · 2026-09-02
[2] Moody's ratings (getEntityRatings) · BNP Paribas · 2026-08-31
[3] Moody's (searchCompanyFilings) · BNP Paribas Q3 2025 report: 2024-2026 trajectory · Interim Report 2025 - Q3, period to 30 Sep 2025, page 9 · 2025-09-30
[4] Moody's (searchCompanyFilings) · BNP Paribas Q3 2025 report: key points · Interim Report 2025 - Q3, period to 30 Sep 2025, page 32 · 2025-09-30
[5] Moody's financials (getEntityFinancials_v2) · Bank Focus, consolidated, Q2 2026 (period end 30 Jun 2026) · BNP Paribas · 2026-06-30
[6] Moody's (searchCompanyFilings) · BNP Paribas Q3 2025 report: capital and liquidity · Interim Report 2025 - Q3, period to 30 Sep 2025, page 42 · 2025-09-30
[7] Moody's (searchCompanyFilings) · BNP Paribas Q3 2025 report: prudential capital reconciliation · Interim Report 2025 - Q3, period to 30 Sep 2025, page 69 · 2025-09-30

Earnings tab updated at 2026-11-15T23:39:24Z. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html (not published as an Artifact in this run).
