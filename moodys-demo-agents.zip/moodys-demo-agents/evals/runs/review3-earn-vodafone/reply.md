**Earnings: Vodafone, recap** (H1 FY27 results of 10 Nov 2026 (six months to 30 Sep 2026); 1 name)

Vodafone raised its FY27 guidance on 10 Nov, but company-reported net debt rose to €33.5bn from €25.4bn on the VodafoneThree buyout and Safaricom, while Moody's-adjusted debt/EBITDA was 3.25x at March 2026 against a 3.3x downgrade trigger. [1][2][3][4]

**Results against the credit view**

- (Guidance): FY27 guidance raised (company-reported): Adjusted EBITDAaL €13.2-13.4bn from €13.0-13.3bn, Adjusted free cash flow €2.8-3.0bn from €2.6-2.9bn; Europe EBITDAaL kept at €7.6-7.9bn. In July management had said it was tracking the upper end of the old ranges. [1][5]
- (H1 trading): Revenue €21.9bn (+11.4%), Adjusted EBITDAaL €6.5bn (+6.4% organic). Germany: organic service revenue +0.4%, Adjusted EBITDAaL €2,139m vs €2,191m; management said the ECJ ruling cost about €100m of EBITDA, absorbed within unchanged Europe guidance. [1][5]
- (Profit or loss): Loss for the period €3,597m (H1 FY26: profit €1,052m); attributable to owners, a loss of €4,789m (profit €829m). Income tax expense was €3,224m, including deferred tax asset write-downs in the UK and Germany whose size was not found in the report. [6]
- (One-offs): €4.85bn goodwill impairment on Germany, cutting its value in use to €25.5bn, mainly from a higher discount rate (8.0%). Partly offset by a €3,022m gain on remeasuring the previously held Safaricom stake. [6]
- (Net debt): Company-reported net debt €33,473m vs €25,411m at 31 Mar 2026 (+€8,062m): acquisitions €6,957m (VodafoneThree 49% buyout €5,019m, Safaricom 15% €1,379m, Safaricom net debt €537m), free cash outflow €845m, dividends €544m, buybacks €92m, FX €98m, less other inflows €474m (incl. €908m VodafoneZiggo loan repaid). [2]
- (Liquidity): Cash and short-term investments €8.4bn (€12.4bn at March); undrawn RCFs €7.6bn, maturing 2031 (€4.1bn) and 2028 (US$4.0bn). Gross debt €42.7bn vs €38.6bn, bonds up €2,264m mainly from new issues. No maturity schedule in the pages pulled. [1][2]
- (Capex and returns): Capital additions €3,320m (€2,800m); restructuring and integration costs to peak at c.€0.7bn in FY27. Interim dividend 2.306 eurocents (+2.5%). Management said it would not guide to a material cut in German capital intensity. [1][2][5]
- (Legal): Kenya's High Court voided the 15% Safaricom purchase on 15 Sep 2026; on 13 Oct the Court of Appeal kept the status quo pending appeal, so Vodafone still consolidates Safaricom. Germany: a €239m teleshopping damages claim and the 1&1 competition case (hearing January 2027). [6]

**Against Moody's triggers**

| Metric | Latest, Moody's-adjusted | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to Mar 2026 [3] | below 2.5x [4] | fails to remain below 3.3x [4] | 0.75x to upgrade; 0.05x to downgrade [3][4] |
| RCF / Net debt | 33.1%, FY to Mar 2026 [3] | above 25%, sustained [4] | towards 18%, sustained [4] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [3][4] |

Note: Worded triggers: upgrade if operating performance improves sustainably, "particularly in Germany"; downgrade on "a failure to turn around its German operations". Moody's forecasts for FY2027: debt/EBITDA 3.1x, RCF/net debt 29.4%. [4]

**What it means for the rating and outlook**

Baa2 senior unsecured, stable outlook, affirmed 13 Oct 2026. The credit opinion of 21 Oct 2026 predates these results. Debt/EBITDA of 3.25x is 0.05x below the 3.3x downgrade trigger, and company net debt has risen €8.1bn since March, mainly on the VodafoneThree buyout and Safaricom. The opinion cites "reduced financial flexibility following the buyout of VodafoneThree", and the rating action measured liquidity "pro forma for the UK buyout"; Safaricom is not in the sections pulled. The outlook assumes Vodafone stays "within the lower half of its net leverage target range" (company basis 2.25-2.75x); the H1 report pulled gives no ratio. Moody's has published no comment on these results. [1][2][3][4][7][8]

**Notes**

- All transcript and filing figures are company-reported; company net debt is not Moody's-adjusted debt. The interim report is titled "Interim Report 2026 - Q4" but covers H1 FY27.
- Beat or miss is against company guidance only: Moody's forecasts are full-year and Moody's-adjusted, so half-year figures are not compared with them. No consensus comparison.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone Group H1 FY27 Results: highlights and outlook · Interim Report 2026 - Q4 (H1 FY27 results, six months to 30 Sep 2026, dated 10 Nov 2026), … · 2026-11-10
[2] Moody's (searchCompanyFilings) · Vodafone Group H1 FY27 Results: cash flow and funding · Interim Report 2026 - Q4 (H1 FY27 results, dated 10 Nov 2026), pp. 4, 10-12: cash flow, … · 2026-11-10
[3] Moody's financials (getEntityFinancials_v2) · Key indicators, Moody's-adjusted, FY ending 31 Mar 2026 · 2026-03-31
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation (Credit Opinion) · PBC_1496608, sections Summary, CreditStrengths, CreditChallenges, upgrade and downgrade … · 2026-10-21
[5] Moody's (searchCompanyFilings) · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call · earnings_call_transcript: Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 … · 2026-11-10
[6] Moody's (searchCompanyFilings) · Vodafone Group H1 FY27 Results: financial statements and notes · Interim Report 2026 - Q4 (H1 FY27 results, dated 10 Nov 2026), pp. 13-14, 16, 18, 22-24: … · 2026-11-10
[7] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-15
[8] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook (Rating Action) · PR_528027 · 2026-10-13

Dashboard: Earnings tab updated at 2026-11-15 23:40 UTC, page at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review3-earn-vodafone/dashboard/dashboard.html (not published: Artifact publish skipped in this test run).
