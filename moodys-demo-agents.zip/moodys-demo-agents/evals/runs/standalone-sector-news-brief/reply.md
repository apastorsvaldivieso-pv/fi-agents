**Daily sector news: Vodafone, Telefonica, Telia** (72h to 16 Nov 2026 06:17 UTC (from 13 Nov 2026 06:17 UTC); 3 names)

Nothing material for Telecoms, Europe (Vodafone, Telefonica, Telia), in the last 72 hours.

**Notes**

- Vodafone's half-year results and full-year guidance raise were reported again in the window, but the results came out on 10 Nov 2026, before it; they are not shown as new.
- The searches returned no Moody's rating action or research on European telecoms in the window.

Dashboard: the "Daily sector news" tab was updated at 06:18 UTC on 16 Nov 2026. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/standalone-sector-news-brief/dashboard/dashboard.html (not published as an Artifact in this run).
