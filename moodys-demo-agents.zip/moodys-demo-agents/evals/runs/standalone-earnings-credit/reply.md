**Earnings: Vodafone, recap** (H1 FY27 results (six months to 30 Sep 2026), call of 10 Nov 2026; 1 name)

Vodafone (Baa2 stable) raised FY27 guidance, but company net debt rose by €8.1bn to €33.5bn in H1 on the VodafoneThree buyout and Safaricom; Moody's-adjusted debt/EBITDA was 3.25x at March 2026 against a 3.3x downgrade trigger, and the 21 Oct 2026 credit opinion predates these results. [1][2][3]

**Results against the credit view**

- (Guidance): Company-reported: FY27 guidance raised to Adjusted EBITDAaL €13.2-13.4bn (from €13.0-13.3bn in July) and Adjusted FCF €2.8-3.0bn (from €2.6-2.9bn); Europe EBITDAaL kept at €7.6-7.9bn. H1 Adjusted EBITDAaL €6.5bn, up 6.4% organically. [4]
- (Against Moody's forecast): No like-for-like test: Moody's forecasts are full-year (FY2027F revenue €43.7bn, debt/EBITDA 3.1x, RCF/net debt 29.4%); H1 total revenue was €21.9bn, company-reported. [4][5]
- (Profit or loss): Company-reported loss for the period €3,597m (H1 FY26: profit €1,052m); owners of the parent €(4,789)m (H1 FY26: €829m). Inside it: Germany goodwill impairment €4,850m, offset by a €3,022m gain remeasuring the prior Safaricom stake, plus deferred tax asset charges. [6]
- (Net debt): Company net debt €33,473m vs €25,411m at 31 Mar 2026 (+€8,062m): free cash outflow €845m, acquisitions and disposals €6,957m (VodafoneThree 49% €5,019m, Safaricom 15% €1,379m, Safaricom net debt €537m), dividends €544m, buybacks €92m, FX €98m, less other movements €474m. [3]
- (Liquidity): Company-reported cash and short-term investments €8.4bn (€12.4bn at March); undrawn RCFs €7.6bn maturing 2028 and 2031. Gross debt €42.7bn (€38.6bn), with new bonds issued. A maturity schedule was not in the excerpts pulled. [3]
- (Capex and returns): Company-reported capital additions €3,320m (H1 FY26: €2,800m). Interim dividend 2.306 eurocents, up 2.5%. On the call, management said it would not guide to any material cut in German capital intensity. [3][7]
- (Legal): Kenya's High Court voided the Safaricom 15% purchase on 15 Sep 2026; the Court of Appeal ordered the status quo kept on 13 Oct pending appeal. A €239m teleshopping damages claim and the 1&1 competition case continue in Germany. [8]

**Against Moody's triggers**

| Metric (Moody's-adjusted) | Latest, FY to 31 Mar 2026 | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x [2] | below 2.5x [5] | fails to stay below 3.3x [5] | 0.05x to downgrade; 0.75x to upgrade [2][5] |
| RCF / Net debt | 33.08% [2] | above 25% sustained [5] | towards 18% [5] | already met, by 8.08pp; 15.08pp to 18% [2][5] |

Note: Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade on "a failure to turn around its German operations". [5]

**What it means for the rating and outlook**

- Baa2 senior unsecured, stable, affirmed 13 Oct 2026. The outlook expects debt/EBITDA below 3.3x, RCF/net debt around 30% and operation "within the lower half of its net leverage target range" (company target 2.25-2.75x). [1][5][9]
- The opinion (21 Oct 2026) predates these results. Company net debt is up €8.1bn since the March period of the adjusted figures; Moody's cites "reduced financial flexibility following the buyout of VodafoneThree". Safaricom: not in the sections pulled. [3][5]
- Moody's forecast for FY2027 is debt/EBITDA 3.1x and net debt/EBITDA 2.6x. No Moody's comment on these results was found in the last 45 days. [5][9]

**Notes**

- Mode: recap, as asked. Company net debt and EBITDAaL are Vodafone's own measures, not Moody's-adjusted; the company did not state an H1 net debt/EBITDAaL ratio in the excerpts pulled.
- Moody's-adjusted metrics are for the year to 31 Mar 2026 and do not yet reflect the VodafoneThree buyout or the Safaricom consolidation.

**Sources**

[1] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-16
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted), FY to 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[3] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results: cash flow, net debt, funding · Interim Report 2026 - Q4 (H1 FY27 results, 6 months to 30 Sep 2026), pp. 2, 4, 10-12 · 2026-11-10
[4] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results: highlights and outlook · Interim Report 2026 - Q4 (H1 FY27 results, 6 months to 30 Sep 2026), pp. 1, 3 · 2026-11-10
[5] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608: triggers, outlook, key indicators, summary · 2026-10-21
[6] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results: income statement and impairment · Interim Report 2026 - Q4 (H1 FY27 results), pp. 13, 18, 21 (income statement, notes 3, 9) · 2026-11-10
[7] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 Nov 2026 · 2026-11-10
[8] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results: contingent liabilities · Interim Report 2026 - Q4 (H1 FY27 results), pp. 3, 23-24 (note 11) · 2026-11-10
[9] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action · 2026-10-13

Earnings tab updated 2026-11-16 06:18 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/standalone-earnings-credit/dashboard/dashboard.html (not published: Artifact publish skipped in this test run).
