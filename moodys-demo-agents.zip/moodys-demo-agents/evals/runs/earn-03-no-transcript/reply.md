**Earnings: Iliad Holding, recap** (Latest Moody's data to 15 Nov 2026; 1 name)

No call transcript or results filing for Iliad Holding S.A.S. in Moody's data, so this recap rests on Moody's figures alone: LTM June 2026 debt/EBITDA of 4.20x is 0.70x above the 3.5x upgrade trigger; Ba2 CFR, stable outlook. [1][2][3]

**Results against the credit view**

- **Results sources** (Missing): Moody's holds no earnings call transcript and no interim or annual results report for Iliad Holding S.A.S., so guidance, beat or miss, profit or loss, company net debt, liquidity, maturities, capex and distributions cannot be given. [4][5]
- **LTM to 30 Jun 2026** (Moody's-adjusted): Revenue EUR 16,712M (FY2025: EUR 15,501M); EBITDA EUR 7,906M (EUR 7,445M); total debt EUR 33,195M (EUR 31,123M); debt/EBITDA 4.20x (4.18x); RCF/net debt 13.99% (15.68%); (EBITDA - capex)/interest 2.27x (2.14x). [1]
- **2026F** (Moody's forecast): The credit opinion forecasts 2026 revenue of EUR 17.4bn, debt/EBITDA of 4.3x and RCF/net debt of 14.5%. The LTM figures are not full-year, so no beat or miss is stated. [2]
- **Last 45 days** (Moody's comment): No Moody's issuer comment, rating action or credit opinion on Iliad Holding was published between 1 Oct and 15 Nov 2026. [6]

**Against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 4.20x, LTM Jun 2026 [1] | below 3.5x [2] | remains well above 4.0x [2] | 0.70x to upgrade level; 0.20x above 4.0x [1][2] |
| RCF / Net Debt | 13.99%, LTM Jun 2026 [1] | towards 25% [2] | no number stated [2] | 11.0 pp to upgrade level [1][2] |

Note: Worded triggers: upgrade needs "strong and stable revenue growth, with a sustainable EBITDA margin"; downgrade also if "Moody's-adjusted free cash flow (FCF) weakens significantly" or on large debt-financed acquisitions or shareholder distributions. [2]

**What it means for the rating and outlook**

- **Position**: Ba2 Corporate Family Rating, outlook stable, upgraded from Ba3 on 19 Jun 2026. Leverage sits between the two debt/EBITDA trigger levels; RCF/net debt fell from 15.68% to 13.99% between FY2025 and LTM June 2026. [1][3]
- **Outlook wording**: The opinion of 30 Jun 2026 expects "some improvement in credit metrics ahead of the SFR acquisition" and "a reduction in leverage following the completion of the transaction"; it lists execution risk on the proposed SFR acquisition as a credit challenge. [2]
- **Timing**: The opinion and the latest adjusted figures both stop at 30 Jun 2026. The change in company-reported net debt since then, and its cause, cannot be given: Moody's holds no results filing for the issuer. [1][2][5]

**Notes**

- Recap chosen because the user asked for one; with no transcript and no filing it covers only what Moody's data supports.
- Iliad Holding S.A.S. (Ba2 CFR) was resolved by name; Iliad S.A. (Ba1) is a separate rated entity and is not covered here.
- The opinion's key indicators show 2025 debt/EBITDA of 4.3x; the current financials feed shows 4.18x for FY2025. The table uses the financials feed.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted), LTM 30 Jun 2026 and FY2025 · Iliad Holding S.A.S. · 2026-06-30
[2] Moody's (getCreditOpinion) · Iliad Holding credit opinion · PBC_1488484, Iliad Holding S.A.S.: Update following rating upgrade to Ba2 · 2026-06-30
[3] Moody's ratings (getEntityRatings) · Iliad Holding S.A.S. ratings · 2026-06-19
[4] Moody's (searchCompanyFilings) · Iliad Holding call transcripts · earnings_call_transcript search: not found · 2026-11-15
[5] Moody's (searchCompanyFilings) · Iliad Holding results filings · interim and annual search: not found after retries · 2026-11-15
[6] Moody's (searchAllDocuments) · Moody's comment on results · Iliad Holding results; Issuer Comment, Rating Action, Credit Opinion; 1 Oct-15 Nov 2026: … · 2026-11-15

Earnings tab updated at 2026-11-15 23:41 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html. Dashboard not published: Artifact publishing skipped in this run.
