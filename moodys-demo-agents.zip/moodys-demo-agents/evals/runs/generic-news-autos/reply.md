**Daily sector news: Auto manufacturers, Europe** (72h to 16 Nov 2026 06:34 UTC; 8 names)

Renault placed a EUR 750m 5% bond due 2032 to pre-fund refinancing; BMW, on negative outlook, faces a 720,796-vehicle US recall and a second week of Mini stoppage at Oxford. [1][2][3]

**Top this week**

- **Renault** (Funding): Renault placed a EUR 750m bond on 13 Nov, maturing 19 Feb 2032 with a 5% coupon, for general corporate purposes including anticipating refinancing. *Why it matters:* Moody's downgrade trigger includes Moody's-adjusted gross leverage above 3x for a prolonged period with a meaningfully weaker net cash position. [1][4]
- **BMW** (Operations): NHTSA announced on 13 Nov a US recall of 720,796 vehicles over water pumps that can short-circuit and catch fire; no cost was stated. Mini production at Oxford is halted for a second week over wire-harness supply from Ukraine (reported 16 Nov). *Why it matters:* Moody's negative outlook cites depressed free cash flow and uncertainty over the timing of a margin recovery. [2][3][5][6]
- **Mercedes-Benz** (Restructuring): Management has warned German plants could close and asked staff to work longer hours for the same pay; labour leaders say they will not accept closures (reported 13-14 Nov, ahead of pay talks). *Why it matters:* Moody's stable outlook assumes cost savings support an EBIT margin of around 5% in 2026, moving towards 7% in 2027. [7][8]

**Macro**

- Bank of England rate-hike expectations are back in focus ahead of UK inflation data; one outlet expects further rises in 2027. [9]
- Euro area and US bond yields rose; the euro softened below 1.1050 on bets of a Fed hike. [10]

**Sector**

- The searches returned no Moody's rating actions and no Moody's research (sector or issuer comments and in-depths, issuer profiles, credit opinions) on European automotive in the window.
- **Latest Moody's sector outlook**: Automotive Manufacturing, Global, 1 Jun 2026: negative, on tariffs, trade disputes and the Middle East conflict; light vehicle sales nearly flat in 2026 and 2027. [11]

**By name**

| Name | Rating (class, outlook) | Last 72h |
|---|---|---|
| BMW | A2 LT Issuer (FC), negative [3] | US recall of 720,796 vehicles; Mini Oxford halted a second week. [2][5] |
| Mercedes-Benz Group | A2 LT Issuer (DC), stable [3] | German plant closures threatened ahead of pay talks. [7] |
| Volkswagen | Baa1 LT Issuer, stable [3] | No material credit news. |
| Renault | Baa3 LT Issuer (DC), stable [3] | EUR 750m 5% bond due Feb 2032 placed 13 Nov. [1] |
| Stellantis | Baa3 LT Issuer (DC), stable [3] | CEO warned component and raw-material costs will keep rising through 2028 (reported 15 Nov; single source, unconfirmed). [12] |
| Jaguar Land Rover Automotive | Ba1 CFR (FC), negative [3] | No material credit news. |
| Volvo Car | Ba1 CFR, negative [3] | No material credit news. |
| Aston Martin Lagonda | Caa1 CFR, stable [3] | No material credit news. |

Note: List built from a Moody's sector search: rated European car makers, parent entities only; funding vehicles and suppliers dropped.

**Notes**

- No prepared list exists for this sector: 8 names survived the sector search (fewer than 15). Porsche, Ferrari and truck makers were not returned and were not added.
- No Moody's 2027 automotive outlook was returned; the 1 Jun 2026 global outlook is the latest the search found.
- Renault's rating history shows Baa3 'Reinstated' on 14 Sep 2026, while its 21 Oct credit opinion is titled 'following rating upgrade to Baa3'.

**Sources**

[1] Moody's (searchNews) · Renault Group successfully issues a EUR 750 million bond (Financial Services … · Renault Group release, 13 Nov 2026 · 2026-11-13
[2] Moody's (searchNews) · BMW's 720,000-car recall comes with a second warning · TheStreet, citing NHTSA and Reuters · 2026-11-14
[3] Moody's ratings (getEntityRatings) · 2026-11-16
[4] Moody's (getCreditOpinion) · Renault S.A.: Update following rating upgrade to Baa3 · PBC_1495405, downgrade factors · 2026-10-21
[5] Moody's (searchNews) · Mini production in Oxford to be halted for second week · Oxford Mail · 2026-11-16
[6] Moody's (getCreditOpinion) · BMW AG: Update to credit analysis following outlook change to negative · PBC_1488472, rating outlook · 2026-06-30
[7] Moody's (searchNews) · Mercedes workers to fight factory closures · TopAuto; CE Noticias Financieras · 2026-11-14
[8] Moody's (getCreditOpinion) · Mercedes-Benz Group AG: Update to credit analysis following rating affirmation · PBC_1478683, rating outlook · 2026-06-10
[9] Moody's (searchNews) · Pound to Euro week-ahead: BoE rate-hike bets back in focus; BOE likely to raise … · ExchangeRates.org; Forex Factory headlines · 2026-11-16
[10] Moody's (searchNews) · Euro softens below 1.1050 as traders ramp up Fed rate hike bets; Eurozone, US … · FXStreet; MSN headlines · 2026-11-16
[11] Moody's (searchAllDocuments) · Automotive Manufacturing - Global: Outlook remains negative as economic growth … · PBC_1484252, Outlook · 2026-06-01
[12] Moody's (searchNews) · Stellantis warns of continued price rises for electronic components and raw … · BusinessAM · 2026-11-15

Dashboard: the Daily sector news tab was updated at 06:37 UTC on 16 Nov 2026, page at /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/generic-news-autos/dashboard/dashboard.html (not published as an Artifact in this run).
