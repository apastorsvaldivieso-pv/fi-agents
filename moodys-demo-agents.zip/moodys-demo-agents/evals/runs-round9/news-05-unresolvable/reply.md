**Daily sector news: Vodafone, Orange** (72h, 12 Nov 2026 23:14 UTC to 15 Nov 2026 23:14 UTC; 2 names)

Nothing material for Telecoms, Europe, in the last 72 hours.

**Unresolved names:** Zzyzx Fakecorp Holdings (no match in Moody's; the name search returned no candidates). Not guessed, not included.

**Notes**

- Vodafone's half-year results and guidance upgrade came out on 10 Nov 2026 (H1 FY27 earnings call, via Moody's searchCompanyFilings), before the window; articles in the window retell them and are not counted as new.

Daily sector news tab updated at 15 Nov 2026 23:16 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html (not published as an Artifact in this run).
