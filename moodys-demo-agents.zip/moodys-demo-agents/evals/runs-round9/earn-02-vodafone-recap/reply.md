**Earnings: Vodafone, recap** (H1 FY27 (six months to 30 Sep 2026), results and call of 10 Nov 2026; 1 name)

Vodafone raised FY27 guidance, but company net debt rose €8.1bn to €33.5bn on the VodafoneThree buyout and Safaricom, alongside a €4.85bn German impairment; Moody's Baa2 stable view predates the results, with adjusted debt/EBITDA 3.25x against a 3.3x downgrade trigger. [1][2][3][4][5]

**Results against the credit view**

- (Guidance): Company-reported: FY27 guidance raised; the new midpoints imply organic growth of 7% in adjusted EBITDA and 21% in adjusted free cash flow, and the Europe outlook was kept despite a €100m ECJ ruling hit. An analyst said the old upper end is the new midpoint; the ranges were not in the filing excerpts pulled. [6]
- (H1 vs forecast): Company-reported: adjusted EBITDAaL €6,451m, up 12.6% (6.4% organic, per the call); adjusted free cash flow an outflow of €440m, €143m better than last year. Moody's forecasts are full-year only (FY27F debt/EBITDA 3.1x), so there is no half-year comparison. [1][4][6]
- (Loss): Basic loss per share of 20.75 eurocents (H1 FY26: earnings of 3.38c), after a €4.85bn goodwill impairment on Germany (discount rate 8.0% vs 7.5%), partly offset by a €3,022m one-off gain on remeasuring the earlier Safaricom stake. [1][2]
- (Net debt): Company-reported net debt €33,473m vs €25,411m at 31 Mar 2026 (+€8,062m): acquisitions €6,957m (VodafoneThree €5,019m, Safaricom stake €1,379m, Safaricom net debt €537m), free cash outflow €845m, dividends €544m, buybacks €92m, FX €98m, less other movements of €474m (including €908m VodafoneZiggo loan repaid). [1]
- (Liquidity): Cash and short-term investments €8.4bn (€12.4bn at 31 Mar 2026); undrawn revolving facilities €7.6bn, maturing 2028 and 2031. Borrowings rose €4,179m, mainly new bonds (+€2,264m) and bank loans (+€1,195m). [1]
- (Maturities): From the annual report to 31 Mar 2026 (no update in the half-year excerpts): debt maturing in any one calendar year is capped, and bonds mature between 2026 and 2086. [7]
- (Capex, returns): Capital additions €3,320m (H1 FY26: €2,800m). Interim dividend 2.306 eurocents, up 2.5%; buybacks €92m, the programme having completed. [1]
- (Legal): Kenya's High Court nullified the 15% Safaricom stake purchase on 15 Sep 2026; pending appeal, a 13 Oct order keeps the shares with Vodafone, which still consolidates Safaricom. Also open: a €239m teleshopping damages claim and the Bundeskartellamt 1&1 case (court hearing January 2027). [2]

**Against Moody's triggers**

| Metric | Moody's-adjusted, FY to 31 Mar 2026 | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x [3] | below 2.5x [4] | fails to stay below 3.3x, sustained [4] | 0.75x to upgrade; 0.05x to downgrade [3][4] |
| RCF / Net debt | 33.08% [3] | above 25%, sustained [4] | towards 18%, sustained [4] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [3][4] |

Note: Worded triggers: upgrade needs sustained improvement, particularly in Germany; downgrade if operating performance deteriorates, including a failure to turn around Germany. Moody's FY27 forecast: debt/EBITDA 3.1x, RCF/net debt 29.4%. [4]

**What it means for the rating and outlook**

- (Position): Baa2 senior unsecured (foreign currency), stable outlook, affirmed 13 Oct 2026. Adjusted debt/EBITDA sits 0.05x inside the downgrade trigger. The credit opinion of 21 Oct 2026 predates the 10 Nov results. [3][4][5]
- (Net debt): Company net debt is up €8.1bn since 31 Mar 2026, the period of the adjusted figures, mainly on the VodafoneThree buyout and Safaricom. Moody's cites "reduced financial flexibility following the buyout of VodafoneThree"; the outlook assumes Vodafone stays in the lower half of its 2.25x-2.75x net leverage target range. [1][4]
- (Not covered): Safaricom, the Kenyan ruling and the impairment are not in the sections pulled; the opinion refers to "ongoing challenges in the core German market". [4]
- (Moody's comment): No Moody's comment on these results found in the last 45 days; the latest is the 13 Oct rating action, which notes the German recovery path "remains uncertain". [8]

**Notes**

- Mode: recap, as asked. Results are the half-year to 30 Sep 2026; Moody's files the report as "Interim Report 2026 - Q4" and the call under fiscal Q4 2026, both labels wrong.
- Company net debt and net leverage are Vodafone's own measures, not Moody's-adjusted.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone half-year report H1 FY27 · Interim Report 2026 - Q4 (H1 to 30 Sep 2026), 10 Nov 2026, pp. 4, 10-12, 21-22, 30 · 2026-11-10
[2] Moody's (searchCompanyFilings) · Vodafone half-year report H1 FY27: impairment and legal notes · Interim Report 2026 - Q4 (H1 to 30 Sep 2026), 10 Nov 2026, pp. 16-19, 23-24 · 2026-11-10
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted): Debt / EBITDA, RCF / Net Debt, FY ending 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, credit opinion sections incl. triggers, outlook, key indicators · 2026-10-21
[5] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-10-13
[6] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call · Call transcript, Half Year 2027 Vodafone Group Earnings Call, 10 Nov 2026 · 2026-11-10
[7] Moody's (searchCompanyFilings) · Vodafone Annual Report on Form 20-F 2026 · Annual Report 2026 (FY to 31 Mar 2026), submitted 22 May 2026, pp. 190, 193 · 2026-03-31
[8] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action · 2026-10-13

Earnings tab updated at 2026-11-15 23:19 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html. Not published to the private link (publishing skipped in this session).
