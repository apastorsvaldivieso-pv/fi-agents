**Regulatory watch: Banks Europe, 16 Oct to 15 Nov** (16 Oct to 15 Nov 2026 (both days included); 15 names)

Twelve regulatory items in the window, none new since the last run; the two that reach a Moody's metric are the Basel Committee's G-SIB measures of 16 Oct, where BNP Paribas (CET1 12.97%) and ING (13.07%) sit in the weaker third of the eight G-SIBs covered. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (Q2 2026) | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% CET1 requirement, 30 Sep 2025, older [3] | 2.46 pp (older) [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger, 31 Dec 2025, older [4] | 2.04 pp (older) [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26% CET1 requirement, 31 Mar 2026 [5] | 2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2% overall CET1 requirement, 31 Dec 2025, older [6] | 2.10 pp (older) [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern CET1, 30 Jun 2026 [7] | 3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [8] | +3.22 [2][8] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Indicators are reported by every bank in the Basel Committee's assessment sample; the G-SIB buffer falls only on the eight on the FSB G-SIB list (27 Nov 2025; 2026 list not yet published). Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: only three have a current requirement. Issuer on our list is Credit Agricole S.A.: CET1 11.3%, Q2 2026; 2.6 pp above SREP, 31 Mar 2026. [2][9][10]

**Who it hits: G-SIB methodology review, banking-union exposures (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (Q2 2026) | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51%, 30 Sep 2025, older [3] | 2.46 pp (older) [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03%, 31 Dec 2025, older [4] | 2.04 pp (older) [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26%, 31 Mar 2026 [5] | 2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% [8] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The page names no addressees; our reading is that it covers the five banking-union G-SIBs on the FSB list (27 Nov 2025). Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven banks not on the list. Credit Agricole S.A.: CET1 11.3%, Q2 2026. [2][10]

**What changed**

- **PRA** (Final): PS20/26 sets final Large Exposures rules on securities financing transactions, trading book limits, intragroup limits and mandatory substitution for credit risk mitigation; implementation 1 January 2028. [11]
- **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance reflects recent AMLA amendments and clarifies correspondent banking rules; in force 1 January 2027. [12]
- **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, embedded gains and losses, earnings indicators) plus a supervisory reporting set; comments by 9 February 2027. [13]
- **EBA** (Final): 2027 EU-wide stress test methodology cuts requested data points by more than 55% and adds a separate climate module that does not affect core results; launch end of January 2027, results end of July 2027. [14]
- **EBA** (Other): Next steps on the supervisory reporting simplification ITS (still draft; final report December 2026): first reference date postponed to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028. [15]
- **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10) align with CRD VI and add a more proportionate approach; application date not stated on the page. *Why it matters:* Moody's calls the revisions credit positive for EU banks, with a greater effect on smaller banks (Sector Comment, 11 Nov 2026). [16][17]
- **Basel Committee** (Consultation): Consequential amendments to point Basel Framework cross-references to the new consolidated guidelines and move some application guidance into them; comments by 21 December 2026. [18]
- **FINMA** (Consultation): Partial revision of Circular 2019/2 on banks' interest rate risk would adopt the Basel Committee's recalibrated shocks and give greater weight to effects on revenues; consultation until 15 January 2027. [19]
- **PRA** (Consultation): CP14/26 would move many senior roles from pre-approval to notification and remove Certification Regime requirements for roughly 7,700 individuals; responses by 22 January 2027. [20]
- **European Commission** (Other): Provisional political agreement on the securitisation review, which makes the CRR prudential treatment of securitisations "more risk sensitive"; still needs technical finalisation and formal approval. [21]
- **Basel Committee** (Final): G-SIB indicators to be reported and disclosed as yearly averages rather than year-end figures, by 1 January 2030; leverage exposure reporting threshold raised from EUR 200 billion to EUR 350 billion from 1 January 2027. *Why it matters:* Changes how G-SIB scores, and so G-SIB buffers, are measured: capital channel. [1]
- **Basel Committee** (Consultation): G-SIB methodology review asks whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework; comments by 14 January 2027. *Why it matters:* Bears on G-SIB scores, and so buffers, of banking-union G-SIBs. [22]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| Basel: IRRBB Pillar 2 guidance (consultation) [13] | All 15, once home countries apply it | IRRBB: no field | Watch |
| FINMA: Circular 2019/2 interest rate risks (consultation) [19] | UBS Group AG | IRRBB: no field | Watch |
| PRA: PS20/26 large exposures (final) [11] | HSBC, Barclays, Lloyds | Large exposures: no field | Watch |
| FINMA: revised AMLO-FINMA (final) [12] | UBS Group AG | AML: no field | Watch |
| EBA: 2027 EU-wide stress test methodology (final) [14] | Scope not known: sample not listed; drawn from the 11 EU/EEA banks | Stress testing: no field | Watch |
| EBA: supervisory reporting next steps [15] | the 11 EU/EEA banks | Reporting: no field | Watch |
| EBA: internal governance guidelines (final) [16] | the 11 EU/EEA banks | Governance: no field | Watch |
| Basel: consolidated guidelines amendments (consultation) [18] | All 15, once home countries apply it | None: cross-references only | Watch |
| PRA: CP14/26 SM&CR phase 2 (consultation) [20] | HSBC, Barclays, Lloyds | Governance: no field | Watch |
| EU: securitisation framework (political agreement) [21] | the 11 EU/EEA banks | Securitisation: no field | Watch |

Note: The 11 EU/EEA banks: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Moody's data carries no field for these channels.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out: speeches, interviews and blogs (ECB 8, SRB 4, FINMA 1); newsletters (Basel AML/CFT, PRA Digest); not measures (EBA NGFS support, ECB Eurogroup overview, Commission dialogue summary and nominations call); other firms (PRA credit union papers, assurance standards, FINMA Bitcoin ETF); consumer factsheet; EBA advice to the Commission; appointment; moved deadlines; supervised-entities list; sanctions notices; statistics.
- All twelve items were already on the running list from the earlier run of this window; every regulator listing was read again and nothing was added. FSB 2026 G-SIB list not yet published; the 2025 list is used. Moody's comment searched for four items, found only on EBA governance. Groupe Credit Agricole asked at Q2 2026 to match the others.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all 15 names; Credit … · Bank financials, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Groep N.V. Form 20-F for 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F for 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (asked … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides filed under … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[12] Web · FINMA: Partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[14] Web · EBA: The EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · EBA: Next steps on supervisory reporting simplification and extended … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[16] Web · EBA: Revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[17] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[18] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA: Consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · PRA: CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[21] Web · European Commission: Political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review

Regulatory watch tab updated at 2026-11-15 23:21 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-10-list-stable/dashboard/dashboard.html (not published to the private link in this run).
