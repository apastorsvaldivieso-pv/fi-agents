import json
M="getEntityFinancials_v2"; F="searchCompanyFilings"
def c(v,src=None,tone=None):
    d={"v":v}
    if src: d["src"]=src
    if tone: d["tone"]=tone
    return d
cet="CET1 ratio (as reported), Q2 2026"
cols=["Name",cet,"vs median of ranked names","Stated CET1 requirement (date)","Distance to requirement","Position"]
t1rows=[
 ["BNP Paribas",c("12.97%",["m1"]),c("-1.04 pp",["m1"]),c("10.51%, 30 Sep 2025, older",["r_bnp"]),c("+2.46 pp (older)",["m1","r_bnp"]),c("",tone="weaker")],
 ["ING Groep N.V.",c("13.07%",["m1"]),c("-0.94 pp",["m1"]),c("11.03% MDA trigger, 31 Dec 2025, older",["r_ing"]),c("+2.04 pp (older)",["m1","r_ing"]),c("",tone="weaker")],
 ["Societe Generale",c("13.2%",["m1"]),c("-0.81 pp",["m1"]),c("10.26%, against 31 Mar 2026",["r_sg"]),c("+2.94 pp",["m1","r_sg"]),c("",tone="middle")],
 ["Deutsche Bank AG",c("13.92%",["m1"]),c("-0.09 pp",["m1"]),"not stated","not stated",c("",tone="middle")],
 ["HSBC Holdings plc",c("14.1%",["m1"]),c("+0.09 pp",["m1"]),"not stated","not stated",c("",tone="middle")],
 ["Barclays PLC",c("14.3%",["m1"]),c("+0.29 pp",["m1"]),c("12.2%, 31 Dec 2025, older",["r_bar"]),c("+2.1 pp (older)",["m1","r_bar"]),c("",tone="middle")],
 ["UBS Group AG",c("14.38%",["m1"]),c("+0.37 pp",["m1"]),c("10.83% going-concern, 30 Jun 2026",["r_ubs"]),c("+3.55 pp",["m1","r_ubs"]),c("",tone="stronger")],
 ["Groupe Credit Agricole",c("17.23%",["m2"]),c("+3.22 pp",["m1","m2"]),"total not stated",c("6.7 pp bank-stated, 31 Mar 2026",["r_gca"]),c("",tone="stronger")],
]
t2rows=[
 ["BNP Paribas",c("12.97%",["m1"]),"not ranked",c("10.51%, 30 Sep 2025, older",["r_bnp"]),c("+2.46 pp (older)",["m1","r_bnp"]),"list too short to rank"],
 ["ING Groep N.V.",c("13.07%",["m1"]),"not ranked",c("11.03% MDA trigger, 31 Dec 2025, older",["r_ing"]),c("+2.04 pp (older)",["m1","r_ing"]),"list too short to rank"],
 ["Societe Generale",c("13.2%",["m1"]),"not ranked",c("10.26%, against 31 Mar 2026",["r_sg"]),c("+2.94 pp",["m1","r_sg"]),"list too short to rank"],
 ["Deutsche Bank AG",c("13.92%",["m1"]),"not ranked","not stated","not stated","list too short to rank"],
 ["Groupe Credit Agricole",c("17.23%",["m2"]),"not ranked","total not stated",c("6.7 pp bank-stated, 31 Mar 2026",["r_gca"]),"list too short to rank"],
]
EU="The 11 EU names"
items=[
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance published (10 Nov), in force 1 January 2027; it also clarifies correspondent banking rules and recognises the revised Swiss banks' code of conduct as a minimum standard. Channel: AML (watch).","src":["w12"]},
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 (10 Nov) finalises Part 2 of the large exposures changes, implemented 1 January 2028: internal models for securities financing exposures are removed and credit risk mitigation substitution becomes mandatory for all firms. Channel: large exposures (watch).","src":["w11"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Final methodology for the 2027 EU-wide stress test (9 Nov), with \"more than 55%\" less requested data in the headline and a separate climate module; launch end of January 2027, results end of July 2027. Channel: stress testing (watch).","src":["w10"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consults (9 Nov) on additional Pillar 2 guidance for interest rate risk in the banking book, covering model risk, stress testing, embedded gains and losses and earnings indicators, plus supervisory information banks would report; comments by 9 February 2027. Channel: IRRBB (watch).","src":["w9"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on supervisory reporting simplification (6 Nov): first reference date postponed to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028, with \"at least a one-year implementation period\"; final report in December 2026. Channel: reporting (watch).","src":["w8"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance (5 Nov), aligned with CRD VI and more proportionate; application date not stated on the page. Channel: governance (watch).","why":"Moody's calls the revision credit positive for EU banks, with a greater effect on smaller banks (Sector Comment, 11 Nov 2026).","src":["w7","m9"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consults (5 Nov) on consequential amendments that repoint Basel Framework cross-references to the new consolidated guidelines and move some application guidance into them; comments by 21 December 2026. Channel: none in the channel map; treated as watch by our judgment.","src":["w6"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consults (4 Nov) on partially revising Circular 2019/2 \"Interest rate risks - banks\" to apply the Basel Committee's July 2024 recalibrated shocks, with more attention to effects on banks' revenues; comments by 15 January 2027. Channel: IRRBB (watch).","src":["w5"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26 (22 Oct) proposes moving most Senior Manager Functions from pre-approval to notification and removing Certification Regime assessments and certificates; comments by 22 January 2027. Channel: governance (watch).","src":["w4"]},
 {"flag":"NEW","tag":"Other","name":"European Commission","text":"Provisional political agreement (22 Oct) on the Securitisation Framework review, amending the Securitisation Regulation and the CRR to make the prudential treatment of securitisations \"more risk sensitive\"; awaits technical finalisation and formal approval. Channel: securitisation (watch).","src":["w3"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consults (16 Oct) on its G-SIB methodology review, including whether to bring its agreed treatment of cross-border exposures within the European Banking Union into the framework; comments by 14 January 2027. Channel: capital, G-SIB buffer (CET1).","src":["w2"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"Finalises (16 Oct) amendments requiring banks to report and disclose G-SIB score indicators as averages over the year rather than year-end figures, by 1 January 2030; the reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 January 2027. Channel: capital, G-SIB buffer (CET1).","src":["w1"]},
]
watch_rows=[
 ["FINMA AMLO (final, 10 Nov)","UBS Group AG","AML: no field","watch"],
 ["PRA PS20/26 large exposures (final, 10 Nov)","HSBC, Barclays, Lloyds","Large exposures: no field","watch"],
 ["EBA 2027 stress test methodology (9 Nov)","Scope not known among the 11 EU names: sample not stated on the page","Stress testing: no field","watch"],
 ["Basel IRRBB Pillar 2 guidance (consultation, 9 Nov)","All 15, once home countries apply it","IRRBB: no field","watch"],
 ["EBA supervisory reporting next steps (6 Nov)",EU,"Reporting: no field","watch"],
 ["EBA internal governance guidelines (final, 5 Nov)",EU,"Governance: no field","watch"],
 ["Basel consolidated guidelines amendments (consultation, 5 Nov)","All 15, once home countries apply it","No channel-map row","watch"],
 ["FINMA Circular 2019/2 IRR (consultation, 4 Nov)","UBS Group AG","IRRBB: no field","watch"],
 ["PRA CP14/26 SM&CR (consultation, 22 Oct)","HSBC, Barclays, Lloyds","Governance: no field","watch"],
 ["EC securitisation agreement (22 Oct)",EU,"Securitisation: no field","watch"],
]
watch_rows=[[r[0],r[1],r[2],{"v":"","tone":"watch"}] for r in watch_rows]
sections=[
 {"title":"Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t1rows,
  "note":"Reporting falls on the Committee's assessment sample, set by size; the buffer effect falls only on FSB-listed G-SIBs, shown here. Out of scope: UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Lloyds, Nordea (not on the FSB G-SIB list of 27 Nov 2025; the 2026 list is not yet published). Ranked by level: only three names have a current stated requirement.","note_src":["w13"]},
 {"title":"Who it hits: G-SIB methodology review (Basel Committee consultation, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t2rows,
  "note":"The page names no addressees; our reading is that a measure on banking-union cross-border exposures covers the five banking-union G-SIBs on the FSB list of 27 Nov 2025. HSBC, Barclays and UBS are out of scope. Fewer than six names: not ranked.","note_src":["w2","w13"]},
 {"title":"What changed","type":"items","items":items},
 {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch_rows,
  "note":"Moody's bank data carries no field for these channels, so no name is positioned. EU names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Scope is judged for the group at its home."}
]
fsrc="bank sector file, pulled 15 Nov 2026: "
sources=[
 {"id":"w1","kind":"web","title":"Basel Committee: Amendments to G-SIB framework to address window dressing","date":"2026-10-16","url":"https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"},
 {"id":"w2","kind":"web","title":"Basel Committee: Global systemically important banks - methodology review (consultative)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
 {"id":"w3","kind":"web","title":"European Commission: political agreement on the review of the Securitisation Framework","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
 {"id":"w4","kind":"web","title":"PRA CP14/26 Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
 {"id":"w5","kind":"web","title":"FINMA consultation on partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
 {"id":"w6","kind":"web","title":"Basel Committee: Consolidated guidelines - consequential amendments (consultative)","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
 {"id":"w7","kind":"web","title":"EBA publishes revised Guidelines on internal governance","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
 {"id":"w8","kind":"web","title":"EBA outlines next steps on supervisory reporting simplification","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
 {"id":"w9","kind":"web","title":"Basel Committee: IRRBB - additional Pillar 2 guidance (consultative)","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
 {"id":"w10","kind":"web","title":"EBA streamlines the 2027 EU-wide stress test","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
 {"id":"w11","kind":"web","title":"PRA PS20/26 Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
 {"id":"w12","kind":"web","title":"FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
 {"id":"w13","kind":"web","title":"FSB: 2025 List of Global Systemically Important Banks (G-SIBs)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
 {"id":"m1","kind":"moodys","tool":M,"ref":"Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all coverage names","title":"European banks financials","date":"2026-06-30"},
 {"id":"m2","kind":"moodys","tool":M,"ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period; LQ returned Q3 2026)","title":"Groupe Credit Agricole financials","date":"2026-06-30"},
 {"id":"r_ubs","kind":"moodys","tool":F,"ref":fsrc+"UBS Group AG, Second quarter 2026 report, as of 30 Jun 2026","title":"UBS required going-concern CET1","date":"2026-06-30"},
 {"id":"r_sg","kind":"moodys","tool":F,"ref":fsrc+"Societe Generale, First quarter 2026 results, shown against 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
 {"id":"r_bnp","kind":"moodys","tool":F,"ref":fsrc+"BNP Paribas, Third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 requirement","date":"2025-09-30"},
 {"id":"r_bar","kind":"moodys","tool":F,"ref":fsrc+"Barclays PLC, Form 20-F 2025, as of 31 Dec 2025","title":"Barclays overall CET1 requirement","date":"2025-12-31"},
 {"id":"r_ing","kind":"moodys","tool":F,"ref":fsrc+"ING Groep N.V., Form 20-F 2025, as of 31 Dec 2025","title":"ING MDA trigger level for CET1","date":"2025-12-31"},
 {"id":"r_gca","kind":"moodys","tool":F,"ref":fsrc+"Credit Agricole S.A. filings, First quarter 2026 results slides (group figures), as of 31 Mar 2026","title":"Groupe Credit Agricole distance to SREP requirement","date":"2026-03-31"},
 {"id":"m9","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042, Sector Comment","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
]
notes=[
 "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
 "Groupe Credit Agricole rows use the group record; the issuer on the list, Credit Agricole S.A., has CET1 of 11.3% (Q2 2026) and states 2.6 pp above its SREP requirement at 31 Mar 2026.",
 "Left out (18 of 30 entries): speeches, blogs, newsletters, sanctions notices, statements, statistics, periodic lists, consumer material, and items for credit unions, auditors or funds.",
 "No Moody's comment found in the window on the G-SIB, securitisation or IRRBB items."
]
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"UPDATED",
 "scope":{"label":"Banks Europe, 30 days","sector":"Banks","region":"Europe","window":"16 Oct to 15 Nov 2026 (30 days)","names":15},
 "status":"ok",
 "headline":"Twelve regulatory items in 30 days; the Basel Committee's G-SIB window-dressing standard hits the eight listed G-SIBs, with BNP Paribas and ING lowest on CET1 among them.",
 "headline_src":["w1","m1"],
 "sections":sections,"sources":sources,"unresolved":[],"notes":notes,
 "meta":{"calls":{"moodys":5,"web":25}}}
import sys
run["updated_at"]=sys.argv[1]
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
