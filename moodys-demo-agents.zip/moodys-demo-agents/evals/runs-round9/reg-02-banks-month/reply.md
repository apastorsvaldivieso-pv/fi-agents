**Regulatory watch: Banks Europe, 30 days** (16 Oct to 15 Nov 2026 (30 days); 15 names)

Twelve regulatory items in 30 days; the Basel Committee's G-SIB window-dressing standard hits the eight listed G-SIBs, with BNP Paribas and ING lowest on CET1 among them. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names | Stated CET1 requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 pp [2] | 10.51%, 30 Sep 2025, older [3] | +2.46 pp (older) [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 pp [2] | 11.03% MDA trigger, 31 Dec 2025, older [4] | +2.04 pp (older) [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 pp [2] | 10.26%, against 31 Mar 2026 [5] | +2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 pp [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 pp [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 pp [2] | 12.2%, 31 Dec 2025, older [6] | +2.1 pp (older) [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 pp [2] | 10.83% going-concern, 30 Jun 2026 [7] | +3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [8] | +3.22 pp [2][8] | total not stated | 6.7 pp bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Reporting falls on the Committee's assessment sample, set by size; the buffer effect falls only on FSB-listed G-SIBs, shown here. Out of scope: UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Lloyds, Nordea (not on the FSB G-SIB list of 27 Nov 2025; the 2026 list is not yet published). Ranked by level: only three names have a current stated requirement. [10]

**Who it hits: G-SIB methodology review (Basel Committee consultation, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names | Stated CET1 requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51%, 30 Sep 2025, older [3] | +2.46 pp (older) [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% MDA trigger, 31 Dec 2025, older [4] | +2.04 pp (older) [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26%, against 31 Mar 2026 [5] | +2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% [8] | not ranked | total not stated | 6.7 pp bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The page names no addressees; our reading is that a measure on banking-union cross-border exposures covers the five banking-union G-SIBs on the FSB list of 27 Nov 2025. HSBC, Barclays and UBS are out of scope. Fewer than six names: not ranked. [10][11]

**What changed**

- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published (10 Nov), in force 1 January 2027; it also clarifies correspondent banking rules and recognises the revised Swiss banks' code of conduct as a minimum standard. Channel: AML (watch). [12]
- [NEW] **PRA** (Final): PS20/26 (10 Nov) finalises Part 2 of the large exposures changes, implemented 1 January 2028: internal models for securities financing exposures are removed and credit risk mitigation substitution becomes mandatory for all firms. Channel: large exposures (watch). [13]
- [NEW] **EBA** (Other): Final methodology for the 2027 EU-wide stress test (9 Nov), with "more than 55%" less requested data in the headline and a separate climate module; launch end of January 2027, results end of July 2027. Channel: stress testing (watch). [14]
- [NEW] **Basel Committee** (Consultation): Consults (9 Nov) on additional Pillar 2 guidance for interest rate risk in the banking book, covering model risk, stress testing, embedded gains and losses and earnings indicators, plus supervisory information banks would report; comments by 9 February 2027. Channel: IRRBB (watch). [15]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification (6 Nov): first reference date postponed to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028, with "at least a one-year implementation period"; final report in December 2026. Channel: reporting (watch). [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (5 Nov), aligned with CRD VI and more proportionate; application date not stated on the page. Channel: governance (watch). *Why it matters:* Moody's calls the revision credit positive for EU banks, with a greater effect on smaller banks (Sector Comment, 11 Nov 2026). [17][18]
- [NEW] **Basel Committee** (Consultation): Consults (5 Nov) on consequential amendments that repoint Basel Framework cross-references to the new consolidated guidelines and move some application guidance into them; comments by 21 December 2026. Channel: none in the channel map; treated as watch by our judgment. [19]
- [NEW] **FINMA** (Consultation): Consults (4 Nov) on partially revising Circular 2019/2 "Interest rate risks - banks" to apply the Basel Committee's July 2024 recalibrated shocks, with more attention to effects on banks' revenues; comments by 15 January 2027. Channel: IRRBB (watch). [20]
- [NEW] **PRA** (Consultation): CP14/26 (22 Oct) proposes moving most Senior Manager Functions from pre-approval to notification and removing Certification Regime assessments and certificates; comments by 22 January 2027. Channel: governance (watch). [21]
- [NEW] **European Commission** (Other): Provisional political agreement (22 Oct) on the Securitisation Framework review, amending the Securitisation Regulation and the CRR to make the prudential treatment of securitisations "more risk sensitive"; awaits technical finalisation and formal approval. Channel: securitisation (watch). [22]
- [NEW] **Basel Committee** (Consultation): Consults (16 Oct) on its G-SIB methodology review, including whether to bring its agreed treatment of cross-border exposures within the European Banking Union into the framework; comments by 14 January 2027. Channel: capital, G-SIB buffer (CET1). [11]
- [NEW] **Basel Committee** (Final): Finalises (16 Oct) amendments requiring banks to report and disclose G-SIB score indicators as averages over the year rather than year-end figures, by 1 January 2030; the reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 January 2027. Channel: capital, G-SIB buffer (CET1). [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| FINMA AMLO (final, 10 Nov) | UBS Group AG | AML: no field | Watch |
| PRA PS20/26 large exposures (final, 10 Nov) | HSBC, Barclays, Lloyds | Large exposures: no field | Watch |
| EBA 2027 stress test methodology (9 Nov) | Scope not known among the 11 EU names: sample not stated on the page | Stress testing: no field | Watch |
| Basel IRRBB Pillar 2 guidance (consultation, 9 Nov) | All 15, once home countries apply it | IRRBB: no field | Watch |
| EBA supervisory reporting next steps (6 Nov) | The 11 EU names | Reporting: no field | Watch |
| EBA internal governance guidelines (final, 5 Nov) | The 11 EU names | Governance: no field | Watch |
| Basel consolidated guidelines amendments (consultation, 5 Nov) | All 15, once home countries apply it | No channel-map row | Watch |
| FINMA Circular 2019/2 IRR (consultation, 4 Nov) | UBS Group AG | IRRBB: no field | Watch |
| PRA CP14/26 SM&CR (consultation, 22 Oct) | HSBC, Barclays, Lloyds | Governance: no field | Watch |
| EC securitisation agreement (22 Oct) | The 11 EU names | Securitisation: no field | Watch |

Note: Moody's bank data carries no field for these channels, so no name is positioned. EU names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Scope is judged for the group at its home.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Groupe Credit Agricole rows use the group record; the issuer on the list, Credit Agricole S.A., has CET1 of 11.3% (Q2 2026) and states 2.6 pp above its SREP requirement at 31 Mar 2026.
- Left out (18 of 30 entries): speeches, blogs, newsletters, sanctions notices, statements, statistics, periodic lists, consumer material, and items for credit unions, auditors or funds.
- No Moody's comment found in the window on the G-SIB, securitisation or IRRBB items.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all coverage names · European banks · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, as of 30 … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, shown … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC, Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period; LQ returned Q3 … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole S.A. filings, First quarter 2026 … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[12] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · Basel Committee: IRRBB - additional Pillar 2 guidance (consultative) · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[16] Web · EBA outlines next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[22] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 2026-11-15T23:17:32Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html. Not published to the private link in this session.
