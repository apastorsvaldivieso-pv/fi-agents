**Daily sector news: Telecoms, Europe** (24h to 15 Nov 2026 23:14 UTC; 15 names)

Nothing material for Telecoms, Europe, in the last 24 hours.

**Notes**

- Window: 14 Nov 2026 23:14 UTC to 15 Nov 2026 23:14 UTC (Sunday, so 24 hours). The searches returned no Moody's rating actions or research on European telecoms in the window.
- Old news retold inside the window was left out: Vodafone's half-year results and guidance raise (results call held 10 Nov 2026) and Deutsche Telekom's Q3 results, guidance raise and weekly buyback disclosure (dated 9 Nov 2026).

Dashboard: "Daily sector news" tab updated at 15 Nov 2026 23:17 UTC — /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-01-telecoms-default/dashboard/dashboard.html
