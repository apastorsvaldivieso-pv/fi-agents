**Earnings: BNP Paribas, recap** (Q3 2026 results, reported 28 Oct 2026; 1 name)

BNP Paribas Q3 2026: net income EUR 3.5bn, up 13.5%, CET1 12.9% against a raised year-end target above 13%. Moody's holds no call transcript, and the latest results filing it holds (FY2025 annual report) is older than these results. [1][2]

**Results against the credit view**

- (Profit): Q3 2026 net income EUR 3.5bn, up 13.5% year on year (company-reported). Moody's calculates RoTE at 13.0% and return on assets at 43 bp annualised, excluding a EUR 81m one-off gain on disposal of financial stakes. [1]
- (Guidance): Underlying cost of risk 39 bp, within the bank's 40 bp target; cost-to-income 58.3%, 2.3 pp better. 2028 guidance reiterated, including cost-to-income below 56%. No beat or miss against Moody's: the opinion's key indicators carry no forecast. [1][3]
- (Capital): CET1 12.9% at Q3 2026 (12.97% at Q2 2026 in Moody's data), with a 15 bp drag from closing the Athlon deal. The bank's last stated CET1 requirement is 10.51%, as of 30 Sep 2025 (older): 2.4 pp of headroom on that basis. [1][4][5]
- (Liquidity, funding): LCR 139% (138% a year earlier); HQLA EUR 399bn and liquidity reserve EUR 495bn (EUR 481bn). The EUR 14.0bn 2026 regulatory issuance plan was 126% done by 16 Oct, with about EUR 4bn prefunded for 2027 (company-reported). [1]
- (Asset quality): Loan loss provisions EUR 964m (EUR 905m); Stage 3 down to EUR 937m, doubtful loans 1.6%, Stage 3 coverage 67.3%. Cost of risk in CPB France 24 bp, up from 15 bp a year earlier. [1]
- (Distributions, Q4): A EUR 1.3bn share buyback launches in November, and the bank expects a capital gain on the sale of BMCI (Morocco) in Q4. [1]
- (Legal): Latest filing held (FY2025 annual report): litigation provisions include EUR 399m for Swiss-franc mortgages in Poland at 31 Dec 2025, up from EUR 366m. Not updated for 2026 in Moody's filings. [2]

**Against Moody's triggers**

| Metric | Latest value and period | Upgrade trigger | Downgrade trigger | Room to upgrade trigger |
|---|---|---|---|---|
| Net income / tangible assets (Moody's) | 0.4%, H1 2026 [3] | Return on assets 0.6% and above [3] | Worded only | 0.2 pp short [3] |
| Return on assets, Moody's calc., annualised | 0.43%, Q3 2026 [1] | 0.6% and above [3] | Worded only | 0.17 pp short [1][3] |

Note: The opinion names return on assets; the key-indicator row is the nearest Moody's measure. Upgrade also needs lower financial leverage and disciplined risk management.

**Worded triggers**

Downgrade: "lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics"; also a material risk management failure, or weaker operating conditions with a weaker funding and liquidity profile. Upgrade could also follow an upgrade of France. [3]

**What it means for the rating and outlook**

- A1 LT Issuer Rating, stable outlook, affirmed 31 Aug 2026; BCA baa1. The credit opinion (2 Sep 2026) predates these results. [3][6]
- Profitability sits 0.17 pp below the 0.6% return-on-assets upgrade level on Moody's Q3 calculation. Capital is near the bank's raised target; the opinion lists "lower-than-peer leverage and capital ratios" as a challenge. [1][3]
- Moody's comment of 28 Oct: results "demonstrated strong resilience against the weak operating momentum in its French home market". The outlook rests on "very stable and highly predictable profitability". Athlon and BMCI: not in the sections pulled. [1][3]

**Notes**

- Moody's holds no earnings call transcript for BNP Paribas; none was sought on the web. The results filings it holds (Q3 2025 interim, FY2025 annual) are older than the Q3 2026 results, so Q3 2026 figures come from Moody's Issuer Comment and are company-reported unless marked as Moody's calculation.
- Capital headroom uses a CET1 requirement stated for 30 Sep 2025; the 2026 requirement is not in the filings Moody's holds.

**Sources**

[1] Moody's (searchAllDocuments) · BNP Paribas: Q3 results underscore position of strength amid worsening domestic … · PBC_1499674, Issuer Comment · 2026-10-28
[2] Moody's (searchCompanyFilings) · BNP Paribas 2025 annual report (notes) · BNP Paribas Annual Report 2025 - Q4, period to 31 Dec 2025, p. 75 · 2025-12-31
[3] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation (Credit Opinion) · PBC_1491623, outlook, triggers, strengths, challenges, key indicators · 2026-09-02
[4] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · BNP Paribas · 2026-06-30
[5] Moody's (searchCompanyFilings) · BNP Paribas Q3 2025 results report · BNP Paribas Interim Report 2025 - Q3, period to 30 Sep 2025, p. 42 · 2025-09-30
[6] Moody's ratings (getEntityRatings) · BNP Paribas · 2026-11-15

Earnings tab updated 15 Nov 2026, 23:20 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-07-old-filing/dashboard/dashboard.html (not published as an Artifact in this run).
