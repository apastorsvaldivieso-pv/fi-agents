**Daily sector news: Telecoms Europe, 7 days** (168h (7 days) from 8 Nov 2026 23:14 UTC to 15 Nov 2026 23:14 UTC; 15 names)

Telefonica and Vodafone raised full-year guidance and TIM's nine-month loss widened; the search returned no Moody's rating actions on European telecoms in the window.

**Top this week**

- **Telefonica S.A.** (Results): Q3 results (12 Nov): net income EUR 802m vs EUR 276m; nine-month profit EUR 464m after a EUR 870m loss on discontinued operations. Adjusted EBITDA guidance raised to slightly above 2.5% (from 1.5-2.5%), revenue cut to 1-1.5%, FCF to about EUR 3.1bn; net financial debt EUR 25.2bn, company-reported leverage 2.63x (2.78x Dec 2025). *Why it matters:* Moody's downgrade trigger is adjusted net leverage of 3.75x, upgrade below 3.0x; the 2.63x is not Moody's-adjusted. [1][2][3][4]
- **Vodafone Group Plc** (Results): H1 FY27 results (10 Nov): guidance raised, midpoint implying organic adjusted EBITDA growth of 7% and adjusted FCF of 21%; Q2 service revenue up 6.4%. Germany H1 EBITDA fell 3.2%, including about EUR 100m for a European Court of Justice ruling. Profit or loss and net debt not in the sources returned. *Why it matters:* Moody's downgrade triggers: adjusted gross debt/EBITDA not staying below 3.3x, or failure to turn Germany around. [5][6]
- **TIM S.p.A.** (Results): Nine-month results (call 11 Nov): net loss EUR 205m vs EUR 109m, on EUR 314m non-recurring costs including litigation provisions; EBITDA EUR 3.053bn, down 1.5%. Adjusted net debt after leases rose to EUR 7.21bn from EUR 6.854bn (Dec 2025); FCF after leases EUR 818m; 2026 targets kept. *Why it matters:* Moody's positive outlook assumes earnings growth and positive FCF; downgrade if adjusted leverage stays above 3.0x and FCF turns persistently negative. [7][8]

**Macro**

- Eurozone government bond yields rose on 13 Nov alongside US Treasuries. [9]
- Moody's 2027 credit conditions outlook (9 Nov): credit will weaken as higher rates and energy costs counter the AI tailwind. [10]

**Sector**

- The search returned no Moody's rating actions and no Moody's research on the listed names in the window.
- **Odido (not on the list)**: Moody's issuer comment (11 Nov): new notes to fund the Apax acquisition raise leverage, credit quality unchanged. [11]
- **Sector outlook**: Telecommunications – Global outlook stable (27 Oct 2026): solid demand and declining capital intensity offset a broad range of risks. [12]

**By name**

| Name | Moody's rating, outlook | This week |
|---|---|---|
| Deutsche Telekom AG | A3 (Senior Unsecured), stable [13] | No material credit news. |
| Orange | Baa1 (LT Issuer Rating), stable [13] | No material credit news. |
| Vodafone Group Plc | Baa2 (Senior Unsecured), stable [13] | H1 results, guidance raised (Top item). [5] |
| Telefonica S.A. | Baa3 (Senior Unsecured), stable [13] | Q3 results, guidance raised; dividend EUR 0.15 confirmed (Top item). [1] |
| Swisscom AG | A2 (LT Issuer Rating), stable [13] | No material credit news. |
| Telekom Austria AG | A3 (LT Issuer Rating), stable [13] | No material credit news. |
| Proximus SA de droit public | A3 (Senior Unsecured), stable [13] | No material credit news. |
| Telenor ASA | Baa1 (Senior Unsecured), positive [13] | Bought 57.5% of Bahnhof (about USD 363m), now 66.9% of shares; mandatory offer at SEK 62 per share. [14][15] |
| Telia Company AB | Baa1 (Senior Unsecured), stable [13] | Agreed to buy Telavox's Nordic enterprise base for SEK 3.8bn plus up to SEK 0.2bn earn-out. Latvia buyout of its LMT and Tet stakes due by 17 Nov: single source, unconfirmed. [16][17] |
| TIM S.p.A. | Baa3 (LT Issuer Rating), positive [13] | Nine-month loss widened, debt up (Top item). [7] |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer Rating), stable [13] | No news returned. |
| BT Group Plc | Baa2 (LT Issuer Rating, British Telecommunications Ltd), stable [13] | No material credit news. |
| Iliad S.A. | Ba1 (Senior Unsecured), stable [13] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 (LT Corporate Family Rating), ratings under review [13] | No news returned. CFR and PDR on review for downgrade since 22 Oct; Telefonica (50% owner) said on 12 Nov it would not inject equity. [2][18] |
| Altice France SAS | Caa1 (Senior Secured Bank Credit Facility), positive [13] | No material credit news. |

Note: Ratings as returned by Moody's, with the class the tool gave. Company-reported leverage is not Moody's-adjusted.

**Notes**

- Results dated before the window are not repeated as new: Deutsche Telekom Q3 and BT H1 with its pension valuation (both 5 Nov), Proximus Q3 (30 Oct). Swisscom's nine-month update was mentioned but its date was not in the sources returned; treated as outside the window.
- An automated article (AktienSensor) gave Vodafone H1 profit figures that the transcript did not confirm; not used.
- Left out as not credit news: share-price items, tenders, a passive 13G filing on Vodafone, subsidiary and associate news (Vodafone Idea, Vodacom, Grameenphone, Sparkle), the Openreach chair change. The Iliad search returned mostly unrelated articles.

**Sources**

[1] Moody's (searchNews) · Telefonica Q3 Net Income Soars As Revenue Rise; Revises Annual Growth Outlook … · 2026-11-12
[2] Moody's (searchNews) · Telefonica SA (Q3 2026) Earnings Call Highlights (Yahoo! Finance) · 2026-11-12
[3] Moody's (searchNews) · Telefonica returns to profitability, earning 464 million through September (CE … · 2026-11-12
[4] Moody's (getCreditOpinion) · Telefonica S.A.: Update to credit analysis · PBC_1482849, outlook and rating factors · 2026-05-27
[5] Moody's (searchCompanyFilings) · Vodafone Group Plc H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group earnings call, 10 Nov 2026 (company-reported) · 2026-11-10
[6] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, outlook and rating factors · 2026-10-21
[7] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September (CE Noticias Financieras) · 2026-11-12
[8] Moody's (getCreditOpinion) · TIM S.p.A.: Update following rating upgrade to Baa3 · PBC_1499423, outlook and rating factors · 2026-10-19
[9] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Morningstar / … · 2026-11-13
[10] Moody's (searchAllDocuments) · Credit Conditions – Global: 2027 Outlook · PBC_1491648, Outlook · 2026-11-09
[11] Moody's (searchAllDocuments) · Odido Group Holding B.V.: New notes issuance increases leverage but credit … · PBC_1502046, Issuer Comment · 2026-11-11
[12] Moody's (searchAllDocuments) · Telecommunications – Global: Outlook stable · PBC_1496503, Outlook · 2026-10-27
[13] Moody's ratings (getEntityRatings) · 2026-11-15
[14] Moody's (searchNews) · Telenor Acquires 57.5% Stake in Bahnhof (Marketline Deals) · 2026-11-11
[15] Moody's (searchNews) · Bahnhof board recommends Telenor Sverige's mandatory cash offer (NewsWeb) · 2026-11-13
[16] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base (Telia release via … · 2026-11-12
[17] Moody's (searchNews) · Buyout of Telia's shares in LMT and Tet to be implemented by 17 Nov (LETA) · 2026-11-13
[18] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559, Rating Action · 2026-10-22


Dashboard: the "Daily sector news" tab was updated at 15 Nov 2026 23:19 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html (not published to a link in this session).
