**Vodafone Group Plc, recap: half-year FY27 results (10 Nov 2026)**

Mode: recap. Moody's holds the half-year call from 10 Nov 2026, which is inside the last 21 days.

**Headline:** Vodafone raised its FY27 guidance. It also booked a €4.85bn goodwill impairment on Germany, which turned the half into a loss. Company-reported net debt rose €8.1bn to €33.5bn after the VodafoneThree buyout and the Safaricom stake. Moody's-adjusted metrics for FY to March 2026 sit inside both downgrade triggers. The credit opinion (21 Oct 2026) predates these results.

## Results against the credit view

- **Guidance raised (company-reported).** Before the results, management guided to the upper end of the old FY27 ranges. The upper end of the old ranges is now the midpoint of the new ones. That midpoint implies organic growth of 7% in adjusted EBITDA and 21% in adjusted free cash flow [4]. The ranges themselves, old and new, were not in the report excerpts pulled [5].
- **Against Moody's forecast.** Moody's forecasts are annual, at 3.1x debt/EBITDA and 29.4% RCF/net debt for FY2027 [1]. Half-year results cannot be set against them.
- **Profit or loss.** Basic loss per share was 20.75c, against earnings of 3.38c a year earlier [5]. The German goodwill impairment was €4.85bn. Behind it: a higher discount rate (8.0%, from 7.5%) and a weaker plan for Germany [5]. A one-off gain of €3,022m came from remeasuring the previously held Safaricom interest [5].
- **German court ruling.** An ECJ ruling cut adjusted EBITDA by about €100m. A small provision was taken for a class action that is not expected to end before late 2027 (company, on the call) [4].
- **Net debt (company measure).** €33,473m, against €25,411m at 31 March 2026: up €8,062m [5]. The drivers the report gives:
  - free cash outflow: €845m
  - acquisitions and disposals, including VodafoneThree and Safaricom: €6,957m
  - equity dividends: €544m
  - buybacks: €92m
  - less other movements: €474m

  These drivers add up to €7,964m. The excerpts do not explain the €98m gap [5].
- **Liquidity.** Cash and short-term investments were €8.4bn, down from €12.4bn [5]. Undrawn revolving credit facilities were €7.6bn, maturing in 2031 (€4.1bn) and 2028 ($4.0bn) [5].
- **Refinancing.** Bonds rose €2,264m, mainly from new issues, and bank loans rose €1,195m [5]. No maturity schedule was in the excerpts.
- **Capex.** Capital additions were €3,320m, against €2,800m a year earlier. Spectrum payments were €21m, against €45m [5].
- **Shareholder returns.** The interim dividend is 2.306 eurocents, against 2.25 a year earlier [5]. Buybacks were €92m [5].
- **Court ruling on a deal.** On 15 Sep 2026, Kenya's High Court nullified the sale of the 15% Safaricom stake. The case is under appeal, and a status-quo order dated 13 Oct 2026 keeps Vodafone as the registered holder. A hearing date is expected before end-December 2026. The report says the accounting "will be reassessed" if the appeal fails [5].
- **Germany fibre joint venture (OXG).** An analyst on the call said Vodafone may have to fund equity injections of up to €1.2bn into OXG. Management said any equity will be phased over the build [4].

## Against Moody's triggers

| Metric (Moody's-adjusted) | Latest, period | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to 31 Mar 2026 [3] | below 2.5x [1] | fails to stay below 3.3x [1] | 0.75x to upgrade; 0.05x to downgrade [1][3] |
| RCF / Net debt | 33.1%, FY to 31 Mar 2026 [3] | above 25%, sustained [1] | towards 18%, sustained [1] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [1][3] |

Worded triggers [1]:
- Upgrade: "underlying revenue and operating performance improve sustainably, particularly in Germany".
- Downgrade: "a failure to turn around its German operations".

## What it means for the rating and outlook

- **Rating and outlook.** Baa2 senior unsecured (foreign currency), stable outlook, affirmed on 13 Oct 2026 [2].
- **Outlook wording.** The stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt of around 30%, and operation in the lower half of the company's 2.25x–2.75x net leverage target [1].
- **Timing.** The opinion (21 Oct 2026) and the rating action both came before these results [1][6]. The trigger values cover the year to March 2026, so they do not yet reflect the €8.1bn rise in company net debt since then [3][5].
- **What Moody's says about the deals.** Moody's already cites "reduced financial flexibility following the buyout of VodafoneThree" [1]. The Safaricom stake and the Kenyan ruling are not in the sections pulled. On Germany, the opinion names "continued operating challenges in its core German market" [1]. The impairment itself is not in the sections pulled.
- **Moody's comment on these results.** None published as of 15 Nov 2026 [6].

Dashboard not updated: this session has no folder to write to and cannot run scripts.

**Sources**
1. Moody's, getCreditOpinion: "Vodafone Group Plc: Update following ratings affirmation", PBC_1496608, 21 Oct 2026.
2. Moody's, getEntityRatings: rating history (Senior Unsecured, foreign currency), RTNG_600018164, retrieved 15 Nov 2026.
3. Moody's, getEntityFinancials_v2: key indicators (adjusted), FY to 31 Mar 2026, retrieved 15 Nov 2026.
4. Moody's, searchCompanyFilings: "Half Year 2027 Vodafone Group Public Ltd Co Earnings Call", 10 Nov 2026.
5. Moody's, searchCompanyFilings: "Vodafone Group Plc Interim Report 2026 - Q4" (in fact the H1 FY27 report, period to 30 Sep 2026), submitted 10 Nov 2026, pp. 4, 10–12, 16, 18–24, 29–30.
6. Moody's, searchAllDocuments: "Moody's Ratings affirms Vodafone's ratings; stable outlook", PR_528027, 13 Oct 2026. The search covered 1 Oct to 15 Nov 2026 and found no Moody's comment on these results.
