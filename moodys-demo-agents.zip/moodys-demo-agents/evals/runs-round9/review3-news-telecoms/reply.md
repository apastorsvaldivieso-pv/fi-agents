**Daily sector news: European telecoms, last 7 days** (168h (7 days) from 8 Nov 2026 23:16 UTC to 15 Nov 2026 23:16 UTC; 15 names)

Telefonica and Vodafone raised guidance and Telia agreed a SEK 3.8bn acquisition; the search returned no Moody's rating action on the listed names in the window. [1][2][3][4]

**Top this week**

- **Telefonica S.A.** (Results): Q3 (12 Nov): net income EUR 802m vs EUR 276m. Adjusted EBITDA guidance raised to slightly above 2.5% growth (from 1.5-2.5%), revenue guidance cut to 1-1.5%, FCF guidance about EUR 3.1bn (from EUR 3bn); company-reported net debt EUR 25.2bn, 2.63x (2.78x Dec 2025). *Why it matters:* Moody's stable outlook assumes adjusted net leverage sustainably below 3.75x; 2.63x is the company's own measure. [1][5][6]
- **Vodafone Group Plc** (Results): H1 FY27 (10 Nov): group guidance upgraded, midpoint implying organic adjusted EBITDA growth of 7% and adjusted FCF growth of 21% (company-reported). Europe outlook kept despite a EUR 100m German EBITDA hit from a European Court of Justice ruling. *Why it matters:* Moody's could downgrade if adjusted gross debt/EBITDA fails to stay below 3.3x, RCF/net debt nears 18%, or Germany is not turned around. [2][7]
- **Telia Company AB** (Deal): Binding agreement (12 Nov) to buy Telavox's Nordic enterprise customer base for SEK 3.8bn plus up to SEK 0.2bn earn-out; the base generates about SEK 1.1bn of annual revenue. Funding not stated in the sources. *Why it matters:* Moody's downgrade triggers are RCF/net debt below 22% with debt/EBITDA moving towards 3.0x. [3][8][9]

**Macro**

- Euro area and US government bond yields rose (13 Nov). [10]
- Bank of England faces fresh rate pressure ahead of UK inflation data (15 Nov). [11]
- Moody's 2027 credit conditions outlook (9 Nov): credit will weaken as higher rates and energy costs counter the AI tailwind. [12]

**Sector**

- The searches returned no Moody's rating action and no Moody's research on the listed names published in the window. [4]
- Latest Moody's sector outlook: Telecommunications - Global, stable (27 Oct 2026), on solid demand and declining capital intensity. [13]

**By name**

| Name | Rating | Outlook | This week |
|---|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured (fgn curr) [14] | Stable [14] | No material credit news. Q3 results and guidance raise date from 5 Nov, before the window. [15] |
| Orange | Baa1 LT Issuer Rating [14] | Stable [14] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (fgn curr) [14] | Stable [14] | H1 FY27 results 10 Nov, guidance raised (see Top). Net result and net debt not in the sources returned. [2] |
| Telefonica S.A. | Baa3 Senior Unsecured (dom curr) [14] | Stable [14] | Q3 12 Nov (see Top). Germany restructuring provision of up to EUR 155m expected in Q4; 2026 dividend EUR 0.15 per share. [5] |
| Swisscom AG | A2 LT Issuer Rating (dom curr) [14] | Stable [14] | No material credit news; date of the nine-month update not in the sources returned. |
| Telekom Austria AG | A3 LT Issuer Rating [14] | Stable [14] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (dom curr) [14] | Stable [14] | No material credit news. Q3 results date from 30 Oct, before the window. [16] |
| Telenor ASA | Baa1 Senior Unsecured (fgn curr) [14] | Positive [14] | Telenor Sverige holds about 66.9% of Bahnhof (90.6% of votes); Bahnhof's committee recommended its SEK 62 per share mandatory cash offer (13 Nov). Offer launched 6 Nov. [17][18] |
| Telia Company AB | Baa1 Senior Unsecured (fgn curr) [14] | Stable [14] | Telavox deal (see Top). Latvian state buyout of Telia's LMT and Tet stakes due by 17 Nov: single source, unconfirmed. [19] |
| TIM S.p.A. | Baa3 LT Issuer Rating (dom curr) [14] | Positive [14] | 9M results (call 11 Nov): net loss EUR 205m (EUR 109m a year earlier) on EUR 314m one-offs, incl. EUR 139m litigation review; EBITDA EUR 3.053bn, down 1.5%; adjusted net debt after leases EUR 7.21bn (EUR 6.854bn Dec 2025); 2026 targets kept. [20] |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (dom curr) [14] | Stable [14] | no news returned |
| BT Group Plc | Baa2 LT Issuer Rating (British Telecommunications Ltd) [14] | Stable [14] | No material credit news. H1 results and pension valuation date from 5 Nov, before the window. [21] |
| Iliad S.A. | Ba1 Senior Unsecured (dom curr) [14] | Stable [14] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 Corporate Family Rating (fgn curr) [14] | Under review for downgrade [14] | CFR, PDR and Virgin Media Bristol LLC bank facility on review for downgrade since 22 Oct. On 12 Nov Telefonica (50% owner) reported VMO2 Q3 service revenue down 3.5%, adjusted EBITDA down 2.6%, and said it would not inject equity. [5][22] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (fgn curr) [14] | Positive [14] | No material credit news. |

Note: Ratings as returned by Moody's on 15 Nov 2026. Results figures are company-reported, not Moody's-adjusted. [14]

**Notes**

- Window: 7 days as asked, 8 Nov 23:16 UTC to 15 Nov 23:16 UTC. Moody's research searches filter by whole days (8-15 Nov).
- Name searches for Iliad, Proximus, Swisscom and Telekom Austria returned mostly unrelated articles; none was credit news on the issuer.
- Results, guidance and net debt figures are company-reported and are not comparable with Moody's-adjusted leverage triggers.

**Sources**

[1] Moody's (searchNews) · Telefonica Q3 Net Income Soars As Revenue Rise; Revises Annual Growth Outlook … · 2026-11-12
[2] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, event date 10 Nov 2026 … · 2026-11-10
[3] Moody's (searchNews) · Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion … · 2026-11-12
[4] Moody's (searchAllDocuments) · Moody's rating action and research searches · Rating Action and research searches, Telecommunications, Europe, 8-15 Nov 2026 (no listed … · 2026-11-15
[5] Moody's (searchNews) · Telefonica SA (TELFY) (Q3 2026) Earnings Call Highlights (Yahoo! Finance) · 2026-11-12
[6] Moody's (getCreditOpinion) · Telefonica S.A.: Update to credit analysis · PBC_1482849, RatingOutlook · 2026-05-27
[7] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, FactorsLeadingToDowngrade · 2026-10-21
[8] Moody's (searchNews) · Telia to acquire Telavox's Nordic enterprise customer base (Telia Company … · 2026-11-12
[9] Moody's (getCreditOpinion) · Telia Company AB: Update to credit analysis · PBC_1472649, FactorsLeadingToDowngrade · 2026-03-02
[10] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes (Morningstar / … · 2026-11-13
[11] Moody's (searchNews) · Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms (The … · 2026-11-15
[12] Moody's (searchAllDocuments) · Credit Conditions - Global: 2027 Outlook · PBC_1491648 · 2026-11-09
[13] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 · 2026-10-27
[14] Moody's ratings (getEntityRatings) · Moody's ratings pull · 2026-11-15
[15] Moody's (searchNews) · Deutsche Telekom's Profit Growth Outpaces Revenue (Ad Hoc News; Q3 release of 5 … · 2026-11-14
[16] Moody's (searchNews) · Proximus Group financial results - Third quarter 2026 (release dated 30 Oct) · 2026-10-30
[17] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · 2026-11-13
[18] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document (Cision) · 2026-11-13
[19] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet to be … · 2026-11-13
[20] Moody's (searchNews) · Telecom Italia's losses soar by 88% through September (CE Noticias Financieras) · 2026-11-12
[21] Moody's (searchNews) · BT Group announces triennial pension valuation (BT Group release dated 5 Nov) · 2026-11-05
[22] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · PR_531559 · 2026-10-22

Daily sector news tab updated at 23:21 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review3-news-telecoms/dashboard/dashboard.html (dashboard not published as an Artifact in this run).
