import json, subprocess
now = subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
def c(v, src, tone=None):
    d={"v":v,"src":src}
    if tone: d["tone"]=tone
    return d
F=["m1"]; G=["m2"]
cols=["Name","CET1 ratio (as reported), Q2 2026","vs median (pp)","Stated CET1 requirement","Distance to requirement","Position"]
t1_rows=[
 ["BNP Paribas", c("12.97%",F), c("-1.04",F), c("10.51% (30 Sep 2025, older)",["r4"]), c("+2.46 pp",F+["r4"]), {"tone":"weaker","v":""}],
 ["ING Groep N.V.", c("13.07%",F), c("-0.94",F), c("11.03% MDA trigger (31 Dec 2025, older)",["r6"]), c("+2.04 pp",F+["r6"]), {"tone":"weaker","v":""}],
 ["Societe Generale", c("13.2%",F), c("-0.81",F), c("10.26% (31 Mar 2026)",["r2"]), c("+2.94 pp",F+["r2"]), {"tone":"middle","v":""}],
 ["Deutsche Bank AG", c("13.92%",F), c("-0.09",F), "not stated", "not stated", {"tone":"middle","v":""}],
 ["HSBC Holdings plc", c("14.1%",F), c("+0.09",F), "not stated", "not stated", {"tone":"middle","v":""}],
 ["Barclays PLC", c("14.3%",F), c("+0.29",F), c("12.2% (31 Dec 2025, older)",["r5"]), c("+2.10 pp",F+["r5"]), {"tone":"middle","v":""}],
 ["UBS Group AG", c("14.38%",F), c("+0.37",F), c("10.83% going-concern (30 Jun 2026)",["r1"]), c("+3.55 pp",F+["r1"]), {"tone":"stronger","v":""}],
 ["Groupe Credit Agricole (for Credit Agricole S.A.)", c("17.23%",G), c("+3.22",G+F), "total not stated", c("6.7 pp, bank-stated, 31 Mar 2026",["r3"]), {"tone":"stronger","v":""}],
]
t2_rows=[
 ["BNP Paribas", c("12.97%",F), "not ranked", c("10.51% (30 Sep 2025, older)",["r4"]), c("+2.46 pp",F+["r4"]), "list too short to rank"],
 ["ING Groep N.V.", c("13.07%",F), "not ranked", c("11.03% MDA trigger (31 Dec 2025, older)",["r6"]), c("+2.04 pp",F+["r6"]), "list too short to rank"],
 ["Societe Generale", c("13.2%",F), "not ranked", c("10.26% (31 Mar 2026)",["r2"]), c("+2.94 pp",F+["r2"]), "list too short to rank"],
 ["Deutsche Bank AG", c("13.92%",F), "not ranked", "not stated", "not stated", "list too short to rank"],
 ["Groupe Credit Agricole (for Credit Agricole S.A.)", c("17.23%",G), "not ranked", "total not stated", c("6.7 pp, bank-stated, 31 Mar 2026",["r3"]), "list too short to rank"],
]
EU="BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC, Banco Sabadell, Swedbank"
watch=[
 ["IRRBB Pillar 2 guidance (Basel Committee, consultation)", "All 12, once home rules apply it", "IRRBB measure (no field)", {"tone":"watch","v":""}],
 ["Basel consolidated guidelines amendments (consultation)", "All 12, once home rules apply it", "none (housekeeping)", {"tone":"watch","v":""}],
 ["Internal governance guidelines (EBA, final)", EU, "governance (no field)", {"tone":"watch","v":""}],
 ["Supervisory reporting timelines (EBA)", EU, "reporting (no field)", {"tone":"watch","v":""}],
 ["2027 EU-wide stress test methodology (EBA)", "Scope not known: sample not stated; candidates "+EU, "stress test (no field)", {"tone":"watch","v":""}],
 ["Securitisation framework review (EU, political agreement)", EU, "securitisation (no field)", {"tone":"watch","v":""}],
 ["Large exposures PS20/26 (PRA, final)", "HSBC, Barclays", "large exposures (no field)", {"tone":"watch","v":""}],
 ["SM&CR Phase 2 CP14/26 (PRA, consultation)", "HSBC, Barclays", "governance (no field)", {"tone":"watch","v":""}],
 ["Anti-money laundering ordinance (FINMA, final)", "UBS", "AML (no field)", {"tone":"watch","v":""}],
 ["IRRBB Circular 2019/2 (FINMA, consultation)", "UBS", "IRRBB measure (no field)", {"tone":"watch","v":""}],
]
items=[
 {"flag":"NEW","tag":"Final","name":"FINMA · 10 Nov","text":"Final partially revised Anti-Money Laundering Ordinance, in force 1 January 2027; correspondent-banking rule now covers only clients with direct access to the correspondent bank's accounts.","src":["w11"]},
 {"flag":"NEW","tag":"Final","name":"PRA · 10 Nov","text":"PS20/26 completes the large exposures reforms: substitution becomes mandatory for all firms, trading-book excess allowance cut to \"up to 85% of Tier 1 capital\" for at most 10 business days. Effective 1 January 2028.","src":["w9"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee · 9 Nov","text":"Additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and a new supervisory reporting item. Comments by 9 February 2027.","src":["w3"]},
 {"flag":"NEW","tag":"Final methodology","name":"EBA · 9 Nov","text":"2027 EU-wide stress test methodology final, with \"more than 55%\" fewer requested data points; templates still draft. Launch end January 2027, results end July 2027. Sample not stated.","src":["w5"]},
 {"flag":"NEW","tag":"Next steps","name":"EBA · 6 Nov","text":"Supervisory reporting simplification: first reference date moved to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028. Final ITS report due December 2026.","src":["w6"]},
 {"flag":"NEW","tag":"Final","name":"EBA · 5 Nov","text":"Revised internal governance guidelines aligned with CRD VI, more proportionate; awaiting translation, application date not stated on the page.","why":"Moody's calls the revisions credit positive for EU banks, more so for smaller ones as larger banks already apply them (Sector Comment, 11 Nov 2026).","src":["w7","m3"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee · 5 Nov","text":"Consequential amendments repointing Basel Framework cross-references to the consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026.","src":["w4"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA · 4 Nov","text":"Partial revision of Circular 2019/2 on banks' interest rate risk: updated shock scenarios (Basel recalibration of July 2024) and more weight on effects on revenues. Comments by 15 January 2027.","src":["w12"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA · 22 Oct","text":"CP14/26, SM&CR Phase 2: pre-approval would end for roughly half of Senior Manager Functions and certification assessments would be removed. Comments by 22 January 2027.","src":["w10"]},
 {"flag":"NEW","tag":"Legislative step","name":"European Commission · 22 Oct","text":"Provisional agreement on the Securitisation Framework review, including CRR changes to make the prudential treatment of securitisations \"more risk sensitive\". Awaits formal adoption; in force on publication.","src":["w8"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee · 16 Oct","text":"G-SIB methodology review: consults on \"whether to incorporate\" the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 January 2027.","src":["w2"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee · 16 Oct","text":"G-SIB indicators to be reported and disclosed as averages over the year, not year-end values, to curb window dressing; implementation by 1 January 2030. Reporting threshold rises from EUR 200 billion to EUR 350 billion from 2027.","why":"G-SIB scores set the G-SIB buffer, which sits inside each bank's CET1 requirement.","src":["w1"]},
]
run={
 "schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"label":"Your 12 banks, 30 days","sector":"Banks","region":"Europe","window":"16 Oct to 15 Nov 2026 (30 days)","names":12},
 "status":"ok",
 "headline":"The Basel Committee finalised G-SIB window-dressing rules (averaging, by 1 January 2030); among your eight G-SIBs, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios.",
 "headline_src":["w1","m1"],
 "sections":[
  {"title":"Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t1_rows,
   "note":"Final standard applies to \"banks participating in the G-SIB assessment exercise\"; its buffer effect falls on listed G-SIBs only. Out of scope: Danske Bank, KBC, Banco Sabadell, Swedbank (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Credit Agricole S.A.'s own CET1: 11.3% (Q2 2026), 2.6 pp above its SREP requirement (31 Mar 2026).",
   "note_src":["fsb","m1","r3"]},
  {"title":"Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table","columns":cols,"rows":t2_rows,
   "note":"The page names no addressees; read as covering the five banking-union G-SIBs on your list (our reading). Out of scope: HSBC, Barclays, UBS (not banking-union) and Danske Bank, KBC, Banco Sabadell, Swedbank (not G-SIBs).",
   "note_src":["fsb"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch,
   "note":"Moody's data carries no field for these channels, so no name is positioned. Danish and Swedish national supervisors are not among the sources searched."}
 ],
 "sources":[
  {"id":"w1","kind":"web","title":"Basel Committee: Amendments to G-SIB framework to address window dressing (media release)","date":"2026-10-16","url":"https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib"},
  {"id":"w2","kind":"web","title":"Basel Committee: Global systemically important banks - methodology review (consultation)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
  {"id":"w3","kind":"web","title":"Basel Committee: IRRBB - additional Pillar 2 guidance (consultation)","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
  {"id":"w4","kind":"web","title":"Basel Committee: Consolidated guidelines - consequential amendments","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
  {"id":"w5","kind":"web","title":"EBA streamlines 2027 EU-wide stress test","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
  {"id":"w6","kind":"web","title":"EBA next steps on supervisory reporting simplification","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
  {"id":"w7","kind":"web","title":"EBA revised Guidelines on internal governance","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
  {"id":"w8","kind":"web","title":"European Commission welcomes political agreement on Securitisation Framework review","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
  {"id":"w9","kind":"web","title":"PRA PS20/26 Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
  {"id":"w10","kind":"web","title":"PRA CP14/26 Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
  {"id":"w11","kind":"web","title":"FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
  {"id":"w12","kind":"web","title":"FINMA consultation on Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
  {"id":"fsb","kind":"web","title":"FSB 2025 List of Global Systemically Important Banks (G-SIBs); no 2026 list found on fsb.org on 15 Nov 2026","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
  {"id":"m1","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all names (Credit Agricole S.A. own record included)","title":"Bank financials, 13 records","date":"2026-06-30"},
  {"id":"m2","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ returned Q3 2026, re-asked for Q2 2026)","title":"Groupe Credit Agricole financials","date":"2026-06-30"},
  {"id":"m3","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks (Sector Comment)","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
  {"id":"r1","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 Jun 2026","title":"UBS required going-concern CET1","date":"2026-06-30"},
  {"id":"r2","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
  {"id":"r3","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Credit Agricole First quarter 2026 results slides, as of 31 Mar 2026","title":"Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement","date":"2026-03-31"},
  {"id":"r4","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 capital requirement","date":"2025-09-30"},
  {"id":"r5","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F 2025, as of 31 Dec 2025","title":"Barclays overall CET1 requirement","date":"2025-12-31"},
  {"id":"r6","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: ING Groep Form 20-F 2025, as of 31 Dec 2025","title":"ING MDA trigger level for CET1","date":"2025-12-31"}
 ],
 "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Your list: all 12 names resolved. Danske Bank A/S (DK), KBC Group N.V. (BE), Banco de Sabadell, S.A. (ES) and Swedbank AB (SE) were matched in Moody's and have current ratings; the other eight come from the checked European banks list.",
  "Left out (not measures for banks): Basel newsletter; EBA consumer factsheet, appointment, NGFS statement, Taxonomy advice to the Commission, moved consultation deadlines; ECB and SRB speeches, interviews, Eurogroup overview and supervised-entities list; Commission statistics, sanctions statements, meeting summary, tokenisation nominations, assurance-standards feedback (other firms); PRA credit-union papers (other firms) and digest; FINMA sanctions notices, speech and Bitcoin ETF approval."
 ],
 "meta":{"calls":{"moodys":10,"web":24}}
}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
