**Regulatory watch: Your 12 banks, 30 days** (16 Oct to 15 Nov 2026 (30 days); 12 names)

The Basel Committee finalised G-SIB window-dressing rules (averaging, by 1 January 2030); among your eight G-SIBs, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median (pp) | Stated CET1 requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% (30 Sep 2025, older) [3] | +2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger (31 Dec 2025, older) [4] | +2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26% (31 Mar 2026) [5] | +2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2% (31 Dec 2025, older) [6] | +2.10 pp [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern (30 Jun 2026) [7] | +3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole (for Credit Agricole S.A.) | 17.23% [8] | +3.22 [2][8] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Final standard applies to "banks participating in the G-SIB assessment exercise"; its buffer effect falls on listed G-SIBs only. Out of scope: Danske Bank, KBC, Banco Sabadell, Swedbank (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Credit Agricole S.A.'s own CET1: 11.3% (Q2 2026), 2.6 pp above its SREP requirement (31 Mar 2026). [2][9][10]

**Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median (pp) | Stated CET1 requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51% (30 Sep 2025, older) [3] | +2.46 pp [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% MDA trigger (31 Dec 2025, older) [4] | +2.04 pp [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26% (31 Mar 2026) [5] | +2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole (for Credit Agricole S.A.) | 17.23% [8] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The page names no addressees; read as covering the five banking-union G-SIBs on your list (our reading). Out of scope: HSBC, Barclays, UBS (not banking-union) and Danske Bank, KBC, Banco Sabadell, Swedbank (not G-SIBs). [10]

**What changed**

- [NEW] **FINMA · 10 Nov** (Final): Final partially revised Anti-Money Laundering Ordinance, in force 1 January 2027; correspondent-banking rule now covers only clients with direct access to the correspondent bank's accounts. [11]
- [NEW] **PRA · 10 Nov** (Final): PS20/26 completes the large exposures reforms: substitution becomes mandatory for all firms, trading-book excess allowance cut to "up to 85% of Tier 1 capital" for at most 10 business days. Effective 1 January 2028. [12]
- [NEW] **Basel Committee · 9 Nov** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and a new supervisory reporting item. Comments by 9 February 2027. [13]
- [NEW] **EBA · 9 Nov** (Final methodology): 2027 EU-wide stress test methodology final, with "more than 55%" fewer requested data points; templates still draft. Launch end January 2027, results end July 2027. Sample not stated. [14]
- [NEW] **EBA · 6 Nov** (Next steps): Supervisory reporting simplification: first reference date moved to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028. Final ITS report due December 2026. [15]
- [NEW] **EBA · 5 Nov** (Final): Revised internal governance guidelines aligned with CRD VI, more proportionate; awaiting translation, application date not stated on the page. *Why it matters:* Moody's calls the revisions credit positive for EU banks, more so for smaller ones as larger banks already apply them (Sector Comment, 11 Nov 2026). [16][17]
- [NEW] **Basel Committee · 5 Nov** (Consultation): Consequential amendments repointing Basel Framework cross-references to the consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026. [18]
- [NEW] **FINMA · 4 Nov** (Consultation): Partial revision of Circular 2019/2 on banks' interest rate risk: updated shock scenarios (Basel recalibration of July 2024) and more weight on effects on revenues. Comments by 15 January 2027. [19]
- [NEW] **PRA · 22 Oct** (Consultation): CP14/26, SM&CR Phase 2: pre-approval would end for roughly half of Senior Manager Functions and certification assessments would be removed. Comments by 22 January 2027. [20]
- [NEW] **European Commission · 22 Oct** (Legislative step): Provisional agreement on the Securitisation Framework review, including CRR changes to make the prudential treatment of securitisations "more risk sensitive". Awaits formal adoption; in force on publication. [21]
- [NEW] **Basel Committee · 16 Oct** (Consultation): G-SIB methodology review: consults on "whether to incorporate" the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 January 2027. [22]
- [NEW] **Basel Committee · 16 Oct** (Final): G-SIB indicators to be reported and disclosed as averages over the year, not year-end values, to curb window dressing; implementation by 1 January 2030. Reporting threshold rises from EUR 200 billion to EUR 350 billion from 2027. *Why it matters:* G-SIB scores set the G-SIB buffer, which sits inside each bank's CET1 requirement. [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| IRRBB Pillar 2 guidance (Basel Committee, consultation) | All 12, once home rules apply it | IRRBB measure (no field) | Watch |
| Basel consolidated guidelines amendments (consultation) | All 12, once home rules apply it | none (housekeeping) | Watch |
| Internal governance guidelines (EBA, final) | BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC, Banco Sabadell, Swedbank | governance (no field) | Watch |
| Supervisory reporting timelines (EBA) | BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC, Banco Sabadell, Swedbank | reporting (no field) | Watch |
| 2027 EU-wide stress test methodology (EBA) | Scope not known: sample not stated; candidates BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC, Banco Sabadell, Swedbank | stress test (no field) | Watch |
| Securitisation framework review (EU, political agreement) | BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC, Banco Sabadell, Swedbank | securitisation (no field) | Watch |
| Large exposures PS20/26 (PRA, final) | HSBC, Barclays | large exposures (no field) | Watch |
| SM&CR Phase 2 CP14/26 (PRA, consultation) | HSBC, Barclays | governance (no field) | Watch |
| Anti-money laundering ordinance (FINMA, final) | UBS | AML (no field) | Watch |
| IRRBB Circular 2019/2 (FINMA, consultation) | UBS | IRRBB measure (no field) | Watch |

Note: Moody's data carries no field for these channels, so no name is positioned. Danish and Swedish national supervisors are not among the sources searched.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Your list: all 12 names resolved. Danske Bank A/S (DK), KBC Group N.V. (BE), Banco de Sabadell, S.A. (ES) and Swedbank AB (SE) were matched in Moody's and have current ratings; the other eight come from the checked European banks list.
- Left out (not measures for banks): Basel newsletter; EBA consumer factsheet, appointment, NGFS statement, Taxonomy advice to the Commission, moved consultation deadlines; ECB and SRB speeches, interviews, Eurogroup overview and supervised-entities list; Commission statistics, sanctions statements, meeting summary, tokenisation nominations, assurance-standards feedback (other firms); PRA credit-union papers (other firms) and digest; FINMA sanctions notices, speech and Bitcoin ETF approval.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all names (Credit Agricole … · Bank financials, 13 records · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Groep Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole First quarter 2026 results slides, … · 2026-03-31
[10] Web · FSB 2025 List of Global Systemically Important Banks (G-SIBs); no 2026 list … · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[12] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · Basel Committee: IRRBB - additional Pillar 2 guidance (consultation) · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[14] Web · EBA streamlines 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · EBA next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[16] Web · EBA revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[17] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[18] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA consultation on Circular 2019/2 Interest rate risks - banks · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[21] Web · European Commission welcomes political agreement on Securitisation Framework … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review

Regulatory watch tab updated at 2026-11-15T23:17:36Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html (not published: test run).
