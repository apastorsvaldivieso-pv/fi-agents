**Regulatory watch: Banks Europe, 7 days** (9 to 15 Nov 2026; 15 names)

Four new items in the week, none on a channel Moody's data measures: a Basel consultation on banking-book rate risk, the EBA's final 2027 stress-test method, the PRA's final large-exposures rules and FINMA's revised AML ordinance. [1][2][3][4]

**What changed**

- [NEW] **PRA** (Final): PS20/26 completes the large-exposures changes: credit risk mitigation substitution becomes mandatory (with exemptions), the internal model option for securities financing exposure values goes, and the intragroup trading book limit rises to 350% of Tier 1. Takes effect 1 January 2028. *Why it matters:* Large exposures channel: concentration limits for HSBC, Barclays and Lloyds. [3]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance, with clarified rules on correspondent banking with foreign banks; the revised banks' code of conduct on due diligence is recognised as a minimum standard. In force 1 January 2027. *Why it matters:* AML channel; conduct and compliance risk for UBS. [4]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, controls, securities gains and losses, earnings indicators. Comments by 9 February 2027. *Why it matters:* Interest rate risk in the banking book channel; a proposal, not a final standard. [1]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test, with "more than 55%" fewer data points requested and a first separate climate-risk module. Launch end of January 2027, results end of July 2027. *Why it matters:* Stress testing channel; the page does not name the participating banks. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (final, 10 Nov) [3] | HSBC, Barclays, Lloyds (GB groups) | Large exposures: no field | Watch |
| FINMA AML ordinance (final, 10 Nov) [4] | UBS (CH group); page names no addressees, our reading | AML: no field | Watch |
| Basel IRRBB Pillar 2 guidance (consultation, 9 Nov) [1] | All 15, once home countries apply it; page states no scope | IRRBB: no field | Watch |
| EBA 2027 stress test method (final, 9 Nov) [2] | The 11 EU groups are candidates; the sample is set in the methodology, scope not known per name | Stress testing: no field | Watch |

Note: EU groups: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea. Moody's data carries no metric for these channels, so no name is given a position.

**Notes**

- Left out (not a measure addressed to banks): EBA support for the NGFS declaration (13 Nov); ECB Supervisory Board Chair's written overview for the Eurogroup (9 Nov) and SRB bi-annual note to the Eurogroup (9 Nov per search result, page not opened), both reports to another authority; SRB and Commission notes on the banking competitiveness dialogue (11 and 13 Nov). Speeches: SRB Chair (10, 11 Nov). Consumer material: EBA white-label factsheet (9 Nov). Other firms: Commission sustainability assurance feedback (12 Nov). Appointments: Commission tokenisation stakeholder group (9 Nov).
- Moody's has published no comment on any of the four items in the window.

**Sources**

[1] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[2] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[3] Web · PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[4] Web · FINMA: FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/

Regulatory watch tab updated 2026-11-15T23:15:12Z UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html (not published as an Artifact in this test run).
