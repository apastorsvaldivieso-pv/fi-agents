**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

The EBA's revised internal governance guidelines (final, 5 Nov) cover 11 of your 15 banks, every EU-headquartered name; HSBC, Barclays, Lloyds and UBS are outside them at group level. Moody's data has no governance metric, so no bank is ranked on it, and Moody's calls the change credit positive for EU banks, with a greater effect on smaller ones. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported, Q2 2026) | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -1.04 [3] | 10.51% (30 Sep 2025, older) [4] | 2.46 pp (older) [3][4] | Weaker third |
| ING Groep N.V. | 13.07% [3] | -0.94 [3] | 11.03% MDA trigger (31 Dec 2025, older) [5] | 2.04 pp (older) [3][5] | Weaker third |
| Societe Generale | 13.20% [3] | -0.81 [3] | 10.26% (against 31 Mar 2026) [6] | 2.94 pp [3][6] | Middle |
| Deutsche Bank AG | 13.92% [3] | -0.09 [3] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [3] | +0.09 [3] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [3] | +0.29 [3] | 12.2% (31 Dec 2025, older) [7] | 2.10 pp (older) [3][7] | Middle |
| UBS Group AG | 14.38% [3] | +0.37 [3] | 10.83% (30 Jun 2026) [8] | 3.55 pp [3][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [9] | +3.22 [3][9] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers the eight G-SIBs on this list (FSB list, 27 Nov 2025); all banks in the G-SIB assessment exercise report on averages. Out of scope: UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea, Lloyds (not on the FSB list). Ranked by level: only three have a current stated requirement. Issuer on the list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [3][10][11]

**Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported, Q2 2026) | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | not ranked | 10.51% (30 Sep 2025, older) [4] | 2.46 pp (older) [3][4] | list too short to rank |
| ING Groep N.V. | 13.07% [3] | not ranked | 11.03% MDA trigger (31 Dec 2025, older) [5] | 2.04 pp (older) [3][5] | list too short to rank |
| Societe Generale | 13.20% [3] | not ranked | 10.26% (against 31 Mar 2026) [6] | 2.94 pp [3][6] | list too short to rank |
| Deutsche Bank AG | 13.92% [3] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% [9] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [10] | list too short to rank |

Note: The page names no addressees; we read it as covering the five banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union); the other names are not on the FSB list. [11][12]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes from CP14/24: substitution for exposures reduced by eligible collateral or protection, with a single 350% higher intragroup limit. Effective 1 January 2028. [13]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance published in final form, aligned with the amended AMLA, with revised bank self-regulation recognised. In force 1 January 2027. [14]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test, with "more than 55%" fewer requested data points and a first climate module that does not affect core results. Launch end of January 2027; results end of July 2027. [15]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book, covering model risk, stress testing, controls and embedded gains and losses. Comments by 9 February 2027. [16]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification after consultation: first reference date moves to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting to December 2028. Final report due December 2026. [17]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10), aligned with CRD VI: duty mapping for management body members and key function holders, a framework for third-country branches, simpler conflict-of-interest rules. Final and awaiting translation; the page states no application date. *Why it matters:* Moody's calls the revisions credit positive for EU banks, with a greater effect on smaller banks because larger ones have already been adopting the guidelines. [1][2]
- [NEW] **Basel Committee** (Consultation): Consequential amendments pointing Basel Framework cross-references to the new consolidated guidelines and moving some application guidance chapters into them. Comments by 21 December 2026. [18]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on interest rate risks for banks, adopting the Basel Committee's July 2024 recalibrated rate shocks and giving more weight to earnings effects. Comments by 15 January 2027. [19]
- [NEW] **European Commission** (Legislative step): Political agreement on the Securitisation Framework review, amending the Securitisation Regulation and the CRR to make prudential treatment of securitisations "more risk sensitive". Awaits formal approval; enters into force on publication. [20]
- [NEW] **PRA** (Consultation): CP14/26 proposes phase 2 of the SM&CR review: many senior roles move from pre-approval to notification and Certification Regime assessments are removed. Comments by 22 January 2027; implementation expected H2 2027. [21]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported and disclosed as averages over the year, not year-end values, to curb window dressing. Implementation by 1 January 2030. *Why it matters:* The G-SIB score sets the G-SIB buffer, a part of each G-SIB's CET1 requirement. [12]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB methodology. Comments by 14 January 2027. [12]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EBA revised Guidelines on internal governance (5 Nov, final) [1] | 11 EU names: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Not HSBC, Barclays, Lloyds, UBS (groups outside the EU) | Governance: no Moody's field | Watch |
| PRA SM&CR review, phase 2 (22 Oct, consultation) [21] | HSBC, Barclays, Lloyds | Governance: no Moody's field | Watch |
| EBA 2027 EU-wide stress test methodology (9 Nov, final) [15] | Scope not known: sample not named on the page (the 11 EU names are candidates) | Stress testing: no Moody's field | Watch |
| EBA supervisory reporting next steps (6 Nov) [17] | The 11 EU names | Reporting: no Moody's field | Watch |
| EU Securitisation Framework agreement (22 Oct) [20] | The 11 EU names | Securitisation: no Moody's field | Watch |
| Basel IRRBB Pillar 2 guidance (9 Nov, consultation) [16] | All 15, once home country applies it | IRRBB: no Moody's field | Watch |
| FINMA Circular 2019/2 interest rate risks (4 Nov, consultation) [19] | UBS | IRRBB: no Moody's field | Watch |
| PRA large exposures PS20/26 (10 Nov, final) [13] | HSBC, Barclays, Lloyds | Large exposures: no Moody's field | Watch |
| FINMA AML Ordinance (10 Nov, final) [14] | UBS | AML: no Moody's field | Watch |
| Basel consolidated guidelines, consequential amendments (5 Nov, consultation) [18] | All 15, once home country applies it | None in channel map (cross-references; our judgment) | Watch |

Note: Moody's data carries no metric for these channels, so no name has a position. Scope is judged for the group at home: EU subsidiaries and branches of HSBC, Barclays, Lloyds and UBS fall under EU rules locally but are not counted.

**Notes**

- Left out (20 entries on the running list): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (Basel AML/CFT newsletter, PRA Regulatory Digest); periodic list (ECB supervised entities); appointments (EBA Vice-Chair, EC tokenisation group); advice to another authority (EBA on Taxonomy disclosures); moved consultation deadline (EBA); consumer material (EBA); sanctions notices (EC, FINMA); statistics (EC); meeting summary (EC competitiveness dialogue); statements (EBA on NGFS); other kinds of firm (PRA credit unions, FINMA Bitcoin ETF, EC assurance standards).
- The FSB's 2026 G-SIB list was not found on fsb.org as of 15 Nov 2026; the 27 Nov 2025 list is used.
- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.

**Sources**

[1] Web · EBA: revised Guidelines on internal governance (press release) · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[2] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all 15 names plus Groupe … · Bank financials, coverage list · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, CET1 capital … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING Groep annual report on Form 20-F for 2025, MDA … · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, CET1 … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays annual report on Form 20-F for 2025, … · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS second quarter 2026 report, required … · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ … · Groupe Credit Agricole · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated distance to requirement · bank sector file, pulled 15 Nov 2026: first quarter 2026 results slides filed under … · 2026-03-31
[11] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · Basel Committee finalises window-dressing measures and consults on G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[13] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · FINMA publishes partially revised Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[15] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · Basel Committee: IRRBB - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA outlines next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[18] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · Commission welcomes political agreement on the Securitisation Framework review · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[21] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 15 Nov 2026, 23:17 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-03-no-metric/dashboard/dashboard.html (not published as an Artifact in this run).
