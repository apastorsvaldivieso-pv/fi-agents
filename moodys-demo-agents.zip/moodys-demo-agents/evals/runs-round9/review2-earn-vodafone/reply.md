**Earnings: Vodafone, recap** (H1 FY27 results (six months to 30 Sep 2026), call of 10 Nov 2026; 1 name)

Vodafone upgraded FY27 guidance, but company-reported net debt rose by €8.1bn to €33.5bn on the VodafoneThree buyout and Safaricom stake, and Germany took a €4.85bn goodwill impairment; Moody's-adjusted debt/EBITDA was 3.25x at March 2026 against a 3.3x downgrade trigger, and the credit opinion predates these results. [1][2][3][4]

**Results against the credit view**

- (Guidance): Company-reported: FY27 adjusted EBITDA and adjusted FCF guidance upgraded; the old range's upper end is the new midpoint, implying 7% organic EBITDA and 21% adjusted FCF growth. Europe outlook kept despite a €100m ECJ ruling hit to EBITDA. Euro ranges not found in the report search. [5]
- (Vs Moody's): No full-year comparison yet: Moody's forecasts FY27 debt/EBITDA of 3.1x and RCF/net debt of 29.4%, and half-year figures cannot be set against them. [4]
- (Profit): Company-reported: operating profit €1,199m (H1 FY26: loss of €631m), after a €4.85bn Germany goodwill impairment and a €3,022m gain on remeasuring the prior 40% Safaricom stake. Basic loss per share 20.75 eurocents. [1][2]
- (Net debt): Company-reported net debt €33,473m vs €25,411m at 31 Mar 2026, up €8,062m: free cash outflow €845m, acquisitions and disposals €6,957m (VodafoneThree €5,019m, Safaricom stake €1,379m, Safaricom net debt €537m), dividends €544m, buybacks €92m, FX €98m, less €474m other inflows (incl. €908m VodafoneZiggo loan settlement). [1]
- (Liquidity): Company-reported cash and short-term investments €8.4bn (€12.4bn at March); undrawn RCFs €7.6bn maturing 2028 and 2031. Gross debt €42.7bn, up on new bonds and €1.2bn more bank loans. [1]
- (Capex, FCF): Company-reported capital additions €3,320m (H1 FY26: €2,800m); adjusted EBITDAaL €6,451m, up 12.6%; adjusted FCF outflow €440m. No material cut to German capital intensity guided. [1][5]
- (Returns): Company-reported interim dividend 2.306 eurocents, up 2.5%; buyback programme completed. OXG fibre JV: an analyst put Vodafone's possible equity injections at up to €1.2bn; management said they would be phased. [1][5]
- (Legal): Kenya's High Court nullified the 15% Safaricom stake sale on 15 Sep 2026; status quo held pending an expedited appeal. Also open: a €239m teleshopping-channel damages claim and the BkA 1&1 case (hearing January 2027). [2]

**Against Moody's triggers**

| Metric (Moody's-adjusted) | Latest, period | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to Mar 2026 [3] | below 2.5x [4] | fails to stay below 3.3x [4] | 0.05x to downgrade; 0.75x to upgrade [3][4] |
| RCF / Net debt | 33.08%, FY to Mar 2026 [3] | above 25% sustained [4] | declines towards 18% [4] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [3][4] |

Note: Worded triggers: upgrade if performance improves sustainably, "particularly in Germany"; downgrade on "a failure to turn around its German operations". [4]

**What it means for the rating and outlook**

- (Position): Baa2 senior unsecured (foreign currency), outlook stable, affirmed 13 Oct 2026. Debt/EBITDA sits 0.05x below the 3.3x downgrade trigger at March 2026; the outlook assumes it stays below 3.3x, RCF/net debt of around 30% and net leverage in the lower half of the 2.25x-2.75x target. [3][4][6]
- (Timing): The credit opinion (21 Oct 2026) and rating action (13 Oct 2026) predate these results. Company net debt has risen €8.1bn since the March 2026 period of the Moody's-adjusted figures, mainly on the VodafoneThree buyout and Safaricom stake. [1][4][7]
- (Moody's on the cause): The opinion cites "reduced financial flexibility following the buyout of VodafoneThree" and the rating action put cash at about €4.1bn pro forma for the UK buyout. Safaricom and the Germany impairment: not in the sections pulled. No Moody's comment on these results found in the last 45 days. [4][7]

**Notes**

- Mode chosen: recap, because Moody's holds the H1 FY27 call transcript of 10 Nov 2026 (within 21 days).
- Company-reported net debt is Vodafone's own measure and is not comparable with Moody's-adjusted debt or the ratios in the trigger table.
- The half-year report is titled "Interim Report 2026 - Q4" in Moody's data; it covers the six months to 30 Sep 2026.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone half-year report: cash flow, funding, dividend · Interim Report 2026 - Q4 (H1 FY27 to 30 Sep 2026), submitted 10 Nov 2026, pp. 4, 10-12 · 2026-09-30
[2] Moody's (searchCompanyFilings) · Vodafone half-year report: impairment, acquisitions, legal · Interim Report 2026 - Q4 (H1 FY27), submitted 10 Nov 2026, notes 3, 9, 11, pp. 18-24 · 2026-09-30
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted), FY ending 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections Summary, triggers, outlook, key indicators · 2026-10-21
[5] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 Nov 2026 · 2026-11-10
[6] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-15
[7] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027 · 2026-10-13

Earnings tab updated at 2026-11-15 23:18 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review2-earn-vodafone/dashboard/dashboard.html (not published as an Artifact in this run).
