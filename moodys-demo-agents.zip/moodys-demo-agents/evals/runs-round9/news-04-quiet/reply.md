**Daily sector news: Telecoms, Europe: Proximus, Telekom Austria, Swisscom** (24h to 15 Nov 2026 23:14 UTC (from 14 Nov 2026 23:14 UTC); 3 names)

Nothing material for Telecoms, Europe (Proximus, Telekom Austria, Swisscom), in the last 24h.

Daily sector news tab updated 15 Nov 2026 23:15 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-04-quiet/dashboard/dashboard.html (not published as an Artifact in this run).
