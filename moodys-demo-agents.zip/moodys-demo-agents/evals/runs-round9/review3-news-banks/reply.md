**Daily sector news: European banks, 7 days** (168h (7 days) to 15 Nov 2026 23:16 UTC; 15 names)

UniCredit posted a record quarter and raised its 2026 profit ambition as approvals to take control of Commerzbank near; Crédit Agricole opened merger talks for its Italian arm with Banco BPM. [1]

**Top this week**

- **UniCredit** (Results / M&A): Q3 net profit rose 24% to €3.26bn (9 Nov), provisions rose to €210m from €113m, CET1 was 15.0%, and the 2026 profit ambition went to well above €11.5bn. Remaining approvals for control of Commerzbank are expected by late November; a report says the EU will clear it unconditionally. *Why it matters:* Moody's says the baa2 BCA could be upgraded once UniCredit controls and consolidates Commerzbank, if execution risk is contained. [1][2][3][4]
- **Credit Agricole S.A.** (M&A): On 9 Nov Crédit Agricole S.A. proposed talks to merge Crédit Agricole Italia with Banco BPM; Banco BPM's board opened discussions on 13 Nov, its chairman saying there is a lot of work to do. *Why it matters:* Moody's said on 13 Nov the plan will likely have no immediate rating implications for CASA, Groupe Crédit Agricole, Banco BPM or CA Italia, and could ultimately be positive for Banco BPM. [5][6][7]
- **Nordea Bank Abp** (Ruling): Copenhagen City Court on 9 Nov fined Nordea DKK 155m on two counts over its 2012-15 anti-money-laundering controls and cleared it of five others, far below what prosecutors had sought. [8][9]

**Macro**

- Euro area and US government bond yields rose on 13 Nov, with markets awaiting an S&P rating decision on Italy, whose sovereign rating caps Italian bank ratings at Moody's. [4][10][11]

**Sector**

- (Moody's actions): No rating action on the 15 listed groups. Moody's upgraded the deposit ratings of VUB, Intesa Sanpaolo's Slovak unit, to A1 (12 Nov) and assigned Baa1 issuer ratings to UniCredit Bank Czech Republic and Slovakia (9 Nov). [12][13]
- (Moody's research): The EBA's revised internal governance guidelines (5 Nov) are credit positive for EU banks, with a greater effect on smaller banks (sector comment, 11 Nov). [14]
- (Outlook): Latest Moody's outlooks: global banks stable (3 Dec 2025); banking systems stable for the UK (10 Feb 2026), France, Spain, Italy (9 Feb), the Netherlands and Switzerland (11 Feb); positive for Germany (9 Feb) and Finland (9 Mar). [15][16][17][18][19][20][21][22][23]

**By name**

| Name | Rating (class, outlook) | This week |
|---|---|---|
| BNP Paribas | A1 LT Issuer, stable [24] | No material credit news. |
| HSBC Holdings plc | A3 Senior Unsecured, positive [24] | $1.5bn 7.625% AT1 issued (13 Nov) to fund a tender for up to $1.5bn of 6.000% AT1; reported working on risk transfers on about $7bn of loans. [25][26] |
| Credit Agricole S.A. | A1 LT Issuer, stable [24] | Banco BPM merger talks (see Top). |
| Barclays PLC | Baa1 LT Issuer, stable [24] | No material credit news. |
| Societe Generale | A1 LT Issuer, negative [24] | No material credit news. |
| Deutsche Bank AG | A1 LT Issuer, positive [24] | BaFin imposed €8m of fines (11 Nov) over 2023 shortcomings in the Postbank migration. [27] |
| UBS Group AG | A2 Senior Unsecured, stable [24] | Swiss capital relief proposal reported going to a parliamentary commission 23-24 Nov: single source, unconfirmed. [28] |
| ING Groep N.V. | Baa1 Senior Unsecured, stable [24] | OCBC reported close to buying ING's Asian private bank for $1.5bn: single source, unconfirmed. [29] |
| Lloyds Banking Group plc | A3 Senior Unsecured, stable [24] | $1.25bn 2030 and $1.5bn 2032 senior notes (reported 13 Nov). [30] |
| UniCredit S.p.A. | A3 Senior Unsecured, stable; BCA and junior, sub and preferred ratings on review for upgrade [24][31] | See Top; $3.5bn senior non-preferred (13 Nov); €4.5bn interim dividend payable 25 Nov. [2][32] |
| Intesa Sanpaolo S.p.A. | A3 LT Issuer, stable [24] | £500m green senior non-preferred (12 Nov). Criticised bank levies in Italy's 2027 budget; cost not in the sources returned. Moody's credit opinion updated 12 Nov. [33][34][35] |
| Banco Bilbao Vizcaya Argentaria, S.A. | A2 LT Issuer, stable [24] | €1bn AT1 (reported 12 Nov); $2.05bn senior non-preferred notes (13 Nov). [36][37] |
| CaixaBank, S.A. | A2 LT Issuer, stable [24] | €1bn five-year green senior preferred (reported 10 Nov). [38] |
| Commerzbank AG | A2 LT Issuer, stable [24] | UniCredit control expected after approvals due late November (see Top). [2] |
| Nordea Bank Abp | Aa3 Senior Unsecured, stable [24] | AML ruling (see Top). |

Note: Rating class as Moody's returned it; outlook on that rating. UniCredit's review for upgrade is from 21 Jul 2026. [31]

**Notes**

- Window: 15 names from the checked European banks list; news searched 8 Nov 2026 23:16 to 15 Nov 2026 23:16 UTC. Moody's document searches filter by whole days (8 to 15 Nov).
- Q3 results from BNP Paribas, HSBC, Lloyds and Commerzbank came out before the window and are not reported as new. Lloyds and Commerzbank buybacks running in the window were announced earlier.
- Bank figures are company-reported, from news articles; none is Moody's-adjusted.

**Sources**

[1] Moody's (searchNews) · UniCredit Lifts FY26 Profit View After Higher Q3; Plans Control Of Commerzbank · RTT News, 202611091203HIND____NEWS__SA_n-105893063_810.221 · 2026-11-09
[2] Moody's (searchNews) · UniCredit stock: Profit rises 24% as Commerzbank control nears · Ad Hoc News, 202611110513AMSPIDEROPNTEEUR_20218_20228175 · 2026-11-11
[3] Moody's (searchNews) · EU set to clear UniCredit's Commerzbank deal, sources say · Shanghai News, 202611130901AMSPIDEROPNT__AS_179835_293358 · 2026-11-11
[4] Moody's (getCreditOpinion) · UniCredit S.p.A.: Update following placement of ratings on review for upgrade · PBC_1490860 · 2026-07-30
[5] Moody's (searchNews) · Moody's Ratings says Credit Agricole's announced offer to merge its Italian … · PR_533048 · 2026-11-13
[6] Moody's (searchNews) · Credit Agricole: Bpm gives go-ahead to talks, confirms strategic value of … · MarketScreener, 202611131039AMSPIDERAMC_USRF_37015_14175590 · 2026-11-13
[7] Moody's (searchNews) · Banco BPM chairman sees logic of Credit Agricole deal but says 'lots of work to … · Radiocor, 202611130527IL_SOLE_SOLENEWS_nRC_13_11_2026_11_27_305 · 2026-11-13
[8] Moody's (searchNews) · Nordea receives verdict in case about anti-money laundering measures from 2012 … · PRNewswire, 202611091011AMSPIDEROPNT__AM_114407_542231 · 2026-11-09
[9] Moody's (searchNews) · Nordea Fine for Flawed Laundering Controls Dodges Worst Case · Bloomberg Law, 202611091153AMSPIDEROPNT__AM_239029_498439 · 2026-11-09
[10] Moody's (searchNews) · U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes · Morningstar/Dow Jones, 202611130510AMSPIDEROPNT__AM_835_4659581 · 2026-11-13
[11] Moody's (searchNews) · Stock markets: Europe ends the week of Nvidia turmoil flat · Il Sole 24 Ore, 202611131304AMSPIDERNEWS__IT_165710_770294 · 2026-11-13
[12] Moody's (searchAllDocuments) · Moody's Ratings upgrades Vseobecna uverova banka, a.s.'s deposit ratings to A1 … · PR_531483 · 2026-11-12
[13] Moody's (searchAllDocuments) · Moody's Ratings assigns Baa1 issuer ratings to UniCredit Bank Czech Republic … · PR_530435 · 2026-11-09
[14] Moody's (searchAllDocuments) · Financial Institutions – Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[15] Moody's (searchAllDocuments) · Banks – Global: 2026 Outlook - Stable · PBC_1462959 · 2025-12-03
[16] Moody's (searchAllDocuments) · Banking System Outlook – United Kingdom · PBC_1463131 · 2026-02-10
[17] Moody's (searchAllDocuments) · Banking System Outlook – France · PBC_1470906 · 2026-02-09
[18] Moody's (searchAllDocuments) · Banking System Outlook – Spain · PBC_1471281 · 2026-02-09
[19] Moody's (searchAllDocuments) · Banking System Outlook – Italy · PBC_1469157 · 2026-02-09
[20] Moody's (searchAllDocuments) · Banking System Outlook – The Netherlands · PBC_1470890 · 2026-02-11
[21] Moody's (searchAllDocuments) · Banking System Outlook – Switzerland · PBC_1468651 · 2026-02-11
[22] Moody's (searchAllDocuments) · Banking System Outlook – Germany · PBC_1470410 · 2026-02-09
[23] Moody's (searchAllDocuments) · Banking System Outlook – Finland · PBC_1475274 · 2026-03-09
[24] Moody's ratings (getEntityRatings) · Moody's ratings pull, Moody's ratings pull · 2026-11-15
[25] Moody's (searchNews) · HSBC Holdings plc announces the satisfaction of the new issue condition in … · PRNewswire, 202611131144AMSPIDEROPNT__AM_114407_546100 · 2026-11-13
[26] Moody's (searchNews) · HSBC Plans SRTs Tied to $7 Billion of US, Asian Corporate Loans · Bloomberg Law, 202611120701AMSPIDEROPNT__AM_239029_498987 · 2026-11-12
[27] Moody's (searchNews) · Deutsche Bank Aktiengesellschaft: BaFin imposes administrative fines · Contify (BaFin release), 202611140415CONTIFY_NEWS____0069721962 · 2026-11-11
[28] Moody's (searchNews) · UBS Matures Ten ETN Lines as Bern Weighs Softer Capital Yardstick · Ad Hoc News, 202611140723AMSPIDEROPNTEEUR_20218_20242596 · 2026-11-14
[29] Moody's (searchNews) · ING Groep stock faces US$1.5 billion Asian private-bank deal · Ad Hoc News, 202611120546AMSPIDEROPNTEEUR_20218_20233261 · 2026-11-12
[30] Moody's (searchNews) · Lloyds Banking Group plc Files Supplemental Indenture for $1,250,000,000 and … · Nasdaq, 202611130706AMSPIDERFIN_NEWS_913_3227882 · 2026-11-13
[31] Moody's (searchAllDocuments) · Moody's Ratings places UniCredit S.p.A. on review for upgrade · PR_526711 · 2026-07-21
[32] Moody's (searchNews) · UniCredit raises USD 3.5bn via three-part senior bond issue · SeeNews Banking, 202611130642ADPR____BANKING__BNK_4338668 · 2026-11-13
[33] Moody's (searchNews) · Intesa Sanpaolo, record order book for sterling green bond · MarketScreener, 202611121331AMSPIDERAMC_USRF_37015_14172193 · 2026-11-12
[34] Moody's (searchNews) · Intesa criticises Italy for bank levies in 2027 budget, says ECB may intervene · Yahoo Finance UK (Reuters), 202611130039AMSPIDERFIN_NEWS_160688_2494583 · 2026-11-12
[35] Moody's (searchAllDocuments) · INTESA SANPAOLO S.P.A.: Update to credit analysis · PBC_1501726 · 2026-11-12
[36] Moody's (searchNews) · BBVA places €1 billion of a 'CoCo' with demand seven times higher · Contify (BBVA release), 202611121015CONTIFY_NEWS____0069710559 · 2026-11-12
[37] Moody's (searchNews) · Banco Bilbao Files Documents for Proposed $2.05 Billion Note Offering · TipRanks (Form 6-K), 202611131130AMSPIDERFIN_NEWS_299205_760056 · 2026-11-13
[38] Moody's (searchNews) · Caixabank raises EUR 1bn through green bond · SeeNews Banking, 202611100138ADPR____BANKING__BNK_4336439 · 2026-11-10

Dashboard: the Daily sector news tab was updated at 15 Nov 2026 23:22 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review3-news-banks/dashboard/dashboard.html. It was not published to a link in this session.
