Coverage for this run (your list, resolved in Moody's):

| Name | Country |
|---|---|
| Banco Santander, S.A. (Spain) | ES |
| BNP Paribas | FR |
| UniCredit S.p.A. | IT |

Unresolved: none.

**Daily sector news: Santander, BNP Paribas, UniCredit** (72h to 15 Nov 2026 23:15 UTC (from 12 Nov 2026 23:15 UTC); 3 names)

UniCredit raised USD 3.5bn of senior non-preferred debt on 13 Nov, its first US deal since 2021, while its Commerzbank takeover still awaits approvals; nothing material for Santander or BNP Paribas. [1][2]

**Top this window**

- **UniCredit** (Funding): On 13 Nov UniCredit issued USD 3.5bn of senior non-preferred notes in three tranches: USD 1.5bn 4NC3 at 5.970%, USD 1bn 6NC5 at 6.201% and USD 1bn 11-year at 6.585%. The bank cites demand above USD 20bn; first US issuance since 2021, starting 2027 pre-funding. *Why it matters:* Moody's notes UniCredit's deposit and senior unsecured ratings are sensitive to changes in its liability structure, which drive loss-given-failure in resolution. [1][2][3]
- **UniCredit** (M&A): Commerzbank takeover still pending: Orcel told Tagesschau (reported 15 Nov) control should come by early 2027 at the latest, with remaining approvals expected by end-November (first said 9 Nov). Nothing final in the window. *Why it matters:* Moody's says UniCredit's baa2 BCA could be upgraded once it gets all authorisations and settles, gaining control of Commerzbank, if execution risks are contained. [3][4][5]

**Macro**

- UK: headlines point to renewed pressure on the Bank of England to raise rates ahead of UK inflation data (15 Nov). [6]
- Euro area government bond yields rose on 13 Nov; the same report flagged a possible rating upgrade for Italy (not a Moody's statement). [7]

**Sector**

- **VUB (not on the list)** (Moody's action): Moody's upgraded Vseobecna uverova banka's deposit ratings to A1 from A2, outlook stable, dated 12 Nov (window start is 23:15 UTC that day). [8]
- **Greek banks (not on the list)** (Moody's research): Sector comment, 13 Nov: competition commission proposals unlikely to erode the big four Greek banks' deposit franchises. [9]
- (Outlook): Moody's 2026 global banks outlook is stable (3 Dec 2025). Banking system outlooks: Spain, France and Italy stable (all 9 Feb 2026). [10][11][12][13]

**By name**

| Name | Moody's rating | Credit news in window |
|---|---|---|
| Banco Santander | A1 LT Issuer Rating, stable [14] | No material credit news. |
| BNP Paribas | A1 LT Issuer Rating, stable [14] | No material credit news. |
| UniCredit | A3 Senior Unsecured, stable; BCA and junior senior, sub and preferred ratings on review for upgrade since 21 Jul 2026 [5][14] | USD 3.5bn SNP issue; Commerzbank approvals pending (see top). [1][4] |

Note: UniCredit's review covers BCA baa2, junior senior unsecured Baa2, subordinated Baa3 and preferred Ba2(hyb); deposit and senior unsecured A3 were affirmed with stable outlooks. [5]

**Notes**

- Left out as outside the window: UniCredit Q3 results and interim dividend (9 Nov) and BNP Paribas Q3 results and EUR 1.3bn buyback (28 Oct), retold in articles dated inside it.
- Santander: news filed under its rated record (orgId 383200) was mostly unrelated to the bank; the search returned no credit news on it.
- The search returned no Moody's rating action or research on the three listed names in the window.

**Sources**

[1] Moody's (searchNews) · UniCredit raises USD 3.5bn via three-part senior bond issue · SeeNews Banking 202611130642ADPR____BANKING__BNK_4338668 · 2026-11-13
[2] Moody's (searchNews) · UniCredit stock: Results and US bond issue shape weekly focus · Ad Hoc News 202611140641AMSPIDEROPNTEEUR_20218_20242477 · 2026-11-14
[3] Moody's (getCreditOpinion) · UniCredit S.p.A.: Update following placement of ratings on review for upgrade · Credit Opinion PBC_1490860, upgrade/downgrade factors and outlook · 2026-07-30
[4] Moody's (searchNews) · Commerzbank Trims Interest-Income Outlook...; Commerzbank stock: UniCredit … · Ad Hoc News 202611150605AMSPIDEROPNTEEUR_KHi5vIEv_1ab1e2fe; … · 2026-11-15
[5] Moody's (searchAllDocuments) · Moody's Ratings places UniCredit S.p.A. on review for upgrade · Rating Action PR_526711 · 2026-07-21
[6] Moody's (searchNews) · Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms · The Eastern Herald 202611151752ACI_INFOBLOGS_EN_EAHE_10010102 · 2026-11-15
[7] Moody's (searchNews) · Eurozone bond yields rise; Italy might get ratings upgrade · MSN US 202611130358AMSPIDERBRDCAST__28738_11440499 · 2026-11-13
[8] Moody's (searchAllDocuments) · Moody's Ratings upgrades Vseobecna uverova banka, a.s.'s deposit ratings to A1 … · Rating Action PR_531483 · 2026-11-12
[9] Moody's (searchAllDocuments) · Banks - Greece: competition commission's proposals unlikely to erode big four … · Sector Comment PBC_1502178 · 2026-11-13
[10] Moody's (searchAllDocuments) · Banks - Global: 2026 Outlook - Stable · Outlook PBC_1462959 · 2025-12-03
[11] Moody's (searchAllDocuments) · Banking System Outlook - Spain: Outlook stable · Outlook PBC_1471281 · 2026-02-09
[12] Moody's (searchAllDocuments) · Banking System Outlook - France: Outlook stable · Outlook PBC_1470906 · 2026-02-09
[13] Moody's (searchAllDocuments) · Banking System Outlook - Italy: Outlook stable · Outlook PBC_1469157 · 2026-02-09
[14] Moody's ratings (getEntityRatings) · Moody's ratings, three names · 2026-11-15

Dashboard: the Daily sector news tab was updated at 2026-11-15 23:18 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-06-banks-own-list/dashboard/dashboard.html (not published as an Artifact in this run).
