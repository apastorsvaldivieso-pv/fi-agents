import json
F="m1"
def c(v,src,tone=None):
    d={"v":v,"src":src}
    if tone: d["tone"]=tone
    return d
SF="bank sector file, pulled 15 Nov 2026: "
sources=[
 {"id":"s1","kind":"web","title":"Basel Committee: Amendments to G-SIB framework to address window dressing (standards)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"},
 {"id":"s2","kind":"web","title":"Basel Committee: Global systemically important banks - methodology review (consultative document)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
 {"id":"s4","kind":"web","title":"Basel Committee: Consolidated guidelines - consequential amendments (consultative document)","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
 {"id":"s5","kind":"web","title":"Basel Committee: Interest rate risk in the banking book - additional Pillar 2 guidance (consultative document)","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
 {"id":"s6","kind":"web","title":"EBA: revised Guidelines on internal governance (EBA/GL/2026/10)","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
 {"id":"s7","kind":"web","title":"EBA: next steps on supervisory reporting simplification, implementation timelines extended","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
 {"id":"s8","kind":"web","title":"EBA: 2027 EU-wide stress test streamlined with more than 55% reduction in requested data","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
 {"id":"s9","kind":"web","title":"PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
 {"id":"s10","kind":"web","title":"PRA: CP14/26 Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
 {"id":"s11","kind":"web","title":"FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
 {"id":"s12","kind":"web","title":"FINMA: partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
 {"id":"s13","kind":"web","title":"FSB: 2025 List of Global Systemically Important Banks (G-SIBs)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
 {"id":"m1","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026","title":"Moody's bank financials (Bank Focus), CET1 ratio","date":"2026-06-30"},
 {"id":"m2","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"UBS Group AG Second quarter 2026 report, as of 30 Jun 2026","title":"UBS required going-concern CET1 capital","date":"2026-06-30"},
 {"id":"m3","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"Societe Generale First quarter 2026 results, as of 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
 {"id":"m4","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"Credit Agricole S.A. First quarter 2026 results slides, as of 31 Mar 2026","title":"Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement","date":"2026-03-31"},
 {"id":"m5","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"BNP Paribas Third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 capital requirement","date":"2025-09-30"},
 {"id":"m6","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"Barclays PLC Form 20-F for 2025, as of 31 Dec 2025","title":"Barclays overall capital requirement for CET1","date":"2025-12-31"},
 {"id":"m7","kind":"moodys","tool":"searchCompanyFilings","ref":SF+"ING Groep N.V. Form 20-F for 2025, as of 31 Dec 2025","title":"ING MDA trigger level for CET1","date":"2025-12-31"},
 {"id":"m9","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042 (Sector Comment)","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
]
NR="not ranked"
t1={"title":"Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
 "columns":["Name","CET1 ratio, Q2 2026","vs median (pp)","Stated requirement (date)","Distance to requirement (pp)","Position"],
 "rows":[
  ["BNP Paribas",c("12.97%",[F]),c("-1.04",[F]),c("10.51%, 30 Sep 2025, older",["m5"]),c("2.46",[F,"m5"]),{"tone":"weaker","v":""}],
  ["ING Groep N.V.",c("13.07%",[F]),c("-0.94",[F]),c("11.03% MDA trigger, 31 Dec 2025, older",["m7"]),c("2.04",[F,"m7"]),{"tone":"weaker","v":""}],
  ["Societe Generale",c("13.2%",[F]),c("-0.81",[F]),c("10.26%, 31 Mar 2026",["m3"]),c("2.94",[F,"m3"]),{"tone":"middle","v":""}],
  ["Deutsche Bank AG",c("13.92%",[F]),c("-0.09",[F]),"not stated","not stated",{"tone":"middle","v":""}],
  ["HSBC Holdings plc",c("14.1%",[F]),c("+0.09",[F]),"not stated","not stated",{"tone":"middle","v":""}],
  ["Barclays PLC",c("14.3%",[F]),c("+0.29",[F]),c("12.2%, 31 Dec 2025, older",["m6"]),c("2.10",[F,"m6"]),{"tone":"middle","v":""}],
  ["UBS Group AG",c("14.38%",[F]),c("+0.37",[F]),c("10.83% going-concern, 30 Jun 2026",["m2"]),c("3.55",[F,"m2"]),{"tone":"stronger","v":""}],
  ["Groupe Credit Agricole",c("17.23%",[F]),c("+3.22",[F]),"total not stated",c("6.7, bank-stated, 31 Mar 2026 (phased-in)",["m4"]),{"tone":"stronger","v":""}]],
 "note":"Covers banks on the FSB G-SIB list; reporting and disclosure fall on the wider assessment sample. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Issuer on the list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above its SREP requirement (31 Mar 2026).",
 "note_src":["s1","s13",F,"m4"]}
t2={"title":"Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
 "columns":["Name","CET1 ratio, Q2 2026","vs median (pp)","Stated requirement (date)","Distance to requirement (pp)","Position"],
 "rows":[
  ["BNP Paribas",c("12.97%",[F]),NR,c("10.51%, 30 Sep 2025, older",["m5"]),c("2.46",[F,"m5"]),"list too short to rank"],
  ["ING Groep N.V.",c("13.07%",[F]),NR,c("11.03% MDA trigger, 31 Dec 2025, older",["m7"]),c("2.04",[F,"m7"]),"list too short to rank"],
  ["Societe Generale",c("13.2%",[F]),NR,c("10.26%, 31 Mar 2026",["m3"]),c("2.94",[F,"m3"]),"list too short to rank"],
  ["Deutsche Bank AG",c("13.92%",[F]),NR,"not stated","not stated","list too short to rank"],
  ["Groupe Credit Agricole",c("17.23%",[F]),NR,"total not stated",c("6.7, bank-stated, 31 Mar 2026 (phased-in)",["m4"]),"list too short to rank"]],
 "note":"The page names no addressees; it asks whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework. Our reading: it covers the five banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (not in the banking union); the other seven names are not G-SIBs (FSB list, 27 Nov 2025).",
 "note_src":["s2","s13"]}
items=[
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 finalises Large Exposures changes: mandatory substitution approach, trading book excess allowance for third-party exposures cut to up to 85% of Tier 1 capital, higher NCLEG trading book limit of 350% of Tier 1. Takes effect 1 January 2028.","why":"Large exposures channel; covers HSBC, Barclays, Lloyds.","src":["s9"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance published, with the banks' revised due-diligence code recognised as a minimum standard. In force 1 January 2027, four-month transition for self-regulation.","why":"AML channel; covers UBS.","src":["s12"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, controls, earnings indicators) and a new supervisory information report. Comments by 9 February 2027.","why":"IRRBB channel; covers all names once home regulators apply it.","src":["s5"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology and draft templates for the 2027 EU-wide stress test, with more than 55% reduction in requested data and a climate-risk module. Launch end of January 2027; results end of July 2027.","why":"Stress testing channel; the participating sample is set in the methodology, not on the page.","src":["s8"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Supervisory reporting simplification: final draft ITS report due December 2026; first reference date for new requirements postponed to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred until December 2028.","why":"Reporting channel; covers EU/EEA banks.","src":["s7"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance under the CRD (EBA/GL/2026/10), reflecting CRD VI with more proportionality. Application date not stated on the page. Moody's (11 Nov 2026): \"credit positive for small EU banks\", smaller effect on larger banks already adopting them.","why":"","src":["s6","m9"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026.","why":"No channel map row; shown as watch by our judgment.","src":["s4"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consultation on partially revised Circular 2019/2 \"Interest rate risks - banks\", applying the Basel interest rate shock scenarios recalibrated in July 2024. Open until 15 January 2027.","why":"IRRBB channel; covers UBS.","src":["s11"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26, Phase 2 of the Senior Managers and Certification Regime review: some roles move from pre-approval to notification, certification fitness assessments removed. Responses by 22 January 2027.","why":"Governance channel; covers HSBC, Barclays, Lloyds.","src":["s10"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"G-SIB window-dressing amendments finalised: G-SIB indicators to use yearly averages rather than year-end figures, by 1 January 2030; reporting and disclosure threshold raised to EUR 350 billion leverage exposure from 1 January 2027.","why":"Changes how G-SIB scores, and so the G-SIB buffer, are measured: CET1 channel.","src":["s1"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"G-SIB methodology review: periodic review, including whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 January 2027.","why":"CET1 channel (G-SIB buffer); banking-union G-SIBs only.","src":["s2"]},
]
DATES={'s9': '10 Nov', 's12': '10 Nov', 's5': '9 Nov', 's8': '9 Nov', 's7': '6 Nov', 's6': '5 Nov', 's4': '5 Nov', 's11': '4 Nov', 's10': '22 Oct', 's1': '16 Oct', 's2': '16 Oct'}
for it in items:
    it["tag"]=it["tag"]+", "+DATES[it["src"][0]]+" 2026"
    if not it["why"]: del it["why"]
EU="11 EU/EEA names (all but HSBC, Barclays, Lloyds, UBS)"
w=lambda: {"tone":"watch","v":"watch"}
t3={"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],
 "rows":[
  ["PRA PS20/26 large exposures","HSBC, Barclays, Lloyds","Large exposures",w()],
  ["FINMA AML Ordinance","UBS","AML",w()],
  ["Basel IRRBB Pillar 2 guidance","All 15, once applied at home","IRRBB",w()],
  ["FINMA Circular 2019/2 interest rate risks","UBS","IRRBB",w()],
  ["EBA 2027 stress test","Scope not known: sample set in the methodology","Stress testing",w()],
  ["EBA reporting simplification",EU,"Reporting",w()],
  ["EBA internal governance guidelines",EU,"Governance",w()],
  ["Basel consolidated guidelines amendments","All 15, once applied at home","None (framework text)",w()],
  ["PRA CP14/26 SM&CR","HSBC, Barclays, Lloyds","Governance",w()]],
 "note":"Moody's bank financials carry no field for these channels."}
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"UPDATED",
 "scope":{"label":"Banks Europe, 16 Oct-15 Nov","sector":"Banks","region":"Europe","window":"16 Oct to 15 Nov 2026","names":15},
 "status":"ok",
 "headline":"Eleven regulatory items in the window; the Basel Committee's G-SIB window-dressing amendments (final) hit CET1 for the eight G-SIBs on the list, where BNP Paribas (12.97%) and ING (13.07%) are the weaker third at Q2 2026.",
 "headline_src":["s1",F],
 "sections":[t1,t2,{"title":"What changed","type":"items","items":items},t3],
 "sources":sources,"unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Left out, not measures for banks: speeches, interviews, blogs (ECB 8, SRB 3, FINMA 1); sanctions notices (FINMA 9, Commission 3); newsletters (Basel, PRA); ECB entity list and Eurogroup report.",
  "Also left out: PRA credit-union papers; EBA Taxonomy advice, consumer factsheet, appointment, moved deadline, NGFS statement; Commission assurance feedback, dialogue summary, tokenisation call; FINMA Bitcoin ETF.",
  "G-SIB scope: FSB list of 27 Nov 2025 (no 2026 list found on fsb.org). Groupe Credit Agricole shown at Q2 2026 to match the others; its latest is Q3 2026.",
 ],
 "meta":{"calls":{"moodys":6,"web":27}}}
import subprocess
run["updated_at"]=subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
