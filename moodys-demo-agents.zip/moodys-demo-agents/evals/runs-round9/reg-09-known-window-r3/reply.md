**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Eleven regulatory items in the window; the Basel Committee's G-SIB window-dressing amendments (final) hit CET1 for the eight G-SIBs on the list, where BNP Paribas (12.97%) and ING (13.07%) are the weaker third at Q2 2026. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51%, 30 Sep 2025, older [3] | 2.46 [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger, 31 Dec 2025, older [4] | 2.04 [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26%, 31 Mar 2026 [5] | 2.94 [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2%, 31 Dec 2025, older [6] | 2.10 [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern, 30 Jun 2026 [7] | 3.55 [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [2] | +3.22 [2] | total not stated | 6.7, bank-stated, 31 Mar 2026 (phased-in) [8] | Stronger third |

Note: Covers banks on the FSB G-SIB list; reporting and disclosure fall on the wider assessment sample. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three names have a current stated requirement. Issuer on the list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above its SREP requirement (31 Mar 2026). [1][2][8][9]

**Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51%, 30 Sep 2025, older [3] | 2.46 [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% MDA trigger, 31 Dec 2025, older [4] | 2.04 [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26%, 31 Mar 2026 [5] | 2.94 [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% [2] | not ranked | total not stated | 6.7, bank-stated, 31 Mar 2026 (phased-in) [8] | list too short to rank |

Note: The page names no addressees; it asks whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework. Our reading: it covers the five banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (not in the banking union); the other seven names are not G-SIBs (FSB list, 27 Nov 2025). [9][10]

**What changed**

- [NEW] **PRA** (Final, 10 Nov 2026): PS20/26 finalises Large Exposures changes: mandatory substitution approach, trading book excess allowance for third-party exposures cut to up to 85% of Tier 1 capital, higher NCLEG trading book limit of 350% of Tier 1. Takes effect 1 January 2028. *Why it matters:* Large exposures channel; covers HSBC, Barclays, Lloyds. [11]
- [NEW] **FINMA** (Final, 10 Nov 2026): Partially revised FINMA Anti-Money Laundering Ordinance published, with the banks' revised due-diligence code recognised as a minimum standard. In force 1 January 2027, four-month transition for self-regulation. *Why it matters:* AML channel; covers UBS. [12]
- [NEW] **Basel Committee** (Consultation, 9 Nov 2026): Additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, controls, earnings indicators) and a new supervisory information report. Comments by 9 February 2027. *Why it matters:* IRRBB channel; covers all names once home regulators apply it. [13]
- [NEW] **EBA** (Final, 9 Nov 2026): Final methodology and draft templates for the 2027 EU-wide stress test, with more than 55% reduction in requested data and a climate-risk module. Launch end of January 2027; results end of July 2027. *Why it matters:* Stress testing channel; the participating sample is set in the methodology, not on the page. [14]
- [NEW] **EBA** (Other, 6 Nov 2026): Supervisory reporting simplification: final draft ITS report due December 2026; first reference date for new requirements postponed to December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred until December 2028. *Why it matters:* Reporting channel; covers EU/EEA banks. [15]
- [NEW] **EBA** (Final, 5 Nov 2026): Revised Guidelines on internal governance under the CRD (EBA/GL/2026/10), reflecting CRD VI with more proportionality. Application date not stated on the page. Moody's (11 Nov 2026): "credit positive for small EU banks", smaller effect on larger banks already adopting them. [16][17]
- [NEW] **Basel Committee** (Consultation, 5 Nov 2026): Consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026. *Why it matters:* No channel map row; shown as watch by our judgment. [18]
- [NEW] **FINMA** (Consultation, 4 Nov 2026): Consultation on partially revised Circular 2019/2 "Interest rate risks - banks", applying the Basel interest rate shock scenarios recalibrated in July 2024. Open until 15 January 2027. *Why it matters:* IRRBB channel; covers UBS. [19]
- [NEW] **PRA** (Consultation, 22 Oct 2026): CP14/26, Phase 2 of the Senior Managers and Certification Regime review: some roles move from pre-approval to notification, certification fitness assessments removed. Responses by 22 January 2027. *Why it matters:* Governance channel; covers HSBC, Barclays, Lloyds. [20]
- [NEW] **Basel Committee** (Final, 16 Oct 2026): G-SIB window-dressing amendments finalised: G-SIB indicators to use yearly averages rather than year-end figures, by 1 January 2030; reporting and disclosure threshold raised to EUR 350 billion leverage exposure from 1 January 2027. *Why it matters:* Changes how G-SIB scores, and so the G-SIB buffer, are measured: CET1 channel. [1]
- [NEW] **Basel Committee** (Consultation, 16 Oct 2026): G-SIB methodology review: periodic review, including whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 January 2027. *Why it matters:* CET1 channel (G-SIB buffer); banking-union G-SIBs only. [10]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures | HSBC, Barclays, Lloyds | Large exposures | Watch |
| FINMA AML Ordinance | UBS | AML | Watch |
| Basel IRRBB Pillar 2 guidance | All 15, once applied at home | IRRBB | Watch |
| FINMA Circular 2019/2 interest rate risks | UBS | IRRBB | Watch |
| EBA 2027 stress test | Scope not known: sample set in the methodology | Stress testing | Watch |
| EBA reporting simplification | 11 EU/EEA names (all but HSBC, Barclays, Lloyds, UBS) | Reporting | Watch |
| EBA internal governance guidelines | 11 EU/EEA names (all but HSBC, Barclays, Lloyds, UBS) | Governance | Watch |
| Basel consolidated guidelines amendments | All 15, once applied at home | None (framework text) | Watch |
| PRA CP14/26 SM&CR | HSBC, Barclays, Lloyds | Governance | Watch |

Note: Moody's bank financials carry no field for these channels.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out, not measures for banks: speeches, interviews, blogs (ECB 8, SRB 3, FINMA 1); sanctions notices (FINMA 9, Commission 3); newsletters (Basel, PRA); ECB entity list and Eurogroup report.
- Also left out: PRA credit-union papers; EBA Taxonomy advice, consumer factsheet, appointment, moved deadline, NGFS statement; Commission assurance feedback, dialogue summary, tokenisation call; FINMA Bitcoin ETF.
- G-SIB scope: FSB list of 27 Nov 2025 (no 2026 list found on fsb.org). Groupe Credit Agricole shown at Q2 2026 to match the others; its latest is Q3 2026.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing … · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Groep N.V. Form 20-F for 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall capital requirement for CET1 · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F for 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 capital · bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole S.A. First quarter 2026 results … · 2026-03-31
[9] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[10] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[11] Web · PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[12] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[14] Web · EBA: 2027 EU-wide stress test streamlined with more than 55% reduction in … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · EBA: next steps on supervisory reporting simplification, implementation … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[16] Web · EBA: revised Guidelines on internal governance (EBA/GL/2026/10) · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[17] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 (Sector Comment) · 2026-11-11
[18] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · PRA: CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated at 2026-11-15T23:18:18Z (UTC). Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r3/dashboard/dashboard.html. Not published to the private link in this run.
