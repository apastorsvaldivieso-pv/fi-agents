**Regulatory watch: Banks Europe, 10 names, 30 days** (30 days, 16 Oct to 15 Nov 2026; 10 names)

Twelve regulatory items in the 30 days to 15 Nov 2026; the two that touch capital are the Basel Committee's G-SIB measures of 16 Oct. No liquidity change was found: all nine names with data are above the 100% LCR minimum, HSBC and BNP Paribas closest. [1][2][3][4]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (Q2 2026) | vs median (pp) | Stated requirement | Distance (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [5] | -0.95 [5] | 10.51%, 30 Sep 2025, older [6] | 2.46 [5][6] | Weaker third |
| ING Groep | 13.07% [5] | -0.85 [5] | 11.03% (MDA trigger), 31 Dec 2025, older [7] | 2.04 [5][7] | Weaker third |
| Societe Generale | 13.2% [5] | -0.72 [5] | 10.26%, 31 Mar 2026 [8] | 2.94 [5][8] | Middle |
| Deutsche Bank | 13.92% [5] | 0.00 [5] | not stated | - | Middle |
| HSBC | 14.1% [5] | +0.18 [5] | not stated | - | Middle |
| Barclays | 14.3% [5] | +0.38 [5] | 12.2%, 31 Dec 2025, older [9] | 2.10 [5][9] | Stronger third |
| UBS | 14.38% [5] | +0.46 [5] | 10.83% (going-concern), 30 Jun 2026 [10] | 3.55 [5][10] | Stronger third |
| BPCE (Groupe BPCE is the G-SIB) | not in Moody's data [11] | not ranked | not stated | - | Not ranked: record may not be the consolidated group |

Note: Page names no addressees; banks in the Basel Committee sample report the indicators, but the G-SIB buffer falls only on listed G-SIBs. Out of scope: DZ Bank, Raiffeisen Bank International (not on the FSB G-SIB list of 27 Nov 2025; no 2026 list found). BPCE not ranked: record may not be the consolidated group. Ranked by level: only two names have a current stated requirement. [1][12]

**Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (Q2 2026) | vs median (pp) | Stated requirement | Distance (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [5] | not ranked | 10.51%, 30 Sep 2025, older [6] | 2.46 [5][6] | list too short to rank |
| ING Groep | 13.07% [5] | not ranked | 11.03% (MDA trigger), 31 Dec 2025, older [7] | 2.04 [5][7] | list too short to rank |
| Societe Generale | 13.2% [5] | not ranked | 10.26%, 31 Mar 2026 [8] | 2.94 [5][8] | list too short to rank |
| Deutsche Bank | 13.92% [5] | not ranked | not stated | - | list too short to rank |
| BPCE (Groupe BPCE is the G-SIB) | not in Moody's data [11] | not ranked | not stated | - | Not ranked: record may not be the consolidated group |

Note: Our reading: the page names no addressees and concerns cross-border exposures within the European Banking Union, so it covers banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (outside the banking union); DZ Bank, Raiffeisen Bank International (not G-SIBs). [2][12]

**Who it hits: Liquidity (asked; no regulatory change found) · LCR**

| Name | LCR (Q2 2026) | vs median (pp) | Stated requirement | Distance (pp) | Position |
|---|---|---|---|---|---|
| HSBC | 134% [4] | -6.12 [4] | 100% minimum [3] | 34.00 [3][4] | Least headroom |
| BNP Paribas | 134.77% [4] | -5.35 [4] | 100% minimum [3] | 34.77 [3][4] | Least headroom |
| ING Groep | 137% [4] | -3.12 [4] | 100% minimum [3] | 37.00 [3][4] | Middle |
| Deutsche Bank | 140.12% [4] | 0.00 [4] | 100% minimum [3] | 40.12 [3][4] | Middle |
| Societe Generale | 146.41% [4] | +6.29 [4] | 100% minimum [3] | 46.41 [3][4] | Middle |
| Barclays | 157.7% [4] | +17.58 [4] | 100% minimum [3] | 57.70 [3][4] | Most headroom |
| UBS | 177.28% [4] | +37.16 [4] | 100% minimum [3] | 77.28 [3][4] | Most headroom |
| Raiffeisen Bank International | 143.65% [4] | not ranked | 100% minimum [3] | 43.65 [3][4] | Not ranked: record may not be the consolidated group |
| DZ Bank | 148.75% [4] | not ranked | 100% minimum [3] | 48.75 [3][4] | Not ranked: record may not be the consolidated group |
| BPCE | not in Moody's data [11] | not ranked | 100% minimum [3] | - | Not ranked: record may not be the consolidated group |

Note: The LCR minimum applies to all ten names. DZ Bank, Raiffeisen Bank International and BPCE are central institutions of co-operative groups: shown, not ranked, and left out of the median, because the record may not be the consolidated group. [3]

**What changed**

- [NEW] **PRA, 10 Nov** (Final): PS20/26 finalises the remaining Large Exposures changes: credit risk mitigation substitution made mandatory, a tighter trading book excess allowance, targeted exemptions and a higher intragroup limit. Takes effect 1 Jan 2028. Channel: large exposures. [13]
- [NEW] **FINMA, 10 Nov** (Final): Final partially revised Anti-Money Laundering Ordinance, with revised bank due-diligence rules (VSB 27) recognised as minimum standards. In force 1 Jan 2027. Channel: AML. [14]
- [NEW] **Basel Committee, 9 Nov** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, controls, embedded gains and losses on securities, earnings indicators, plus a new supervisory reporting requirement. Comments by 9 Feb 2027. Channel: IRRBB (no Moody's metric). [15]
- [NEW] **EBA, 9 Nov** (Final): Final methodology and draft templates for the 2027 EU-wide stress test, with "more than 55%" fewer data points and a first climate risk module. Launch end of January 2027, results end of July 2027; the sample is not stated on the page. Channel: stress testing. [16]
- [NEW] **EBA, 6 Nov** (Other): Next steps after the supervisory reporting consultation: first reference date for new requirements postponed to December 2027, December 2028 for liquidity, asset encumbrance, benchmarking and ESG reporting; final report due December 2026. Channel: reporting. [17]
- [NEW] **EBA, 5 Nov** (Final): Revised Guidelines on internal governance under CRD VI, adding proportionality and simplification; application date not stated on the page. Channel: governance. *Why it matters:* Moody's calls the revisions credit positive for small EU banks, with a smaller effect on larger banks already adopting them (11 Nov 2026). [18][19]
- [NEW] **Basel Committee, 5 Nov** (Consultation): Consequential amendments aligning Basel Framework cross-references with the new consolidated guidelines and moving "Application guidance" into them. Comments by 21 Dec 2026. No channel-map row; mapped to watch by our judgment. [20]
- [NEW] **FINMA, 4 Nov** (Consultation): Consultation on partially revised Circular 2019/2 "Interest rate risks - banks", applying recalibrated Basel interest rate shocks. Comments by 15 Jan 2027. Channel: IRRBB. [21]
- [NEW] **European Commission, 22 Oct** (Other): Political agreement on the Securitisation Framework review, including a "more risk sensitive" CRR treatment of securitisations; awaits technical finalisation and formal approval. Channel: securitisation. [22]
- [NEW] **PRA, 22 Oct** (Consultation): CP14/26 proposes lighter Senior Managers and Certification Regime requirements, moving many roles from pre-approval to notification. Comments by 22 Jan 2027. Channel: governance, conduct. [23]
- [NEW] **Basel Committee, 16 Oct** (Final): G-SIB score indicators to be reported and disclosed as year averages, not year-end values, by 1 Jan 2030; the reporting threshold rises to EUR 350 billion from 1 Jan 2027. Channel: capital (G-SIB buffer). [1]
- [NEW] **Basel Committee, 16 Oct** (Consultation): Consults on whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB methodology. Comments by 14 Jan 2027. Channel: capital (G-SIB buffer). [2]
- **Liquidity** (Asked): No regulatory change to the liquidity channel was found at the primary regulators in the window. Shown because you asked for it.

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| BCBS IRRBB Pillar 2 guidance (consultation) | All ten, once home countries apply it | IRRBB | Watch |
| BCBS consolidated guidelines amendments (consultation) | All ten, once home countries apply it | none (cross-references) | Watch |
| EBA 2027 stress test methodology | Scope not known (sample not stated): BNP Paribas, Societe Generale, Deutsche Bank, ING, BPCE, DZ Bank, Raiffeisen Bank International | stress test results | Watch |
| EBA reporting next steps | BNP Paribas, Societe Generale, Deutsche Bank, ING, BPCE, DZ Bank, Raiffeisen Bank International | reporting | Watch |
| EBA internal governance guidelines | BNP Paribas, Societe Generale, Deutsche Bank, ING, BPCE, DZ Bank, Raiffeisen Bank International | governance | Watch |
| EU securitisation framework agreement | BNP Paribas, Societe Generale, Deutsche Bank, ING, BPCE, DZ Bank, Raiffeisen Bank International | securitisation | Watch |
| PRA PS20/26 large exposures | HSBC, Barclays | large exposures | Watch |
| PRA CP14/26 SM&CR (consultation) | HSBC, Barclays | governance, conduct | Watch |
| FINMA Circular 2019/2 (consultation) | UBS | IRRBB | Watch |
| FINMA AML Ordinance | UBS (addressees not stated on page) | AML | Watch |

Note: Moody's data carries no metric for these channels. Scope is judged for each group at its home; EU subsidiaries of HSBC, Barclays and UBS are not counted.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- The 3% and 100% minimums are Basel III standards; local rules can be higher. The FSB's 2026 G-SIB list was not found on fsb.org by 15 Nov 2026, so the 27 Nov 2025 list is used.
- BPCE, DZ Bank and Raiffeisen Bank International were resolved in Moody's for this run (FR, DE, AT). The BPCE record returned no CET1 or LCR; its latest period is Q4 2024.
- Left out (21): speeches, interviews, blogs, newsletters, meeting summaries, sanctions notices, appointments, statistics, a periodic list, consumer material, advice to the Commission, a moved deadline, and measures for credit unions, assurance providers or a fund.

**Sources**

[1] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · BCBS: Global systemically important banks - methodology review (consultation) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Web · Basel Framework (LEV, LCR, NSF standards) · 2026-11-15 · https://www.bis.org/basel_framework/
[4] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 · Bank financials, LCR · 2026-06-30
[5] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · Bank financials, CET1 · 2026-06-30
[6] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Q3 2025 report, as of 30 Sep 2025 · 2025-09-30
[7] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale Q1 2026 results, as of 31 Mar 2026 · 2026-03-31
[9] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[10] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[11] Moody's financials (getEntityFinancials_v2) · BPCE SA record: LQ = Q4 2024 with no CET1 or LCR; Q2 2026 returned no fields · BPCE · 2024-12-31
[12] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[13] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[15] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[16] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[17] Web · EBA outlines next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[18] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[19] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[20] Web · BCBS: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[21] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[22] Web · Commission welcomes political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[23] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 15 Nov 2026, 23:16 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-11-coop-names/dashboard/dashboard.html (not published: Artifact publish skipped in this test run).
