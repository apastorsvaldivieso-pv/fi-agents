**Earnings: Iliad Holding S.A.S., recap** (Latest results in Moody's data: LTM to 30 Jun 2026; 1 name)

Moody's holds no call transcript and no results report for Iliad Holding, so this recap rests on Moody's data alone: Moody's-adjusted debt/EBITDA of 4.20x for the 12 months to June 2026 sits 0.70x above the 3.5x upgrade trigger, with the Ba2 CFR on stable outlook. [1][2][3]

**Results against the credit view**

- **Transcript and filing** (Missing): Moody's returned no earnings call transcript for Iliad Holding, and no interim or annual results report (the filing search returned 'not found' or 'ingesting' across five tries each). Guidance, beat or miss against guidance, company net debt, liquidity, maturities, capex, dividends, impairments and legal matters are therefore not covered. [4][5]
- **LTM to 30 Jun 2026** (Moody's-adjusted): Revenue EUR 16,712m, EBITDA EUR 7,906m, total debt EUR 33,195m, debt/EBITDA 4.20x, RCF/net debt 13.99%, (EBITDA - capex)/interest 2.27x. Against FY2025: debt/EBITDA 4.18x, RCF/net debt 15.68%, total debt EUR 31,123m. [2]
- **2026F** (Against Moody's forecast): Moody's 2026 forecast: revenue EUR 17.4bn, debt/EBITDA 4.3x, RCF/net debt 14.5%, (EBITDA - capex)/interest 2.1x. The LTM June 2026 figures are a half-year view, not the full year the forecast covers: debt/EBITDA 4.20x and coverage 2.27x are on the better side of the forecast, RCF/net debt 13.99% below it. [2][3]
- **Last 45 days** (Moody's comment): No Moody's issuer comment, rating action or credit opinion on Iliad Holding was published between 1 Oct and 15 Nov 2026. [6]

**Against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 4.20x, LTM Jun 2026 [2] | below 3.5x [3] | remains well above 4.0x [3] | 0.70x to upgrade level; 0.20x above 4.0x [2][3] |
| RCF / Net debt | 13.99%, LTM Jun 2026 [2] | towards 25% [3] | no number stated | 11.01 points to upgrade level [2][3] |

Note: Worded triggers (credit opinion, 30 Jun 2026): upgrade needs 'strong and stable revenue growth, with a sustainable EBITDA margin'; downgrade if 'operating performance deteriorates' or large debt-financed acquisitions or distributions, with Moody's-adjusted FCF that 'weakens significantly'. [3]

**What it means for the rating and outlook**

- **Position**: Ba2 LT Corporate Family Rating, upgraded on 19 Jun 2026, outlook stable. Debt/EBITDA of 4.20x is above the 4.0x reference in the downgrade trigger and 0.70x short of the 3.5x upgrade level. [1][2][3]
- **Opinion date**: The credit opinion is dated 30 Jun 2026 and its key indicators run to FY2025, so it predates the LTM June 2026 figures and any later results. Company-reported net debt since June 2026 is not available: no filing was returned. [2][3][5]
- **SFR acquisition**: The outlook 'incorporates our expectation of a reduction in leverage following the completion of the transaction', and the credit challenges list 'execution risk associated with the proposed acquisition of SFR'. [3]

**Notes**

- No transcript or results filing, so this recap uses Moody's data only; the latest period Moody's holds is LTM to 30 Jun 2026. Results published after that date are not reflected.
- Iliad S.A., the listed subsidiary, is a separate Moody's entity with its own rating and filings; it is not covered here.

**Sources**

[1] Moody's ratings (getEntityRatings) · Iliad Holding S.A.S. · 2026-11-15
[2] Moody's financials (getEntityFinancials_v2) · Key indicators, Moody's-adjusted, LTM 30 Jun 2026 and FY2025 · Iliad Holding S.A.S. · 2026-06-30
[3] Moody's (getCreditOpinion) · Iliad Holding S.A.S.: Update following rating upgrade to Ba2 · PBC_1488484, sections Summary, Credit Strengths/Challenges, Upgrade/Downgrade factors, … · 2026-06-30
[4] Moody's (searchCompanyFilings) · Iliad Holding S.A.S. earnings call transcript search · earnings_call_transcript: not_found · 2026-11-15
[5] Moody's (searchCompanyFilings) · Iliad Holding S.A.S. results filing search · interim and annual: not_found / ingesting, five tries per query · 2026-11-15
[6] Moody's (searchAllDocuments) · Moody's comment on Iliad Holding results · Issuer Comment, Rating Action, Credit Opinion, 1 Oct to 15 Nov 2026: no documents · 2026-11-15

Earnings tab updated at 2026-11-15 23:21 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html (not published as an Artifact in this run).
