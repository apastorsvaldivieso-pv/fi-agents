I couldn't build an earnings preview for Zzyzx Fakecorp Holdings. Moody's has no entity under that name. The name search found no match and no alternative candidates, so there is no rating, credit opinion, triggers, financials or call transcript to work from.

I haven't substituted a similarly named company or used anything outside Moody's data, and nothing has been saved to the dashboard.

To try again, send me any of these:
- the exact legal name, or the name of the parent or rated issuing company
- the home country
- a ticker, LEI or Moody's entity ID

With one of those I'll look it up again and build the preview.
