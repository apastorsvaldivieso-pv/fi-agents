**Regulatory watch: Banks Europe, 30 days** (16 Oct to 15 Nov 2026 (30 days); 15 names)

Twelve new regulatory items in 30 days; the Basel Committee's final G-SIB window-dressing amendments are the one mapped to capital, and among the eight G-SIBs on the list BNP Paribas and ING sit in the weaker third on CET1. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% (30 Sep 2025, older) [3] | 2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger (31 Dec 2025, older) [4] | 2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26% (31 Mar 2026) [5] | 2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2% (31 Dec 2025, older) [6] | 2.10 pp [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern (30 Jun 2026) [7] | 3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole (for Credit Agricole S.A.) | 17.23% [8] | +3.22 [8] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Covers the banks on the FSB G-SIB list of 27 Nov 2025; the 2026 list is not yet out. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea. Ranked by level: three names have a current requirement. Issuer on the list: Credit Agricole S.A., 11.3% at Q2 2026, 2.6 pp above SREP at 31 Mar 2026. The methodology consultation covers only BNP, Credit Agricole, Societe Generale, Deutsche Bank and ING (our reading). [2][9][10][11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises Part 2 of the large exposures changes: no internal model option for securities financing exposure values, and substitution mandatory for all firms. Takes effect 1 January 2028. *Why it matters:* Large exposures channel: watch. [12]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance published, aligned with the amended AMLA ahead of the FATF evaluation. In force 1 January 2027. [13]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book, drawing on weaknesses seen in periods of high inflation and rapid rate rises. Comments by 9 February 2027. *Why it matters:* IRRBB channel: watch. [14]
- [NEW] **EBA** (Final): Final 2027 EU-wide stress test methodology, with a more than 55% reduction in requested data and a climate module "without affecting the core stress test results". Launch end of January 2027, results end of July 2027. *Why it matters:* Stress-testing channel: watch. [15]
- [NEW] **EBA** (Other): Next steps on reporting simplification: final report on the draft ITS in December 2026; first reference date December 2027, with liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10), with less detail on mapping duties and more proportionality; application date not stated. Moody's (11 Nov 2026) calls them credit positive for small EU banks, with less effect on large banks already adopting them. [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026. No channel in the map; tagged watch by our judgment. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on banks' interest rate risks, updating banking-book shocks to the Basel recalibration of July 2024. Consultation until 15 January 2027. [20]
- [NEW] **PRA** (Consultation): CP14/26 would move almost half of current Senior Manager Functions to a notification approach. Comments by 22 January 2027; implementation expected H2 2027. [21]
- [NEW] **European Commission** (Legislative step): Political agreement on the securitisation framework review; the CRR amendments make the prudential treatment of securitisations "more risk sensitive". Formal adoption pending; no application date stated. [22]
- [NEW] **Basel Committee** (Consultation): Consults on whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB methodology. Comments by 14 January 2027. *Why it matters:* Capital channel (G-SIB buffer): five banking-union G-SIBs, see table note. [11]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be reported using averages over the year instead of year-end figures, by 1 January 2030; the reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 January 2027. *Why it matters:* Changes how G-SIB scores, and so buffers, are measured: capital channel, table above. [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) [12] | HSBC, Barclays, Lloyds | large exposures | Watch |
| FINMA AML ordinance (10 Nov) [13] | UBS | AML | Watch |
| Basel IRRBB guidance (9 Nov) [14] | all 15, once applied at home | IRRBB | Watch |
| EBA 2027 stress test (9 Nov) [15] | scope not known: sample not named on the page; EU names only | stress test | Watch |
| EBA reporting ITS timelines (6 Nov) [16] | the 11 EU names | reporting | Watch |
| EBA governance guidelines (5 Nov) [17] | the 11 EU names | governance | Watch |
| Basel consequential amendments (5 Nov) [19] | all 15, once applied at home | none (cross-references) | Watch |
| FINMA IRR circular (4 Nov) [20] | UBS | IRRBB | Watch |
| PRA CP14/26 SM&CR (22 Oct) [21] | HSBC, Barclays, Lloyds | governance, conduct | Watch |
| EU securitisation agreement (22 Oct) [22] | the 11 EU names | securitisation | Watch |

Note: The 11 EU names: BNP, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (20 entries on the running list): speeches, interviews, blog and event news (ECB, SRB, FINMA); newsletters (Basel AML/CFT newsletter, PRA digest); sanctions notices (FINMA, Commission); appointment, consumer factsheet, NGFS support statement (EBA); periodic list and Eurogroup overview (ECB); statistics, nominations call and dialogue summary (Commission); a moved consultation deadline (EBA); advice to the Commission on taxonomy disclosures (EBA); items for other firms (PRA credit unions, FINMA Bitcoin ETF, Commission assurance standards).
- Basel Committee items cover a bank once its home country applies the standard. No Moody's comment was found on the G-SIB, securitisation, IRRBB or stress-test items.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, 15 coverage names · Bank financials, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, as of 30 … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for … · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, shown … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall capital requirement for CET1 · bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, … · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 capital · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole S.A. first quarter 2026 results … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[12] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA: partially revised Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · Basel Committee: IRRBB - additional Pillar 2 guidance (consultative) · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA: 2027 EU-wide stress test streamlined · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA: next steps on supervisory reporting simplification, extended … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[22] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 15 Nov 2026, 23:16 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review2-reg-banks/dashboard/dashboard.html. Not published to the private link in this session.
