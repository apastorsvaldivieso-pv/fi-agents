**Daily sector news: Telecoms, Europe** (72h, 12 Nov 2026 23:14 UTC to 15 Nov 2026 23:14 UTC; 15 names)

One confirmed credit item in the last 72 hours: Telenor now holds about 66.9% of Bahnhof's shares after its mandatory offer. The search returned no Moody's rating actions or research on European telecoms in the window. [1]

**Top this week**

- [NEW] **Telenor ASA** (Deal): Telenor Sverige now holds about 66.9% of Bahnhof's shares and 90.6% of the votes. Bahnhof's independent board committee recommended accepting the unconditional mandatory cash offer of SEK 62 per share (13 Nov); the sources do not say how it is funded. *Why it matters:* Moody's positive outlook builds in no M&A beyond the GlobalConnect deal and could go back to stable on debt-funded acquisitions; it expects debt/EBITDA below 2.75x over 2026-27. [1][2][3]

**Macro**

- (UK): Headlines on 15 Nov point to pressure on the Bank of England to raise rates again ahead of UK inflation data. [4]
- (Euro area): Euro area government bond yields rose on 13 Nov (headline only). [5]

**Sector**

- (Moody's): The search returned no Moody's rating actions and no Moody's research on European telecoms published in the window.
- (Outlook): Latest Moody's sector outlook: Telecommunications - Global, stable (27 Oct 2026). Stronger EBITDA and lower investment support cash flow and leverage, against modest growth and refinancing pressure. [6]

**By name**

| Name | Moody's rating | Last 72 hours |
|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured (Fgn Curr), stable [7] | No material credit news. |
| Orange | Baa1 LT Issuer Rating, stable [7] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr), stable [7] | No material credit news. |
| Telefonica S.A. | Baa3 Senior Unsecured (Dom Curr), stable [7] | No material credit news. |
| Swisscom AG | A2 LT Issuer Rating (Dom Curr), stable [7] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating, stable [7] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (Dom Curr), stable [7] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured (Fgn Curr), positive [7] | Holds about 66.9% of Bahnhof after mandatory offer (Top item). [1] |
| Telia Company AB | Baa1 Senior Unsecured (Fgn Curr), stable [7] | LMT says Latvia's directive to buy out Telia's stakes in LMT and Tet will be implemented by the 17 Nov deadline (13 Nov). Single source, unconfirmed. [8] |
| TIM S.p.A. | Baa3 LT Issuer Rating (Dom Curr), positive [7] | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (Dom Curr), stable [7] | No news returned. |
| BT Group Plc | Baa2 LT Issuer Rating (at British Telecommunications Limited), stable [7] | No material credit news. |
| Iliad S.A. | Ba1 Senior Unsecured (Dom Curr), stable [7] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 CFR (Fgn Curr), on review for downgrade [7][9] | No news returned. CFR and PDR on review for downgrade since 22 Oct. [9] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (Fgn Curr), positive [7] | No news returned. |

**Before the window**

Reported in the window but dated earlier, so not new: Vodafone half-year results and guidance upgrade (10 Nov); Telefonica Q3 results (12 Nov); Telia's agreed SEK 3.8bn purchase of Telavox's Nordic enterprise base (12 Nov); Deutsche Telekom Q3 results and a buyback of up to EUR 2bn for 2027 (5 Nov). [10][11][12][13]

**Notes**

- You gave Monday 16 Nov; the clock read Sunday 15 Nov 23:14 UTC, so the Monday 72-hour window runs back from that time. Searches cannot go past the present.
- News searches for Orange, Iliad and Proximus returned mostly articles about other subjects sharing the name; none was credit news for these issuers.

**Sources**

[1] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · NewsWeb (Oslo Bors) message 686452, article 202611130231AMSPIDEROPNTNEUR_76750_166542 · 2026-11-13
[2] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document (Bahnhof) · Cision Wire, article 202611130222AMSPIDERAMC_USR__11290_566814 · 2026-11-13
[3] Moody's (getCreditOpinion) · Telenor ASA: Update following change in outlook to positive · PBC_1474480, sections RatingOutlook, FactorsLeadingToUpgrade, FactorsLeadingToDowngrade · 2026-02-24
[4] Moody's (searchNews) · Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms; BOE's … · The Eastern Herald 202611151752ACI_INFOBLOGS_EN_EAHE_10010102_01M7GPHA3WEW7SKYPDAMZFZ630; … · 2026-11-15
[5] Moody's (searchNews) · Eurozone bond yields rise; Italy might get ratings upgrade · MSN US, article 202611130358AMSPIDERBRDCAST__28738_11440499 · 2026-11-13
[6] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · Outlook PBC_1496503 · 2026-10-27
[7] Moody's ratings (getEntityRatings) · Moody's ratings pull, Moody's ratings pull · 2026-11-15
[8] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet to be … · LETA Latvian News Agency, article 202611130000PPI_____ASIANET_LETA1311202600010004 · 2026-11-13
[9] Moody's (searchAllDocuments) · Moody's Ratings places VMED O2's and affiliated entities' ratings on review for … · Rating Action PR_531559 · 2026-10-22
[10] Moody's (searchCompanyFilings) · Vodafone Group Plc Half Year 2027 Earnings Call · Half Year 2027 Vodafone Group Earnings Call, event date 10 Nov 2026 (company-reported) · 2026-11-10
[11] Moody's (searchNews) · Telefonica regains financial momentum and achieves its best figures for new … · CE Noticias Financieras, article 202611122144CONTENGEBRZL_GVT_91115800 · 2026-11-12
[12] Moody's (searchNews) · Telia to buy Telavox's Nordic customer base for USD 380m · SeeNews Deals, article 202611130637ADPR____DEALS____DEA_4338701 · 2026-11-12
[13] Moody's (searchNews) · Deutsche Telekom's Cash-Flow Test: AI Chip Pact and Munich Build-Out Collide … · Ad Hoc News Germany, article 202611140436AMSPIDEROPNTEEUR_20218_20241754 · 2026-11-05

Daily sector news tab updated at 2026-11-15 23:18 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html (not published as an Artifact in this run).
