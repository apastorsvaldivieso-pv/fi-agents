**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in 16 Oct-15 Nov 2026; the Basel G-SIB window-dressing standard is the one with a capital channel, and among the eight G-SIBs BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% CET1 capital requirement (30 Sep 2025, older) [3] | +2.46 [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% MDA trigger level (31 Dec 2025, older) [4] | +2.04 [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26% CET1 requirement (31 Mar 2026) [5] | +2.94 [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2% overall CET1 requirement (31 Dec 2025, older) [6] | +2.10 [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% going-concern CET1 (30 Jun 2026) [7] | +3.55 [2][7] | Stronger third |
| Groupe Credit Agricole (issuer on list: Credit Agricole S.A.) | 17.23% [8] | +3.22 [2][8] | total not stated | 6.7 bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Covers banks on the FSB G-SIB list (2026 list not yet published). Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list of 27 Nov 2025). Ranked by level: only three of eight have a current stated requirement. Score reporting reaches the wider assessment sample; the buffer falls on listed banks. Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [2][9][10]

**Who it hits: G-SIB methodology review consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51% (30 Sep 2025, older) [3] | +2.46 [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% (31 Dec 2025, older) [4] | +2.04 [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26% (31 Mar 2026) [5] | +2.94 [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole (issuer on list: Credit Agricole S.A.) | 17.23% [8] | not ranked | total not stated | 6.7 bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The page names no addressees; on our reading it covers the five banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. Fewer than six names, so not ranked. [10][11]

**What changed**

- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published 10 Nov 2026, in force 1 Jan 2027; correspondent-banking rules clarified after consultation. *Why it matters:* AML channel: no Moody's metric; covers UBS. [12]
- [NEW] **PRA** (Final): PS20/26 (10 Nov 2026) completes the large exposures reform: no internal models for securities financing exposure values, trading book excess allowance cut to 85% of Tier 1 capital. Applies from 1 Jan 2028. *Why it matters:* Large exposures channel: no Moody's metric; covers HSBC, Barclays, Lloyds. [13]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (9 Nov 2026): model risk, stress testing, embedded gains and losses, earnings indicators, new supervisory reporting. Comments by 9 Feb 2027. [14]
- [NEW] **EBA** (Final): 2027 EU-wide stress test methodology (9 Nov 2026) cuts requested data by "more than 55%" and adds a first climate module outside the core results. Launch end-January 2027, results end-July 2027. [15]
- [NEW] **EBA** (Other): After consultation, the EBA extended reporting timelines (6 Nov 2026): first reference date December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Final report due December 2026. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (5 Nov 2026) reflect CRD VI, with more proportionality; application date not stated. Moody's (11 Nov 2026) calls them credit positive, with a greater effect on small EU banks. [17][18]
- [NEW] **Basel Committee** (Consultation): Consultation on consequential amendments (5 Nov 2026): Basel Framework cross-references repointed to the consolidated guidelines, some application guidance moved there. Comments by 21 Dec 2026. No channel-map row; our mapping is watch. [19]
- [NEW] **FINMA** (Consultation): Consultation on revised Circular 2019/2 'Interest rate risks - banks' (4 Nov 2026) implements the Basel Committee's July 2024 recalibrated shocks. Comments by 15 Jan 2027. [20]
- [NEW] **PRA** (Consultation): CP14/26 (22 Oct 2026), SM&CR Phase 2: some Senior Manager Functions move from pre-approval to notification; Certification Regime fitness assessments removed. Comments by 22 Jan 2027. [21]
- [NEW] **European Commission** (Legislative step): Political agreement on the securitisation framework review (22 Oct 2026), including CRR changes to make the prudential treatment of securitisations more risk sensitive. Awaits formal approval; in force on publication. [22]
- [NEW] **Basel Committee** (Final): Amendments against G-SIB window-dressing (16 Oct 2026): score indicators reported as yearly averages by 1 Jan 2030; leverage exposure reporting threshold raised from EUR 200 billion to EUR 350 billion from 1 Jan 2027. Page status field reads "Forthcoming". *Why it matters:* Capital channel via the G-SIB buffer; covers the eight G-SIBs on the list. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review (16 Oct 2026): whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 Jan 2027. *Why it matters:* Capital channel via the G-SIB buffer; covers the five banking-union G-SIBs, on our reading. [11]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| Basel IRRBB Pillar 2 guidance (consultation, 9 Nov) | All 15, once home countries apply it | IRRBB measure | Watch [14] |
| FINMA Circular 2019/2 IRRBB (consultation, 4 Nov) | UBS | IRRBB measure | Watch [20] |
| EBA 2027 stress test (final, 9 Nov) | EU banks in the EBA sample; sample not given on the page, so scope not known for the 11 EU names | stress test results | Watch [15] |
| EBA reporting timelines (other, 6 Nov) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | none (reporting) | Watch [16] |
| EBA internal governance guidelines (final, 5 Nov) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | none (governance) | Watch [17] |
| Basel consequential amendments (consultation, 5 Nov) | All 15, once home countries apply it | none | Watch [19] |
| EU securitisation review (political agreement, 22 Oct) | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | securitisation exposure | Watch [22] |
| PRA PS20/26 large exposures (final, 10 Nov) | HSBC, Barclays, Lloyds | large exposures | Watch [13] |
| PRA CP14/26 SM&CR (consultation, 22 Oct) | HSBC, Barclays, Lloyds | none (governance) | Watch [21] |
| FINMA AML Ordinance (final, 10 Nov) | UBS | none (AML) | Watch [12] |

Note: Moody's data carries no field for IRRBB, stress testing, reporting, governance, securitisation, large exposures or AML, so no name is positioned on these items.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (22 entries on the running list): speeches, blogs, newsletters, sanctions notices, periodic lists, appointments, statistics, EBA advice to the Commission, a moved EBA deadline, a Commission opinion piece, and papers for credit unions, assurance providers and funds.
- The ECB Banking Supervision press feed ends at 6 Nov 2026; no ECB press release was found for 7-15 Nov. Moody's research had no comment on the other eleven items.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, 16 coverage records · CET1 ratio, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, as of 30 … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for … · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, shown … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, … · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, as of 30 … · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, Groupe Credit Agricole record … · Groupe Credit Agricole CET1 · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole S.A. first quarter 2026 results … · 2026-03-31
[10] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[12] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA: streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA: next steps on supervisory reporting simplification, extended timelines · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA: CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[22] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 2026-11-15T23:17:51Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r2/dashboard/dashboard.html (Artifact publish skipped for this test run).
