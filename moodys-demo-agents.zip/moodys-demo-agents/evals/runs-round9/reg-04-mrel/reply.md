**Regulatory watch: Banks Europe, 7 days, MREL asked** (8 Nov to 15 Nov 2026 (7 days); 15 names)

No MREL change at any primary regulator in the week to 15 Nov, and Moody's data has no MREL field, so no bank can be ranked on MREL headroom. A tightening by the EU or the SRB would cover the 11 banking-union banks on the list; the Commission's stated direction is simplification. [1][2]

**What changed**

- [Asked] **MREL (SRB, European Commission, Bank of England, FINMA)** (No change): No MREL rule, consultation or date change was published by a primary regulator between 8 and 15 Nov 2026; the SRB's items in the window were speeches and meeting news. Moody's (14 Sep 2026) notes the Commission is weighing bringing EU MREL closer to the TLAC standard. *Why it matters:* Moody's says such changes would be credit negative if they reduce the amount of bail-inable debt in the EU banking system. [1][2][3]
- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes from CP14/24, making the substitution approach mandatory for all firms. Takes effect 1 Jan 2028. *Why it matters:* Large exposures channel; no Moody's metric. [4]
- [NEW] **FINMA** (Final): Final partially revised FINMA Anti-Money Laundering Ordinance, recognising the revised Swiss banks' code of conduct as a minimum standard. In force 1 Jan 2027, with a four-month transition for the self-regulation. *Why it matters:* AML channel; no Moody's metric. [5]
- [NEW] **Basel Committee** (Consultation): Consults on additional Pillar 2 guidance for interest rate risk in the banking book: model risk, stress testing, controls, embedded gains and losses, earnings indicators. Comments by 9 Feb 2027. *Why it matters:* Interest rate risk in the banking book channel; no Moody's metric. [6]
- [NEW] **EBA** (Final): Final methodology and draft templates for the 2027 EU-wide stress test, with requested data cut by "more than 55%" and a climate-risk module for the first time. Launch end of Jan 2027, results end of Jul 2027. *Why it matters:* Stress testing channel; no Moody's metric. [7]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| MREL tightening (Asked) | EU or SRB change: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. UK change: HSBC, Barclays, Lloyds. UBS: Swiss rules only | MREL ratio vs requirement (no Moody's field) | Watch |
| PRA PS20/26 large exposures | HSBC, Barclays, Lloyds | Large exposures (no Moody's field) | Watch |
| FINMA AML Ordinance | UBS | AML (no Moody's field) | Watch |
| Basel Committee IRRBB guidance | All 15, once each home country applies it | IRRBB (no Moody's field) | Watch |
| EBA 2027 stress test | EU banks in the EBA sample (sample not checked): BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Stress test results (no Moody's field) | Watch |

Note: Moody's financials carry no MREL or TLAC field, so no position is given for any name. Scope follows each body's remit: SRB and EU law for banking-union groups, the UK and Swiss authorities for their own banks. Out of scope of EU MREL: HSBC, Barclays, Lloyds (GB), UBS (CH).

**Notes**

- Left out (8 to 15 Nov): speeches and testimony (SRB MREL Workshop keynote 10 Nov and conglomerates keynote 11 Nov; ECB Supervisory Board Chair to the Eurogroup 9 Nov); meeting news (SRB 13 Nov and Commission 11 Nov on the EU banking competitiveness dialogue); consumer material (EBA white-labelling factsheet); not addressed to banks (EBA NGFS declaration support; Commission assurance-standards feedback; Commission tokenisation stakeholder nominations).
- MREL was asked about directly, so it is shown even though nothing changed; it is not added to the running list. No metric applied to any item, so no Moody's financials call was made.
- Listings checked: Basel Committee, EBA, ECB Banking Supervision, SRB, European Commission, PRA, FINMA. ECB Banking Supervision published no press release in the window.

**Sources**

[1] Moody's (searchAllDocuments) · Banking – Europe: European regulators put more resolve into bank resolution · PBC_1491385, Sector In-Depth · 2026-09-14
[2] Moody's (searchAllDocuments) · Banks – EU: EU bank reforms support capital mobility, but could ease some … · PBC_1489046, Sector In-Depth · 2026-07-27
[3] Web · SRB news and media listing (entries 8 to 15 Nov 2026) · 2026-11-15 · https://www.srb.europa.eu/en/news
[4] Web · PRA: PS20/26 – Amendments to the Large Exposures Framework – Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[5] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[6] Web · Basel Committee: Interest rate risk in the banking book – additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[7] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data

Regulatory watch tab updated 15 Nov 2026 23:15 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html (not published: test run).
