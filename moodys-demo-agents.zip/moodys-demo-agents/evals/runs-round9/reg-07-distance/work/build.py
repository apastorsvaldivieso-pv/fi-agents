import json, subprocess
now = subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
def c(v, src, tone=None):
    d = {"v": v, "src": src}
    if tone: d["tone"] = tone
    return d
REQ = c("100% (Basel III minimum)", ["s14"])
lcr = [("HSBC Holdings plc",134.00,"s15","least"),("BNP Paribas",134.77,"s15","least"),
       ("Groupe Credit Agricole",135.75,"s16","least"),("ING Groep N.V.",137.00,"s15","least"),
       ("Intesa Sanpaolo S.p.A.",137.60,"s15","least"),("UniCredit S.p.A.",140.00,"s15","middle"),
       ("Deutsche Bank AG",140.12,"s15","middle"),("Commerzbank AG",141.00,"s15","middle"),
       ("Banco Bilbao Vizcaya Argentaria, S.A.",142.00,"s15","middle"),("Lloyds Banking Group plc",144.00,"s15","middle"),
       ("Societe Generale",146.41,"s15","most"),("Nordea Bank Abp",156.00,"s15","most"),
       ("Barclays PLC",157.70,"s15","most"),("UBS Group AG",177.28,"s15","most"),("CaixaBank, S.A.",192.99,"s15","most")]
med = 141.00
lcr_rows = []
for n,v,s,t in lcr:
    lcr_rows.append([n, c(f"{v:.2f}%",[s]), c(f"{v-med:+.2f}",[s,"s15"] if s!="s15" else ["s15"]), REQ,
                     c(f"{v-100:+.2f} pp",[s,"s14"]), {"tone":t,"v":""}])
cet1 = [("BNP Paribas",12.97,"s17","10.51% (30 Sep 2025, older)","s21",10.51,"weaker"),
        ("ING Groep N.V.",13.07,"s17","11.03% (MDA trigger, 31 Dec 2025, older)","s23",11.03,"weaker"),
        ("Societe Generale",13.20,"s17","10.26% (vs 31 Mar 2026)","s19",10.26,"middle"),
        ("Deutsche Bank AG",13.92,"s17","not stated",None,None,"middle"),
        ("HSBC Holdings plc",14.10,"s17","not stated",None,None,"middle"),
        ("Barclays PLC",14.30,"s17","12.2% (excl. PRA buffer, 31 Dec 2025, older)","s22",12.2,"middle"),
        ("UBS Group AG",14.38,"s17","10.83% (going-concern, 30 Jun 2026)","s18",10.83,"stronger"),
        ("Groupe Credit Agricole",17.23,"s16","total not stated",None,None,"stronger")]
cmed = 14.01
cet_rows = []
for n,v,s,req,rs,rv,t in cet1:
    reqcell = c(req,[rs]) if rs else req
    if rv is not None:
        dist = c(f"{v-rv:+.2f} pp",[s,rs])
    elif n=="Groupe Credit Agricole":
        dist = c("+6.7 pp (bank-stated, 31 Mar 2026)",["s20"])
    else:
        dist = "not stated"
    cet_rows.append([n, c(f"{v:.2f}%",[s]), c(f"{v-cmed:+.2f}",["s17","s16"]), reqcell, dist, {"tone":t,"v":""}])
W = lambda: {"tone":"watch","v":""}
EU11 = "the 11 EU/EEA groups (all but HSBC, Barclays, Lloyds, UBS)"
watch_rows = [
 ["Large exposures, PS20/26 (PRA, 10 Nov)", c("HSBC, Barclays, Lloyds",["s9"]), "large exposures (no Moody's field)", W()],
 ["Anti-Money Laundering Ordinance (FINMA, 10 Nov)", c("UBS",["s11"]), "AML (no Moody's field)", W()],
 ["IRRBB Pillar 2 guidance (Basel Committee, 9 Nov)", c("all 15, once applied at home",["s4"]), "IRRBB (no Moody's field)", W()],
 ["2027 EU-wide stress test (EBA, 9 Nov)", c("scope not known (sample not stated)",["s5"]), "stress testing (no Moody's field)", W()],
 ["Supervisory reporting timelines (EBA, 6 Nov)", c(EU11,["s6"]), "reporting (no Moody's field)", W()],
 ["Consolidated guidelines, consequential amendments (Basel Committee, 5 Nov)", c("all 15, once applied at home",["s3"]), "none (our reading: cross-references only)", W()],
 ["Internal governance guidelines (EBA, 5 Nov)", c(EU11,["s7"]), "governance (no Moody's field)", W()],
 ["Circular 2019/2 interest rate risks (FINMA, 4 Nov)", c("UBS",["s12"]), "IRRBB (no Moody's field)", W()],
 ["Securitisation framework (European Commission, 22 Oct)", c(EU11,["s8"]), "securitisation (no Moody's field)", W()],
 ["SM&CR phase 2, CP14/26 (PRA, 22 Oct)", c("HSBC, Barclays, Lloyds",["s10"]), "governance, conduct (no Moody's field)", W()],
]
items = [
 {"tag":"Asked","name":"Liquidity (LCR)","text":"No regulatory change to the liquidity coverage requirement was found at the primary regulators between 16 Oct and 15 Nov 2026. Shown because you asked; distances are to the 100% Basel III minimum.","src":["s14"]},
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 makes substitution mandatory for all firms and keeps a 'materially reduced' trading book excess allowance of up to 85% of Tier 1 capital for a maximum of 10 business days. Takes effect 1 Jan 2028. Large exposures: watch.","src":["s9"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised Anti-Money Laundering Ordinance, with the revised bank code of conduct recognised as a minimum standard. In force 1 Jan 2027. AML: watch.","src":["s11"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Additional Pillar 2 guidance on interest rate risk in the banking book, raising expectations for banks' risk management and supervisory oversight. Comments by 9 Feb 2027. IRRBB: watch.","src":["s4"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology for the 2027 EU-wide stress test, cutting requested data by more than 55% and adding a separate climate module that does not affect core results. Starts end Jan 2027; results end Jul 2027. Stress testing: watch.","src":["s5"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on supervisory reporting: first reference date for new requirements moves to Dec 2027, and liquidity, asset encumbrance, benchmarking and ESG reporting to Dec 2028. Final report on the draft ITS due Dec 2026. Reporting: watch.","why":"The liquidity item is a reporting deferral, not a change to the LCR requirement.","src":["s6"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consequential amendments updating Basel Framework cross-references to the consolidated guidelines and moving some 'Application guidance' chapters into them. Comments by 21 Dec 2026. No channel-map row; mapped to watch by our judgment.","src":["s3"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance under CRD VI, with a 'more proportionate and risk-based approach'. Application date not stated on the page. Governance: watch.","why":"Moody's (11 Nov 2026) calls the revisions credit positive for EU banks, with a greater effect on smaller banks.","src":["s7","s24"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consultation on partially revised Circular 2019/2 'Interest rate risks - banks', applying the Basel Committee's recalibrated shocks and giving greater weight to effects on revenues. Open until 15 Jan 2027. IRRBB: watch.","src":["s12"]},
 {"flag":"NEW","tag":"Legislative step","name":"European Commission","text":"Political agreement on the securitisation framework review, making the CRR prudential treatment of securitisations 'more risk sensitive'. Awaits technical finalisation and formal approval; no application date given. Securitisation: watch.","src":["s8"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26 proposes removing pre-approval for 'almost half of' Senior Manager Functions and the Certification requirements, if implemented as proposed. Comments by 22 Jan 2027. Governance: watch.","src":["s10"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"G-SIB score indicators to be reported and disclosed as averages over the reporting year, not year-end values, by 1 Jan 2030; the leverage-exposure reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 Jan 2027. Capital buffers: CET1 table.","src":["s1"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"G-SIB methodology review: whether to bring the 'previously agreed' treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 Jan 2027. Capital buffers: see note under the CET1 table.","src":["s2"]},
]
run = {
 "schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"label":"Banks Europe, 30 days, LCR asked","sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15},
 "status":"ok",
 "headline":"No liquidity rule changed in the 30 days to 15 Nov 2026; on LCR, HSBC (134.00%), BNP Paribas (134.77%) and Groupe Credit Agricole (135.75%) sit closest to the 100% minimum, and the Basel Committee finalised G-SIB anti-window-dressing rules.",
 "headline_src":["s15","s16","s14","s1"],
 "sections":[
  {"title":"Who it hits: Liquidity, asked (no regulatory change found) · LCR","type":"table",
   "columns":["Name","LCR (Q2 2026)","vs median (pp)","Stated requirement","Distance to requirement","Position"],
   "rows":lcr_rows,
   "note":"All 15 names covered: the LCR applies at home in the EU, UK and Switzerland. Median 141.00% (Commerzbank). Groupe Credit Agricole is measured on the group record at Q2 2026; the issuer on the list, Credit Agricole S.A., reports 141.29% (Q2 2026).",
   "note_src":["s15","s16"]},
  {"title":"Who it hits: G-SIB framework amendments on window dressing (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
   "columns":["Name","CET1 (Q2 2026)","vs median (pp)","Stated requirement","Distance to requirement","Position"],
   "rows":cet_rows,
   "note":"Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three have a current requirement. Credit Agricole S.A.: CET1 11.30%, 2.6 pp above SREP (31 Mar 2026). The 16 Oct methodology consultation, read by us as covering banking-union G-SIBs, covers BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING: list too short to rank.",
   "note_src":["s13","s15","s20","s2"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch_rows}
 ],
 "sources":[
  {"id":"s1","kind":"web","title":"Basel Committee: Amendments to G-SIB framework to address window dressing","date":"2026-10-16","url":"https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"},
  {"id":"s2","kind":"web","title":"Basel Committee: Global systemically important banks - methodology review (consultative)","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
  {"id":"s3","kind":"web","title":"Basel Committee: Consolidated guidelines - consequential amendments (consultative)","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
  {"id":"s4","kind":"web","title":"Basel Committee: Interest rate risk in the banking book - additional Pillar 2 guidance (consultative)","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
  {"id":"s5","kind":"web","title":"EBA: streamlines the 2027 EU-wide stress test","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
  {"id":"s6","kind":"web","title":"EBA: next steps on supervisory reporting simplification","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
  {"id":"s7","kind":"web","title":"EBA: revised Guidelines on internal governance","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
  {"id":"s8","kind":"web","title":"European Commission: political agreement on the review of the Securitisation Framework","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
  {"id":"s9","kind":"web","title":"PRA PS20/26: Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
  {"id":"s10","kind":"web","title":"PRA CP14/26: Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
  {"id":"s11","kind":"web","title":"FINMA: partially revised FINMA Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
  {"id":"s12","kind":"web","title":"FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
  {"id":"s13","kind":"web","title":"FSB: 2025 List of Global Systemically Important Banks (G-SIBs)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
  {"id":"s14","kind":"web","title":"Basel Framework (LEV, LCR, NSF standards)","date":"2026-11-15","url":"https://www.bis.org/basel_framework/"},
  {"id":"s15","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Basel III Liquidity Coverage Ratio (LCR) (as reported), LQ = Q2 2026, 15 names in one call (Groupe Credit Agricole returned Q3 2026 and was re-requested)","title":"Bank financials, coverage list","date":"2026-06-30"},
  {"id":"s16","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Groupe Credit Agricole, LCR (as reported) and Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period)","title":"Groupe Credit Agricole financials","date":"2026-06-30"},
  {"id":"s17","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, same call as the LCR pull","title":"Bank financials, coverage list","date":"2026-06-30"},
  {"id":"s18","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, as of 30 Jun 2026","title":"UBS required going-concern CET1","date":"2026-06-30"},
  {"id":"s19","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, shown against 31 Mar 2026","title":"Societe Generale CET1 requirement","date":"2026-03-31"},
  {"id":"s20","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides filed under Credit Agricole S.A., as of 31 Mar 2026","title":"Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement","date":"2026-03-31"},
  {"id":"s21","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, as of 30 Sep 2025","title":"BNP Paribas CET1 capital requirement","date":"2025-09-30"},
  {"id":"s22","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, as of 31 Dec 2025","title":"Barclays overall CET1 requirement","date":"2025-12-31"},
  {"id":"s23","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for 2025, as of 31 Dec 2025","title":"ING MDA trigger level","date":"2025-12-31"},
  {"id":"s24","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"}
 ],
 "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "The 100% LCR minimum is the Basel III standard; local rules can be higher, so distances are to the Basel minimum.",
  "The FSB's 2026 G-SIB list, due in November 2026, was not found on fsb.org; the 2025 list is used. The Basel window-dressing page says 'finalised' but its status field reads 'Forthcoming'; treated as final.",
  "Left out, not regulatory items: speeches, interviews and blogs; newsletters; statistics and periodic lists; appointments; sanctions notices; consumer material; advice to another authority; a moved deadline; papers for other firms; the Basel press release of 16 Oct (its two measures are shown)."
 ],
 "meta":{"calls":{"moodys":6,"web":24}}
}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
