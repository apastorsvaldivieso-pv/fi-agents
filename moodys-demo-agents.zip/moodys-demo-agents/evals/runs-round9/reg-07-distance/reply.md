**Regulatory watch: Banks Europe, 30 days, LCR asked** (30 days, 16 Oct to 15 Nov 2026; 15 names)

No liquidity rule changed in the 30 days to 15 Nov 2026; on LCR, HSBC (134.00%), BNP Paribas (134.77%) and Groupe Credit Agricole (135.75%) sit closest to the 100% minimum, and the Basel Committee finalised G-SIB anti-window-dressing rules. [1][2][3][4]

**Who it hits: Liquidity, asked (no regulatory change found) · LCR**

| Name | LCR (Q2 2026) | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134.00% [1] | -7.00 [1] | 100% (Basel III minimum) [3] | +34.00 pp [1][3] | Least headroom |
| BNP Paribas | 134.77% [1] | -6.23 [1] | 100% (Basel III minimum) [3] | +34.77 pp [1][3] | Least headroom |
| Groupe Credit Agricole | 135.75% [2] | -5.25 [1][2] | 100% (Basel III minimum) [3] | +35.75 pp [2][3] | Least headroom |
| ING Groep N.V. | 137.00% [1] | -4.00 [1] | 100% (Basel III minimum) [3] | +37.00 pp [1][3] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.60% [1] | -3.40 [1] | 100% (Basel III minimum) [3] | +37.60 pp [1][3] | Least headroom |
| UniCredit S.p.A. | 140.00% [1] | -1.00 [1] | 100% (Basel III minimum) [3] | +40.00 pp [1][3] | Middle |
| Deutsche Bank AG | 140.12% [1] | -0.88 [1] | 100% (Basel III minimum) [3] | +40.12 pp [1][3] | Middle |
| Commerzbank AG | 141.00% [1] | +0.00 [1] | 100% (Basel III minimum) [3] | +41.00 pp [1][3] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142.00% [1] | +1.00 [1] | 100% (Basel III minimum) [3] | +42.00 pp [1][3] | Middle |
| Lloyds Banking Group plc | 144.00% [1] | +3.00 [1] | 100% (Basel III minimum) [3] | +44.00 pp [1][3] | Middle |
| Societe Generale | 146.41% [1] | +5.41 [1] | 100% (Basel III minimum) [3] | +46.41 pp [1][3] | Most headroom |
| Nordea Bank Abp | 156.00% [1] | +15.00 [1] | 100% (Basel III minimum) [3] | +56.00 pp [1][3] | Most headroom |
| Barclays PLC | 157.70% [1] | +16.70 [1] | 100% (Basel III minimum) [3] | +57.70 pp [1][3] | Most headroom |
| UBS Group AG | 177.28% [1] | +36.28 [1] | 100% (Basel III minimum) [3] | +77.28 pp [1][3] | Most headroom |
| CaixaBank, S.A. | 192.99% [1] | +51.99 [1] | 100% (Basel III minimum) [3] | +92.99 pp [1][3] | Most headroom |

Note: All 15 names covered: the LCR applies at home in the EU, UK and Switzerland. Median 141.00% (Commerzbank). Groupe Credit Agricole is measured on the group record at Q2 2026; the issuer on the list, Credit Agricole S.A., reports 141.29% (Q2 2026). [1][2]

**Who it hits: G-SIB framework amendments on window dressing (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (Q2 2026) | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [5] | -1.04 [2][5] | 10.51% (30 Sep 2025, older) [6] | +2.46 pp [5][6] | Weaker third |
| ING Groep N.V. | 13.07% [5] | -0.94 [2][5] | 11.03% (MDA trigger, 31 Dec 2025, older) [7] | +2.04 pp [5][7] | Weaker third |
| Societe Generale | 13.20% [5] | -0.81 [2][5] | 10.26% (vs 31 Mar 2026) [8] | +2.94 pp [5][8] | Middle |
| Deutsche Bank AG | 13.92% [5] | -0.09 [2][5] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [5] | +0.09 [2][5] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [5] | +0.29 [2][5] | 12.2% (excl. PRA buffer, 31 Dec 2025, older) [9] | +2.10 pp [5][9] | Middle |
| UBS Group AG | 14.38% [5] | +0.37 [2][5] | 10.83% (going-concern, 30 Jun 2026) [10] | +3.55 pp [5][10] | Stronger third |
| Groupe Credit Agricole | 17.23% [2] | +3.22 [2][5] | total not stated | +6.7 pp (bank-stated, 31 Mar 2026) [11] | Stronger third |

Note: Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three have a current requirement. Credit Agricole S.A.: CET1 11.30%, 2.6 pp above SREP (31 Mar 2026). The 16 Oct methodology consultation, read by us as covering banking-union G-SIBs, covers BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING: list too short to rank. [1][11][12][13]

**What changed**

- **Liquidity (LCR)** (Asked): No regulatory change to the liquidity coverage requirement was found at the primary regulators between 16 Oct and 15 Nov 2026. Shown because you asked; distances are to the 100% Basel III minimum. [3]
- [NEW] **PRA** (Final): PS20/26 makes substitution mandatory for all firms and keeps a 'materially reduced' trading book excess allowance of up to 85% of Tier 1 capital for a maximum of 10 business days. Takes effect 1 Jan 2028. Large exposures: watch. [14]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance, with the revised bank code of conduct recognised as a minimum standard. In force 1 Jan 2027. AML: watch. [15]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book, raising expectations for banks' risk management and supervisory oversight. Comments by 9 Feb 2027. IRRBB: watch. [16]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test, cutting requested data by more than 55% and adding a separate climate module that does not affect core results. Starts end Jan 2027; results end Jul 2027. Stress testing: watch. [17]
- [NEW] **EBA** (Other): Next steps on supervisory reporting: first reference date for new requirements moves to Dec 2027, and liquidity, asset encumbrance, benchmarking and ESG reporting to Dec 2028. Final report on the draft ITS due Dec 2026. Reporting: watch. *Why it matters:* The liquidity item is a reporting deferral, not a change to the LCR requirement. [18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments updating Basel Framework cross-references to the consolidated guidelines and moving some 'Application guidance' chapters into them. Comments by 21 Dec 2026. No channel-map row; mapped to watch by our judgment. [19]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, with a 'more proportionate and risk-based approach'. Application date not stated on the page. Governance: watch. *Why it matters:* Moody's (11 Nov 2026) calls the revisions credit positive for EU banks, with a greater effect on smaller banks. [20][21]
- [NEW] **FINMA** (Consultation): Consultation on partially revised Circular 2019/2 'Interest rate risks - banks', applying the Basel Committee's recalibrated shocks and giving greater weight to effects on revenues. Open until 15 Jan 2027. IRRBB: watch. [22]
- [NEW] **European Commission** (Legislative step): Political agreement on the securitisation framework review, making the CRR prudential treatment of securitisations 'more risk sensitive'. Awaits technical finalisation and formal approval; no application date given. Securitisation: watch. [23]
- [NEW] **PRA** (Consultation): CP14/26 proposes removing pre-approval for 'almost half of' Senior Manager Functions and the Certification requirements, if implemented as proposed. Comments by 22 Jan 2027. Governance: watch. [24]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be reported and disclosed as averages over the reporting year, not year-end values, by 1 Jan 2030; the leverage-exposure reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 Jan 2027. Capital buffers: CET1 table. [4]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to bring the 'previously agreed' treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 Jan 2027. Capital buffers: see note under the CET1 table. [13]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| Large exposures, PS20/26 (PRA, 10 Nov) | HSBC, Barclays, Lloyds [14] | large exposures (no Moody's field) | Watch |
| Anti-Money Laundering Ordinance (FINMA, 10 Nov) | UBS [15] | AML (no Moody's field) | Watch |
| IRRBB Pillar 2 guidance (Basel Committee, 9 Nov) | all 15, once applied at home [16] | IRRBB (no Moody's field) | Watch |
| 2027 EU-wide stress test (EBA, 9 Nov) | scope not known (sample not stated) [17] | stress testing (no Moody's field) | Watch |
| Supervisory reporting timelines (EBA, 6 Nov) | the 11 EU/EEA groups (all but HSBC, Barclays, Lloyds, UBS) [18] | reporting (no Moody's field) | Watch |
| Consolidated guidelines, consequential amendments (Basel Committee, 5 Nov) | all 15, once applied at home [19] | none (our reading: cross-references only) | Watch |
| Internal governance guidelines (EBA, 5 Nov) | the 11 EU/EEA groups (all but HSBC, Barclays, Lloyds, UBS) [20] | governance (no Moody's field) | Watch |
| Circular 2019/2 interest rate risks (FINMA, 4 Nov) | UBS [22] | IRRBB (no Moody's field) | Watch |
| Securitisation framework (European Commission, 22 Oct) | the 11 EU/EEA groups (all but HSBC, Barclays, Lloyds, UBS) [23] | securitisation (no Moody's field) | Watch |
| SM&CR phase 2, CP14/26 (PRA, 22 Oct) | HSBC, Barclays, Lloyds [24] | governance, conduct (no Moody's field) | Watch |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- The 100% LCR minimum is the Basel III standard; local rules can be higher, so distances are to the Basel minimum.
- The FSB's 2026 G-SIB list, due in November 2026, was not found on fsb.org; the 2025 list is used. The Basel window-dressing page says 'finalised' but its status field reads 'Forthcoming'; treated as final.
- Left out, not regulatory items: speeches, interviews and blogs; newsletters; statistics and periodic lists; appointments; sanctions notices; consumer material; advice to another authority; a moved deadline; papers for other firms; the Basel press release of 16 Oct (its two measures are shown).

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), LQ = Q2 2026, 15 names in one … · Bank financials, coverage list · 2026-06-30
[2] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, LCR (as reported) and Common Equity / Core Tier 1 ratio (as … · Groupe Credit Agricole · 2026-06-30
[3] Web · Basel Framework (LEV, LCR, NSF standards) · 2026-11-15 · https://www.bis.org/basel_framework/
[4] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[5] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, same call as the LCR pull · Bank financials, coverage list · 2026-06-30
[6] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas, Third quarter 2025 report, as of 30 … · 2025-09-30
[7] Moody's (searchCompanyFilings) · ING MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Groep N.V., Annual report on Form 20-F for … · 2025-12-31
[8] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale, First quarter 2026 results, shown … · 2026-03-31
[9] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC, Annual report on Form 20-F for 2025, … · 2025-12-31
[10] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG, Second quarter 2026 report, as of 30 … · 2026-06-30
[11] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides filed under … · 2026-03-31
[12] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[13] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[14] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[16] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA: streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[18] Web · EBA: next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[21] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[22] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[23] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[24] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated at 2026-11-15 23:17 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html
