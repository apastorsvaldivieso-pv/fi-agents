**Sector news brief: European telecoms, 7 days to 15 Nov 2026**

Window: 8 Nov 2026 00:00 UTC to 15 Nov 2026 23:17 UTC (191h). The searches ran on whole calendar days from 8 to 15 November, so the window is a little over 7 days. 15 names from the checked Telecoms Europe list.

Telia agreed a SEK 3.8bn deal for Telavox's Nordic enterprise base, and Telefonica and Vodafone both raised guidance after reporting results.

**Top this week**

1. **Telia: SEK 3.8bn acquisition (agreed 12 Nov).** Telia signed a binding agreement to buy Telavox's Nordic enterprise customer base for SEK 3.8bn, plus a possible SEK 0.2bn earn-out, and to license Telavox's unified communications platform [2]. The base brings about SEK 1.1bn of annual revenue [3]. *Why it matters:* Moody's could downgrade Telia if RCF/adjusted net debt falls below 22% and adjusted debt/EBITDA moves towards 3.0x [4]. The articles returned do not say how the deal is funded.

2. **Telefonica: Q3 results, guidance raised (12 Nov).** Q3 net income was EUR 802m (EUR 276m a year earlier). Adjusted EBITDA guidance rose to slightly above 2.5% growth, while revenue guidance was cut to 1%–1.5% [6]. Company-reported net financial debt fell to EUR 25.2bn and net debt/EBITDA to 2.63x (2.78x at Dec 2025). FCF guidance went up to about EUR 3.1bn, and liquidity is EUR 17.5bn [5]. Germany will take a further restructuring provision of up to EUR 155m in Q4 [5]. *Why it matters:* the 2.63x is the company's own measure, not Moody's. Moody's upgrade trigger is adjusted net debt/EBITDA below 3.0x with RCF/net debt above 20% [7].

3. **Vodafone: H1 FY27 results, guidance raised (10 Nov).** Vodafone raised its FY27 guidance. At the midpoint it now implies about 7% organic growth in adjusted EBITDA and about 21% in adjusted FCF (company-reported) [8]. A European Court of Justice ruling cut German EBITDA by about EUR 100m [8]. One headline reported an H1 loss of EUR 3.6bn [9]. Net debt and leverage were not in the sources returned. *Why it matters:* Moody's stable outlook assumes adjusted debt/EBITDA stays below 3.3x and RCF/net debt around 30% [10].

**Macro**

- Moody's 2027 global credit outlook (9 Nov) expects credit to weaken, as higher rates and energy costs outweigh the AI tailwind [17].
- US and euro-area bond yields rose (13 Nov) [18]. The Bank of England faces fresh rate pressure ahead of UK inflation data (15 Nov) [19].

**Sector**

- The search returned no Moody's rating action on European telecoms in the window.
- Odido Group Holding (not on the list): Moody's says new notes raise leverage to fund Apax's buyout but leave credit quality unchanged (11 Nov) [15].
- Latest Moody's sector outlook: Telecommunications – Global, **stable**, 27 Oct 2026. Solid demand and falling capital intensity offset refinancing pressure and structural risks [16].

**By name**

| Name | Rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom AG | A3 (Sr Unsec, FC), stable [1] | No material credit news. Q3 came out on 5 Nov, before the window. |
| Orange | Baa1 (LT Issuer), stable [1] | No material credit news. |
| Vodafone Group Plc | Baa2 (Sr Unsec, FC), stable [1] | H1 results and guidance raise, see Top 3 [8][9]. |
| Telefonica S.A. | Baa3 (Sr Unsec, DC), stable [1] | Q3 results and guidance raise, see Top 2 [5][6]. |
| Swisscom AG | A2 (LT Issuer, DC), stable [1] | No material credit news. Results came out before the window. |
| Telekom Austria AG | A3 (LT Issuer), stable [1] | No material credit news. |
| Proximus | A3 (Sr Unsec, DC), stable [1] | No material credit news. Q3 came out on 30 Oct, before the window. |
| Telenor ASA | Baa1 (Sr Unsec, FC), positive [1] | Holds about 66.9% of Bahnhof's shares and 90.6% of the votes. Bahnhof's board recommends accepting Telenor's mandatory offer at SEK 62 a share (13 Nov) [12]. The first 57.5% stake was reported at USD 363m [13]. |
| Telia Company AB | Baa1 (Sr Unsec, FC), stable [1] | Telavox deal, see Top 1 [2]. Latvian government buyout of Telia's LMT and Tet stakes due by 17 Nov (reported on 13 Nov; no amount given) [20]. |
| TIM S.p.A. | Baa3 (LT Issuer, DC), positive [1] | 9M results (out 11 Nov): net loss EUR 205m (EUR 109m a year earlier) after EUR 314m of one-off costs. Adjusted net debt after leases EUR 7.21bn (EUR 6.854bn at Dec 2025). 2026 targets maintained [11]. |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer, DC), stable [1] | No news returned. |
| BT Group (rated at British Telecommunications Ltd) | Baa2 (LT Issuer), stable [1] | No material credit news. H1 results and the pension valuation came out on 5 Nov, before the window. |
| Iliad S.A. | Ba1 (Sr Unsec, DC), stable [1] | No material credit news. |
| VMED O2 UK Holdings | B1 (CFR, FC), on review for downgrade [1] | No news returned. Moody's put the CFR, the PD rating and affiliated ratings on review for downgrade on 22 Oct [14]. |
| Altice France SAS | Caa1 (Sr Sec Bank Facility, FC), positive [1] | No material credit news. |

**Notes**

- Not included: an aggregator report that Virgin Media O2 is nearing a deal to use BT's Openreach network. It is single source, unconfirmed, and may predate the window.
- All Telefonica, Vodafone and TIM figures are company-reported, not Moody's-adjusted.

**Sources**

1. Moody's, getEntityRatings, current ratings for the 15 names (RTNG_600020481 … RTNG_823642946), 15 Nov 2026
2. Moody's, searchNews, Telia release "Telia to acquire Telavox's Nordic enterprise customer base…" (Contify, 202611120738CONTIFY_NEWS____0069709181), 12 Nov 2026
3. Moody's, searchNews, Telecomlead "Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion…" (202611120703CONTIFY_NEWS____0069708735), 12 Nov 2026
4. Moody's, getCreditOpinion, Telia Company AB: Update to credit analysis, PBC_1472649, 2 Mar 2026
5. Moody's, searchNews, Yahoo Finance "Telefonica SA (Q3 2026) Earnings Call Highlights" (202611121419AMSPIDERFIN_NEWS_3478_8464965), 12 Nov 2026
6. Moody's, searchNews, RTT News "Telefonica Q3 Net Income Soars…" (202611120357AMSPIDERFIN_NEWS_25778_1033860), 12 Nov 2026
7. Moody's, getCreditOpinion, Telefonica S.A.: Update to credit analysis, PBC_1482849, 27 May 2026
8. Moody's, searchCompanyFilings, Vodafone Group Half Year 2027 earnings call transcript, event 10 Nov 2026
9. Moody's, searchNews, Yahoo Finance headline "Vodafone raises profit, cash flow guidance despite €3.6 billion H1 loss" (in 202611101452AMSPIDERFIN_NEWS_3478_8456802), 10 Nov 2026
10. Moody's, getCreditOpinion, Vodafone Group Plc: Update following ratings affirmation, PBC_1496608, 21 Oct 2026
11. Moody's, searchNews, CE Noticias Financieras "Telecom Italia's losses soar by 88% through September" (202611121042CONTENGEBRZL_GVT_91079729), 12 Nov 2026
12. Moody's, searchNews, NewsWeb "Bahnhof's independent board committee recommends acceptance…" (202611130231AMSPIDEROPNTNEUR_76750_166542), 13 Nov 2026
13. Moody's, searchNews, Marketline "Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million" (202611110000DMON____NEWS_____8F0458C9…), 11 Nov 2026
14. Moody's, searchAllDocuments, Rating Action "Moody's Ratings places VMED O2's and affiliated entities' ratings on review for downgrade", PR_531559, 22 Oct 2026
15. Moody's, searchAllDocuments, Issuer Comment "Odido Group Holding B.V.: New notes issuance increases leverage…", PBC_1502046, 11 Nov 2026
16. Moody's, searchAllDocuments, Outlook "Telecommunications – Global: Outlook stable…", PBC_1496503, 27 Oct 2026
17. Moody's, searchAllDocuments, Outlook "Credit Conditions – Global: 2027 Outlook…", PBC_1491648, 9 Nov 2026
18. Moody's, searchNews, Morningstar/Dow Jones "U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes" (202611130510AMSPIDEROPNT__AM_835_4659581), 13 Nov 2026
19. Moody's, searchNews, Eastern Herald "Bank of England Faces Fresh Rate Pressure as UK Inflation Test Looms" (202611151752ACI_INFOBLOGS_EN_EAHE_10010102…), 15 Nov 2026
20. Moody's, searchNews, LETA "Government's directive regarding buyout of Telia's shares in LMT and Tet…" (202611130000PPI_____ASIANET_LETA1311202600010004), 13 Nov 2026

Dashboard not updated: no folder to write to, scripts cannot run, and publishing is not available in this session.
