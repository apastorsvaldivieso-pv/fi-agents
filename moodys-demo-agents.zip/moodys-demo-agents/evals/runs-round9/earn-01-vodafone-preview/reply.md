**Earnings: Vodafone, preview** (Next results after H1 FY27 (reported 10 Nov 2026); 1 name)

Vodafone (Baa2 senior unsecured, stable) sits 0.05x inside its 3.3x Moody's-adjusted debt/EBITDA downgrade trigger at FY26 (3.25x), while company-reported net debt rose to EUR 33.5bn in H1 FY27 from EUR 25.4bn after the VodafoneThree and Safaricom deals. [1][2][3]

**Rating and outlook**

Baa2 Senior Unsecured (foreign currency), outlook stable, affirmed 13 Oct 2026. Credit opinion of 21 Oct 2026: the stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt around 30%, and net leverage in the lower half of the company's target range. [1][4]

**What to watch against Moody's triggers**

| Metric (Moody's-adjusted) | Latest (FY to 31 Mar 2026) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x [2] | below 2.5x [4] | fails to stay below 3.3x [4] | 0.05x to downgrade; 0.75x to upgrade [2][4] |
| RCF / Net Debt | 33.08% [2] | above 25% sustained [4] | towards 18% sustained [4] | upgrade level already met, by 8.1pp; 15.1pp to downgrade [2][4] |

Note: Worded triggers (credit opinion): upgrade if 'underlying revenue and operating performance improve sustainably, particularly in Germany'; downgrade if 'operating performance deteriorates, including a failure to turn around its German operations'. [4]

**Sector metrics to watch**

- **Service revenue**: Organic service revenue growth 5.8% in H1 FY27 and 6.4% in Q2 (company-reported). Germany is the trigger line: H1 Adjusted EBITDAaL EUR 2,139m vs EUR 2,191m a year earlier. *Why it matters:* Germany's turnaround is named in both the upgrade and downgrade triggers. [3][5]
- **EBITDA and coverage**: Moody's-adjusted EBITDA EUR 15.8bn and (EBITDA - capex)/interest 2.39x at FY26; company H1 capital additions EUR 3,320m vs EUR 2,800m (company-reported). *Why it matters:* Higher capex with flat German EBITDA weighs on coverage. [2][3]
- **Net debt and leverage target**: Company-reported net debt EUR 33.5bn at 30 Sep 2026, up EUR 8.1bn; drivers as stated: free cash outflow EUR 845m, acquisitions and disposals EUR 6,957m, dividends EUR 544m, buybacks EUR 92m, offset by other movements EUR 474m. Target: lower half of 2.25-2.75x net debt/Adjusted EBITDAaL. *Why it matters:* Company measure, not Moody's-adjusted; it shows the deals' debt not yet in the FY26 Moody's figures. [3]
- **Liquidity and maturities**: Cash and short-term investments EUR 8.4bn (EUR 12.4bn at 31 Mar 2026); cash EUR 5.0bn plus undrawn RCFs EUR 7.6bn at 30 Sep 2026. Debt maturities not in the excerpts pulled. [3]
- **Spectrum, M&A, shareholder returns**: H1 licence and spectrum payments EUR 21m; VodafoneThree buyout and Safaricom stake completed; possible Greek fibre JV; OXG equity injections of up to EUR 1.2bn raised by an analyst on the call. Interim dividend 2.306 eurocents. *Why it matters:* Deal funding and JV equity add to debt or cut cash flow. [3][5]

**What management guided on the last call**

- FY27 guidance upgraded: Adjusted EBITDAaL EUR 13.2-13.4bn (from EUR 13.0-13.3bn in July) and Adjusted FCF EUR 2.8-3.0bn (from EUR 2.6-2.9bn); midpoints imply organic growth of 7% and 21%. Half Year 2027 call, 10 Nov 2026; ranges from the H1 report. [3][5]
- Europe Adjusted EBITDAaL outlook kept at EUR 7.6-7.9bn after absorbing an ECJ ruling impact of about EUR 100m on EBITDA, which management said it offset with better UK and German trading. [3][5]
- Germany: 'We are not yet where we need to be'; 2,300 further role reductions announced; no material cut in German capital intensity guided. [5]
- Restructuring and integration costs to peak at c.EUR 0.7bn in FY27; over EUR 200m of net cost reduction expected this fiscal year. [3][5]

**Moody's expectations**

| Moody's-adjusted | FY27F | FY28F | FY29F |
|---|---|---|---|
| Debt / EBITDA | 3.1x [4] | 3.0x [4] | 2.9x [4] |
| RCF / Net Debt | 29.4% [4] | 30.9% [4] | 31.7% [4] |
| (EBITDA - CAPEX) / Interest | 2.6x [4] | 2.8x [4] | 3.0x [4] |
| Revenue (EUR bn) | 43.7 [4] | 45.1 [4] | 46.0 [4] |

**Notes**

- H1 FY27 results were reported on 10 Nov 2026, so this preview covers the next results; Moody's data does not give their date. A recap of the H1 FY27 results is available on request.
- Moody's-adjusted figures are for FY26 (to 31 Mar 2026) and predate the VodafoneThree buyout and Safaricom consolidation; company net debt and the 2.25-2.75x target are the company's own measures, not comparable with Moody's debt/EBITDA.

**Sources**

[1] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-10-13
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted), fiscal year ended 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[3] Moody's (searchCompanyFilings) · Vodafone Group H1 FY27 Results (Form 6-K) · Interim filing 'Vodafone Group Plc Interim Report 2026 - Q4' (H1 FY27 results, period to … · 2026-11-10
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections FactorsLeadingToUpgrade, FactorsLeadingToDowngrade, RatingOutlook, … · 2026-10-21
[5] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call · Earnings call transcript: Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, … · 2026-11-10

Earnings tab updated 2026-11-15 23:19 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html (not published: Artifact publish skipped in this run).
