# Regulatory watch: Banks, Europe (8 to 15 Nov 2026)

**No regulator changed liquidity rules this week. On LCR, HSBC (134% [1]), BNP Paribas (134.77% [1]) and Groupe Credit Agricole (135.75% [2]) have the least headroom over the 100% minimum [3]. The four items found this week fall on channels where Moody's data carries no metric.**

## Who it hits: Liquidity (asked; no change in window) · LCR

| Name | LCR, Q2 2026 | vs median (pp) | Stated requirement | Distance (pp) | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134% [1] | -7.0 [1] | 100%, Basel minimum [3] | +34.0 [1][3] | Least headroom |
| BNP Paribas | 134.77% [1] | -6.2 [1] | 100% [3] | +34.8 [1][3] | Least headroom |
| Groupe Credit Agricole | 135.75% [2] | -5.3 [1][2] | 100% [3] | +35.8 [2][3] | Least headroom |
| ING Groep N.V. | 137% [1] | -4.0 [1] | 100% [3] | +37.0 [1][3] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.6% [1] | -3.4 [1] | 100% [3] | +37.6 [1][3] | Least headroom |
| UniCredit S.p.A. | 140% [1] | -1.0 [1] | 100% [3] | +40.0 [1][3] | Middle |
| Deutsche Bank AG | 140.12% [1] | -0.9 [1] | 100% [3] | +40.1 [1][3] | Middle |
| Commerzbank AG | 141% [1] | 0.0 [1] | 100% [3] | +41.0 [1][3] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142% [1] | +1.0 [1] | 100% [3] | +42.0 [1][3] | Middle |
| Lloyds Banking Group plc | 144% [1] | +3.0 [1] | 100% [3] | +44.0 [1][3] | Middle |
| Societe Generale | 146.41% [1] | +5.4 [1] | 100% [3] | +46.4 [1][3] | Most headroom |
| Nordea Bank Abp | 156% [1] | +15.0 [1] | 100% [3] | +56.0 [1][3] | Most headroom |
| Barclays PLC | 157.7% [1] | +16.7 [1] | 100% [3] | +57.7 [1][3] | Most headroom |
| UBS Group AG | 177.28% [1] | +36.3 [1] | 100% [3] | +77.3 [1][3] | Most headroom |
| CaixaBank, S.A. | 192.99% [1] | +52.0 [1] | 100% [3] | +93.0 [1][3] | Most headroom |

Note: The Basel LCR standard covers all 15 names, so none is out of scope. Median of the 15 ranked names: 141% [1]. Credit Agricole S.A. is the issuer on the list. The row uses Groupe Credit Agricole, the group supervisors measure. Credit Agricole S.A.'s own LCR is 141.29%, Q2 2026 [1]. Groupe Credit Agricole's latest quarter was Q3 2026, so it was pulled again at Q2 2026 [2].

## What changed

- **PRA · Final policy, 10 Nov.** PS20/26 finalises the rest of the PRA's large exposures changes. Substitution becomes mandatory for all firms. The trading-book excess allowance for third-party exposures is cut to "up to 85% of Tier 1 capital" for at most 10 business days [4]. It takes effect on 1 Jan 2028 [4]. Channel: large exposures (watch). Page only partly read.
- **FINMA · Final ordinance, 10 Nov.** FINMA published its partly revised Anti-Money Laundering Ordinance to reflect recent changes to Swiss AML law, ahead of the FATF mutual evaluation. It comes into force on 1 Jan 2027, with a four-month transition period for the self-regulation [5]. Channel: AML (watch).
- **Basel Committee · Consultation, 9 Nov.** Proposed extra Pillar 2 guidance on interest rate risk in the banking book. It covers model validation, stress testing, controls, embedded gains and losses in securities portfolios, and earnings indicators. Comments are due by 9 Feb 2027 [6]. Channel: IRRBB (watch).
- **EBA · Final methodology, 9 Nov.** The EBA released the final methodology for the 2027 EU-wide stress test, with a "more than 55%" cut in requested data [7], and added a climate module for the first time. The exercise starts in January 2027, with results due by the end of July 2027 [7]. Channel: stress testing (watch).
- **Asked · Liquidity.** No regulatory change to liquidity was found in the window.

## Who it hits: no Moody's metric

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26, large exposures [4] | HSBC, Barclays, Lloyds | Large exposures | watch |
| FINMA AML Ordinance [5] | UBS | AML | watch |
| Basel IRRBB Pillar 2 guidance (consultation) [6] | All 15, once their home country applies it | IRRBB | watch |
| EBA 2027 stress test [7] | EU banks in the EBA sample. Scope not known by name, because the sample was not read: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Not covered: HSBC, Barclays, Lloyds, UBS | Stress testing | watch |

## Notes

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact. Local liquidity rules can be stricter than the Basel minimum.
- Left out: speeches and news, meaning the SRB on 10, 11 and 13 Nov, the ECB's written overview for the Eurogroup on 9 Nov and the EC's banking-dialogue summary on 11 Nov. Also left out: consumer material (EBA factsheet, 9 Nov), the EBA's support for an NGFS declaration (13 Nov), appointments (EC tokenisation stakeholder group, 9 Nov), and measures not addressed to banks (EC feedback call on sustainability assurance standards, 12 Nov).
- No Moody's comment on these four items was found for 9 to 15 Nov. The running item list could not be read in this session, so no item is flagged NEW.
- Dashboard not updated: no folder to write to, and scripts cannot run in this session.

## Sources

1. Moody's, getEntityFinancials_v2: Basel III LCR (as reported), plus the full bank field list, LQ = Q2 2026 (period end 30 Jun 2026), 15 names including Credit Agricole S.A. Pulled 15 Nov 2026.
2. Moody's, getEntityFinancials_v2: Groupe Credit Agricole, Basel III LCR (as reported), Q2 2026 (period end 30 Jun 2026). Pulled 15 Nov 2026.
3. Web: Basel Framework (LEV, LCR, NSF standards), https://www.bis.org/basel_framework/
4. Web: PRA, PS20/26 Amendments to the Large Exposures Framework, Part 2, 10 Nov 2026, https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
5. Web: FINMA, FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance, 10 Nov 2026, https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
6. Web: Basel Committee, Interest rate risk in the banking book: additional Pillar 2 guidance (consultative), 9 Nov 2026, https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
7. Web: EBA, The EBA streamlines the 2027 EU-wide stress test with more than 55% reduction in requested data, 9 Nov 2026, https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
