**Earnings: BNP Paribas, preview** (Latest Moody's data to 15 Nov 2026; 1 name)

BNP Paribas (A1 LT Issuer Rating, stable) has one numeric Moody's trigger: return on assets of 0.6% or more for an upgrade, against 0.4% at June 2026; all downgrade triggers are worded. Moody's holds no call transcript, and the latest filings (Q3 2025 and FY2025) are older than the Q2 2026 data. [1][2][3][4][5]

**Rating and outlook**

- A1 LT Issuer Rating, outlook stable, affirmed 31 Aug 2026 (last downgrade 17 Dec 2024). Credit opinion of 2 Sep 2026: stable outlook reflects 'very stable and highly predictable profitability and sound risk profile'. [1][2]

**What to watch against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Net income / tangible assets (return on assets) | 0.4%, H1 2026 (Jun 2026) [2] | 0.6% and above [2] | No number stated | 0.2 pp below upgrade level [2] |

Note: Moody's states a number only for the upgrade path. Worded triggers, quoted from the credit opinion of 2 Sep 2026, are listed below.

**Worded triggers (quoted)**

- (Upgrade): "if the group manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management ... limiting any sudden and significant increase in problem loans and risk provisioning." Also: an upgrade of France's rating, through recovery of the government support uplift. [2]
- (Downgrade): "if the bank maintained lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics." Also: "a marked increase in risk appetite, loss incidents or a material risk management failure". [2]
- (Downgrade): "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile." Senior unsecured: if growth in senior and lower-ranking debt relative to tangible banking assets falls short of Moody's expectations. [2]

**Sector metrics to watch**

| Metric | Latest value and period | Basis | Trigger it bears on |
|---|---|---|---|
| Net interest margin | 0.9%, H1 2026 [2] | Moody's-adjusted | Profitability (downgrade); ROA (upgrade) |
| Cost of risk | not in Moody's data |  | Risk provisioning (upgrade) |
| CET1 ratio | 12.97%, Q2 2026 [3] | As reported | Regulatory capital buffers (downgrade) |
| TCE / RWA | 13.7%, H1 2026 [2] | Moody's-adjusted | Capital buffers (downgrade) |
| Planned distributions | not in Moody's data |  | Capital buffers (downgrade) |
| Problem loans / gross loans | 2.9%, H1 2026 [2] | Moody's-adjusted | Asset quality (both) |
| Impaired loans / gross loans | 2.93%, Q2 2026 [3] | As reported | Asset quality (both) |
| Cost / income | 60.6%, H1 2026 [2] | Moody's-adjusted | Profitability (downgrade) |
| LCR | 134.77%, Q2 2026 [3] | As reported | Funding and liquidity (downgrade) |
| NSFR | 108.63%, Q2 2026 [3] | As reported | Funding and liquidity (downgrade) |
| Loans / deposits | 82.30%, Q2 2026 [3] | As reported | Funding and liquidity (downgrade) |

**What the latest filing says**

- **Q3 2025 report**: Company-reported: 2026 trajectory confirmed - revenue CAGR above 5% and net income CAGR above 7% for 2024-2026, jaws about +1.5 points a year. [4]
- **Q3 2025 report**: Company-reported: cost of risk below 40 bps in 2025 and 2026; RoTE targets 12% for 2026 and 13% for 2028. [4]
- **FY2025 report**: Company-reported: net income attributable to shareholders EUR 12,225m for 2025, against EUR 11,688m for 2024, meeting the >EUR 12.2bn 2025 target stated in the Q3 2025 report. [4][5]
- No CET1 or distribution target was found in the filing excerpts returned.

**Moody's expectations**

The credit opinion's key indicators table has no forecast columns, only historical periods to June 2026. [2]

**Notes**

- No earnings call transcript in Moody's data for BNP Paribas; no web search was made for one. Guidance comes from the Q3 2025 interim and FY2025 annual reports, which are older than the Q2 2026 Moody's data.
- Company RoTE and net income targets are company-reported measures, not Moody's return on assets.

**Sources**

[1] Moody's ratings (getEntityRatings) · BNP Paribas · 2026-11-15
[2] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation · PBC_1491623; sections FactorsLeadingToUpgrade, FactorsLeadingToDowngrade, RatingOutlook, … · 2026-09-02
[3] Moody's financials (getEntityFinancials_v2) · Bank Focus, consolidated, LQ = Q2 2026 (CET1, LCR, NSFR, impaired loans, loans/deposits) · BNP Paribas · 2026-06-30
[4] Moody's (searchCompanyFilings) · Third amendment to the 2024 Universal registration document (Q3 2025) · BNP Paribas Interim Report 2025 - Q3 (period to 30 Sep 2025), pages 9 and 32 · 2025-09-30
[5] Moody's (searchCompanyFilings) · BNP Paribas Annual Report 2025 · BNP Paribas Annual Report 2025 - Q4 (period to 31 Dec 2025), page 5 · 2025-12-31

Earnings tab updated at 23:19 UTC, 15 Nov 2026. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html (not published as an Artifact in this run).
