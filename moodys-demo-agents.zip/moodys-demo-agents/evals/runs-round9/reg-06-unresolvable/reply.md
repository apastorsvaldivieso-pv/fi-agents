**Regulatory watch: BNP Paribas, Deutsche Bank, 30 days** (30 days, 16 Oct to 15 Nov 2026; 2 names)

The Basel Committee finalised averaging of G-SIB indicators to curb window-dressing and opened a consultation on the banking-union treatment in the G-SIB methodology, both covering BNP Paribas and Deutsche Bank; the other ten items in the window carry no Moody's metric. [1][2]

**Who it hits: G-SIB window-dressing amendments and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported), Q2 2026 | vs median of ranked names | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | not ranked | 10.51%, CET1 capital requirement (30 Sep 2025, older) [4] | +2.46 pp [3][4] | list too short to rank |
| Deutsche Bank AG | 13.92% [3] | not ranked | not stated | n/a | list too short to rank |

Note: Both are on the FSB G-SIB list of 27 Nov 2025 (BNP Paribas bucket 2, Deutsche Bank bucket 1); the 2026 list was not found. The standard requires reporting by banks participating in the G-SIB assessment exercise; its buffer effect falls on listed banks. The consultation page names no addressees; we read it as covering banking-union G-SIBs, which includes both. [1][2][5]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes: a trading book excess allowance of up to 85% of Tier 1 capital for at most 10 business days, and a 350% of Tier 1 limit for some trading book exposures. Takes effect 1 January 2028. Channel: large exposures. [6]
- [NEW] **FINMA** (Final): Final partially revised Anti-Money Laundering Ordinance, with revised bank due-diligence self-regulation recognised as minimum standards. In force 1 January 2027, with a four-month transition for the self-regulation. Channel: AML. [7]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, controls, embedded gains and losses in securities portfolios, and earnings indicators. Comments by 9 February 2027. Channel: IRRBB. [8]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test cuts requested data by more than 55% (the body says 55%) and adds a climate module outside the core results. Launch end of January 2027, results end of July 2027. Channel: stress testing. [9]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: final ITS report due December 2026, first reference date postponed to December 2027, liquidity, asset encumbrance, benchmarking and ESG reporting deferred to December 2028. Channel: reporting. [10]
- [NEW] **Basel Committee** (Consultation): Consultation on consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 December 2026. Channel: supervisory guidance (our mapping; no row in the channel map). [11]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, more proportionate than the consultation draft; awaiting translation, no application date on the page. Channel: governance. *Why it matters:* Moody's (11 Nov 2026) calls the revision credit positive for EU banks, more so for small banks, as larger ones already apply the guidelines. [12][13]
- [NEW] **FINMA** (Consultation): Consultation on partially revised Circular 2019/2 on interest rate risks for banks, implementing the Basel Committee's July 2024 recalibrated shocks. Consultation until 15 January 2027. Channel: IRRBB. [14]
- [NEW] **European Commission** (Legislative step): Political agreement on the securitisation framework review: simpler due diligence and transparency rules, and a more risk-sensitive CRR prudential treatment. Awaits technical finalisation and formal approval; enters into force on publication. Channel: securitisation. [15]
- [NEW] **PRA** (Consultation): CP14/26, phase 2 of the SM&CR review: most Senior Manager Functions become notified rather than pre-approved and Certification Regime fitness requirements are removed. Responses by 22 January 2027. Channel: governance, conduct. [16]
- [NEW] **Basel Committee** (Final): Final amendments require banks in the G-SIB assessment to report and disclose stock indicators as yearly averages, not year-end values, by 1 January 2030; the leverage exposure threshold for reporting rises from EUR 200 billion to EUR 350 billion from 1 January 2027. Channel: G-SIB buffer (CET1). [1][17]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: consults on bringing the agreed treatment of cross-border exposures within the European Banking Union into the framework. Comments by 14 January 2027. Channel: G-SIB buffer (CET1). [2][17]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA large exposures PS20/26 [6] | none (UK groups only) | large exposures | Watch |
| FINMA AML Ordinance [7] | none (Swiss groups only) | AML | Watch |
| Basel IRRBB Pillar 2 guidance [8] | BNP Paribas, Deutsche Bank, once applied at home | IRRBB | Watch |
| EBA 2027 stress test [9] | scope not known: EU banks in the EBA sample (sample not checked) | stress test results | Watch |
| EBA reporting simplification [10] | BNP Paribas, Deutsche Bank | reporting | Watch |
| Basel consolidated guidelines amendments [11] | BNP Paribas, Deutsche Bank, once applied at home | supervisory guidance | Watch |
| EBA internal governance guidelines [12] | BNP Paribas, Deutsche Bank | governance | Watch |
| FINMA Circular 2019/2 consultation [14] | none (Swiss groups only) | IRRBB | Watch |
| EU securitisation framework [15] | BNP Paribas, Deutsche Bank | securitisation | Watch |
| PRA SM&CR review CP14/26 [16] | none (UK groups only) | governance, conduct | Watch |

Note: Moody's data carries no metric for these channels, so no name has a position on them.

**Unresolved names:** Zzyzx Fakecorp Bank (no match in Moody's (findEntity returned no results; home country unknown, so no country filter)). Not guessed, not included.

**Notes**

- Left out (17 entries on the running list): speeches, interviews, blog and meeting news (ECB, SRB, FINMA, Commission dialogue summary, ECB written overview to the Eurogroup); newsletters (Basel AML/CFT newsletter, PRA Regulatory Digest); a periodic list (ECB supervised entities); sanctions notices (FINMA, Commission); advice to another authority (EBA on Taxonomy disclosures); a moved consultation deadline and an appointment (EBA); consumer material and an NGFS statement (EBA); items addressed to other kinds of firm (PRA credit union papers, FINMA Bitcoin ETF approval, Commission sustainability assurance and tokenisation notices).
- Ratings, credit opinions and news for BNP Paribas and Deutsche Bank were not pulled: this run covers regulation only.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[6] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[7] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[8] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[9] Web · EBA: The EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[10] Web · EBA: Next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[11] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[12] Web · EBA: Revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[13] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[14] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[15] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[16] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[17] Web · Basel Committee media release: window-dressing measures and G-SIB methodology … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib

Regulatory watch tab updated 15 Nov 2026 23:16 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html (not published: publish step skipped for this test run).
