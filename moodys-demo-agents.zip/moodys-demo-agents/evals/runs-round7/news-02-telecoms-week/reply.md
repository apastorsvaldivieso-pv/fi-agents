**Daily sector news: Telecoms, Europe, last 7 days** (168h from 8 Nov 2026 22:06 UTC to 15 Nov 2026 22:06 UTC; 15 names)

No Moody's rating action on the list; Telefonica and Vodafone raised cash flow guidance and Telia agreed a SEK 3.8 billion Nordic purchase. [1][2][3]

**Top this week**

- **Telefonica S.A.** (Results): Q3 results (12 Nov): revenue EUR 8.43 billion, up 4.8%; guidance raised for adjusted EBITDA, operating cash flow after leases and free cash flow. *Why it matters:* More free cash flow supports deleveraging at Baa3 senior unsecured, stable outlook. [1][4]
- **Telia Company AB** (M&A): Agreed on 12 Nov to buy Telavox's Nordic enterprise customer base for SEK 3.8 billion plus up to SEK 0.2 billion earn-out. Latvia's buyout of Telia's LMT and Tet stakes is due by 17 Nov. *Why it matters:* The purchase adds to net debt and the Latvian sale brings in cash; undisclosed terms decide the net effect on leverage. [3][5]
- **Vodafone Group Plc** (Results): Half-year results this week, with full-year profit and cash flow guidance raised. *Why it matters:* Higher cash flow supports leverage at Baa2 senior unsecured, stable outlook. [2][4]

**Macro**

- Euro zone bond yields dipped on 12 Nov and rose on 13 Nov (headlines only). *Why it matters:* Higher yields lift refinancing costs. [6][7]
- Moody's 2027 global credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs offset the AI tailwind. *Why it matters:* Costlier refinancing weighs most on the list's high-yield names. [8]

**Sector**

- (Moody's): No Moody's rating action or research on listed names in the window. *Why it matters:* Moody's stated view on each name is unchanged.
- (Outlook): Latest Moody's outlook, Telecommunications - Global (27 Oct 2026): stable, as solid demand and lower capital intensity offset refinancing pressure. *Why it matters:* The sector backdrop is unchanged. [9]

**By name**

| Name | Rating (class, outlook) | This week |
|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured, stable [4] | No material credit news; Q3 was 5 Nov. |
| Orange | Baa1 LT Issuer, stable [4] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured, stable [4] | Guidance raised. [2] |
| Telefonica S.A. | Baa3 Senior Unsecured, stable [4] | Guidance raised. [1] |
| Swisscom AG | A2 LT Issuer, stable [4] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer, stable [4] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured, stable [4] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured, positive [4] | Bought 57.5% of Bahnhof; mandatory offer, now about 66.9%. [10][11] |
| Telia Company AB | Baa1 Senior Unsecured, stable [4] | Telavox purchase; Latvian stake buyout. [3][5] |
| TIM S.p.A. | Baa3 LT Issuer, positive [4] | 2026 targets kept; 9M net loss EUR 205 million. [12][13] |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer, stable [4] | No material credit news. |
| BT Group Plc | Baa2 LT Issuer (British Telecommunications Ltd), stable [4] | Openreach Chair to step down 31 Mar 2027. [14] |
| Iliad S.A. | Ba1 Senior Unsecured, stable [4] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 CFR, on review for downgrade (22 Oct) [4] | No material credit news. |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility, positive [4] | No material credit news. |

Note: BT's 5 Nov results and pension valuation fall before the window.

**Notes**

- News for Iliad S.A. returned only unrelated articles that mention the word Iliad; none were used.
- Deutsche Telekom, Proximus and BT results were published before the window; articles in the window that repeat them are not treated as new.

**Sources**

[1] Moody's (searchNews) · Telefonica raises EBITDA and free cash flow outlook after Q3 results (Seeking … · 202611120151AMSPIDERBLG_FIN__25812_2267290 · 2026-11-12
[2] Moody's (searchNews) · Vodafone publishes half-year results, raises full-year profit and cash flow … · 202611130657AMSPIDERFIN_NEWS_260566_328912 · 2026-11-13
[3] Moody's (searchNews) · Telia to acquire Telavox enterprise customers for SEK 3.8 billion … · 202611120703CONTIFY_NEWS____0069708735 · 2026-11-12
[4] Moody's ratings (getEntityRatings) · Ratings: Deutsche Telekom, Orange, Vodafone, Telefonica, Swisscom, Telekom Austria, Proximus, Telenor, Ratings: Telia, TIM, PPF Telecom, British Telecommunications, Iliad, VMED O2, Altice France · 2026-11-15
[5] Moody's (searchNews) · Government directive on buyout of Telia's shares in LMT and Tet to be … · 202611130000PPI_____ASIANET_LETA1311202600010004 · 2026-11-13
[6] Moody's (searchNews) · U.S., Eurozone bond yields rise but two-year Treasury stabilizes (Morningstar) · 202611130510AMSPIDEROPNT__AM_835_4659581 · 2026-11-13
[7] Moody's (searchNews) · Euro zone bond yields dip as traders mull inflation, interest rate outlook … · 202611120435AMSPIDERNEWSSERV_22014_1245470 · 2026-11-12
[8] Moody's (searchAllDocuments) · Credit Conditions - Global: 2027 Outlook: Credit will weaken as higher rates … · PBC_1491648 · 2026-11-09
[9] Moody's (searchAllDocuments) · Telecommunications - Global: Outlook stable as solid demand, declining capital … · PBC_1496503 · 2026-10-27
[10] Moody's (searchNews) · Telenor acquires 57.5% stake in Bahnhof for USD 363.02 million (MarketLine) · 202611110000DMON____NEWS_____8F0458C9_ADC1_4E0B_9CC3_85AFBD8B56A8 · 2026-11-11
[11] Moody's (searchNews) · Bahnhof board recommends Telenor Sverige's mandatory cash offer; Telenor holds … · 202611130231AMSPIDEROPNTNEUR_76750_166542 · 2026-11-13
[12] Moody's (searchNews) · Telecom Italia keeps 2026 outlook after stronger 9M growth (Ad Hoc News) · 202611111909AMSPIDEROPNTEEUR_20218_20231259 · 2026-11-12
[13] Moody's (searchNews) · Telecom Italia's losses rise 88% through September (CE Noticias Financieras) · 202611121042CONTENGEBRZL_GVT_91079729 · 2026-11-12
[14] Moody's (searchNews) · Openreach announces Board and executive changes (Contify) · 202611130138CONTIFY_NEWS____0069713219 · 2026-11-12

Dashboard: the Daily sector news tab was updated at 15 Nov 2026 22:09 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-02-telecoms-week/dashboard/dashboard.html
