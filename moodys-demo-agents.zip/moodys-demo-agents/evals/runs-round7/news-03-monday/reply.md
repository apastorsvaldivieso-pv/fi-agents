**Daily sector news: Telecoms, Europe** (72h to 15 Nov 2026 22:18 UTC, from 12 Nov 22:18 UTC; 15 names)

A light weekend for European telecoms: two portfolio moves in the Nordics (Telia's Latvian exit nears its 17 Nov deadline, Telenor controls Bahnhof), and no Moody's rating actions or research in the window. [1][2][3]

**Top this weekend**

- **Telia Company AB** (Disposal): LMT's vice president said on 13 Nov that the Latvian government's directive to buy out Telia's shares in LMT and Tet will be carried out by the 17 November deadline. No price was given. *Why it matters:* Proceeds would bring in cash for debt reduction but remove the Latvian EBITDA, so the net effect on leverage depends on terms not yet public. [1]
- **Telenor ASA** (M&A): Telenor Sverige now holds about 66.9% of Bahnhof's shares and 90.6% of the votes, and Bahnhof's independent committee recommended its SEK 62 per share mandatory cash offer (launched 6 Nov). *Why it matters:* A cash-funded acquisition adds to outflows while Telenor sits on a positive outlook. [2][4]

**Macro**

- Headlines point to further Bank of England hikes in 2027, with UK price data seen strengthening the case. *Why it matters:* Higher sterling rates raise refinancing costs for the UK names, most for the high-yield VMED O2. [5][6]
- Euro area government bond yields rose on 13 Nov. *Why it matters:* Higher base rates feed through to the cost of new euro issuance. [7]

**Sector**

- Moody's published no rating action and no sector or issuer research on European telecoms in the window. [3]
- (Outlook): Latest Moody's global telecommunications outlook (27 Oct 2026) is stable: solid demand, stronger EBITDA and declining capital intensity offset modest growth, refinancing pressure and structural risks. [8]

**By name**

| Name | Moody's rating | Outlook | Credit news |
|---|---|---|---|
| Deutsche Telekom AG | A3 Senior Unsecured (Fgn Curr) [9] | Stable [9] | No material credit news. |
| Orange | Baa1 LT Issuer Rating [9] | Stable [9] | No material credit news. |
| Vodafone Group Plc | Baa2 Senior Unsecured (Fgn Curr) [9] | Stable [9] | No material credit news. |
| Telefonica S.A. | Baa3 Senior Unsecured (Dom Curr) [9] | Stable [9] | No material credit news. |
| Swisscom AG | A2 LT Issuer Rating (Dom Curr) [9] | Stable [9] | No material credit news. |
| Telekom Austria AG | A3 LT Issuer Rating [9] | Stable [9] | No material credit news. |
| Proximus SA de droit public | A3 Senior Unsecured (Dom Curr) [9] | Stable [9] | No material credit news. |
| Telenor ASA | Baa1 Senior Unsecured (Fgn Curr) [9] | Positive [9] | Bahnhof offer nearly complete (see top). |
| Telia Company AB | Baa1 Senior Unsecured (Fgn Curr) [9] | Stable [9] | LMT and Tet buyout due by 17 Nov (see top). |
| TIM S.p.A. | Baa3 LT Issuer Rating (Dom Curr) [9] | Positive [9] | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 LT Issuer Rating (Dom Curr) [9] | Stable [9] | No material credit news. |
| BT Group Plc | Baa2 LT Issuer Rating, at British Telecommunications Limited [9] | Stable [9] | No material credit news. |
| Iliad S.A. | Ba1 Senior Unsecured (Dom Curr) [9] | Stable [9] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 Corporate Family Rating (Fgn Curr) [9] | Review for downgrade [9] | No material credit news; review open since 22 Oct. [9] |
| Altice France SAS | Caa1 Senior Secured Bank Credit Facility (Fgn Curr) [9] | Positive [9] | No material credit news. |

Note: Ratings are Moody's ratings as returned, with their class. No rating action on any name fell inside the window.

**Notes**

- You said it is Monday 16 Nov; the system clock reads Sunday 15 Nov 22:18 UTC, so searches run to now. Monday rule applied: 72-hour window.
- Dropped as before the window: Deutsche Telekom guidance raise (Q3, 5 Nov) and BT pension valuation (5 Nov), both re-reported this weekend.
- News for Orange and Iliad came back almost entirely as unrelated name matches; nothing credit-relevant was found for either.

**Sources**

[1] Moody's (searchNews) · Government's directive regarding buyout of Telia's shares in LMT and Tet to be … · 2026-11-13
[2] Moody's (searchNews) · Bahnhof's independent board committee recommends acceptance of Telenor … · 2026-11-13
[3] Moody's (searchAllDocuments) · Moody's actions and research, European telecoms, in window · Rating Action; Sector Comment, Sector In-Depth, Issuer Comment; Telecommunications, … · 2026-11-15
[4] Moody's (searchNews) · Telenor Sverige announces a supplement to the offer document for the mandatory … · 2026-11-13
[5] Moody's (searchNews) · BOE likely to raise rates further in 2027 (Forex Factory) · 2026-11-15
[6] Moody's (searchNews) · BOE's case to raise rates again may strengthen on UK price data (WN) · 2026-11-15
[7] Moody's (searchNews) · Eurozone bond yields rise; Italy might get ratings upgrade (MSN) · 2026-11-13
[8] Moody's (searchAllDocuments) · Telecommunications – Global: Outlook stable as solid demand, declining capital … · PBC_1496503 · 2026-10-27
[9] Moody's ratings (getEntityRatings) · Moody's ratings, coverage list part 1, Moody's ratings, coverage list part 2 · 2026-11-15

Daily sector news tab updated 15 Nov 2026 22:20 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html (not published as an Artifact in this run).
