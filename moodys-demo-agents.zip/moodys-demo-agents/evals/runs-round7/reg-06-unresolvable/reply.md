**Regulatory watch: Banks Europe, 30 days, own names** (16 Oct to 15 Nov 2026 (30 days); 2 names)

Two Basel Committee G-SIB measures of 16 Oct, one final and one a consultation, reach BNP Paribas and Deutsche Bank through the G-SIB buffer; the other ten items carry no Moody's metric. [1][2]

**Who it hits: G-SIB window-dressing amendments and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, as reported (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | not ranked | 10.51%, 30 Sep 2025, older [4] | +2.46 pp (vs older requirement) [3][4] | list too short to rank |
| Deutsche Bank AG | 13.92% [3] | not ranked | not stated | not stated | list too short to rank |

Note: Both are on the FSB G-SIB list of 27 Nov 2025 (BNP bucket 2, Deutsche bucket 1); no 2026 list found on fsb.org. The final rule's reporting applies to banks in the assessment sample; its capital effect falls on listed G-SIBs. The consultation page names no banks; it concerns banking-union cross-border exposures, so banking-union G-SIBs are taken as covered (own judgment). [1][2][5]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the remaining Large Exposures changes: no internal models for securities financing exposures, mandatory credit risk mitigation substitution. Applies from 1 Jan 2028 to PRA-authorised UK banks. Channel: large exposures. Covers no name on this list. [6]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance, in force 1 Jan 2027. Channel: AML. Covers Swiss groups only, none on this list. [7]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded gains and losses, earnings indicators. Comments by 9 Feb 2027. Channel: IRRBB. [8]
- [NEW] **EBA** (Final): Final methodology and draft templates for the 2027 EU-wide stress test, with 55% fewer data points and a climate module outside the core results. Launch end Jan 2027, results end Jul 2027. Channel: stress testing. [9]
- [NEW] **EBA** (Other): Supervisory reporting simplification: final ITS report due Dec 2026; first reference date moved to Dec 2027, and Dec 2028 for liquidity, asset encumbrance, benchmarking and ESG reporting. Channel: reporting. [10]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10) reflecting CRD VI; application date not stated. Channel: governance. *Why it matters:* Moody's sector comment of 11 Nov 2026 calls the revision credit positive, mainly for smaller EU banks. [11][12]
- [NEW] **Basel Committee** (Consultation): Consequential amendments updating Basel Framework cross-references to the new consolidated guidelines and moving some application guidance into them. Comments by 21 Dec 2026. No channel-map row; treated as watch by own judgment. [13]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on interest rate risk in the banking book, adopting recalibrated Basel shocks. Comments by 15 Jan 2027. Channel: IRRBB. Covers Swiss banks only, none on this list. [14]
- [NEW] **European Commission** (Other): Provisional political agreement on the Securitisation Framework review, including a more risk-sensitive CRR treatment of securitisations; awaits formal approval by Parliament and Council. Channel: securitisation. [15]
- [NEW] **PRA** (Consultation): CP14/26 proposes phase 2 of the SM&CR review, moving most Senior Manager roles to notification. Comments by 22 Jan 2027. Channel: governance. Covers UK groups only, none on this list. [16]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be reported as averages over the year, not year-end values, by 1 Jan 2030; reporting threshold raised to EUR 350bn leverage exposure from 1 Jan 2027. Channel: G-SIB buffer (CET1). [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: asks whether to build the agreed treatment of cross-border exposures within the banking union into the G-SIB assessment. Comments by 14 Jan 2027. Channel: G-SIB buffer (CET1). [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EC securitisation framework agreement (22 Oct) | BNP Paribas, Deutsche Bank | securitisation exposure | Watch |
| EBA internal governance guidelines (5 Nov) | BNP Paribas, Deutsche Bank | none (governance) | Watch |
| EBA reporting timelines (6 Nov) | BNP Paribas, Deutsche Bank | none (reporting) | Watch |
| EBA 2027 stress test (9 Nov) | scope not known: sample not listed on the page | stress test results | Watch |
| BCBS IRRBB Pillar 2 guidance (9 Nov) | BNP Paribas, Deutsche Bank, once applied in the EU | IRRBB sensitivity | Watch |
| BCBS consolidated guidelines amendments (5 Nov) | BNP Paribas, Deutsche Bank, once applied in the EU | none | Watch |
| PRA PS20/26, CP14/26; FINMA AMLO, Circular 2019/2 | none (UK and Swiss groups only) | large exposures, governance, AML, IRRBB | Watch |

Note: Moody's bank data carries no field for these channels.

**Unresolved names:** Zzyzx Fakecorp Bank (no match in Moody's: findEntity returned no results and no candidates). Not guessed, not included.

**Notes**

- Left out (18 entries): speeches, interviews and blog posts (ECB, SRB, FINMA); newsletters (Basel Committee AML/CFT newsletter, PRA Regulatory Digest); sanctions notices and statements (FINMA, European Commission); periodic lists and statistics (ECB supervised entities, EC sustainable investment data); reports between authorities (ECB to Eurogroup); consumer material and an NGFS statement (EBA); items for other firms (PRA credit union papers, FINMA Bitcoin ETF, EC assurance standards); an EC meeting summary and stakeholder nominations.
- No Moody's comment found on the G-SIB measures or the securitisation agreement in the window.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, CET1 capital … · 2025-09-30
[5] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[6] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[7] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[8] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[9] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[10] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[11] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[12] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[13] Web · Basel Committee: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[14] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[15] Web · European Commission welcomes political agreement on the review of the … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[16] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 15 Nov 2026 22:15 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html. Dashboard not published: Artifact publishing skipped for this run.
