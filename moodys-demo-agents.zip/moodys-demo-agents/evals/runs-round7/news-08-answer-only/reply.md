**Daily sector news: Telecoms, Europe**
Window: 7 days, 8 Nov 2026 00:00 UTC to 15 Nov 2026 22:10 UTC (searched as whole calendar days, about 190h). 15 names.

**Headline:** Moody's took no rating actions on the list this week. The week brought three bolt-on deals in the Nordics (Telia, Telenor) and guidance raises at Telefonica and Vodafone.

### Top this week

1. **Telia: buys Telavox's Nordic enterprise base and moves to exit Latvia.** Telia agreed on 12 Nov to buy Telavox's Nordic enterprise customer base for SEK 3.8bn, plus up to SEK 0.2bn of earn-out. The base brings about SEK 1.1bn of annual revenue [3]. Separately, LMT says Latvia's government buyout of Telia's stakes in LMT and Tet will happen by the 17 Nov deadline [4]. *Why it matters:* the purchase uses cash and the Latvian exit should bring it in, so the net effect on leverage depends on the timing of the two.
2. **Telenor: takes control of Bahnhof.** Telenor Sverige bought 57.5% of Bahnhof (about USD 363m) [6] and launched a mandatory cash offer at SEK 62 a share. By 13 Nov it held about 66.9% of the shares and 90.6% of the votes [5]. *Why it matters:* this is debt-funded or cash-funded M&A while Telenor's Baa1 senior unsecured rating has a positive outlook [1].
3. **Telefonica: raises FY guidance after Q3 (12 Nov).** Telefonica raised its guidance for adjusted EBITDA, operating cash flow after leases and free cash flow. Q3 revenue was EUR 8.43bn, up 4.8% year on year (company-reported) [7]. *Why it matters:* higher free cash flow supports deleveraging at a Baa3 senior unsecured, stable issuer [1].

### Macro

- Moody's 2027 global credit conditions outlook (9 Nov) expects credit to weaken as higher rates and energy costs outweigh the boost from AI [13].
- US and euro-area bond yields rose on 13 Nov [14]. *Why it matters:* refinancing costs for heavily indebted operators.

### Sector

- **Moody's rating actions:** none on European telecoms in the window.
- **Moody's research:** Issuer Comment on Odido Group Holding B.V. (not on the list, 11 Nov). New notes raise leverage to fund Apax's acquisition, but Moody's says credit quality is unchanged at a B2 CFR with B1 senior secured notes [11]. This shows sponsor buyouts in European telecoms being funded with more debt.
- **Sector outlook:** Moody's global telecommunications outlook is **stable** (27 Oct 2026). It cites solid demand and lower capital intensity, which offset refinancing pressure and structural risks [12].

### By name

| Name | Rating (class), outlook | This week |
|---|---|---|
| Deutsche Telekom AG | A3 (Senior Unsecured, FC), stable [1] | No material credit news. Q3 results and the guidance raise came on 5 Nov, before the window. |
| Orange | Baa1 (LT Issuer), stable [1] | No material credit news. |
| Vodafone Group Plc | Baa2 (Senior Unsecured, FC), stable [1] | H1 results raised full-year profit and cash flow guidance [8]. |
| Telefonica S.A. | Baa3 (Senior Unsecured, DC), stable [1] | Guidance raised; see Top [7]. |
| Swisscom AG | A2 (LT Issuer, DC), stable [1] | No material credit news. |
| Telekom Austria AG | A3 (LT Issuer), stable [1] | No material credit news. |
| Proximus SA de droit public | A3 (Senior Unsecured, DC), stable [1] | No material credit news. |
| Telenor ASA | Baa1 (Senior Unsecured, FC), positive [1] | Bahnhof control; see Top [5][6]. |
| Telia Company AB | Baa1 (Senior Unsecured, FC), stable [1] | Telavox purchase and Latvian exit; see Top [3][4]. |
| TIM S.p.A. | Baa3 (LT Issuer, DC), positive [1] | 9M net loss attributable widened to EUR 205m (EUR 109m a year earlier); 2026 targets kept [9]. Owner Poste Italiane is launching a EUR 600m data-centre co-investment fund [10]. |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer, DC), stable [2] | No material credit news. |
| BT Group Plc | Baa2 (LT Issuer, at British Telecommunications Ltd), stable [2] | No material credit news. H1 results and the pension valuation came out before the window. |
| Iliad S.A. | Ba1 (Senior Unsecured, DC), stable [2] | No material credit news. |
| VMED O2 UK Holdings Limited | B1 (CFR, FC), on review for downgrade since 22 Oct 2026 [2] | No material credit news. |
| Altice France SAS | Caa1 (Senior Secured Bank Credit Facility, FC), positive [2] | No material credit news. |

Notes
- Figures from news items are company-reported, not Moody's-adjusted.
- The Iliad news search returned only articles about other things that share the name ("Iliad"). None of them was used.
- Dashboard not updated: this session has no folder to write to, cannot run scripts and cannot publish.

Sources
1. Moody's, getEntityRatings: current ratings and 1-year history for Deutsche Telekom, Orange, Vodafone, Telefonica, Swisscom, Telekom Austria, Proximus, Telenor, Telia and TIM, 15 Nov 2026
2. Moody's, getEntityRatings: current ratings and 1-year history for PPF Telecom, British Telecommunications Ltd, Iliad, VMED O2 UK and Altice France, 15 Nov 2026
3. Moody's, searchNews: "Telia to acquire Telavox's Nordic enterprise customer base…" (Contify, 202611120738CONTIFY_NEWS____0069709181) and "Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion…" (Telecomlead, 202611120703CONTIFY_NEWS____0069708735), 12 Nov 2026
4. Moody's, searchNews: "Government's directive regarding buyout of Telia's shares in LMT and Tet to be implemented by November 17 deadline", LETA, 202611130000PPI_____ASIANET_LETA1311202600010004, 13 Nov 2026
5. Moody's, searchNews: "Bahnhof's independent board committee recommends acceptance of Telenor Sverige's… offer", NewsWeb 686452, 13 Nov 2026
6. Moody's, searchNews: "Telenor Acquires 57.5% Stake in Bahnhof for USD363.02 Million", Marketline, 202611110000DMON____NEWS_____8F0458C9_ADC1_4E0B_9CC3_85AFBD8B56A8, 11 Nov 2026
7. Moody's, searchNews: "Telefónica raises EBITDA and free cash flow outlook after Q3 results", Seeking Alpha, 202611120151AMSPIDERBLG_FIN__25812_2267290, 12 Nov 2026
8. Moody's, searchNews: "FTSE 100 Vodafone (LSE:VOD) Publishes Half-Year Results", Kalkine Media, 202611130657AMSPIDERFIN_NEWS_260566_328912, 13 Nov 2026
9. Moody's, searchNews: "Telecom Italia's losses soar by 88% through September", CE Noticias Financieras, 202611121042CONTENGEBRZL_GVT_91079729, 12 Nov 2026; "Telecom Italia stock keeps 2026 outlook after stronger 9M growth", Ad Hoc News, 202611111909AMSPIDEROPNTEEUR_20218_20231259, 12 Nov 2026
10. Moody's, searchNews: "Italy's Poste targets a €600M co-investment fund for data centres", TheNextWeb, 202611120514AMSPIDERBLG_TECH_26222_101877, 12 Nov 2026
11. Moody's, searchAllDocuments: Issuer Comment "Odido Group Holding B.V.: New notes issuance increases leverage but credit quality remains unchanged", PBC_1502046, 11 Nov 2026
12. Moody's, searchAllDocuments: Outlook "Telecommunications – Global: Outlook stable as solid demand, declining capital intensity offset broad range of risks", PBC_1496503, 27 Oct 2026
13. Moody's, searchAllDocuments: Outlook "Credit Conditions – Global: 2027 Outlook: Credit will weaken as higher rates and energy costs counter AI tailwind", PBC_1491648, 9 Nov 2026
14. Moody's, searchNews: "U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes — Update", Morningstar/Dow Jones, 202611130510AMSPIDEROPNT__AM_835_4659581, 13 Nov 2026
