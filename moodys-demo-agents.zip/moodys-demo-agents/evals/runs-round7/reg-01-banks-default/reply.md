**Regulatory watch: Banks Europe, 7 days** (7 days, 8 to 15 Nov 2026; 15 names)

Four new regulatory items for European banks between 8 and 15 Nov 2026, none on a channel Moody's data carries a metric for: a Basel Committee consultation on IRRBB, the PRA's final large-exposures rules (HSBC, Barclays, Lloyds), FINMA's revised AML ordinance (UBS) and the EBA's 2027 stress-test methodology. [1][2][3][4]

**What changed**

- [NEW] **PRA** (Final): PS20/26 completes the large-exposures changes: credit risk mitigation substitution becomes mandatory, internal models can no longer set securities-financing exposure values, and trading-book allowances are cut. Implementation 1 January 2028. Channel: large exposures. *Why it matters:* Can tighten single-name and intragroup concentration limits for UK groups; no Moody's comment found yet. [3]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published after an earlier consultation, with the revised banks' due-diligence code recognised as a minimum standard. In force 1 January 2027. Channel: AML. *Why it matters:* Compliance and conduct-risk channel for UBS; no capital or liquidity metric is touched. [4]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, embedded gains and losses in securities, earnings measures) and a new supervisory information category. Comments by 9 February 2027. Channel: IRRBB. *Why it matters:* Could raise supervisory scrutiny of banks with large unrealised securities losses; a consultation, not a final standard. No Moody's comment found yet. [1]
- [NEW] **EBA** (Final methodology): Final methodology and draft templates for the 2027 EU-wide stress test, with requested data cut by more than 55% and a new climate-risk module. Launch end-January 2027, results end-July 2027. Channel: stress testing. *Why it matters:* Results feed supervisors' Pillar 2 guidance; the participating sample is set in the methodology and may change before launch. No Moody's comment found yet. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26, large exposures (10 Nov) [3] | HSBC Holdings, Barclays, Lloyds Banking Group (UK groups) | Large exposures: no field in Moody's data | Watch |
| FINMA AML ordinance (10 Nov) [4] | UBS Group (Swiss group) | AML: no field in Moody's data | Watch |
| Basel Committee IRRBB guidance, consultation (9 Nov) [1] | All 15 names, once their home jurisdiction applies it | IRRBB: no field in Moody's data | Watch |
| EBA 2027 EU-wide stress test (9 Nov) [2] | Scope not known: sample set by the EBA; the 11 EU/EEA names are eligible (BNP Paribas, Groupe Credit Agricole, Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea) | Stress testing: no field in Moody's data | Watch |

Note: Not covered: PRA item excludes EU and Swiss groups; FINMA item covers only UBS; EBA stress test excludes UK and Swiss groups. The Basel page does not state addressees; scope follows its home-implementation rule.

**Notes**

- Left out (not a measure addressed to banks): speeches (SRB, 10 and 11 Nov); meeting reports on the EU banking competitiveness dialogue (European Commission 11 Nov, SRB 13 Nov); ECB Supervisory Board Chair's written overview to the Eurogroup (9 Nov); EBA consumer factsheet (9 Nov); EBA support for the NGFS declaration (13 Nov); Commission call for tokenisation stakeholder nominations (9 Nov); Commission feedback request on sustainability assurance standards (12 Nov, addressed to assurance providers).
- Moody's view: no Moody's research on the IRRBB, PRA large-exposures or EBA stress-test items was published between 9 and 15 Nov 2026 (searchAllDocuments, Banking, Europe).
- No item in the window maps to a metric in Moody's bank data, so no financials were pulled and no name is ranked.

**Sources**

[1] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[2] Web · EBA: The EBA streamlines the 2027 EU-wide stress test with more than 55% … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[3] Web · PRA: PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[4] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/

Regulatory watch tab updated at 2026-11-15 22:14 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html (not published as an Artifact in this run).
