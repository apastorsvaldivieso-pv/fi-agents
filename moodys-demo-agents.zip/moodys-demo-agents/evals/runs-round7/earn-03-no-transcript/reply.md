**Earnings: Iliad Holding, recap** (Latest results in Moody's data to 15 Nov 2026; Moody's comment searched 1 Oct to 15 Nov 2026; 1 names)

No recap possible from company material: Moody's holds no earnings call transcript and no results filing for Iliad Holding S.A.S.; on Moody's data to June 2026 the Ba2 CFR (stable) sits with Moody's-adjusted debt/EBITDA at 4.20x, 0.70x above the 3.5x upgrade level. [1][2]

**Results against the credit view**

- **Call and filing**: Moody's holds no earnings call transcript and no interim or annual results filing for Iliad Holding S.A.S. (the filings search first returned 'ingesting', then 'not found'). Guidance, beat or miss against guidance, net debt, liquidity, maturities, capex and distributions cannot be reported. [3]
- **Latest Moody's data**: The latest period in Moody's financials is the 12 months to 30 Jun 2026 (Moody's-adjusted): revenue EUR 16,712m, EBITDA EUR 7,906m, total debt EUR 33,195m, against EUR 15,501m, EUR 7,445m and EUR 31,123m for 2025. [2]
- **Against Moody's forecast**: Moody's forecasts for 2026 are revenue EUR 17.4bn, debt/EBITDA 4.3x and RCF/net debt 14.5%. The LTM to June 2026 shows 4.20x and 13.99%; it is a 12-month figure to mid-year, not the full-year 2026 the forecast covers. [2][4]
- **Moody's comment**: Moody's has published no issuer comment, rating action or credit opinion on Iliad Holding between 1 Oct and 15 Nov 2026. [5]
- **Issuer**: This recap covers the holding company Iliad Holding S.A.S. Moody's rates the operating company Iliad S.A. separately, at Ba1; ask for that recap if it is the issuer you meant. [6]

**Against Moody's triggers**

| Metric (Moody's-adjusted) | Latest, period | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 4.20x, LTM Jun 2026 [2] | below 3.5x [4] | remains well above 4.0x (with significantly weaker FCF) [4] | 0.70x to upgrade level; 0.20x above 4.0x [2][4] |
| RCF / Net Debt | 13.99%, LTM Jun 2026 [2] | towards 25% [4] | none stated [4] | 11.0 pp to upgrade level [2][4] |

Note: Worded downgrade factors: a deterioration in operating performance, or further large debt-financed acquisitions or shareholder distributions (credit opinion, 30 Jun 2026). [4]

**What it means for the rating and outlook**

- **Position**: Ba2 CFR, outlook stable, upgraded on 19 Jun 2026. Debt/EBITDA of 4.20x is 0.70x above the 3.5x upgrade level and 0.20x above the 4.0x reference in the downgrade factor; RCF/net debt of 13.99% is 11.0 pp short of the 25% upgrade level. [1][2][4]
- **Outlook wording**: The outlook expects "steady earnings and cash flow growth, supporting some improvement in credit metrics ahead of the SFR acquisition" and a reduction in leverage after completion. [4]
- **Timing**: The credit opinion is dated 30 Jun 2026, so it predates the LTM June 2026 figures. With no filing, the change in company-reported net debt and its causes is not in Moody's data. [2][4]

**Notes**

- Recap mode as asked. No transcript was looked for on the web.

**Sources**

[1] Moody's ratings (getEntityRatings) · Iliad Holding S.A.S. · 2026-11-15
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (Moody's-adjusted), LTM 30 Jun 2026 and FY2025 · Iliad Holding S.A.S. · 2026-06-30
[3] Moody's (searchCompanyFilings) · Iliad Holding S.A.S. company filings · earnings_call_transcript, interim and annual: not found · 2026-11-15
[4] Moody's (getCreditOpinion) · Iliad Holding S.A.S.: Update following rating upgrade to Ba2 · PBC_1488484, Summary, Factors leading to upgrade and downgrade, Rating outlook, Key … · 2026-06-30
[5] Moody's (searchAllDocuments) · Iliad Holding results · Issuer Comment, Rating Action, Credit Opinion, 1 Oct to 15 Nov 2026: no documents · 2026-11-15
[6] Moody's (findEntity) · Entity search: Iliad Holding · Iliad Holding S.A.S. (FR), alternatives include Iliad S.A., Ba1 · 2026-11-15

Earnings tab updated at 2026-11-15T22:13:50Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html (not published as an Artifact in this run).
