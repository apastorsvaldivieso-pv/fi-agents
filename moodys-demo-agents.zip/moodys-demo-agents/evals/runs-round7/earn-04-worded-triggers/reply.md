**Earnings: BNP Paribas, preview** (Latest data held by Moody's at 15 Nov 2026; 1 names)

BNP Paribas (A1, stable) has one numeric trigger: return on assets of 0.6% and above for an upgrade, against 0.4% at June 2026; every downgrade trigger is worded. Moody's holds no call transcript, and the latest filing (Q3 2025) is older than the Q2 2026 data Moody's holds. [1][2]

**Rating and outlook**

- A1 LT Issuer Rating, outlook stable, affirmed 31 Aug 2026. Credit opinion dated 2 Sep 2026. [1][2]

**What to watch against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room to upgrade |
|---|---|---|---|---|
| Return on assets (Net income / tangible assets) | 0.4%, Jun 2026 [2] | 0.6% and above [2] | no number stated | 0.2 pp below [2] |

Note: Only trigger with a number. Moody's names return on assets; the key indicators row used is Net income / tangible assets. [2]

**Worded triggers (quoted)**

- (Upgrade): "manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management", "limiting any sudden and significant increase in problem loans and risk provisioning". [2]
- (Upgrade): "An upgrade of the Government of France's rating could also result in an upgrade". [2]
- (Downgrade): "lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics"; also "a marked increase in risk appetite, loss incidents or a material risk management failure". [2]
- (Downgrade): "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile". [2]
- (Downgrade): Senior unsecured only: if growth in senior unsecured and lower-ranking debt relative to tangible banking assets "falls short of our current expectations" and is not offset by government support uplift. [2]

**Sector metrics to watch**

| Metric | Latest | Basis | Trigger it bears on |
|---|---|---|---|
| Net interest margin | 0.9%, Jun 2026 [2] | Moody's-adjusted | Upgrade: return on assets |
| Cost of risk | not in Moody's data |  | Upgrade: risk provisioning |
| CET1 ratio | 12.97%, Q2 2026 [3] | As reported | Downgrade: capital buffers |
| Tangible common equity / RWA | 13.7%, Jun 2026 [2] | Moody's-adjusted | Downgrade: capital buffers |
| Leverage ratio (fully loaded) | not in Moody's data |  | Downgrade: regulatory leverage |
| Problem loans / gross loans | 2.9%, Jun 2026 [2] | Moody's-adjusted | Both: asset quality |
| Loan loss reserves / impaired loans | 57.68%, Q2 2026 [3] | As reported | Both: asset quality |
| Cost / income | 60.6%, Jun 2026 [2] | Moody's-adjusted | Downgrade: profitability |
| LCR | 134.77%, Q2 2026 [3] | As reported | Downgrade: funding and liquidity |
| HQLA / tangible banking assets | 15.9%, Jun 2026 [2] | Moody's-adjusted | Downgrade: funding and liquidity |
| Loans / customer deposits | 82.30%, Q2 2026 [3] | As reported | Downgrade: funding and liquidity |

**What the latest filing says (Q3 2025 interim report, period to 30 Sep 2025)**

- Company-reported: 2026 trajectory confirmed, with revenue CAGR above 5% and net income CAGR above 7% for 2024-2026, and jaws of about +1.5 points a year. [4]
- Company-reported: cost of risk "below 40 bps in 2025 and 2026"; RoTE targets of 12% for 2026 and 13% for 2028. [4]
- Company-reported: CET1 12.5% phased-in at 30 Sep 2025 against a 10.51% requirement, with +30bps organic capital generation in 3Q25. [5]
- Company-reported: 2025 net income target above EUR 12.2bn; the FY2025 annual report shows net income attributable to shareholders of EUR 12,225m against EUR 11,688m. [6][7]

**Moody's expectations**

The key indicators table in the 2 Sep 2026 credit opinion has no forecast columns. [2]

**Notes**

- Moody's holds no earnings call transcript for BNP Paribas; the latest results filing was used instead. The Q3 2025 interim report predates the Q2 2026 figures Moody's holds, so its guidance may since have changed.
- As-reported ratios are the bank's own figures via Moody's Bank Focus, not Moody's-adjusted. The date of the next results is not in Moody's data.

**Sources**

[1] Moody's ratings (getEntityRatings) · BNP Paribas · 2026-08-31
[2] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation (Credit Opinion) · PBC_1491623, triggers, outlook, key indicators · 2026-09-02
[3] Moody's financials (getEntityFinancials_v2) · Bank Focus ratios (as reported), Q2 2026 · BNP Paribas · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas Interim Report 2025 - Q3 (period to 30 Sep 2025) · Interim Report Q3 2025, p.9 · 2025-09-30
[5] Moody's (searchCompanyFilings) · BNP Paribas Interim Report 2025 - Q3 (period to 30 Sep 2025) · Interim Report Q3 2025, p.42 · 2025-09-30
[6] Moody's (searchCompanyFilings) · BNP Paribas Interim Report 2025 - Q3 (period to 30 Sep 2025) · Interim Report Q3 2025, p.32 · 2025-09-30
[7] Moody's (searchCompanyFilings) · BNP Paribas Annual Report 2025 (period to 31 Dec 2025) · Annual Report 2025, p.5 · 2025-12-31

Earnings tab updated at 2026-11-15 22:14 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html (not published: test run).
