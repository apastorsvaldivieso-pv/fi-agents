import json
FIN="Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 (period end 30 Jun 2026), one call for the 15 names plus Groupe Credit Agricole"
def W(i,t,d,u): return {"id":i,"kind":"web","title":t,"date":d,"url":u}
def F(i,bank,filing,asof,d): return {"id":i,"kind":"moodys","tool":"searchCompanyFilings","title":bank+" stated CET1 requirement","ref":"bank sector file, pulled 15 Nov 2026: "+filing+", as of "+asof,"date":d}
src=[
 W("s1","Basel Committee: Amendments to G-SIB framework to address window dressing","2026-10-16","https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"),
 W("s2","Basel Committee: Global systemically important banks - methodology review (consultative document)","2026-10-16","https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"),
 W("s3","FSB: 2025 List of Global Systemically Important Banks (G-SIBs)","2025-11-27","https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"),
 {"id":"s4","kind":"moodys","tool":"getEntityFinancials_v2","title":"European banks financials (Bank Focus, consolidated)","ref":FIN,"date":"2026-06-30"},
 {"id":"s5","kind":"moodys","tool":"getEntityFinancials_v2","title":"Groupe Credit Agricole financials (Bank Focus, consolidated)","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026 requested explicitly (LQ returned Q3 2026)","date":"2026-06-30"},
 F("s6","UBS Group AG","Second quarter 2026 report (required going-concern CET1 capital)","30 Jun 2026","2026-06-30"),
 F("s7","Societe Generale","First quarter 2026 results (CET1 requirement, shown against 31 Mar 2026)","31 Mar 2026","2026-03-31"),
 F("s8","Groupe Credit Agricole","First quarter 2026 results slides filed under Credit Agricole S.A. (distance to SREP requirement, phased-in CET1)","31 Mar 2026","2026-03-31"),
 F("s9","BNP Paribas","Third quarter 2025 report (CET1 capital requirement)","30 Sep 2025","2025-09-30"),
 F("s10","Barclays PLC","Annual report on Form 20-F for 2025 (overall capital requirement for CET1, excluding any PRA buffer)","31 Dec 2025","2025-12-31"),
 F("s11","ING Groep N.V.","Annual report on Form 20-F for 2025 (MDA trigger level for CET1)","31 Dec 2025","2025-12-31"),
 W("s12","Basel Committee: Consolidated guidelines - consequential amendments (consultative)","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"),
 W("s13","Basel Committee: Interest rate risk in the banking book - additional Pillar 2 guidance (consultative)","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"),
 W("s14","EBA: Revised Guidelines on internal governance (EBA/GL/2026/10)","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"),
 {"id":"s15","kind":"moodys","tool":"searchAllDocuments","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks (Sector Comment)","ref":"PBC_1502042","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
 W("s16","EBA: Next steps on supervisory reporting simplification; implementation timelines extended","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"),
 W("s17","EBA: 2027 EU-wide stress test streamlined, requested data cut by more than 55%","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"),
 W("s18","European Commission: political agreement on the review of the Securitisation Framework","2026-10-22","https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"),
 W("s19","PRA: CP14/26 Review of the SM&CR - Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"),
 W("s20","PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"),
 W("s21","FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - banks","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"),
 W("s22","FINMA: partially revised FINMA Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"),
]
def c(v,s,tone=None):
    d={"v":v,"src":s}
    if tone: d["tone"]=tone
    return d
def pos(t): return {"tone":t,"v":""}
rows=[
 ["BNP Paribas",c("12.97%",["s4"]),c("-1.04",["s4"]),c("10.51% (30 Sep 2025, older)",["s9"]),c("2.46 pp (older)",["s4","s9"]),pos("weaker")],
 ["ING Groep N.V.",c("13.07%",["s4"]),c("-0.94",["s4"]),c("11.03% MDA trigger (31 Dec 2025, older)",["s11"]),c("2.04 pp (older)",["s4","s11"]),pos("weaker")],
 ["Societe Generale",c("13.2%",["s4"]),c("-0.81",["s4"]),c("10.26% (vs 31 Mar 2026)",["s7"]),c("2.94 pp",["s4","s7"]),pos("middle")],
 ["Deutsche Bank AG",c("13.92%",["s4"]),c("-0.09",["s4"]),"not stated","not stated",pos("middle")],
 ["HSBC Holdings plc",c("14.1%",["s4"]),c("+0.09",["s4"]),"not stated","not stated",pos("middle")],
 ["Barclays PLC",c("14.3%",["s4"]),c("+0.29",["s4"]),c("12.2% (31 Dec 2025, older)",["s10"]),c("2.10 pp (older)",["s4","s10"]),pos("middle")],
 ["UBS Group AG",c("14.38%",["s4"]),c("+0.37",["s4"]),c("10.83% going-concern (30 Jun 2026)",["s6"]),c("3.55 pp",["s4","s6"]),pos("stronger")],
 ["Groupe Credit Agricole",c("17.23%",["s5"]),c("+3.22",["s5","s4"]),c("total not stated",["s8"]),c("6.7 pp, bank-stated, 31 Mar 2026",["s8"]),pos("stronger")],
]
EU="EU/EEA 11"
watch=[
 ["FINMA: AMLO-FINMA revised (final, 10 Nov)","UBS Group AG","AML: no Moody's field",c("watch",["s22"],"watch")],
 ["PRA: PS20/26 large exposures (final, 10 Nov)","HSBC, Barclays, Lloyds","Large exposures: no Moody's field",c("watch",["s20"],"watch")],
 ["Basel: IRRBB Pillar 2 guidance (consultation, 9 Nov)","All 15, once home rules apply","IRRBB: no Moody's field",c("watch",["s13"],"watch")],
 ["EBA: 2027 stress test methodology (9 Nov)","Banks in the EBA sample; sample not named, so scope not known for the "+EU,"Stress testing: no Moody's field",c("watch",["s17"],"watch")],
 ["EBA: supervisory reporting timelines (6 Nov)",EU,"Reporting: no Moody's field",c("watch",["s16"],"watch")],
 ["EBA: internal governance guidelines (final, 5 Nov)",EU,"Governance: no Moody's field",c("watch",["s14"],"watch")],
 ["Basel: consolidated guidelines amendments (consultation, 5 Nov)","All 15, once home rules apply","None: cross-references only",c("watch",["s12"],"watch")],
 ["FINMA: Circular 2019/2 interest rate risks (consultation, 4 Nov)","UBS Group AG","IRRBB: no Moody's field",c("watch",["s21"],"watch")],
 ["PRA: CP14/26 SM&CR Phase 2 (consultation, 22 Oct)","HSBC, Barclays, Lloyds","Governance: no Moody's field",c("watch",["s19"],"watch")],
 ["EU: securitisation framework review (political agreement, 22 Oct)",EU,"Securitisation: no Moody's field",c("watch",["s18"],"watch")],
]
def it(tag,name,text,why,s): return {"flag":"NEW","tag":tag,"name":name,"text":text,"why":why,"src":s}
items=[
 it("Final","FINMA","Partially revised AMLO-FINMA published 10 Nov, aligning with the amended Anti-Money Laundering Act ahead of the FATF evaluation; correspondent-banking rules clarified. In force 1 Jan 2027.","AML channel, UBS only; no Moody's metric.",["s22"]),
 it("Final","PRA","PS20/26 (10 Nov) makes substitution mandatory for exposures reduced by credit risk mitigation, removes internal models for SFT exposure values and caps trading-book excess allowances. Takes effect 1 Jan 2028.","Large exposures channel for the three UK banks; no Moody's metric.",["s20"]),
 it("Consultation","Basel Committee","Additional Pillar 2 guidance on interest rate risk in the banking book (9 Nov): expectations on models, stress testing, controls and earnings indicators. Comments by 9 Feb 2027.","IRRBB channel; earnings sensitivity to rates is not a Moody's field.",["s13"]),
 it("Other","EBA","2027 EU-wide stress test methodology final (9 Nov), with requested data cut by more than 55% and a first separate climate module. Launch end-Jan 2027, results end-Jul 2027.","Stress-test channel; the page does not name the bank sample.",["s17"]),
 it("Other","EBA","Next steps on supervisory reporting (6 Nov): first reference date moves to Dec 2027, and liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final ITS report due Dec 2026.","Reporting channel; no direct effect on capital or liquidity metrics.",["s16"]),
 it("Final","EBA","Revised internal governance guidelines (EBA/GL/2026/10, 5 Nov) under CRD, more proportionate than the consultation draft. Application date not stated on the page.","Moody's (Sector Comment, 11 Nov): credit positive for EU banks, with a greater effect on smaller banks.",["s14","s15"]),
 it("Consultation","Basel Committee","Consequential amendments to point the Basel Framework to the new consolidated guidelines (5 Nov). Comments by 21 Dec 2026.","Mapped to watch by judgment: the channel map has no row for framework cross-references.",["s12"]),
 it("Consultation","FINMA","Partial revision of Circular 2019/2 on interest rate risks for banks (4 Nov), adopting the Basel Committee's recalibrated shocks. Comments by 15 Jan 2027.","IRRBB channel, UBS only; no Moody's metric.",["s21"]),
 it("Consultation","PRA","CP14/26 (22 Oct) would remove pre-approval for almost half of Senior Manager Functions and drop Certification Regime assessments. Comments by 22 Jan 2027.","Governance channel for the three UK banks; no Moody's metric.",["s19"]),
 it("Other","European Commission","Provisional political agreement (21 Oct, announced 22 Oct) on the securitisation framework review, including more risk-sensitive CRR treatment of securitisations. Needs formal approval by Parliament and Council.","Securitisation channel, EU banks; not yet law.",["s18"]),
 it("Final","Basel Committee","G-SIB indicators to be reported as averages over the year, not year-end values, by 1 Jan 2030; reporting threshold raised to EUR 350bn from 1 Jan 2027.","Changes how G-SIB scores, and so the G-SIB buffer, are measured: capital channel, CET1.",["s1"]),
 it("Consultation","Basel Committee","G-SIB methodology review consults on adding the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 Jan 2027.","Capital channel, CET1, via the G-SIB score.",["s2"]),
]
run={
 "schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"2026-11-15T22:10:05Z",
 "scope":{"label":"Banks Europe, 30 days","sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15},
 "status":"ok",
 "headline":"The Basel Committee finalised averaging of G-SIB indicators (by 1 Jan 2030) and opened a G-SIB methodology consultation on 16 Oct; of the eight G-SIBs on the list, BNP Paribas (12.97%) and ING (13.07%) are in the weaker third on CET1 at Q2 2026.",
 "headline_src":["s1","s2","s4"],
 "sections":[
  {"title":"Who it hits: G-SIB window-dressing standard and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
   "columns":["Name","CET1 (as reported, Q2 2026)","vs median of ranked names (pp)","Stated requirement (date)","Distance to requirement","Position"],
   "rows":rows,
   "note":"Covers G-SIBs on the FSB list of 27 Nov 2025 (no 2026 list found); the wider Basel sample reports the indicators, but the buffer falls on listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: only three names have a current stated requirement. Listed issuer Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026).",
   "note_src":["s3","s4","s8"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch,
   "note":"EU/EEA 11: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Moody's data carries no metric for these channels.","note_src":[]},
 ],
 "sources":src,
 "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Left out (35 entries checked, 23 left out): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (Basel AML/CFT newsletter, PRA Regulatory Digest); sanctions notices (FINMA, Commission); periodic lists and statistics (ECB supervised entities, Commission sustainable-investment data); addressed to other firms (PRA credit-union CP15/26 and DP2/26, Commission assurance-standards consultation, FINMA Bitcoin ETF); EBA advice to the Commission on Taxonomy disclosures; EBA moved consultation deadlines, consumer factsheet, Vice-Chair appointment and NGFS statement; ECB report to the Eurogroup; Commission and SRB items on the competitiveness dialogue, tokenisation nominations and a one-year equity-investment update.",
  "Gaps: the Commission listing read showed nothing after 12 Nov; the ECB press feed held only speeches and interviews in the window. Basel standards apply only once each home country adopts them. Moody's research search found a comment only on the EBA governance guidelines, none on the G-SIB, securitisation, IRRBB or stress-test items.",
 ],
 "meta":{"calls":{"moodys":6,"web":26}}
}
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
