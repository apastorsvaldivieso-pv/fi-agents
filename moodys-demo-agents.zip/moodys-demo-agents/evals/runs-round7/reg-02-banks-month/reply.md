**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

The Basel Committee finalised averaging of G-SIB indicators (by 1 Jan 2030) and opened a G-SIB methodology consultation on 16 Oct; of the eight G-SIBs on the list, BNP Paribas (12.97%) and ING (13.07%) are in the weaker third on CET1 at Q2 2026. [1][2][3]

**Who it hits: G-SIB window-dressing standard and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (as reported, Q2 2026) | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -1.04 [3] | 10.51% (30 Sep 2025, older) [4] | 2.46 pp (older) [3][4] | Weaker third |
| ING Groep N.V. | 13.07% [3] | -0.94 [3] | 11.03% MDA trigger (31 Dec 2025, older) [5] | 2.04 pp (older) [3][5] | Weaker third |
| Societe Generale | 13.2% [3] | -0.81 [3] | 10.26% (vs 31 Mar 2026) [6] | 2.94 pp [3][6] | Middle |
| Deutsche Bank AG | 13.92% [3] | -0.09 [3] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [3] | +0.09 [3] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [3] | +0.29 [3] | 12.2% (31 Dec 2025, older) [7] | 2.10 pp (older) [3][7] | Middle |
| UBS Group AG | 14.38% [3] | +0.37 [3] | 10.83% going-concern (30 Jun 2026) [8] | 3.55 pp [3][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [9] | +3.22 [3][9] | total not stated [10] | 6.7 pp, bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers G-SIBs on the FSB list of 27 Nov 2025 (no 2026 list found); the wider Basel sample reports the indicators, but the buffer falls on listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: only three names have a current stated requirement. Listed issuer Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026). [3][10][11]

**What changed**

- [NEW] **FINMA** (Final): Partially revised AMLO-FINMA published 10 Nov, aligning with the amended Anti-Money Laundering Act ahead of the FATF evaluation; correspondent-banking rules clarified. In force 1 Jan 2027. *Why it matters:* AML channel, UBS only; no Moody's metric. [12]
- [NEW] **PRA** (Final): PS20/26 (10 Nov) makes substitution mandatory for exposures reduced by credit risk mitigation, removes internal models for SFT exposure values and caps trading-book excess allowances. Takes effect 1 Jan 2028. *Why it matters:* Large exposures channel for the three UK banks; no Moody's metric. [13]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book (9 Nov): expectations on models, stress testing, controls and earnings indicators. Comments by 9 Feb 2027. *Why it matters:* IRRBB channel; earnings sensitivity to rates is not a Moody's field. [14]
- [NEW] **EBA** (Other): 2027 EU-wide stress test methodology final (9 Nov), with requested data cut by more than 55% and a first separate climate module. Launch end-Jan 2027, results end-Jul 2027. *Why it matters:* Stress-test channel; the page does not name the bank sample. [15]
- [NEW] **EBA** (Other): Next steps on supervisory reporting (6 Nov): first reference date moves to Dec 2027, and liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final ITS report due Dec 2026. *Why it matters:* Reporting channel; no direct effect on capital or liquidity metrics. [16]
- [NEW] **EBA** (Final): Revised internal governance guidelines (EBA/GL/2026/10, 5 Nov) under CRD, more proportionate than the consultation draft. Application date not stated on the page. *Why it matters:* Moody's (Sector Comment, 11 Nov): credit positive for EU banks, with a greater effect on smaller banks. [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments to point the Basel Framework to the new consolidated guidelines (5 Nov). Comments by 21 Dec 2026. *Why it matters:* Mapped to watch by judgment: the channel map has no row for framework cross-references. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on interest rate risks for banks (4 Nov), adopting the Basel Committee's recalibrated shocks. Comments by 15 Jan 2027. *Why it matters:* IRRBB channel, UBS only; no Moody's metric. [20]
- [NEW] **PRA** (Consultation): CP14/26 (22 Oct) would remove pre-approval for almost half of Senior Manager Functions and drop Certification Regime assessments. Comments by 22 Jan 2027. *Why it matters:* Governance channel for the three UK banks; no Moody's metric. [21]
- [NEW] **European Commission** (Other): Provisional political agreement (21 Oct, announced 22 Oct) on the securitisation framework review, including more risk-sensitive CRR treatment of securitisations. Needs formal approval by Parliament and Council. *Why it matters:* Securitisation channel, EU banks; not yet law. [22]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported as averages over the year, not year-end values, by 1 Jan 2030; reporting threshold raised to EUR 350bn from 1 Jan 2027. *Why it matters:* Changes how G-SIB scores, and so the G-SIB buffer, are measured: capital channel, CET1. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review consults on adding the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 Jan 2027. *Why it matters:* Capital channel, CET1, via the G-SIB score. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| FINMA: AMLO-FINMA revised (final, 10 Nov) | UBS Group AG | AML: no Moody's field | Watch [12] |
| PRA: PS20/26 large exposures (final, 10 Nov) | HSBC, Barclays, Lloyds | Large exposures: no Moody's field | Watch [13] |
| Basel: IRRBB Pillar 2 guidance (consultation, 9 Nov) | All 15, once home rules apply | IRRBB: no Moody's field | Watch [14] |
| EBA: 2027 stress test methodology (9 Nov) | Banks in the EBA sample; sample not named, so scope not known for the EU/EEA 11 | Stress testing: no Moody's field | Watch [15] |
| EBA: supervisory reporting timelines (6 Nov) | EU/EEA 11 | Reporting: no Moody's field | Watch [16] |
| EBA: internal governance guidelines (final, 5 Nov) | EU/EEA 11 | Governance: no Moody's field | Watch [17] |
| Basel: consolidated guidelines amendments (consultation, 5 Nov) | All 15, once home rules apply | None: cross-references only | Watch [19] |
| FINMA: Circular 2019/2 interest rate risks (consultation, 4 Nov) | UBS Group AG | IRRBB: no Moody's field | Watch [20] |
| PRA: CP14/26 SM&CR Phase 2 (consultation, 22 Oct) | HSBC, Barclays, Lloyds | Governance: no Moody's field | Watch [21] |
| EU: securitisation framework review (political agreement, 22 Oct) | EU/EEA 11 | Securitisation: no Moody's field | Watch [22] |

Note: EU/EEA 11: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Moody's data carries no metric for these channels.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (23 of 35 entries): speeches, blogs, newsletters; sanctions notices; periodic lists, statistics; items for other firms (credit unions, assurance providers, a fund); EBA advice to the Commission; a moved deadline; an appointment; consumer material; dialogue news.
- Gaps: Commission listing showed nothing after 12 Nov; no 2026 FSB G-SIB list found. Moody's commented only on the EBA governance guidelines.

**Sources**

[1] Web · Basel Committee: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · Basel Committee: Global systemically important banks - methodology review … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 (period end 30 Jun 2026), … · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Third quarter 2025 report (CET1 capital … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING Groep N.V. stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025 (MDA trigger … · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results (CET1 requirement, shown … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays PLC stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025 (overall … · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS Group AG stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Second quarter 2026 report (required going-concern … · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 requested explicitly (LQ … · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides filed under … · 2026-03-31
[11] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · FINMA: partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[14] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA: 2027 EU-wide stress test streamlined, requested data cut by more than 55% · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA: Next steps on supervisory reporting simplification; implementation … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA: Revised Guidelines on internal governance (EBA/GL/2026/10) · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · Basel Committee: Consolidated guidelines - consequential amendments … · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA: consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA: CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[22] Web · European Commission: political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 15 Nov 2026 22:10 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html. Not published to the private link in this run.
