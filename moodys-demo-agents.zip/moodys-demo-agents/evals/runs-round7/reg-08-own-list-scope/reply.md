Coverage (your list, saved as banks-europe-own): HSBC Holdings plc (GB), BNP Paribas (FR), Deutsche Bank AG (DE), UBS Group AG (CH), Barclays PLC (GB), ING Groep N.V. (NL), Societe Generale (FR), Credit Agricole S.A. (FR), Danske Bank A/S (DK), KBC Group N.V. (BE), Banco de Sabadell, S.A. (ES), Swedbank AB (SE). Unresolved: none.

**Regulatory watch: Own list, 12 banks, 30 days** (30 days, 16 Oct to 15 Nov 2026; 12 names)

Eleven new regulatory items in 30 days; the Basel Committee's G-SIB changes are the only ones with a capital channel, and among your eight G-SIBs BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios (Q2 2026). [1][2][3]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, as reported (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -1.04 [3] | 10.51% (30 Sep 2025, older) [4] | +2.46 pp [3][4] | Weaker third |
| ING Groep N.V. | 13.07% [3] | -0.94 [3] | 11.03% (MDA trigger, 31 Dec 2025, older) [5] | +2.04 pp [3][5] | Weaker third |
| Societe Generale | 13.20% [3] | -0.81 [3] | 10.26% (CET1 requirement, vs 31 Mar 2026) [6] | +2.94 pp [3][6] | Middle |
| Deutsche Bank AG | 13.92% [3] | -0.09 [3] | not stated | n/a | Middle |
| HSBC Holdings plc | 14.10% [3] | +0.09 [3] | not stated | n/a | Middle |
| Barclays PLC | 14.30% [3] | +0.29 [3] | 12.2% (31 Dec 2025, older) [7] | +2.10 pp [3][7] | Middle |
| UBS Group AG | 14.38% [3] | +0.37 [3] | 10.83% (going-concern CET1, 30 Jun 2026) [8] | +3.55 pp [3][8] | Stronger third |
| Groupe Credit Agricole (for Credit Agricole S.A.) | 17.23% [9] | +3.22 [9] | total not stated [10] | +6.7 pp (bank-stated, 31 Mar 2026) [9][10] | Stronger third |

Note: Banks in the G-SIB assessment sample report the indicators; the buffer falls on FSB-listed G-SIBs only. Out of scope: Danske Bank, KBC Group, Banco Sabadell, Swedbank (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three of eight have a current stated requirement. Credit Agricole S.A. own figures: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [3][10][11]

**Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, as reported (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | not ranked | 10.51% (30 Sep 2025, older) [4] | +2.46 pp [3][4] | list too short to rank |
| ING Groep N.V. | 13.07% [3] | not ranked | 11.03% (MDA trigger, 31 Dec 2025, older) [5] | +2.04 pp [3][5] | list too short to rank |
| Societe Generale | 13.20% [3] | not ranked | 10.26% (CET1 requirement, vs 31 Mar 2026) [6] | +2.94 pp [3][6] | list too short to rank |
| Deutsche Bank AG | 13.92% [3] | not ranked | not stated | n/a | list too short to rank |
| Groupe Credit Agricole (for Credit Agricole S.A.) | 17.23% [9] | not ranked | total not stated [10] | +6.7 pp (bank-stated, 31 Mar 2026) [9][10] | list too short to rank |

Note: Covers G-SIBs with cross-border exposures inside the European Banking Union, so the banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (outside the banking union); KBC Group, Banco Sabadell (banking union, but not on the FSB G-SIB list of 27 Nov 2025); Danske Bank, Swedbank (neither). [11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes, including mandatory substitution for credit risk mitigation and removal of internal models for securities financing exposures. Applies to PRA-authorised banks from 1 Jan 2028. [12]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance, in force 1 Jan 2027 with a four-month transition; clarifies the correspondent banking rule. [13]
- [NEW] **Basel Committee** (Consultation): Proposes extra Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, earnings indicators) and new supervisory reporting. Comments by 9 Feb 2027. [14]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test: 55% fewer data points and a first, separate climate module. Launch end-January 2027, results end-July 2027. [15]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: final draft ITS due December 2026; first reference date December 2027, with liquidity, encumbrance, benchmarking and ESG reporting deferred to December 2028. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance aligned with CRD VI, with lighter duty mapping and more proportionate rules for third-country branches. Application date not stated; awaiting translation. *Why it matters:* Moody's calls the revisions credit positive for small EU banks; larger banks already largely apply them (Sector Comment, 11 Nov 2026). [17][18]
- [NEW] **Basel Committee** (Consultation): Consults on consequential amendments moving cross-references and application guidance into the consolidated guidelines. Comments by 21 Dec 2026. Mapped to no channel by our judgment. [19]
- [NEW] **FINMA** (Consultation): Consults on revising Circular 2019/2 'Interest rate risks - banks' to adopt the Basel Committee's 2024 shock recalibration and weigh earnings effects more. Comments by 15 Jan 2027. [20]
- [NEW] **PRA** (Consultation): CP14/26 proposes moving most Senior Manager Functions from pre-approval to notification and removing Certification Regime certificates. Comments by 22 Jan 2027; implementation expected H2 2027. [21]
- [NEW] **Basel Committee** (Final): Final G-SIB amendments against window dressing: score indicators reported and disclosed as yearly averages by 1 Jan 2030; the leverage exposure reporting threshold rises from EUR 200bn to EUR 350bn from 1 Jan 2027. *Why it matters:* Averaging can change G-SIB scores and so the G-SIB buffer in the CET1 requirement. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: consults on adding the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB assessment. Comments by 14 Jan 2027. *Why it matters:* Could lower banking-union G-SIBs' scores and buffers; a consultation, not a final rule. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 Large Exposures Part 2 (10 Nov) [12] | HSBC, Barclays | large exposures: no Moody's field | Watch |
| FINMA revised AML Ordinance (10 Nov) [13] | UBS | AML: no Moody's field | Watch |
| BCBS IRRBB Pillar 2 guidance, consultation (9 Nov) [14] | All 12, once home rules apply it | IRRBB: no Moody's field | Watch |
| EBA 2027 EU-wide stress test methodology (9 Nov) [15] | Scope not known: sample not named; candidates are the nine EU/EEA names | stress testing: no Moody's field | Watch |
| EBA reporting simplification, new timelines (6 Nov) [16] | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, Danske Bank, KBC, Banco Sabadell, Swedbank | reporting: no Moody's field | Watch |
| EBA revised internal governance Guidelines (5 Nov) [17] | BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, Danske Bank, KBC, Banco Sabadell, Swedbank | governance: no Moody's field | Watch |
| BCBS consolidated guidelines amendments, consultation (5 Nov) [19] | All 12, once home rules apply it | none (our mapping: cross-references only) | Watch |
| FINMA Circular 2019/2 interest rate risks, consultation (4 Nov) [20] | UBS | IRRBB: no Moody's field | Watch |
| PRA CP14/26 SM&CR Phase 2, consultation (22 Oct) [21] | HSBC, Barclays | governance, conduct: no Moody's field | Watch |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (20): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters; sanctions notices; measures for credit unions, auditors and funds; EBA consumer, appointment, deadline and advisory items; periodic lists.
- The FSB's 2026 G-SIB list was not out by 15 Nov 2026, so the 2025 list is used. Moody's research in the window commented only on the EBA governance item.
- Danske Bank, KBC Group, Banco Sabadell and Swedbank were resolved for this run; no stated CET1 requirement is on file for them.

**Sources**

[1] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · BCBS: Global systemically important banks - methodology review (consultation) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all 12 names and Credit … · Bank financials, latest quarter · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING MDA trigger level · bank sector file, pulled 15 Nov 2026: ING Groep Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays PLC Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Group AG Second quarter 2026 report, as of 30 … · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026, Groupe Credit Agricole … · Groupe Credit Agricole · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole First quarter 2026 results slides, … · 2026-03-31
[11] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[19] Web · BCBS: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated at 2026-11-15 22:17 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html (not published as an Artifact in this test run).
