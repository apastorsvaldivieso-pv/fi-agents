**Earnings: BNP Paribas, recap** (Q3 2026 results (reported 28 Oct 2026); 1 names)

BNP Paribas (A1 stable) reported Q3 2026 net income of EUR 3.5 billion, up 13.5%, per Moody's comment; Moody's holds no call transcript, and the latest results filings it holds (Q3 2025, FY2025) are older than these results. [1][2][3][4]

**Results against the credit view**

- **Q3 2026**: Net income EUR 3.5 billion, up 13.5% year on year; annualised return on assets 43 bp and RoTE 13.0% (Moody's calculations, excluding exceptional items). Moody's says cost of risk stayed moderate and on target, with sizable pre-funding for 2027. [2]
- **Guidance**: No beat or miss can be stated: there is no call transcript in Moody's, and the filings it holds predate the guidance for these results. The opinion's key indicators table has no Moody's forecast columns. [5]
- **Capital**: CET1 ratio 12.97% at Q2 2026 (as reported). The latest requirement in the filings is older: CET1 requirement 10.51% at 30 Sep 2025, company-reported, against a CET1 ratio of 12.50% then. [3][6]
- **Liquidity**: LCR 134.77% and NSFR 108.63% at Q2 2026 (as reported), against a 100% minimum stated in the Q3 2025 report. Moody's HQLA / tangible banking assets 15.9% at Jun 2026, from 18.2% at Dec 2025. [3][5][6]
- **Distributions**: FY2025 annual report (company-reported): 2025 net income EUR 12,225 million; interim dividend payments EUR 2,891 million. No 2026 distribution or buyback figures in the filings returned. [4]
- **Funding**: Issuance, maturities and funding plans: not in the filings Moody's returned. Moody's comment notes sizable pre-funding for 2027 (no amount quoted here). [2]

**Against Moody's triggers**

| Metric | Latest value, period | Upgrade trigger | Downgrade trigger | Room to upgrade |
|---|---|---|---|---|
| Net income / tangible assets (Moody's key indicator) | 0.4%, H1 2026 (06-26) [5] | 0.6% and above [5] | worded | 0.2 pp below [5] |
| Return on assets, Q3 2026 annualised (Moody's calculation) | 43 bp, Q3 2026 [2] | 0.6% and above [5] | worded | 17 bp below [2][5] |

Note: Worded triggers (opinion, 2 Sep 2026): upgrade with lower financial leverage and disciplined risk management; downgrade on lower regulatory capital buffers or higher regulatory leverage together with sustained deterioration in asset quality or profitability, or a material risk failure. [5]

**What it means for the rating and outlook**

- **Position**: A1 LT Issuer Rating, outlook stable, affirmed 31 Aug 2026. The credit opinion of 2 Sep 2026 predates the Q3 2026 results; on its H1 2026 figures, return on assets of 0.4% sits 0.2 pp below the 0.6% upgrade level, and problem loans / gross loans are 2.9%. [1][5]
- **Capital change**: CET1 moved from 12.50% at 30 Sep 2025 (company-reported) to 12.97% at Q2 2026 (as reported); no filing Moody's holds gives the cause for the later period. The opinion cites "moderately improved levels of regulatory capitalisation". [3][5][6]
- **Moody's comment**: Moody's issuer comment of 28 Oct 2026 says the Q3 results "underscore position of strength amid worsening domestic operating conditions". [2]

**Notes**

- Recap mode, as asked. Moody's holds no earnings call transcript for BNP Paribas; no web search was made for one.
- The latest results filings Moody's returned cover Q3 2025 and FY2025; the Q3 2026 results are taken from Moody's own issuer comment, and capital and liquidity from Moody's financials at Q2 2026.
- Company-reported CET1 and Moody's tangible common equity / RWA are different measures; this recap does not compare them.

**Sources**

[1] Moody's ratings (getEntityRatings) · 2026-08-31
[2] Moody's (searchAllDocuments) · BNP Paribas: Q3 results underscore position of strength amid worsening domestic … · PBC_1499674, Issuer Comment · 2026-10-28
[3] Moody's (searchCompanyFilings) · BNP Paribas Interim Report 2025 - Q3 · BNP Paribas Interim Report 2025 - Q3 (Third amendment to the 2024 Universal registration … · 2025-09-30
[4] Moody's (searchCompanyFilings) · BNP Paribas Annual Report 2025 · BNP Paribas Annual Report 2025 (2025 Universal registration document), period ended 31 … · 2025-12-31
[5] Moody's (getCreditOpinion) · BNP Paribas: Update following ratings affirmation · PBC_1491623, sections Summary, upgrade and downgrade factors, Outlook, Key indicators · 2026-09-02
[6] Moody's financials (getEntityFinancials_v2) · CET1 ratio, LCR, NSFR (as reported), LQ = Q2 2026 · 2026-06-30

Earnings tab updated at 2026-11-15T22:15:33Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-07-old-filing/dashboard/dashboard.html (not published as an Artifact in this run).
