**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

12 new regulatory items in 16 Oct-15 Nov 2026; the Basel Committee's final G-SIB window-dressing standard covers 8 names, with BNP Paribas (12.97%) and ING (13.07%) lowest on CET1 among them. [1][2]

**Who it hits: G-SIB window-dressing standard (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported) | vs median (pp) | Stated CET1 requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% (Q2 2026) [1] | -1.04 [1] | 10.51% (30 Sep 2025, older) [3] | 2.46 pp (older) [1][3] | Weaker third |
| ING Groep N.V. | 13.07% (Q2 2026) [1] | -0.94 [1] | 11.03% MDA trigger (31 Dec 2025, older) [4] | 2.04 pp (older) [1][4] | Weaker third |
| Societe Generale | 13.20% (Q2 2026) [1] | -0.81 [1] | 10.26% (31 Mar 2026) [5] | 2.94 pp [1][5] | Middle |
| Deutsche Bank AG | 13.92% (Q2 2026) [1] | -0.09 [1] | not stated [6] | not stated | Middle |
| HSBC Holdings plc | 14.10% (Q2 2026) [1] | +0.09 [1] | not stated [6] | not stated | Middle |
| Barclays PLC | 14.30% (Q2 2026) [1] | +0.29 [1] | 12.2% (31 Dec 2025, older) [7] | 2.10 pp (older) [1][7] | Middle |
| UBS Group AG | 14.38% (Q2 2026) [1] | +0.37 [1] | 10.83% going-concern (30 Jun 2026) [8] | 3.55 pp [1][8] | Stronger third |
| Groupe Credit Agricole | 17.23% (Q2 2026) [9] | +3.22 [1][9] | total not stated [10] | 6.7 pp phased-in (bank-stated, 31 Mar 2026) [10] | Stronger third |

Note: Ranked by CET1 level: only 3 of 8 have a current stated requirement. Covers G-SIBs (FSB list of 27 Nov 2025; 2026 list not yet out); banks in the BCBS assessment sample report under the averaging rule. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Issuer on list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [1][10][11][12]

**Who it hits: G-SIB methodology review, banking union (BCBS consultation, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported) | vs median (pp) | Stated CET1 requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% (Q2 2026) [1] | not ranked | 10.51% (30 Sep 2025, older) [3] | 2.46 pp (older) [1][3] | list too short to rank |
| ING Groep N.V. | 13.07% (Q2 2026) [1] | not ranked | 11.03% MDA trigger (31 Dec 2025, older) [4] | 2.04 pp (older) [1][4] | list too short to rank |
| Societe Generale | 13.20% (Q2 2026) [1] | not ranked | 10.26% (31 Mar 2026) [5] | 2.94 pp [1][5] | list too short to rank |
| Deutsche Bank AG | 13.92% (Q2 2026) [1] | not ranked | not stated [6] | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% (Q2 2026) [9] | not ranked | total not stated [10] | 6.7 pp phased-in (bank-stated, 31 Mar 2026) [10] | list too short to rank |

Note: The consultation asks whether to apply the agreed treatment of cross-border exposures within the European Banking Union in the G-SIB methodology, so it covers banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. Credit Agricole S.A.: CET1 11.3% (Q2 2026). [1][11][13]

**What changed**

- [NEW] **PRA** (Final): PS20/26 makes the substitution approach mandatory for credit risk mitigation, ends internal models for SFT exposures and caps trading-book and intragroup allowances at 85% of Tier 1. Applies from 1 Jan 2028. *Why it matters:* Large exposures channel: no Moody's metric. [14]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance, aligned with AMLA changes and clarifying correspondent banking rules. In force 1 Jan 2027. [15]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book, with stronger supervisory expectations and new supervisory reporting. Comments by 9 Feb 2027. *Why it matters:* IRRBB channel: no Moody's metric. [16]
- [NEW] **EBA** (Final): 2027 EU-wide stress test methodology cuts requested data by more than 55% and adds a separate climate module outside the core results. Launch end Jan 2027, results end Jul 2027. [17]
- [NEW] **EBA** (Next steps): Supervisory reporting simplification: first reference date moves to Dec 2027, and liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final report due Dec 2026. [18]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance reflect CRD VI, with a more proportionate approach; application date not stated. Moody's (11 Nov 2026): credit positive for EU banks, more so for small banks. [19][20]
- [NEW] **Basel Committee** (Consultation): Technical amendments pointing Basel Framework cross-references to the new consolidated guidelines. Comments by 21 Dec 2026. Channel mapped by judgment: none. [21]
- [NEW] **FINMA** (Consultation): Revised Circular 2019/2 updates interest rate shock scenarios to the Basel Committee's July 2024 recalibration and weights revenue effects more. Comments by 15 Jan 2027. *Why it matters:* IRRBB channel: no Moody's metric. [22]
- [NEW] **PRA** (Consultation): CP14/26 would move most Senior Manager Functions to notification and remove Certification Regime requirements. Comments by 22 Jan 2027; implementation expected H2 2027. [23]
- [NEW] **European Commission** (Legislative step): Political agreement on the securitisation review: more risk-sensitive CRR capital treatment and lighter due diligence and transparency rules. Needs formal adoption; in force on publication. *Why it matters:* Securitisation channel: no Moody's metric. [24]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 Jan 2027. *Why it matters:* G-SIB buffer sits on the CET1 channel. [12][13]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported and disclosed as year averages, not year-end values, by 1 Jan 2030; reporting threshold rises to EUR 350bn leverage exposure from 2027. *Why it matters:* Changes how G-SIB scores, and so buffers, are measured: CET1 channel. [2][12]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| BCBS IRRBB Pillar 2 guidance (consultation) [16] | All 15, once home countries apply it | IRRBB measure (no Moody's field) | Watch |
| BCBS consolidated guidelines amendments (consultation) [21] | All 15, once home countries apply it | none (technical cross-references) | Watch |
| EBA internal governance guidelines (final) [19] | 11 EU/EEA groups: BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | governance (no field) | Watch |
| EBA supervisory reporting next steps [18] | 11 EU/EEA groups: BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | reporting (no field) | Watch |
| EBA 2027 stress test methodology [17] | EU banks in the EBA sample (sample not stated on page): scope not known | stress testing (no field) | Watch |
| EU securitisation framework agreement [24] | 11 EU/EEA groups: BNP, Credit Agricole, SocGen, Deutsche, ING, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea | securitisation (no field) | Watch |
| PRA SM&CR Phase 2 (consultation) [23] | HSBC, Barclays, Lloyds | governance (no field) | Watch |
| PRA large exposures PS20/26 (final) [14] | HSBC, Barclays, Lloyds | large exposures (no field) | Watch |
| FINMA AML Ordinance (final) [15] | UBS | AML (no field) | Watch |
| FINMA Circular 2019/2 interest rate risks (consultation) [22] | UBS | IRRBB measure (no Moody's field) | Watch |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (21 entries): speeches, interviews, blog and event news (ECB 9, SRB 4, FINMA 1); sanctions notices (FINMA 8 as one, EC 3 as one); newsletters (BCBS, PRA); credit-union papers (PRA 2); consumer, statement, appointment, deadline-move and Taxonomy advice entries (EBA 5); statistics, nominations, dialogue summary, assurance consultation (EC 4); ECB supervised-entities list and Eurogroup overview.
- Moody's has no comment yet on the other items. Basel minimums are not used here; CET1 requirements are each bank's own stated figure, never summed from parts.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026, all coverage-list names · 2026-06-30
[2] Web · BCBS, Amendments to G-SIB framework to address window dressing (and media … · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger for CET1 · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[6] Moody's (searchCompanyFilings) · CET1 requirement not stated · bank sector file, pulled 15 Nov 2026: no total stated in HSBC and Deutsche Bank Form 20-F … · 2025-12-31
[7] Moody's (searchCompanyFilings) · Barclays overall CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS required going-concern CET1 · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 … · Groupe Credit Agricole · 2026-06-30
[10] Moody's (searchCompanyFilings) · Credit Agricole stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole Q1 2026 results slides, as of 31 … · 2026-03-31
[11] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · BCBS media release: finalises window-dressing measures, consults on G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[13] Web · BCBS, Global systemically important banks - methodology review (consultative) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[14] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[16] Web · BCBS, Interest rate risk in the banking book - additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[18] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[19] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[20] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[21] Web · BCBS, Consolidated guidelines - consequential amendments (consultative) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[22] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[23] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[24] Web · Commission welcomes political agreement on the review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated at 2026-11-15T22:18:13Z (UTC): /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r3/dashboard/dashboard.html
