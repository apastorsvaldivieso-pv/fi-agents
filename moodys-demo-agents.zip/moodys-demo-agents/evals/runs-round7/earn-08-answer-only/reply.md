**Vodafone Group Plc, recap: H1 FY27 results (call 10 Nov 2026)**

I ran this as a recap because Moody's holds the half-year call from 10 Nov 2026, which is within the last 21 days.

**Headline:** Vodafone raised its FY27 guidance. Company-reported net debt rose by €8.1bn to €33.5bn [5] after the VodafoneThree buyout and the Safaricom deal. Moody's-adjusted debt/EBITDA was 3.25x at March 2026 [3], against a downgrade trigger of 3.3x [2]. The credit opinion of 21 Oct 2026 [2] was published before these results.

**Rating:** Baa2 (Senior Unsecured, foreign currency), outlook stable, affirmed 13 Oct 2026 [1].

## Results against the credit view

- **Guidance raised.** Management upgraded the FY27 group guidance. The new midpoints imply organic growth of 7% in adjusted EBITDA and 21% in adjusted free cash flow [4]. On the call, an analyst said the old ranges' upper end is the new midpoint (analyst's statement) [4]. The euro ranges were not in the excerpts returned. The European outlook was held, after absorbing a €100m EBITDA hit from the ECJ ruling in Germany (company-reported) [4].
- **H1 delivery (company-reported).** Adjusted EBITDA grew 6.4% in H1 and group service revenue grew 6.4% in Q2 [4]. Germany's H1 EBITDA fell 3.2%, of which 2 points was the ECJ provision [4]. Comparison with Moody's forecast: Moody's forecasts are full-year Moody's-adjusted ratios (FY27F debt/EBITDA 3.1x, RCF/net debt 29.4% [2]), so a half-year cannot be set against them.
- **Net debt (company-reported).** €33,473m at 30 Sep 2026, against €25,411m at 31 Mar 2026 [5]. The drivers were €6,957m of acquisitions and disposals (the VodafoneThree buyout and Safaricom), a €845m free cash outflow, €544m of dividends and €92m of buybacks [5].
- **Liquidity (company-reported).** Cash and short-term investments were €8.4bn, down from €12.4bn at March [5]. Undrawn revolving credit facilities were €7.6bn: €4.1bn maturing in 2031 and US$4.0bn maturing in 2028 [5]. Debt maturities were not in the excerpts returned.
- **Capex and shareholder returns (company-reported).** Capital additions were €3,320m in H1, against €2,800m a year earlier [5]. Management does not expect a material cut in capital intensity in Germany [4]. The interim dividend is 2.306 eurocents, up 2.5% [5]. Equity calls for the OXG fibre joint venture will be phased over the build [4]. An analyst on the call put them at up to €1.2bn (analyst's figure) [4].

## Against Moody's triggers

| Metric (Moody's-adjusted) | Latest, period | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to Mar 2026 [3] | below 2.5x [2] | fails to stay below 3.3x [2] | 0.75x to upgrade; 0.05x to downgrade |
| RCF / Net debt | 33.08%, FY to Mar 2026 [3] | above 25% sustained [2] | towards 18% [2] | upgrade level already met, by 8.1pp; 15.1pp to downgrade |

The opinion also gives worded triggers [2]. Upgrade: "underlying revenue and operating performance improve sustainably, particularly in Germany". Downgrade: "a failure to turn around its German operations".

## What it means for the rating and outlook

- The stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt of around 30%, and net leverage in the lower half of the 2.25x-2.75x target range [2]. The latest adjusted debt/EBITDA is 0.05x inside the downgrade level [3][2].
- The credit opinion (21 Oct) [2] and the rating action (13 Oct) [6] both predate these results. The adjusted figures are for March 2026 [3]. Since then, company-reported net debt has risen by €8.1bn, mainly from the buyouts [5].
- On that cause, the opinion cites "reduced financial flexibility following the buyout of VodafoneThree" [2]. The rating action calls liquidity "excellent", pro forma for the UK buyout [6].
- Moody's has published no comment on these results in the last 45 days.

**Notes**
- Company net debt excludes lease liabilities (€12.8bn at September) [5]. It is not the same measure as Moody's-adjusted total debt (€51.3bn at March 2026) [3].
- The filing's title ("Interim Report 2026 - Q4") is a mislabel. The document is the H1 FY27 report for the six months to 30 Sep 2026.

Dashboard not updated: this session has no folder to write to, cannot run scripts and cannot publish.

**Sources**
1. Moody's, getEntityRatings: Vodafone Group Plc rating history (Senior Unsecured, foreign currency), RTNG_600018164, retrieved 15 Nov 2026.
2. Moody's, getCreditOpinion: "Vodafone Group Plc: Update following ratings affirmation", PBC_1496608, 21 Oct 2026 (Summary, outlook, triggers, key indicators).
3. Moody's, getEntityFinancials_v2: Moody's-adjusted key indicators (Debt / EBITDA, RCF / Net Debt, Total Debt), fiscal year ended 31 Mar 2026.
4. Moody's, searchCompanyFilings: "Half Year 2027 Vodafone Group Public Ltd Co Earnings Call", event date 10 Nov 2026.
5. Moody's, searchCompanyFilings: Vodafone Group Plc "Interim Report 2026 - Q4" (6-K, H1 FY27, period to 30 Sep 2026), submitted 10 Nov 2026, pp. 4, 11, 29.
6. Moody's, searchAllDocuments: "Moody's Ratings affirms Vodafone's ratings; stable outlook", Rating Action PR_528027, 13 Oct 2026.
