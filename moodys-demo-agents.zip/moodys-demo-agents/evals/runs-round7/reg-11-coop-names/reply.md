**Regulatory watch: Banks Europe, 10 own names, 30 days** (30 days, 16 Oct to 15 Nov 2026; 10 names)

No liquidity rule changed in the 30 days; on LCR, HSBC and BNP Paribas sit closest to the 100% minimum among ranked names, and the Basel G-SIB package of 16 Oct is the one item on the capital channel. [1][2][3][4]

**Who it hits: Liquidity, asked (no change in window) · LCR**

| Name | LCR (Q2 2026) | vs median (pp) | Stated requirement | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134% [1] | -6.12 [1] | 100% [2] | 34.00 [1][2] | Least headroom |
| BNP Paribas | 134.77% [1] | -5.35 [1] | 100% [2] | 34.77 [1][2] | Least headroom |
| ING Groep N.V. | 137% [1] | -3.12 [1] | 100% [2] | 37.00 [1][2] | Middle |
| Deutsche Bank AG | 140.12% [1] | 0.00 [1] | 100% [2] | 40.12 [1][2] | Middle |
| Societe Generale | 146.41% [1] | +6.29 [1] | 100% [2] | 46.41 [1][2] | Middle |
| Barclays PLC | 157.7% [1] | +17.58 [1] | 100% [2] | 57.70 [1][2] | Most headroom |
| UBS Group AG | 177.28% [1] | +37.16 [1] | 100% [2] | 77.28 [1][2] | Most headroom |
| Raiffeisen Bank International AG | 143.65% [1] | not ranked | 100% [2] | 43.65 [1][2] | Not ranked: record may not be the consolidated group |
| DZ BANK AG | 148.75% [1] | not ranked | 100% [2] | 48.75 [1][2] | Not ranked: record may not be the consolidated group |
| BPCE | not in Moody's data [5] | not ranked | 100% [2] | none | Not ranked: record may not be the consolidated group |

Note: All ten covered: the Basel LCR minimum of 100% applies to each; local rules can be higher. Not ranked: BPCE, DZ Bank, Raiffeisen Bank International, whose records may not be the consolidated group; BPCE also has no LCR in Moody's data. [2]

**Who it hits: G-SIB window-dressing standard and methodology review (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (Q2 2026) | vs median (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [6] | -0.95 [6] | 10.51% (30 Sep 2025, older) [7] | 2.46 [6][7] | Weaker third |
| ING Groep N.V. | 13.07% [6] | -0.85 [6] | 11.03% (31 Dec 2025, older) [8] | 2.04 [6][8] | Weaker third |
| Societe Generale | 13.20% [6] | -0.72 [6] | 10.26% (31 Mar 2026) [9] | 2.94 [6][9] | Middle |
| Deutsche Bank AG | 13.92% [6] | 0.00 [6] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% [6] | +0.18 [6] | not stated | not stated | Middle |
| Barclays PLC | 14.30% [6] | +0.38 [6] | 12.2% (31 Dec 2025, older) [10] | 2.10 [6][10] | Stronger third |
| UBS Group AG | 14.38% [6] | +0.46 [6] | 10.83% (30 Jun 2026) [11] | 3.55 [6][11] | Stronger third |
| BPCE | not in Moody's data [5] | not ranked | not stated | not stated | Not ranked: record may not be the consolidated group |

Note: Covered: banks on the FSB G-SIB list of 27 Nov 2025; the buffer falls on listed banks, while reporting applies to the wider Basel assessment sample. Out of scope: DZ Bank, Raiffeisen Bank International (not on that list). Ranked by level: only UBS and Societe Generale have a current stated requirement. BPCE not ranked: no CET1 in Moody's data; record may not be the consolidated group. [12]

**What changed**

- **Liquidity (LCR)** (Asked): No liquidity rule changed at the seven regulators in the window. The EBA's reporting package defers liquidity reporting changes to December 2028; that is reporting, not the LCR requirement. [13]
- [NEW] **PRA** (Final): PS20/26 finalises the remaining large exposures changes: mandatory substitution approach, no internal models for securities financing exposures, smaller trading book and intragroup allowances. Effective 1 January 2028. *Why it matters:* Concentration limits tighten for UK groups. [14]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance, in force 1 January 2027, aligned with the revised AMLA ahead of the FATF evaluation. [15]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded securities losses, earnings indicators and new supervisory reporting. Comments by 9 February 2027. *Why it matters:* Earlier supervisory sight of rate-risk exposures. [16]
- [NEW] **EBA** (Final): Final 2027 EU-wide stress test methodology, with draft templates and 55% fewer data points; first separate climate module. Launch end January 2027, results end July 2027. [17]
- [NEW] **EBA** (Other): Supervisory reporting simplification being finalised (final ITS report December 2026); first reference date moved to December 2027, some areas to December 2028. [13]
- [NEW] **EBA** (Final): Revised internal governance guidelines (EBA/GL/2026/10) reflecting CRD VI; application date not stated. Moody's (11 Nov) calls them credit positive, more so for small EU banks. [18][19]
- [NEW] **Basel Committee** (Consultation): Consequential amendments moving application guidance into the new consolidated guidelines. Comments by 21 December 2026. Channel assigned by own judgment: no row in the channel map. [20]
- [NEW] **FINMA** (Consultation): Revised Circular 2019/2 on interest rate risk: recalibrated Basel shock scenarios and more weight on earnings effects. Comments by 15 January 2027. [21]
- [NEW] **European Commission** (Other): Political agreement on the securitisation framework review, including more risk-sensitive CRR capital treatment. Awaits formal adoption; application dates not stated. [22]
- [NEW] **PRA** (Consultation): CP14/26: SM&CR phase 2 would move most senior manager approvals to notification and drop certification assessments. Comments by 22 January 2027. [23]
- [NEW] **Basel Committee** (Final): G-SIB indicators to be reported on yearly averages, not year-end values, to curb window dressing; implement by 1 January 2030. Leverage exposure reporting threshold rises to EUR 350bn from 1 January 2027. *Why it matters:* Can change G-SIB scores and so buffer buckets. [3]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to build the agreed treatment of cross-border exposures within the Banking Union into the framework. Comments by 14 January 2027. *Why it matters:* Bears on G-SIB buffers of banking-union G-SIBs. [4]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures (10 Nov) | HSBC, Barclays | large exposures: no field | Watch |
| FINMA AML Ordinance (10 Nov) | UBS | AML: no field | Watch |
| Basel IRRBB Pillar 2 guidance (9 Nov) | all ten, once home rules adopt it | IRRBB: no field | Watch |
| EBA 2027 stress test (9 Nov) | scope not known: EU names in the EBA sample (BNP Paribas, Deutsche Bank, ING, Societe Generale, BPCE, DZ Bank, RBI) | stress test: no field | Watch |
| EBA reporting simplification (6 Nov) | BNP Paribas, Deutsche Bank, ING, Societe Generale, BPCE, DZ Bank, RBI | reporting: no field | Watch |
| EBA internal governance guidelines (5 Nov) | BNP Paribas, Deutsche Bank, ING, Societe Generale, BPCE, DZ Bank, RBI | governance: no field | Watch |
| Basel consolidated guidelines amendments (5 Nov) | all ten, once home rules adopt it | none (own judgment) | Watch |
| FINMA Circular 2019/2 interest rate risk (4 Nov) | UBS | IRRBB: no field | Watch |
| EU securitisation framework (22 Oct) | BNP Paribas, Deutsche Bank, ING, Societe Generale, BPCE, DZ Bank, RBI | securitisation: no field | Watch |
| PRA CP14/26 SM&CR (22 Oct) | HSBC, Barclays | conduct, governance: no field | Watch |

Note: Moody's data carries no field for these channels, so no name is positioned.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- BPCE, DZ Bank and RBI were resolved by name (ratings confirmed); as co-operative central institutions with no group record, they are shown, not ranked.
- Left out: speeches, newsletters, sanctions notices, periodic lists, consumer and credit-union material, appointments, moved deadlines, inter-authority advice.
- Basel minimums are shown; UK and Swiss local rules can set higher requirements. The FSB 2026 G-SIB list was not found on fsb.org on 15 Nov 2026, so the 2025 list is used.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 (period end 30 Jun 2026) · Bank financials, 9 names · 2026-06-30
[2] Web · Basel Framework (LEV, LCR, NSF standards) · 2026-11-15 · https://www.bis.org/basel_framework/
[3] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[4] Web · BCBS consultation: G-SIB methodology review · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[5] Moody's financials (getEntityFinancials_v2) · BPCE: LQ returned Q4 2024 with no CET1 or LCR field; explicit Q2 2026 returned no data · BPCE · 2024-12-31
[6] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (period end 30 Jun 2026) · Bank financials, 9 names · 2026-06-30
[7] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, CET1 capital … · 2025-09-30
[8] Moody's (searchCompanyFilings) · ING stated CET1 requirement · bank sector file, pulled 15 Nov 2026: ING 2025 Form 20-F, MDA trigger level for CET1, as … · 2025-12-31
[9] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, CET1 … · 2026-03-31
[10] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays 2025 Form 20-F, overall capital … · 2025-12-31
[11] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS second quarter 2026 report, required … · 2026-06-30
[12] Web · FSB: 2025 List of Global Systemically Important Banks (2026 list not found on … · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[13] Web · EBA: next steps on supervisory reporting simplification, extended timelines · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[14] Web · PRA PS20/26: Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · FINMA: partially revised Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[16] Web · BCBS consultation: IRRBB - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA: 2027 EU-wide stress test methodology · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[18] Web · EBA: revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[19] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[20] Web · BCBS consultation: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[21] Web · FINMA consultation: partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[22] Web · European Commission: political agreement on review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[23] Web · PRA CP14/26: Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 2026-11-15T22:18:34Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-11-coop-names/dashboard/dashboard.html (not published as an Artifact in this run).
