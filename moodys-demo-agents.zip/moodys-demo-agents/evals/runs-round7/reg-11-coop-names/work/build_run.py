import json
L=json.load(open("/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/plugin/skills/coverage-list/lists/banks-europe.json"))
want=["HSBC Holdings plc","BNP Paribas","Deutsche Bank AG","UBS Group AG","Barclays PLC","ING Groep N.V.","Societe Generale"]
names=[n for n in L["names"] if n["name"] in want]
names+=[
 {"name":"BPCE","country":"FR","entityId":"b3JnSWQ6ODIxNjk3NzY2I29yYmlzSWQ6MDU3MDcwMjQyI2J2ZElkOkZSNDkzNDU1MDQyI2RlYWxJZDpudWxsI3RyYW5jaGVJZDpudWxs","note":"central institution of a co-operative group; no groupEntityId"},
 {"name":"DZ BANK AG","country":"DE","entityId":"b3JnSWQ6Mjc3NTUwI29yYmlzSWQ6MDAwNzU0NDU1I2J2ZElkOkRFRkVCMTc4ODEjZGVhbElkOm51bGwjdHJhbmNoZUlkOm51bGw","note":"central institution of a co-operative group; no groupEntityId"},
 {"name":"Raiffeisen Bank International AG","country":"AT","entityId":"b3JnSWQ6ODA4NTQ5NDg2I29yYmlzSWQ6MDAxOTIyMjM5I2J2ZElkOkFURkVCNDA0OTQjZGVhbElkOm51bGwjdHJhbmNoZUlkOm51bGw","note":"Raiffeisen central bank; no groupEntityId"}]
json.dump({"sector":"Banks","region":"Europe","checked":"2026-11-15","names":names,"unresolved":[]},open("dashboard/data/coverage/banks-europe-own.json","w"),indent=1)

def c(v,src,tone=None):
    d={"v":v,"src":src}
    if tone: d["tone"]=tone
    return d
T=lambda t:{"tone":t,"v":""}
NR="Not ranked: record may not be the consolidated group"
cet1_rows=[
 ["BNP Paribas",c("12.97%",["m1"]),c("-0.95",["m1"]),c("10.51% (30 Sep 2025, older)",["m6"]),c("2.46",["m1","m6"]),T("weaker")],
 ["ING Groep N.V.",c("13.07%",["m1"]),c("-0.85",["m1"]),c("11.03% (31 Dec 2025, older)",["m8"]),c("2.04",["m1","m8"]),T("weaker")],
 ["Societe Generale",c("13.20%",["m1"]),c("-0.72",["m1"]),c("10.26% (31 Mar 2026)",["m4"]),c("2.94",["m1","m4"]),T("middle")],
 ["Deutsche Bank AG",c("13.92%",["m1"]),c("0.00",["m1"]),"not stated","not stated",T("middle")],
 ["HSBC Holdings plc",c("14.10%",["m1"]),c("+0.18",["m1"]),"not stated","not stated",T("middle")],
 ["Barclays PLC",c("14.30%",["m1"]),c("+0.38",["m1"]),c("12.2% (31 Dec 2025, older)",["m7"]),c("2.10",["m1","m7"]),T("stronger")],
 ["UBS Group AG",c("14.38%",["m1"]),c("+0.46",["m1"]),c("10.83% (30 Jun 2026)",["m5"]),c("3.55",["m1","m5"]),T("stronger")],
 ["BPCE",{"v":"not in Moody's data","src":["m3"],"tone":"nodata"},"not ranked","not stated","not stated",{"tone":"nodata","v":NR}],
]
lcr_rows=[
 ["HSBC Holdings plc",c("134%",["m2"]),c("-6.12",["m2"]),c("100%",["w14"]),c("34.00",["m2","w14"]),T("least")],
 ["BNP Paribas",c("134.77%",["m2"]),c("-5.35",["m2"]),c("100%",["w14"]),c("34.77",["m2","w14"]),T("least")],
 ["ING Groep N.V.",c("137%",["m2"]),c("-3.12",["m2"]),c("100%",["w14"]),c("37.00",["m2","w14"]),T("middle")],
 ["Deutsche Bank AG",c("140.12%",["m2"]),c("0.00",["m2"]),c("100%",["w14"]),c("40.12",["m2","w14"]),T("middle")],
 ["Societe Generale",c("146.41%",["m2"]),c("+6.29",["m2"]),c("100%",["w14"]),c("46.41",["m2","w14"]),T("middle")],
 ["Barclays PLC",c("157.7%",["m2"]),c("+17.58",["m2"]),c("100%",["w14"]),c("57.70",["m2","w14"]),T("most")],
 ["UBS Group AG",c("177.28%",["m2"]),c("+37.16",["m2"]),c("100%",["w14"]),c("77.28",["m2","w14"]),T("most")],
 ["Raiffeisen Bank International AG",c("143.65%",["m2"]),"not ranked",c("100%",["w14"]),c("43.65",["m2","w14"]),NR],
 ["DZ BANK AG",c("148.75%",["m2"]),"not ranked",c("100%",["w14"]),c("48.75",["m2","w14"]),NR],
 ["BPCE",{"v":"not in Moody's data","src":["m3"],"tone":"nodata"},"not ranked",c("100%",["w14"]),"none",{"tone":"nodata","v":NR}],
]
EU="BNP Paribas, Deutsche Bank, ING, Societe Generale, BPCE, DZ Bank, RBI"
W=T("watch")
watch=[
 ["PRA PS20/26 large exposures (10 Nov)","HSBC, Barclays","large exposures: no field",W],
 ["FINMA AML Ordinance (10 Nov)","UBS","AML: no field",W],
 ["Basel IRRBB Pillar 2 guidance (9 Nov)","all ten, once home rules adopt it","IRRBB: no field",W],
 ["EBA 2027 stress test (9 Nov)","scope not known: EU names in the EBA sample ("+EU+")","stress test: no field",W],
 ["EBA reporting simplification (6 Nov)",EU,"reporting: no field",W],
 ["EBA internal governance guidelines (5 Nov)",EU,"governance: no field",W],
 ["Basel consolidated guidelines amendments (5 Nov)","all ten, once home rules adopt it","none (own judgment)",W],
 ["FINMA Circular 2019/2 interest rate risk (4 Nov)","UBS","IRRBB: no field",W],
 ["EU securitisation framework (22 Oct)",EU,"securitisation: no field",W],
 ["PRA CP14/26 SM&CR (22 Oct)","HSBC, Barclays","conduct, governance: no field",W],
]
I=lambda flag,tag,name,text,why,src:{k:v for k,v in dict(flag=flag,tag=tag,name=name,text=text,why=why,src=src).items() if v}
items=[
 I("","Asked","Liquidity (LCR)","No liquidity rule changed at the seven regulators in the window. The EBA's reporting package defers liquidity reporting changes to December 2028; that is reporting, not the LCR requirement.","",["w6"]),
 I("NEW","Final","PRA","PS20/26 finalises the remaining large exposures changes: mandatory substitution approach, no internal models for securities financing exposures, smaller trading book and intragroup allowances. Effective 1 January 2028.","Concentration limits tighten for UK groups.",["w9"]),
 I("NEW","Final","FINMA","Partially revised Anti-Money Laundering Ordinance, in force 1 January 2027, aligned with the revised AMLA ahead of the FATF evaluation.","",["w12"]),
 I("NEW","Consultation","Basel Committee","Additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded securities losses, earnings indicators and new supervisory reporting. Comments by 9 February 2027.","Earlier supervisory sight of rate-risk exposures.",["w4"]),
 I("NEW","Final","EBA","Final 2027 EU-wide stress test methodology, with draft templates and 55% fewer data points; first separate climate module. Launch end January 2027, results end July 2027.","",["w7"]),
 I("NEW","Other","EBA","Supervisory reporting simplification being finalised (final ITS report December 2026); first reference date moved to December 2027, some areas to December 2028.","",["w6"]),
 I("NEW","Final","EBA","Revised internal governance guidelines (EBA/GL/2026/10) reflecting CRD VI; application date not stated. Moody's (11 Nov) calls them credit positive, more so for small EU banks.","",["w5","m9"]),
 I("NEW","Consultation","Basel Committee","Consequential amendments moving application guidance into the new consolidated guidelines. Comments by 21 December 2026. Channel assigned by own judgment: no row in the channel map.","",["w3"]),
 I("NEW","Consultation","FINMA","Revised Circular 2019/2 on interest rate risk: recalibrated Basel shock scenarios and more weight on earnings effects. Comments by 15 January 2027.","",["w11"]),
 I("NEW","Other","European Commission","Political agreement on the securitisation framework review, including more risk-sensitive CRR capital treatment. Awaits formal adoption; application dates not stated.","",["w8"]),
 I("NEW","Consultation","PRA","CP14/26: SM&CR phase 2 would move most senior manager approvals to notification and drop certification assessments. Comments by 22 January 2027.","",["w10"]),
 I("NEW","Final","Basel Committee","G-SIB indicators to be reported on yearly averages, not year-end values, to curb window dressing; implement by 1 January 2030. Leverage exposure reporting threshold rises to EUR 350bn from 1 January 2027.","Can change G-SIB scores and so buffer buckets.",["w1"]),
 I("NEW","Consultation","Basel Committee","G-SIB methodology review: whether to build the agreed treatment of cross-border exposures within the Banking Union into the framework. Comments by 14 January 2027.","Bears on G-SIB buffers of banking-union G-SIBs.",["w2"]),
]
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"UPDATED",
 "scope":{"label":"Banks Europe, 10 own names, 30 days","sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":10},
 "status":"ok",
 "headline":"No liquidity rule changed in the 30 days; on LCR, HSBC and BNP Paribas sit closest to the 100% minimum among ranked names, and the Basel G-SIB package of 16 Oct is the one item on the capital channel.",
 "headline_src":["m2","w14","w1","w2"],
 "sections":[
  {"title":"Who it hits: Liquidity, asked (no change in window) · LCR","type":"table",
   "columns":["Name","LCR (Q2 2026)","vs median (pp)","Stated requirement","Distance to requirement (pp)","Position"],
   "rows":lcr_rows,
   "note":"All ten covered: the Basel LCR minimum of 100% applies to each; local rules can be higher. Not ranked: BPCE, DZ Bank, Raiffeisen Bank International, whose records may not be the consolidated group; BPCE also has no LCR in Moody's data.",
   "note_src":["w14"]},
  {"title":"Who it hits: G-SIB window-dressing standard and methodology review (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
   "columns":["Name","CET1 (Q2 2026)","vs median (pp)","Stated requirement (date)","Distance to requirement (pp)","Position"],
   "rows":cet1_rows,
   "note":"Covered: banks on the FSB G-SIB list of 27 Nov 2025; the buffer falls on listed banks, while reporting applies to the wider Basel assessment sample. Out of scope: DZ Bank, Raiffeisen Bank International (not on that list). Ranked by level: only UBS and Societe Generale have a current stated requirement. BPCE not ranked: no CET1 in Moody's data; record may not be the consolidated group.",
   "note_src":["w13"]},
  {"title":"What changed","type":"items","items":items},
  {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":watch,
   "note":"Moody's data carries no field for these channels, so no name is positioned."}
 ],
 "sources":[
  {"id":"w1","kind":"web","title":"BCBS: Amendments to G-SIB framework to address window dressing","date":"2026-10-16","url":"https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"},
  {"id":"w2","kind":"web","title":"BCBS consultation: G-SIB methodology review","date":"2026-10-16","url":"https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"},
  {"id":"w3","kind":"web","title":"BCBS consultation: Consolidated guidelines - consequential amendments","date":"2026-11-05","url":"https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"},
  {"id":"w4","kind":"web","title":"BCBS consultation: IRRBB - additional Pillar 2 guidance","date":"2026-11-09","url":"https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"},
  {"id":"w5","kind":"web","title":"EBA: revised Guidelines on internal governance","date":"2026-11-05","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"},
  {"id":"w6","kind":"web","title":"EBA: next steps on supervisory reporting simplification, extended timelines","date":"2026-11-06","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"},
  {"id":"w7","kind":"web","title":"EBA: 2027 EU-wide stress test methodology","date":"2026-11-09","url":"https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"},
  {"id":"w8","kind":"web","title":"European Commission: political agreement on review of the Securitisation Framework","date":"2026-10-22","url":"https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"},
  {"id":"w9","kind":"web","title":"PRA PS20/26: Amendments to the Large Exposures Framework - Part 2","date":"2026-11-10","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"},
  {"id":"w10","kind":"web","title":"PRA CP14/26: Review of the SM&CR - Phase 2","date":"2026-10-22","url":"https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"},
  {"id":"w11","kind":"web","title":"FINMA consultation: partially revised Circular 2019/2 Interest rate risks - banks","date":"2026-11-04","url":"https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"},
  {"id":"w12","kind":"web","title":"FINMA: partially revised Anti-Money Laundering Ordinance","date":"2026-11-10","url":"https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"},
  {"id":"w13","kind":"web","title":"FSB: 2025 List of Global Systemically Important Banks (2026 list not found on fsb.org on 15 Nov 2026)","date":"2025-11-27","url":"https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"},
  {"id":"w14","kind":"web","title":"Basel Framework (LEV, LCR, NSF standards)","date":"2026-11-15","url":"https://www.bis.org/basel_framework/"},
  {"id":"m1","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (period end 30 Jun 2026)","title":"Bank financials, 9 names","date":"2026-06-30"},
  {"id":"m2","kind":"moodys","tool":"getEntityFinancials_v2","ref":"Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 (period end 30 Jun 2026)","title":"Bank financials, 9 names","date":"2026-06-30"},
  {"id":"m3","kind":"moodys","tool":"getEntityFinancials_v2","ref":"BPCE: LQ returned Q4 2024 with no CET1 or LCR field; explicit Q2 2026 returned no data","title":"BPCE financials","date":"2024-12-31"},
  {"id":"m4","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Societe Generale first quarter 2026 results, CET1 requirement, as of 31 Mar 2026","title":"Societe Generale stated CET1 requirement","date":"2026-03-31"},
  {"id":"m5","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: UBS second quarter 2026 report, required going-concern CET1 capital, as of 30 Jun 2026","title":"UBS stated CET1 requirement","date":"2026-06-30"},
  {"id":"m6","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: BNP Paribas third quarter 2025 report, CET1 capital requirement, as of 30 Sep 2025","title":"BNP Paribas stated CET1 requirement","date":"2025-09-30"},
  {"id":"m7","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: Barclays 2025 Form 20-F, overall capital requirement for CET1 excluding PRA buffer, as of 31 Dec 2025","title":"Barclays stated CET1 requirement","date":"2025-12-31"},
  {"id":"m8","kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: ING 2025 Form 20-F, MDA trigger level for CET1, as of 31 Dec 2025","title":"ING stated CET1 requirement","date":"2025-12-31"},
  {"id":"m9","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042, Sector Comment","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"}
 ],
 "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Names: seven taken from the checked European banks list; BPCE, DZ Bank and Raiffeisen Bank International resolved by name and rating confirmed. These three are central institutions of co-operative groups with no group record on the list, so they are shown and not ranked.",
  "Left out (listings read for all seven regulators): speeches, interviews, newsletters and blogs (ECB, SRB, FINMA, BCBS, PRA digest); periodic list and Eurogroup overview (ECB); sanctions notices (FINMA, Commission); consumer material, appointment, NGFS statement, moved deadlines, Taxonomy advice (EBA); credit-union papers (PRA); Bitcoin ETF approval (FINMA); Commission statements and statistics.",
  "Basel minimums are shown; UK and Swiss local rules can set higher requirements. The FSB 2026 G-SIB list was not found on fsb.org on 15 Nov 2026, so the 2025 list is used."
 ],
 "meta":{"calls":{"moodys":9,"web":25}}}
import subprocess
run["updated_at"]=subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
