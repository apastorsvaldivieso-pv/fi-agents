**Regulatory watch: Banks Europe, PRA only, 2 days** (13 Nov to 15 Nov 2026)

No new PRA rule, consultation or policy statement for banks was published between 13 and 15 Nov 2026; the latest entry in the PRA publications feed is dated 10 Nov 2026. [1]

**Sources**

[1] Web · Bank of England, Prudential Regulation publications feed · 2026-11-15 · https://www.bankofengland.co.uk/rss/prudential-regulation-publications

Regulatory watch tab updated 15 Nov 2026 22:12 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-05-quiet/dashboard/dashboard.html (not published as an Artifact in this run).
