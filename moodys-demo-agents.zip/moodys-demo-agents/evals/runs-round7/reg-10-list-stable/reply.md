**Regulatory watch: Banks Europe, 16 Oct-15 Nov 2026** (16 Oct to 15 Nov 2026; 15 names)

Twelve regulatory items in the window, none new since the last run; the two that reach a Moody's metric are the Basel Committee's 16 October G-SIB changes, which sit on the CET1 channel for the eight G-SIBs on the list, where BNP Paribas and ING are in the weaker third on level. [1][2]

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | -1.04 [2] | 10.51% (30 Sep 2025, older) [3] | 2.46 pp [2][3] | Weaker third |
| ING Groep N.V. | 13.07% [2] | -0.94 [2] | 11.03% (31 Dec 2025, older) [4] | 2.04 pp [2][4] | Weaker third |
| Societe Generale | 13.2% [2] | -0.81 [2] | 10.26% (31 Mar 2026) [5] | 2.94 pp [2][5] | Middle |
| Deutsche Bank AG | 13.92% [2] | -0.09 [2] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.1% [2] | +0.09 [2] | not stated | not stated | Middle |
| Barclays PLC | 14.3% [2] | +0.29 [2] | 12.2% (31 Dec 2025, older) [6] | 2.10 pp [2][6] | Middle |
| UBS Group AG | 14.38% [2] | +0.37 [2] | 10.83% (30 Jun 2026) [7] | 3.55 pp [2][7] | Stronger third |
| Groupe Credit Agricole | 17.23% [8] | +3.22 [2][8] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | Stronger third |

Note: Ranked by level: only three names have a current requirement. Reporting applies to banks in the G-SIB assessment exercise; the buffer falls only on FSB-listed G-SIBs. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on FSB list of 27 Nov 2025). Listed issuer Credit Agricole S.A.: CET1 11.3%, Q2 2026; 2.6 pp above SREP, 31 Mar 2026. [1][2][9][10]

**Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio, Q2 2026 | vs median (pp) | Stated requirement (date) | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [2] | not ranked | 10.51% (30 Sep 2025, older) [3] | 2.46 pp [2][3] | list too short to rank |
| ING Groep N.V. | 13.07% [2] | not ranked | 11.03% (31 Dec 2025, older) [4] | 2.04 pp [2][4] | list too short to rank |
| Societe Generale | 13.2% [2] | not ranked | 10.26% (31 Mar 2026) [5] | 2.94 pp [2][5] | list too short to rank |
| Deutsche Bank AG | 13.92% [2] | not ranked | not stated | not stated | list too short to rank |
| Groupe Credit Agricole | 17.23% [8] | not ranked | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [9] | list too short to rank |

Note: The release asks whether to bring the agreed treatment of cross-border exposures within the European Banking Union into the G-SIB methodology; it names no banks. Scope taken as banking-union G-SIBs (our reading). Out of scope: HSBC, Barclays, UBS (not banking-union); seven others not on FSB list of 27 Nov 2025. [1][10]

**What changed**

- **PRA** (Final): PS20/26 (10 Nov) amends large exposures: no internal models for SFT exposure values, mandatory substitution of credit risk mitigation, intragroup trading book allowance cut to 85% of Tier 1. Effective 1 Jan 2028. *Why it matters:* Large exposures channel; no Moody's metric. Covers HSBC, Barclays, Lloyds. [11]
- **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published 10 Nov, clarifying correspondent banking rules. In force 1 Jan 2027. *Why it matters:* AML channel; covers UBS. [12]
- **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book (9 Nov): model validation, stress testing, embedded gains and losses, earnings indicators, supervisory reporting. Comments by 9 Feb 2027. *Why it matters:* IRRBB channel; covers all 15 names once applied at home. [13]
- **EBA** (Final): Final methodology for the 2027 EU-wide stress test (9 Nov) cuts requested data points by 55% and adds a separate climate module. Launch end-January 2027, results end-July 2027. *Why it matters:* Stress-test channel; sample set in the methodology, not checked by name. [14]
- **EBA** (Other): Next steps on reporting simplification (6 Nov): final ITS report due December 2026, first reference date December 2027; liquidity, encumbrance, benchmarking and ESG reporting deferred to December 2028. *Why it matters:* Reporting channel; covers the 11 EU names. [15]
- **EBA** (Final): Revised Guidelines on internal governance (5 Nov) align with CRD VI, with more proportionality. Moody's (11 Nov) calls them credit positive for EU banks, more so for smaller banks. *Why it matters:* Governance channel; covers the 11 EU names. [16][17]
- **Basel Committee** (Consultation): Consequential amendments (5 Nov) repoint Basel Framework cross-references to the new consolidated guidelines and move application guidance into them. Comments by 21 Dec 2026. *Why it matters:* No channel in the map (framework structure, our mapping); covers all 15 names. [18]
- **FINMA** (Consultation): Consultation on revised Circular 2019/2 'Interest rate risks - banks' (4 Nov), adopting the Basel Committee's recalibrated shocks and weighting earnings effects more. Comments by 15 Jan 2027. *Why it matters:* IRRBB channel; covers UBS. [19]
- **European Commission** (Other): Provisional political agreement on the securitisation framework (22 Oct): CRR treatment made more risk sensitive, due diligence and transparency simplified. Formal adoption pending. *Why it matters:* Securitisation channel; covers the 11 EU names. [20]
- **PRA** (Consultation): CP14/26 (22 Oct) on SM&CR phase 2: pre-approval dropped for almost half of Senior Manager Functions, Certification Regime assessments removed. Comments by 22 Jan 2027. *Why it matters:* Governance channel; covers HSBC, Barclays, Lloyds. [21]
- **Basel Committee** (Final): G-SIB stock indicators to be reported as averages over the year, not year-end values, by 1 Jan 2030; reporting threshold rises to EUR 350bn from 2027. *Why it matters:* Changes how G-SIB scores, and so the G-SIB buffer, are measured: CET1 channel. [1]
- **Basel Committee** (Consultation): Consultation (16 Oct) on bringing the European Banking Union cross-border exposure treatment into the G-SIB methodology. Comments by 14 Jan 2027. *Why it matters:* G-SIB score and buffer measurement: CET1 channel. [1]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA PS20/26 large exposures | HSBC, Barclays, Lloyds | large exposures | Watch |
| FINMA AML Ordinance | UBS | AML | Watch |
| Basel IRRBB Pillar 2 guidance | all 15 | IRRBB | Watch |
| EBA 2027 stress test | EU names in the EBA sample (not checked) | stress test | Watch |
| EBA reporting simplification | 11 EU names | reporting | Watch |
| EBA internal governance guidelines | 11 EU names | governance | Watch |
| Basel consolidated guidelines amendments | all 15 | none (framework structure) | Watch |
| FINMA Circular 2019/2 IRRBB | UBS | IRRBB | Watch |
| EU securitisation agreement | 11 EU names | securitisation | Watch |
| PRA CP14/26 SM&CR | HSBC, Barclays, Lloyds | governance | Watch |

Note: Moody's data carries no metric for these channels. The 11 EU names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (22 entries): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (BCBS, ECB, PRA digest); sanctions notices (Commission, FINMA); periodic lists, statistics and appointments (ECB, Commission, EBA); communications to another authority (ECB, EBA); a moved consultation deadline (EBA); a statement and a meeting summary (EBA, Commission); consumer material (EBA); items for credit unions, assurance providers or funds (PRA, Commission, FINMA).
- ECB Banking Supervision and SRB listings showed no rule, guideline or supervisory decision in the window. Moody's research found no comment on the G-SIB, securitisation or large exposures items.
- Requirements marked older are not current and are not used for ranking.

**Sources**

[1] Web · Basel Committee finalises measures to address window-dressing in the G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[2] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 (Credit Agricole S.A. own … · Bank financials, coverage list · 2026-06-30
[3] Moody's (searchCompanyFilings) · BNP Paribas CET1 capital requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[4] Moody's (searchCompanyFilings) · ING MDA trigger level for CET1 · bank sector file, pulled 15 Nov 2026: ING Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[5] Moody's (searchCompanyFilings) · Societe Generale CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, as of … · 2026-03-31
[6] Moody's (searchCompanyFilings) · Barclays overall capital requirement for CET1 · bank sector file, pulled 15 Nov 2026: Barclays Form 20-F 2025, as of 31 Dec 2025 · 2025-12-31
[7] Moody's (searchCompanyFilings) · UBS required going-concern CET1 capital · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[8] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (re-pulled at explicit period; … · Groupe Credit Agricole · 2026-06-30
[9] Moody's (searchCompanyFilings) · Groupe Credit Agricole and Credit Agricole S.A. distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole First quarter 2026 results slides, … · 2026-03-31
[10] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs); 2026 list not … · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[11] Web · PRA PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[12] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[13] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[14] Web · EBA streamlines the 2027 EU-wide stress test with more than 55% reduction in … · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[15] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[16] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[17] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042 · 2026-11-11
[18] Web · BCBS: Consolidated guidelines - consequential amendments (consultative) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[19] Web · FINMA launches consultation on the partially revised Circular 2019/2 Interest … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[20] Web · The Commission welcomes the political agreement reached on the review of the … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[21] Web · PRA CP14/26 - Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated at 2026-11-15T22:19:26Z: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-10-list-stable/dashboard/dashboard.html. Not published to the private link in this session.
