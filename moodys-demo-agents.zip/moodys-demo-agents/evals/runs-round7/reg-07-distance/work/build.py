import json, subprocess
now = subprocess.check_output(["date","-u","+%Y-%m-%dT%H:%M:%SZ"]).decode().strip()
W = lambda tone="watch": {"tone": tone, "v": ""}
def c(v, *s, tone=None):
    d = {"v": v, "src": list(s)}
    if tone: d["tone"] = tone
    return d
# LCR
lcr = [("HSBC Holdings plc",134.0),("BNP Paribas",134.77),("Groupe Credit Agricole",135.75),("ING Groep N.V.",137.0),
       ("Intesa Sanpaolo S.p.A.",137.6),("UniCredit S.p.A.",140.0),("Deutsche Bank AG",140.12),("Commerzbank AG",141.0),
       ("Banco Bilbao Vizcaya Argentaria, S.A.",142.0),("Lloyds Banking Group plc",144.0),("Societe Generale",146.41),
       ("Nordea Bank Abp",156.0),("Barclays PLC",157.7),("UBS Group AG",177.28),("CaixaBank, S.A.",192.99)]
med = sorted(v for _,v in lcr)[7]
rows=[]
for i,(n,v) in enumerate(lcr):
    tone = "least" if i<5 else ("most" if i>=10 else "middle")
    rows.append([n, c(f"{v:.2f}%","m1"), c(f"{v-med:+.2f}","m1"), c("100%","wbasel"),
                 c(f"{v-100:.2f}","m1","wbasel"), {"tone":tone,"v":""}])
lcr_tab = {"title":"Who it hits: liquidity channel, asked (no rule change in window) · LCR","type":"table",
 "columns":["Name","LCR, Q2 2026","vs median (pp)","Stated requirement","Distance to requirement (pp)","Position"],
 "rows":rows,
 "note":"Asked: no LCR change was found 16 Oct to 15 Nov. The 100% minimum applies to all 15 names. Median 141.00%. Groupe Credit Agricole re-requested at Q2 2026 (latest quarter returned Q3 2026). The issuer on the list, Credit Agricole S.A., has its own LCR of 141.29%, Q2 2026.",
 "note_src":["m1","wbasel"]}
# CET1 final standard (8 G-SIBs), case B
cet = [("BNP Paribas",12.97,"weaker",c("10.51% (Sep 2025, older)","rbnp"),c("2.46 (older)","m2","rbnp")),
       ("ING Groep N.V.",13.07,"weaker",c("11.03% (Dec 2025, older)","ring"),c("2.04 (older)","m2","ring")),
       ("Societe Generale",13.2,"middle",c("10.26% (Mar 2026)","rsg"),c("2.94","m2","rsg")),
       ("Deutsche Bank AG",13.92,"middle","not stated","n/a"),
       ("HSBC Holdings plc",14.1,"middle","not stated","n/a"),
       ("Barclays PLC",14.3,"middle",c("12.2% (Dec 2025, older)","rbarc"),c("2.10 (older)","m2","rbarc")),
       ("UBS Group AG",14.38,"stronger",c("10.83% (Jun 2026)","rubs"),c("3.55","m2","rubs")),
       ("Groupe Credit Agricole",17.23,"stronger","total not stated",c("6.7 (bank-stated, Mar 2026)","rca"))]
m8 = (13.92+14.1)/2
rows=[[n,c(f"{v:.2f}%","m2"),c(f"{v-m8:+.2f}","m2"),req,dist,{"tone":t,"v":""}] for n,v,t,req,dist in cet]
cet_final = {"title":"Who it hits: G-SIB window-dressing standard (Basel Committee, 16 Oct 2026) · CET1","type":"table",
 "columns":["Name","CET1, Q2 2026","vs median (pp)","Stated requirement","Distance to requirement (pp)","Position"],
 "rows":rows,
 "note":"Applies to \"banks participating in the G-SIB assessment exercise\"; the buffer falls on FSB-listed G-SIBs (27 Nov 2025). Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: only three names have a current requirement. Median 14.01%. Credit Agricole S.A.: CET1 11.30%, Q2 2026; bank-stated 2.6 pp above SREP, 31 Mar 2026.",
 "note_src":["wfsb","m2","rca","wbcbs1"]}
cons = [("BNP Paribas",12.97,cet[0][3],cet[0][4]),("ING Groep N.V.",13.07,cet[1][3],cet[1][4]),("Societe Generale",13.2,cet[2][3],cet[2][4]),
        ("Deutsche Bank AG",13.92,"not stated","n/a"),("Groupe Credit Agricole",17.23,"total not stated",cet[7][4])]
rows=[[n,c(f"{v:.2f}%","m2"),"not ranked",req,dist,"list too short to rank"] for n,v,req,dist in cons]
cet_cons = {"title":"Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1","type":"table",
 "columns":["Name","CET1, Q2 2026","vs median (pp)","Stated requirement","Distance to requirement (pp)","Position"],
 "rows":rows,
 "note":"The page names no banks; it asks whether to apply the agreed treatment of cross-border exposures within the European Banking Union, which changes scores only for banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. Credit Agricole S.A.: CET1 11.30%, Q2 2026.",
 "note_src":["wbcbs1","wfsb","m2"]}
items = [
 {"flag":"ASKED","tag":"Liquidity (LCR)","name":"All regulators","text":"No change to the LCR or its 100% minimum was published at the seven primary regulators between 16 Oct and 15 Nov 2026. Shown because you asked for the liquidity channel.","why":"","src":["wbasel"]},
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26 completes the Large Exposures changes: mandatory substitution for credit risk mitigation, a time-limited 85% of Tier 1 trading-book allowance, and no internal models for SFT exposures. Applies from 1 Jan 2028 (10 Nov 2026).","why":"","src":["wpra1"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance published, aligned with the amended AML Act ahead of the FATF evaluation. In force 1 Jan 2027 (10 Nov 2026).","why":"","src":["wfin2"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model validation, stress testing, controls and a new supervisory information element. Comments by 9 Feb 2027 (9 Nov 2026).","why":"","src":["wbcbs3"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology and draft templates for the 2027 EU-wide stress test, with requested data cut by more than 55% and a separate climate module. Launch end-Jan 2027, results end-Jul 2027 (9 Nov 2026).","why":"","src":["weba3"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on reporting simplification: first reference date moves to Dec 2027; liquidity, asset encumbrance, benchmarking and ESG reporting move to Dec 2028. Final ITS report due Dec 2026 (6 Nov 2026).","why":"The liquidity deferral concerns reporting templates, not the LCR requirement.","src":["weba2"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance under CRD VI, more proportionate, awaiting translation; application date not stated (5 Nov 2026).","why":"Moody's calls them credit positive for small EU banks; larger banks have largely adopted them already (Sector Comment, 11 Nov 2026).","src":["weba1","mv1"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consequential amendments moving cross-references and application guidance into the new consolidated guidelines. Comments by 21 Dec 2026 (5 Nov 2026). No channel-map row; set to watch by own judgment.","why":"","src":["wbcbs2"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Partial revision of Circular 2019/2 'Interest rate risks - banks' for the Basel Committee's recalibrated rate shocks and more focus on earnings effects. Comments by 15 Jan 2027 (4 Nov 2026).","why":"","src":["wfin1"]},
 {"flag":"NEW","tag":"Other","name":"European Commission","text":"Provisional political agreement on the securitisation review, amending the CRR for more risk-sensitive capital treatment and simplifying the Securitisation Regulation. Formal adoption pending; Council aims for end-2026 (22 Oct 2026).","why":"","src":["wec1"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26, SM&CR phase 2: many Senior Manager roles move to notification and Certification Regime assessments go, subject to the FSM Bill. Comments by 22 Jan 2027 (22 Oct 2026).","why":"","src":["wpra2"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"G-SIB banks must report and disclose stock indicators as yearly averages, not year-end values, to curb window dressing. Effective 1 Jan 2030 (16 Oct 2026).","why":"Changes how G-SIB scores, and so G-SIB buffers, are measured: CET1 channel.","src":["wbcbs1"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"G-SIB methodology review: whether to apply the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 Jan 2027 (16 Oct 2026).","why":"Could lower scores, and buffers, for banking-union G-SIBs: CET1 channel.","src":["wbcbs1"]},
 {"flag":"NEW","tag":"Other","name":"Basel Committee","text":"G-SIB reporting and disclosure threshold agreed to rise from EUR 200bn to EUR 350bn leverage exposure, from 2027 (16 Oct 2026).","why":"","src":["wbcbs1"]},
]
eu = "11 EU/EEA names"
watch = {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":[
 ["PRA large exposures (PS20/26)","HSBC, Barclays, Lloyds","Large exposures",W()],
 ["FINMA AML ordinance","UBS","AML",W()],
 ["Basel IRRBB Pillar 2 guidance","All 15, once applied","IRRBB",W()],
 ["EBA 2027 stress test","Scope not known (sample unnamed)","Stress test",W()],
 ["EBA reporting timelines",eu,"Reporting",W()],
 ["EBA governance guidelines",eu,"Governance",W()],
 ["Basel consolidated guidelines amendments","All 15, once applied","None (drafting)",W()],
 ["FINMA interest rate risk circular","UBS","IRRBB",W()],
 ["EU securitisation review",eu,"Securitisation",W()],
 ["PRA SM&CR phase 2","HSBC, Barclays, Lloyds","Governance, conduct",W()],
 ["Basel G-SIB reporting threshold","Scope not known (size test)","Reporting",W()]]}
F = lambda id,title,date,url: {"id":id,"kind":"web","title":title,"date":date,"url":url}
R = lambda id,bank,filing,asof,date: {"id":id,"kind":"moodys","tool":"searchCompanyFilings","title":f"{bank} stated CET1 requirement","ref":f"bank sector file, pulled 15 Nov 2026: {filing}, as of {asof}","date":date}
sources = [
 {"id":"m1","kind":"moodys","tool":"getEntityFinancials_v2","title":"LCR, 15 banks","ref":"Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026","date":"2026-06-30"},
 {"id":"m2","kind":"moodys","tool":"getEntityFinancials_v2","title":"CET1, 15 banks","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026","date":"2026-06-30"},
 R("rubs","UBS Group AG","Second quarter 2026 report","30 Jun 2026","2026-06-30"),
 R("rsg","Societe Generale","First quarter 2026 results","31 Mar 2026 (column undated)","2026-03-31"),
 R("rca","Groupe Credit Agricole","First quarter 2026 results slides, filed under Credit Agricole S.A.","31 Mar 2026","2026-03-31"),
 R("rbnp","BNP Paribas","Third quarter 2025 report","30 Sep 2025","2025-09-30"),
 R("rbarc","Barclays PLC","Annual report on Form 20-F for 2025","31 Dec 2025","2025-12-31"),
 R("ring","ING Groep N.V.","Annual report on Form 20-F for 2025","31 Dec 2025","2025-12-31"),
 {"id":"mv1","kind":"moodys","tool":"searchAllDocuments","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","ref":"PBC_1502042, Sector Comment","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"},
 F("wbasel","Basel Framework (LEV, LCR, NSF standards)","","https://www.bis.org/basel_framework/"),
 F("wfsb","FSB, 2025 List of Global Systemically Important Banks (G-SIBs)","2025-11-27","https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"),
 F("wbcbs1","Basel Committee finalises measures to address window-dressing in the G-SIB framework and consults on G-SIB methodology review","2026-10-16","https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib"),
 F("wbcbs2","Consolidated guidelines - consequential amendments","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"),
 F("wbcbs3","Interest rate risk in the banking book - additional Pillar 2 guidance","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"),
 F("weba1","EBA publishes revised Guidelines on internal governance","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"),
 F("weba2","EBA outlines next steps on supervisory reporting simplification and extends implementation timelines","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"),
 F("weba3","EBA streamlines the 2027 EU-wide stress test","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"),
 F("wec1","Commission welcomes political agreement on review of the Securitisation Framework","2026-10-22","https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"),
 F("wpra1","PS20/26 Amendments to the Large Exposures Framework - Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"),
 F("wpra2","CP14/26 Review of the SM&CR - Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"),
 F("wfin1","FINMA consultation on partially revised Circular 2019/2 Interest rate risks - banks","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"),
 F("wfin2","FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"),
]
run = {"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15,"label":"Banks Europe, 30 days, LCR asked"},
 "status":"ok",
 "headline":"No LCR rule changed between 16 Oct and 15 Nov 2026; every bank on the list is above the 100% minimum, with HSBC (34.00 pp) and BNP Paribas (34.77 pp) closest. The only items on a Moody's metric were the Basel Committee's G-SIB changes of 16 Oct.",
 "headline_src":["m1","wbasel","wbcbs1"],
 "sections":[lcr_tab,cet_final,cet_cons,{"title":"What changed","type":"items","items":items},watch],
 "sources":sources,"unresolved":[],
 "notes":["Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "The 100% LCR minimum is the Basel III standard; EU, PRA and FINMA rules apply at home and can be higher. G-SIB scope uses the FSB list of 27 Nov 2025; no 2026 list was found on fsb.org on 15 Nov 2026.",
  "Left out (21): speeches, interviews, blogs and meeting summaries (ECB 9, SRB 4, FINMA 1, Commission 1); newsletters (Basel AML/CFT, PRA Digest); sanctions notices (FINMA 8, Commission 3); appointments (EBA Vice-Chair, Commission tokenisation group); other kinds of firm (PRA credit unions 2, Commission assurance standards, FINMA Bitcoin ETF); EBA taxonomy advice to the Commission, consumer factsheet, moved deadlines, NGFS declaration; ECB supervised-entities list; Commission investment statistics."],
 "meta":{"calls":{"moodys":3,"web":22}}}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
