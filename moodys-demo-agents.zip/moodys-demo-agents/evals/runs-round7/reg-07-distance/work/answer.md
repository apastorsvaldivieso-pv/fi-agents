**Regulatory watch: Banks Europe, 30 days, LCR asked** (30 days, 16 Oct to 15 Nov 2026; 15 names)

No LCR rule changed between 16 Oct and 15 Nov 2026; every bank on the list is above the 100% minimum, with HSBC (34.00 pp) and BNP Paribas (34.77 pp) closest. The only items on a Moody's metric were the Basel Committee's G-SIB changes of 16 Oct. [1][2][3]

**Who it hits: liquidity channel, asked (no rule change in window) · LCR**

| Name | LCR, Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134.00% [1] | -7.00 [1] | 100% [2] | 34.00 [1][2] | Least headroom |
| BNP Paribas | 134.77% [1] | -6.23 [1] | 100% [2] | 34.77 [1][2] | Least headroom |
| Groupe Credit Agricole | 135.75% [1] | -5.25 [1] | 100% [2] | 35.75 [1][2] | Least headroom |
| ING Groep N.V. | 137.00% [1] | -4.00 [1] | 100% [2] | 37.00 [1][2] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.60% [1] | -3.40 [1] | 100% [2] | 37.60 [1][2] | Least headroom |
| UniCredit S.p.A. | 140.00% [1] | -1.00 [1] | 100% [2] | 40.00 [1][2] | Middle |
| Deutsche Bank AG | 140.12% [1] | -0.88 [1] | 100% [2] | 40.12 [1][2] | Middle |
| Commerzbank AG | 141.00% [1] | +0.00 [1] | 100% [2] | 41.00 [1][2] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142.00% [1] | +1.00 [1] | 100% [2] | 42.00 [1][2] | Middle |
| Lloyds Banking Group plc | 144.00% [1] | +3.00 [1] | 100% [2] | 44.00 [1][2] | Middle |
| Societe Generale | 146.41% [1] | +5.41 [1] | 100% [2] | 46.41 [1][2] | Most headroom |
| Nordea Bank Abp | 156.00% [1] | +15.00 [1] | 100% [2] | 56.00 [1][2] | Most headroom |
| Barclays PLC | 157.70% [1] | +16.70 [1] | 100% [2] | 57.70 [1][2] | Most headroom |
| UBS Group AG | 177.28% [1] | +36.28 [1] | 100% [2] | 77.28 [1][2] | Most headroom |
| CaixaBank, S.A. | 192.99% [1] | +51.99 [1] | 100% [2] | 92.99 [1][2] | Most headroom |

Note: Asked: no LCR change was found 16 Oct to 15 Nov. The 100% minimum applies to all 15 names. Median 141.00%. Groupe Credit Agricole re-requested at Q2 2026 (latest quarter returned Q3 2026). The issuer on the list, Credit Agricole S.A., has its own LCR of 141.29%, Q2 2026. [1][2]

**Who it hits: G-SIB window-dressing standard (Basel Committee, 16 Oct 2026) · CET1**

| Name | CET1, Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [4] | -1.04 [4] | 10.51% (Sep 2025, older) [5] | 2.46 (older) [4][5] | Weaker third |
| ING Groep N.V. | 13.07% [4] | -0.94 [4] | 11.03% (Dec 2025, older) [6] | 2.04 (older) [4][6] | Weaker third |
| Societe Generale | 13.20% [4] | -0.81 [4] | 10.26% (Mar 2026) [7] | 2.94 [4][7] | Middle |
| Deutsche Bank AG | 13.92% [4] | -0.09 [4] | not stated | n/a | Middle |
| HSBC Holdings plc | 14.10% [4] | +0.09 [4] | not stated | n/a | Middle |
| Barclays PLC | 14.30% [4] | +0.29 [4] | 12.2% (Dec 2025, older) [8] | 2.10 (older) [4][8] | Middle |
| UBS Group AG | 14.38% [4] | +0.37 [4] | 10.83% (Jun 2026) [9] | 3.55 [4][9] | Stronger third |
| Groupe Credit Agricole | 17.23% [4] | +3.22 [4] | total not stated | 6.7 (bank-stated, Mar 2026) [10] | Stronger third |

Note: Applies to "banks participating in the G-SIB assessment exercise"; the buffer falls on FSB-listed G-SIBs (27 Nov 2025). Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the list). Ranked by level: only three names have a current requirement. Median 14.01%. Credit Agricole S.A.: CET1 11.30%, Q2 2026; bank-stated 2.6 pp above SREP, 31 Mar 2026. [3][4][10][11]

**Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1**

| Name | CET1, Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [4] | not ranked | 10.51% (Sep 2025, older) [5] | 2.46 (older) [4][5] | list too short to rank |
| ING Groep N.V. | 13.07% [4] | not ranked | 11.03% (Dec 2025, older) [6] | 2.04 (older) [4][6] | list too short to rank |
| Societe Generale | 13.20% [4] | not ranked | 10.26% (Mar 2026) [7] | 2.94 [4][7] | list too short to rank |
| Deutsche Bank AG | 13.92% [4] | not ranked | not stated | n/a | list too short to rank |
| Groupe Credit Agricole | 17.23% [4] | not ranked | total not stated | 6.7 (bank-stated, Mar 2026) [10] | list too short to rank |

Note: The page names no banks; it asks whether to apply the agreed treatment of cross-border exposures within the European Banking Union, which changes scores only for banking-union G-SIBs. Out of scope: HSBC, Barclays, UBS (G-SIBs outside the banking union) and the seven non-G-SIBs. Credit Agricole S.A.: CET1 11.30%, Q2 2026. [3][4][11]

**What changed**

- [ASKED] **All regulators** (Liquidity (LCR)): No change to the LCR or its 100% minimum was published at the seven primary regulators between 16 Oct and 15 Nov 2026. Shown because you asked for the liquidity channel. [2]
- [NEW] **PRA** (Final): PS20/26 completes the Large Exposures changes: mandatory substitution for credit risk mitigation, a time-limited 85% of Tier 1 trading-book allowance, and no internal models for SFT exposures. Applies from 1 Jan 2028 (10 Nov 2026). [12]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published, aligned with the amended AML Act ahead of the FATF evaluation. In force 1 Jan 2027 (10 Nov 2026). [13]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model validation, stress testing, controls and a new supervisory information element. Comments by 9 Feb 2027 (9 Nov 2026). [14]
- [NEW] **EBA** (Final): Final methodology and draft templates for the 2027 EU-wide stress test, with requested data cut by more than 55% and a separate climate module. Launch end-Jan 2027, results end-Jul 2027 (9 Nov 2026). [15]
- [NEW] **EBA** (Other): Next steps on reporting simplification: first reference date moves to Dec 2027; liquidity, asset encumbrance, benchmarking and ESG reporting move to Dec 2028. Final ITS report due Dec 2026 (6 Nov 2026). *Why it matters:* The liquidity deferral concerns reporting templates, not the LCR requirement. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance under CRD VI, more proportionate, awaiting translation; application date not stated (5 Nov 2026). *Why it matters:* Moody's calls them credit positive for small EU banks; larger banks have largely adopted them already (Sector Comment, 11 Nov 2026). [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments moving cross-references and application guidance into the new consolidated guidelines. Comments by 21 Dec 2026 (5 Nov 2026). No channel-map row; set to watch by own judgment. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 'Interest rate risks - banks' for the Basel Committee's recalibrated rate shocks and more focus on earnings effects. Comments by 15 Jan 2027 (4 Nov 2026). [20]
- [NEW] **European Commission** (Other): Provisional political agreement on the securitisation review, amending the CRR for more risk-sensitive capital treatment and simplifying the Securitisation Regulation. Formal adoption pending; Council aims for end-2026 (22 Oct 2026). [21]
- [NEW] **PRA** (Consultation): CP14/26, SM&CR phase 2: many Senior Manager roles move to notification and Certification Regime assessments go, subject to the FSM Bill. Comments by 22 Jan 2027 (22 Oct 2026). [22]
- [NEW] **Basel Committee** (Final): G-SIB banks must report and disclose stock indicators as yearly averages, not year-end values, to curb window dressing. Effective 1 Jan 2030 (16 Oct 2026). *Why it matters:* Changes how G-SIB scores, and so G-SIB buffers, are measured: CET1 channel. [3]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to apply the agreed treatment of cross-border exposures within the European Banking Union. Comments by 14 Jan 2027 (16 Oct 2026). *Why it matters:* Could lower scores, and buffers, for banking-union G-SIBs: CET1 channel. [3]
- [NEW] **Basel Committee** (Other): G-SIB reporting and disclosure threshold agreed to rise from EUR 200bn to EUR 350bn leverage exposure, from 2027 (16 Oct 2026). [3]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| PRA large exposures (PS20/26) | HSBC, Barclays, Lloyds | Large exposures | Watch |
| FINMA AML ordinance | UBS | AML | Watch |
| Basel IRRBB Pillar 2 guidance | All 15, once applied | IRRBB | Watch |
| EBA 2027 stress test | Scope not known (sample unnamed) | Stress test | Watch |
| EBA reporting timelines | 11 EU/EEA names | Reporting | Watch |
| EBA governance guidelines | 11 EU/EEA names | Governance | Watch |
| Basel consolidated guidelines amendments | All 15, once applied | None (drafting) | Watch |
| FINMA interest rate risk circular | UBS | IRRBB | Watch |
| EU securitisation review | 11 EU/EEA names | Securitisation | Watch |
| PRA SM&CR phase 2 | HSBC, Barclays, Lloyds | Governance, conduct | Watch |
| Basel G-SIB reporting threshold | Scope not known (size test) | Reporting | Watch |

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- The 100% LCR minimum is the Basel III standard; EU, PRA and FINMA rules apply at home and can be higher. G-SIB scope uses the FSB list of 27 Nov 2025; no 2026 list was found on fsb.org on 15 Nov 2026.
- Left out (21): speeches, interviews, blogs and meeting summaries (ECB 9, SRB 4, FINMA 1, Commission 1); newsletters (Basel AML/CFT, PRA Digest); sanctions notices (FINMA 8, Commission 3); appointments (EBA Vice-Chair, Commission tokenisation group); other kinds of firm (PRA credit unions 2, Commission assurance standards, FINMA Bitcoin ETF); EBA taxonomy advice to the Commission, consumer factsheet, moved deadlines, NGFS declaration; ECB supervised-entities list; Commission investment statistics.

**Sources**

[1] Moody's financials (getEntityFinancials_v2) · Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 · LCR, 15 banks · 2026-06-30
[2] Web · Basel Framework (LEV, LCR, NSF standards) · https://www.bis.org/basel_framework/
[3] Web · Basel Committee finalises measures to address window-dressing in the G-SIB … · 2026-10-16 · https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib
[4] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 · CET1, 15 banks · 2026-06-30
[5] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Third quarter 2025 report, as of 30 Sep 2025 · 2025-09-30
[6] Moody's (searchCompanyFilings) · ING Groep N.V. stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025, as of 31 Dec … · 2025-12-31
[7] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results, as of 31 Mar 2026 … · 2026-03-31
[8] Moody's (searchCompanyFilings) · Barclays PLC stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025, as of 31 Dec … · 2025-12-31
[9] Moody's (searchCompanyFilings) · UBS Group AG stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides, filed under … · 2026-03-31
[11] Web · FSB, 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · Interest rate risk in the banking book - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA streamlines the 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA outlines next steps on supervisory reporting simplification and extends … · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[19] Web · Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · Commission welcomes political agreement on review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
