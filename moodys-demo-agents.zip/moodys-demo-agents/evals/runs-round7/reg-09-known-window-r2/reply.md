**Regulatory watch: Banks Europe, 16 Oct-15 Nov** (16 Oct to 15 Nov 2026; 15 names)

Twelve new regulatory items from 16 Oct to 15 Nov 2026; only the Basel Committee's G-SIB package maps to a Moody's metric, and of the 8 G-SIBs it covers, BNP Paribas (CET1 12.97%) and ING (13.07%) are in the weaker third. [1][2][3]

**Who it hits: G-SIB window-dressing standard and G-SIB methodology review (BCBS, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (Q2 2026) | vs median of ranked names (pp) | Stated requirement (date) | Distance to requirement (pp) | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% [3] | -1.04 [3] | 10.51%, 30 Sep 2025, older [4] | 2.46 [3][4] | Weaker third |
| ING Groep N.V. | 13.07% [3] | -0.94 [3] | 11.03% MDA trigger, 31 Dec 2025, older [5] | 2.04 [3][5] | Weaker third |
| Societe Generale | 13.20% [3] | -0.81 [3] | 10.26%, 31 Mar 2026 [6] | 2.94 [3][6] | Middle |
| Deutsche Bank AG | 13.92% [3] | -0.09 [3] | not stated | n/a | Middle |
| HSBC Holdings plc | 14.10% [3] | +0.09 [3] | not stated | n/a | Middle |
| Barclays PLC | 14.30% [3] | +0.29 [3] | 12.2% excl. PRA buffer, 31 Dec 2025, older [7] | 2.10 [3][7] | Middle |
| UBS Group AG | 14.38% [3] | +0.37 [3] | 10.83% going-concern, 30 Jun 2026 [8] | 3.55 [3][8] | Stronger third |
| Groupe Credit Agricole | 17.23% [9] | +3.22 [3][9] | total not stated | 6.7, bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers G-SIBs: the 8 names on the FSB list of 27 Nov 2025. Out of scope: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on that list). Banks in the wider assessment sample report scores; the buffer falls only on listed banks. Ranked by level: only 3 have a current requirement. Issuer on the list is Credit Agricole S.A.: CET1 11.3% (Q2 2026), 2.6 pp above SREP (31 Mar 2026). [3][10][11]

**What changed**

- [NEW] **PRA** (Final): PS20/26 finalises the rest of the large exposures reforms, including mandatory substitution for credit risk mitigation and a smaller trading book excess allowance. Effective 1 Jan 2028. Channel: large exposures. *Why it matters:* Covers HSBC, Barclays and Lloyds; concentration limits, no Moody's metric. [12]
- [NEW] **FINMA** (Final): Partially revised Anti-Money Laundering Ordinance, recognising the banks' updated due-diligence code as a minimum standard. In force 1 Jan 2027. Channel: AML. [13]
- [NEW] **Basel Committee** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded gains and losses, earnings indicators and new supervisory reporting. Comments by 9 Feb 2027. Channel: IRRBB. [14]
- [NEW] **EBA** (Final): 2027 EU-wide stress test methodology finalised, with more than 55% fewer data points and a separate climate module. Launch end Jan 2027, results end Jul 2027. Channel: stress testing. *Why it matters:* Sample not given on the page. [15]
- [NEW] **EBA** (Other): Next steps on supervisory reporting simplification: first reference date moves to Dec 2027; liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final ITS report due Dec 2026. Channel: reporting. [16]
- [NEW] **EBA** (Final): Revised Guidelines on internal governance (EBA/GL/2026/10) reflecting CRD VI, with more proportionality; application date not stated on the page. Channel: governance. *Why it matters:* Moody's: credit positive for EU banks, more so for smaller ones (Sector Comment, 11 Nov 2026). [17][18]
- [NEW] **Basel Committee** (Consultation): Consequential amendments pointing Basel Framework cross-references to the new consolidated guidelines and moving some application guidance there. Comments by 21 Dec 2026. Channel: none mapped. [19]
- [NEW] **FINMA** (Consultation): Partial revision of Circular 2019/2 on banks' interest rate risk, applying the Basel Committee's recalibrated rate shocks (Jul 2024) with more focus on earnings. Comments by 15 Jan 2027. Channel: IRRBB. [20]
- [NEW] **European Commission** (Other): Political agreement on the securitisation framework review, simplifying the Securitisation Regulation and making the CRR treatment of securitisations more risk-sensitive. Formal adoption pending; aim end 2026. Channel: securitisation. [21]
- [NEW] **PRA** (Consultation): CP14/26, SM&CR review phase 2: most Senior Manager Functions to a notification regime, certification requirements cut. Responses by 22 Jan 2027. Channel: governance. [22]
- [NEW] **Basel Committee** (Final): G-SIB score indicators to be reported and disclosed as averages over the year, not year-end values, by 1 Jan 2030; leverage exposure reporting threshold rises to EUR 350bn from 1 Jan 2027. Channel: G-SIB buffer, CET1. *Why it matters:* Targets year-end window dressing that can lower G-SIB scores and buffers. [1]
- [NEW] **Basel Committee** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 Jan 2027. Channel: G-SIB buffer, CET1. *Why it matters:* Bears on scores of banking-union G-SIBs: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING. [2]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| IRRBB Pillar 2 guidance (BCBS, 9 Nov); Circular 2019/2 (FINMA, 4 Nov) [14][20] | BCBS: all 15 once applied at home; FINMA: UBS | IRRBB sensitivity (EVE, NII) | Watch |
| Large exposures PS20/26 (PRA, 10 Nov) [12] | HSBC, Barclays, Lloyds | Large exposures | Watch |
| Securitisation framework agreement (EC, 22 Oct) [21] | 11 EU/EEA names: BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea | Securitisation exposures | Watch |
| 2027 EU-wide stress test (EBA, 9 Nov) [15] | Scope not known: EU/EEA names in the EBA sample, not given on the page | Stress test results | Watch |
| Internal governance guidelines (EBA, 5 Nov); SM&CR CP14/26 (PRA, 22 Oct) [17][22] | EBA: the 11 EU/EEA names; PRA: HSBC, Barclays, Lloyds | None (governance) | Watch |
| Reporting simplification (EBA, 6 Nov) [16] | The 11 EU/EEA names | None (reporting) | Watch |
| AML Ordinance (FINMA, 10 Nov) [13] | UBS | None (AML) | Watch |
| Consolidated guidelines amendments (BCBS, 5 Nov) [19] | All 15 once applied at home | None (cross-references) | Watch |

Note: Moody's financial data carries no field for these channels, so no name is given a position.

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- Left out (21): speeches, news and statements (ECB, SRB, EC, FINMA); newsletters (BCBS, PRA); sanctions notices; ECB periodic list; EBA appointment, deadline move, consumer and advice items; EC statistics; items for other firms.
- Moody's research searched for the G-SIB, securitisation, IRRBB and stress test items returned no comment on them; only the EBA governance guidelines have one.
- The FSB's 2026 G-SIB list was not yet published on 15 Nov 2026, so the 27 Nov 2025 list is used. Banco Santander, a G-SIB, is not on this coverage list.

**Sources**

[1] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[2] Web · BCBS: Global systemically important banks - methodology review (consultative … · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026 (period end 30 Jun 2026), … · Bank Focus financials, coverage list · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Third quarter 2025 report, as of 30 Sep 2025 · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING Groep N.V. stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025, as of 31 Dec … · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results, as of 31 Mar 2026 · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays PLC stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Annual report on Form 20-F for 2025, as of 31 Dec … · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS Group AG stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Groupe Credit Agricole, Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (asked … · Groupe Credit Agricole · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole / Credit Agricole S.A. stated CET1 requirement · bank sector file, pulled 15 Nov 2026: First quarter 2026 results slides, filed under … · 2026-03-31
[11] Web · FSB: 2025 List of Global Systemically Important Banks (G-SIBs) · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[12] Web · PRA PS20/26 Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[13] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[14] Web · BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[15] Web · EBA streamlines 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[16] Web · EBA outlines next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[17] Web · EBA publishes revised Guidelines on internal governance · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[18] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[19] Web · BCBS: Consolidated guidelines - consequential amendments · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[20] Web · FINMA consultation on partially revised Circular 2019/2 Interest rate risks - … · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[21] Web · Commission welcomes political agreement on review of the Securitisation … · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en
[22] Web · PRA CP14/26 Review of the SM&CR - Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper

Regulatory watch tab updated 15 Nov 2026, 22:17 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r2/dashboard/dashboard.html. Not published to the private link in this session.
