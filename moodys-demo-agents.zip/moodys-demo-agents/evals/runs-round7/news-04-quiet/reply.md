**Daily sector news: Telecoms, Europe: Proximus, Telekom Austria, Swisscom** (24h to 15 Nov 2026 22:18 UTC (from 14 Nov 2026 22:18 UTC); 3 names)

Nothing material for Telecoms, Europe, in the last 24 hours.

Dashboard: "Daily sector news" tab updated 15 Nov 2026 22:19 UTC, /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-04-quiet/dashboard/dashboard.html
