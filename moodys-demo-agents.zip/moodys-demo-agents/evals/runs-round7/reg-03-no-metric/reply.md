**Regulatory watch: Banks Europe, 30 days** (30 days, 16 Oct to 15 Nov 2026; 15 names)

The EBA's revised internal governance guidelines (final, 5 Nov) cover all 11 EU-headquartered banks on your list; HSBC, Barclays, Lloyds and UBS are outside at group level. Moody's data carries no governance metric, so no bank is ranked on it. [1][2]

**Who it hits: G-SIB window-dressing standard and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 ratio (as reported, Q2 2026) | vs median of ranked names | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% (Q2 2026) [3] | -1.04 pp [3] | 10.51%, 30 Sep 2025, older [4] | 2.46 pp (older) [3][4] | Weaker third |
| ING Groep N.V. | 13.07% (Q2 2026) [3] | -0.94 pp [3] | 11.03% MDA trigger, 31 Dec 2025, older [5] | 2.04 pp (older) [3][5] | Weaker third |
| Societe Generale | 13.20% (Q2 2026) [3] | -0.81 pp [3] | 10.26%, vs 31 Mar 2026 [6] | 2.94 pp [3][6] | Middle |
| Deutsche Bank AG | 13.92% (Q2 2026) [3] | -0.09 pp [3] | not stated | not stated | Middle |
| HSBC Holdings plc | 14.10% (Q2 2026) [3] | +0.09 pp [3] | not stated | not stated | Middle |
| Barclays PLC | 14.30% (Q2 2026) [3] | +0.29 pp [3] | 12.2%, 31 Dec 2025, older [7] | 2.10 pp (older) [3][7] | Middle |
| UBS Group AG | 14.38% (Q2 2026) [3] | +0.37 pp [3] | 10.83% going-concern, 30 Jun 2026 [8] | 3.55 pp [3][8] | Stronger third |
| Groupe Credit Agricole | 17.23% (Q2 2026) [9] | +3.22 pp [3][9] | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 [10] | Stronger third |

Note: Covers G-SIBs (G-SIB buffer); the wider assessment sample reports scores. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three current requirements. Credit Agricole S.A. on its own: 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026). [3][10][11][12][13]

**What changed**

- [NEW] **PRA, 10 Nov** (Final): PS20/26 finalises large exposures changes: no internal models for SFT exposure values, mandatory credit risk mitigation substitution. Takes effect 1 Jan 2028. Covers HSBC, Barclays, Lloyds. [14]
- [NEW] **FINMA, 10 Nov** (Final): Revised AMLO-FINMA, aligned to amended AML law ahead of the FATF evaluation; in force 1 Jan 2027. Covers UBS. [15]
- [NEW] **Basel Committee, 9 Nov** (Consultation): Additional Pillar 2 guidance on interest rate risk in the banking book, plus supervisory reporting to spot excessive exposures earlier. Comments by 9 Feb 2027. [16]
- [NEW] **EBA, 9 Nov** (Final): Final 2027 EU-wide stress test methodology (templates still draft) with over 55% fewer data points and a climate module outside the core results. Launch end Jan 2027, results end Jul 2027. [17]
- [NEW] **EBA, 6 Nov** (Other): Supervisory reporting simplification: first reference date moved to Dec 2027; liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final ITS report due Dec 2026. [18]
- [NEW] **EBA, 5 Nov** (Final): Revised Guidelines on internal governance under the CRD (EBA/GL/2026/10) replace the 2021 guidelines, align with CRD VI and DORA, add chapters on corporate-structure transparency and the supervisory function, and set a framework for third-country branches. Final, awaiting translation; no application date on the page. *Why it matters:* Moody's calls the revisions credit positive for EU banks, more so for smaller ones, as larger banks already apply most of them. [1][2][19]
- [NEW] **Basel Committee, 5 Nov** (Consultation): Consequential amendments repointing Basel Framework cross-references to the new consolidated guidelines. Comments by 21 Dec 2026. Editorial; no channel. [20]
- [NEW] **FINMA, 4 Nov** (Consultation): Revised Circular 2019/2 on banks' interest rate risk, implementing the Basel Committee's recalibrated shocks of July 2024. Consultation to 15 Jan 2027. Covers UBS. [21]
- [NEW] **PRA, 22 Oct** (Consultation): CP14/26, SM&CR Phase 2: about half of senior manager functions would move from pre-approval to notification and the Certification Regime would be scaled back. Responses by 22 Jan 2027. Covers HSBC, Barclays, Lloyds. [22]
- [NEW] **European Commission, 22 Oct** (Legislative step): Political agreement on the Securitisation Framework review: more risk-sensitive CRR capital treatment, lighter due diligence and transparency rules. Formal adoption pending. [23]
- [NEW] **Basel Committee, 16 Oct** (Final): G-SIB score indicators to be reported as year averages rather than year-end values, to curb window dressing, by 1 Jan 2030; reporting threshold raised to EUR 350bn from 1 Jan 2027. [11]
- [NEW] **Basel Committee, 16 Oct** (Consultation): G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the banking union to the assessment. Comments by 14 Jan 2027. [12]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| EBA revised Guidelines on internal governance (5 Nov, final) | All 11 EU-headquartered banks: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Not at group level: HSBC, Barclays, Lloyds (GB), UBS (CH) [1][2] | Governance: no Moody's metric | Watch |
| PRA CP14/26 SM&CR Phase 2 (22 Oct, consultation) | HSBC, Barclays, Lloyds [22] | Governance: no Moody's metric | Watch |
| EBA 2027 EU-wide stress test (9 Nov) | EU banks in the EBA sample; the page does not list it: scope not known for the 11 EU names [17] | Stress testing: no Moody's metric | Watch |
| EBA reporting timelines (6 Nov) | The 11 EU-headquartered banks [18] | Reporting: no Moody's metric | Watch |
| EC securitisation agreement (22 Oct) | The 11 EU-headquartered banks [23] | Securitisation: no Moody's metric | Watch |
| Basel IRRBB Pillar 2 guidance (9 Nov, consultation) | All 15, once home rules apply it [16] | IRRBB: no Moody's metric | Watch |
| FINMA Circular 2019/2 IRRBB (4 Nov, consultation) | UBS [21] | IRRBB: no Moody's metric | Watch |
| FINMA AMLO-FINMA (10 Nov, final) | UBS [15] | AML: no Moody's metric | Watch |
| PRA PS20/26 large exposures (10 Nov, final) | HSBC, Barclays, Lloyds [14] | Large exposures: no Moody's metric | Watch |
| Basel consolidated guidelines amendments (5 Nov, consultation) | All 15, editorial [20] | None | Watch |

Note: EBA guidelines apply 'under the CRD' to institutions, with a separate framework for third-country branches; scope judged at group home. UK and Swiss groups' EU subsidiaries and branches fall under them locally. [1]

**Notes**

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.
- The EBA final report PDF could not be read; scope and dates come from the EBA press release and status page. No application date is stated there.
- Left out (21): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (BCBS AML/CFT, PRA Digest); sanctions notices (EC, FINMA); EBA vice-chair appointment, consumer factsheet, NGFS statement, Taxonomy advice to the Commission and moved consultation deadlines; ECB supervised-entities list and Eurogroup overview; EC statistics, banking dialogue summary, tokenisation nominations and sustainability assurance standards; PRA credit union papers; FINMA Bitcoin ETF approval.

**Sources**

[1] Web · EBA: revised Guidelines on internal governance (press release) · 2026-11-05 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and
[2] Web · EBA: Guidelines on internal governance under CRD (status page) · 2026-11-05 · https://www.eba.europa.eu/activities/single-rulebook/regulatory-activities/internal-governance/guidelines-internal-governance-under-crd
[3] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ), 15 names · CET1 ratio, coverage list · 2026-06-30
[4] Moody's (searchCompanyFilings) · BNP Paribas stated CET1 requirement · bank sector file, pulled 15 Nov 2026: BNP Paribas Third quarter 2025 report, as of 30 Sep … · 2025-09-30
[5] Moody's (searchCompanyFilings) · ING stated MDA trigger · bank sector file, pulled 15 Nov 2026: ING Annual report on Form 20-F for 2025, as of 31 … · 2025-12-31
[6] Moody's (searchCompanyFilings) · Societe Generale stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Societe Generale First quarter 2026 results, shown … · 2026-03-31
[7] Moody's (searchCompanyFilings) · Barclays stated CET1 requirement · bank sector file, pulled 15 Nov 2026: Barclays Annual report on Form 20-F for 2025, as of … · 2025-12-31
[8] Moody's (searchCompanyFilings) · UBS stated CET1 requirement · bank sector file, pulled 15 Nov 2026: UBS Second quarter 2026 report, as of 30 Jun 2026 · 2026-06-30
[9] Moody's financials (getEntityFinancials_v2) · Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period), Groupe Credit … · Groupe Credit Agricole CET1 · 2026-06-30
[10] Moody's (searchCompanyFilings) · Groupe Credit Agricole stated distance to SREP requirement · bank sector file, pulled 15 Nov 2026: Credit Agricole First quarter 2026 results slides, … · 2026-03-31
[11] Web · BCBS: Amendments to G-SIB framework to address window dressing · 2026-10-16 · https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing
[12] Web · BCBS: G-SIB methodology review (consultative) · 2026-10-16 · https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review
[13] Web · FSB: 2025 List of G-SIBs · 2025-11-27 · https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/
[14] Web · PRA PS20/26 Large Exposures Framework Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[15] Web · FINMA: partially revised AMLO-FINMA · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[16] Web · BCBS: IRRBB additional Pillar 2 guidance (consultative) · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[17] Web · EBA: 2027 EU-wide stress test streamlined · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
[18] Web · EBA: next steps on supervisory reporting simplification · 2026-11-06 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines
[19] Moody's (searchAllDocuments) · Financial Institutions - Europe: EBA's revised governance guidelines are credit … · PBC_1502042, Sector Comment · 2026-11-11
[20] Web · BCBS: Consolidated guidelines, consequential amendments (consultative) · 2026-11-05 · https://www.bis.org/publications/consolidated-guidelines-consequential-amendments
[21] Web · FINMA: consultation on Circular 2019/2 Interest rate risks - banks · 2026-11-04 · https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/
[22] Web · PRA CP14/26 Review of SM&CR Phase 2 · 2026-10-22 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper
[23] Web · European Commission: political agreement on Securitisation Framework review · 2026-10-22 · https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en

Regulatory watch tab updated 15 Nov 2026 22:16 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-03-no-metric/dashboard/dashboard.html (not published as an Artifact in this run).
