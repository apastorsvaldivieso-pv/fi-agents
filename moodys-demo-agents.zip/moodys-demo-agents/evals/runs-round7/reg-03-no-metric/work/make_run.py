import json
F="bank sector file, pulled 15 Nov 2026: "
def c(v,s,tone=None):
    d={"v":v,"src":s}
    if tone: d["tone"]=tone
    return d
def pos(t): return {"tone":t,"v":""}
cet1_rows=[
 ["BNP Paribas", c("12.97% (Q2 2026)",["m2"]), c("-1.04 pp",["m2"]), c("10.51%, 30 Sep 2025, older",["r_bnp"]), c("2.46 pp (older)",["m2","r_bnp"]), pos("weaker")],
 ["ING Groep N.V.", c("13.07% (Q2 2026)",["m2"]), c("-0.94 pp",["m2"]), c("11.03% MDA trigger, 31 Dec 2025, older",["r_ing"]), c("2.04 pp (older)",["m2","r_ing"]), pos("weaker")],
 ["Societe Generale", c("13.20% (Q2 2026)",["m2"]), c("-0.81 pp",["m2"]), c("10.26%, vs 31 Mar 2026",["r_sg"]), c("2.94 pp",["m2","r_sg"]), pos("middle")],
 ["Deutsche Bank AG", c("13.92% (Q2 2026)",["m2"]), c("-0.09 pp",["m2"]), "not stated", "not stated", pos("middle")],
 ["HSBC Holdings plc", c("14.10% (Q2 2026)",["m2"]), c("+0.09 pp",["m2"]), "not stated", "not stated", pos("middle")],
 ["Barclays PLC", c("14.30% (Q2 2026)",["m2"]), c("+0.29 pp",["m2"]), c("12.2%, 31 Dec 2025, older",["r_bar"]), c("2.10 pp (older)",["m2","r_bar"]), pos("middle")],
 ["UBS Group AG", c("14.38% (Q2 2026)",["m2"]), c("+0.37 pp",["m2"]), c("10.83% going-concern, 30 Jun 2026",["r_ubs"]), c("3.55 pp",["m2","r_ubs"]), pos("stronger")],
 ["Groupe Credit Agricole", c("17.23% (Q2 2026)",["m3"]), c("+3.22 pp",["m3","m2"]), "total not stated", c("6.7 pp, bank-stated, 31 Mar 2026",["r_gca"]), pos("stronger")],
]
items=[
 dict(flag="NEW",tag="Final",name="PRA, 10 Nov",text="PS20/26 finalises large exposures changes: no internal models for SFT exposure values, mandatory credit risk mitigation substitution. Takes effect 1 Jan 2028. Covers HSBC, Barclays, Lloyds.",src=["w10"]),
 dict(flag="NEW",tag="Final",name="FINMA, 10 Nov",text="Revised AMLO-FINMA, aligned to amended AML law ahead of the FATF evaluation; in force 1 Jan 2027. Covers UBS.",src=["w12"]),
 dict(flag="NEW",tag="Consultation",name="Basel Committee, 9 Nov",text="Additional Pillar 2 guidance on interest rate risk in the banking book, plus supervisory reporting to spot excessive exposures earlier. Comments by 9 Feb 2027.",src=["w5"]),
 dict(flag="NEW",tag="Final",name="EBA, 9 Nov",text="Final 2027 EU-wide stress test methodology (templates still draft) with over 55% fewer data points and a climate module outside the core results. Launch end Jan 2027, results end Jul 2027.",src=["w3"]),
 dict(flag="NEW",tag="Other",name="EBA, 6 Nov",text="Supervisory reporting simplification: first reference date moved to Dec 2027; liquidity, encumbrance, benchmarking and ESG reporting to Dec 2028. Final ITS report due Dec 2026.",src=["w4"]),
 dict(flag="NEW",tag="Final",name="EBA, 5 Nov",text="Revised Guidelines on internal governance under the CRD (EBA/GL/2026/10) replace the 2021 guidelines, align with CRD VI and DORA, add chapters on corporate-structure transparency and the supervisory function, and set a framework for third-country branches. Final, awaiting translation; no application date on the page.",why="Moody's calls the revisions credit positive for EU banks, more so for smaller ones, as larger banks already apply most of them.",src=["w1","w2","m1"]),
 dict(flag="NEW",tag="Consultation",name="Basel Committee, 5 Nov",text="Consequential amendments repointing Basel Framework cross-references to the new consolidated guidelines. Comments by 21 Dec 2026. Editorial; no channel.",src=["w6"]),
 dict(flag="NEW",tag="Consultation",name="FINMA, 4 Nov",text="Revised Circular 2019/2 on banks' interest rate risk, implementing the Basel Committee's recalibrated shocks of July 2024. Consultation to 15 Jan 2027. Covers UBS.",src=["w13"]),
 dict(flag="NEW",tag="Consultation",name="PRA, 22 Oct",text="CP14/26, SM&CR Phase 2: about half of senior manager functions would move from pre-approval to notification and the Certification Regime would be scaled back. Responses by 22 Jan 2027. Covers HSBC, Barclays, Lloyds.",src=["w11"]),
 dict(flag="NEW",tag="Legislative step",name="European Commission, 22 Oct",text="Political agreement on the Securitisation Framework review: more risk-sensitive CRR capital treatment, lighter due diligence and transparency rules. Formal adoption pending.",src=["w9"]),
 dict(flag="NEW",tag="Final",name="Basel Committee, 16 Oct",text="G-SIB score indicators to be reported as year averages rather than year-end values, to curb window dressing, by 1 Jan 2030; reporting threshold raised to EUR 350bn from 1 Jan 2027.",src=["w7"]),
 dict(flag="NEW",tag="Consultation",name="Basel Committee, 16 Oct",text="G-SIB methodology review: whether to add the agreed treatment of cross-border exposures within the banking union to the assessment. Comments by 14 Jan 2027.",src=["w8"]),
]
EU="BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea"
watch_rows=[
 ["EBA revised Guidelines on internal governance (5 Nov, final)", c("All 11 EU-headquartered banks: "+EU+". Not at group level: HSBC, Barclays, Lloyds (GB), UBS (CH)",["w1","w2"]), "Governance: no Moody's metric", pos("watch")],
 ["PRA CP14/26 SM&CR Phase 2 (22 Oct, consultation)", c("HSBC, Barclays, Lloyds",["w11"]), "Governance: no Moody's metric", pos("watch")],
 ["EBA 2027 EU-wide stress test (9 Nov)", c("EU banks in the EBA sample; the page does not list it: scope not known for the 11 EU names",["w3"]), "Stress testing: no Moody's metric", pos("watch")],
 ["EBA reporting timelines (6 Nov)", c("The 11 EU-headquartered banks",["w4"]), "Reporting: no Moody's metric", pos("watch")],
 ["EC securitisation agreement (22 Oct)", c("The 11 EU-headquartered banks",["w9"]), "Securitisation: no Moody's metric", pos("watch")],
 ["Basel IRRBB Pillar 2 guidance (9 Nov, consultation)", c("All 15, once home rules apply it",["w5"]), "IRRBB: no Moody's metric", pos("watch")],
 ["FINMA Circular 2019/2 IRRBB (4 Nov, consultation)", c("UBS",["w13"]), "IRRBB: no Moody's metric", pos("watch")],
 ["FINMA AMLO-FINMA (10 Nov, final)", c("UBS",["w12"]), "AML: no Moody's metric", pos("watch")],
 ["PRA PS20/26 large exposures (10 Nov, final)", c("HSBC, Barclays, Lloyds",["w10"]), "Large exposures: no Moody's metric", pos("watch")],
 ["Basel consolidated guidelines amendments (5 Nov, consultation)", c("All 15, editorial",["w6"]), "None", pos("watch")],
]
src=[
 dict(id="w1",kind="web",title="EBA: revised Guidelines on internal governance (press release)",date="2026-11-05",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"),
 dict(id="w2",kind="web",title="EBA: Guidelines on internal governance under CRD (status page)",date="2026-11-05",url="https://www.eba.europa.eu/activities/single-rulebook/regulatory-activities/internal-governance/guidelines-internal-governance-under-crd"),
 dict(id="w3",kind="web",title="EBA: 2027 EU-wide stress test streamlined",date="2026-11-09",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"),
 dict(id="w4",kind="web",title="EBA: next steps on supervisory reporting simplification",date="2026-11-06",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"),
 dict(id="w5",kind="web",title="BCBS: IRRBB additional Pillar 2 guidance (consultative)",date="2026-11-09",url="https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"),
 dict(id="w6",kind="web",title="BCBS: Consolidated guidelines, consequential amendments (consultative)",date="2026-11-05",url="https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"),
 dict(id="w7",kind="web",title="BCBS: Amendments to G-SIB framework to address window dressing",date="2026-10-16",url="https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"),
 dict(id="w8",kind="web",title="BCBS: G-SIB methodology review (consultative)",date="2026-10-16",url="https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"),
 dict(id="w9",kind="web",title="European Commission: political agreement on Securitisation Framework review",date="2026-10-22",url="https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"),
 dict(id="w10",kind="web",title="PRA PS20/26 Large Exposures Framework Part 2",date="2026-11-10",url="https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"),
 dict(id="w11",kind="web",title="PRA CP14/26 Review of SM&CR Phase 2",date="2026-10-22",url="https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"),
 dict(id="w12",kind="web",title="FINMA: partially revised AMLO-FINMA",date="2026-11-10",url="https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"),
 dict(id="w13",kind="web",title="FINMA: consultation on Circular 2019/2 Interest rate risks - banks",date="2026-11-04",url="https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"),
 dict(id="w14",kind="web",title="FSB: 2025 List of G-SIBs",date="2025-11-27",url="https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"),
 dict(id="m1",kind="moodys",tool="searchAllDocuments",ref="PBC_1502042, Sector Comment",title="Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks",date="2026-11-11",url="https://www.moodys.com/research/doc--PBC_1502042"),
 dict(id="m2",kind="moodys",tool="getEntityFinancials_v2",ref="Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ), 15 names",title="CET1 ratio, coverage list",date="2026-06-30"),
 dict(id="m3",kind="moodys",tool="getEntityFinancials_v2",ref="Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (explicit period), Groupe Credit Agricole",title="Groupe Credit Agricole CET1",date="2026-06-30"),
 dict(id="r_ubs",kind="moodys",tool="searchCompanyFilings",ref=F+"UBS Second quarter 2026 report, as of 30 Jun 2026",title="UBS stated CET1 requirement",date="2026-06-30"),
 dict(id="r_sg",kind="moodys",tool="searchCompanyFilings",ref=F+"Societe Generale First quarter 2026 results, shown against 31 Mar 2026",title="Societe Generale stated CET1 requirement",date="2026-03-31"),
 dict(id="r_bnp",kind="moodys",tool="searchCompanyFilings",ref=F+"BNP Paribas Third quarter 2025 report, as of 30 Sep 2025",title="BNP Paribas stated CET1 requirement",date="2025-09-30"),
 dict(id="r_ing",kind="moodys",tool="searchCompanyFilings",ref=F+"ING Annual report on Form 20-F for 2025, as of 31 Dec 2025",title="ING stated MDA trigger",date="2025-12-31"),
 dict(id="r_bar",kind="moodys",tool="searchCompanyFilings",ref=F+"Barclays Annual report on Form 20-F for 2025, as of 31 Dec 2025",title="Barclays stated CET1 requirement",date="2025-12-31"),
 dict(id="r_gca",kind="moodys",tool="searchCompanyFilings",ref=F+"Credit Agricole First quarter 2026 results slides, as of 31 Mar 2026",title="Groupe Credit Agricole stated distance to SREP requirement",date="2026-03-31"),
]
run=dict(schema="fi-dashboard/1",agent="reg-watch",title="Regulatory watch",updated_at="2026-11-15T22:16:15Z",
 scope=dict(label="Banks Europe, 30 days",sector="Banks",region="Europe",window="30 days, 16 Oct to 15 Nov 2026",names=15),
 status="ok",
 headline="The EBA's revised internal governance guidelines (final, 5 Nov) cover all 11 EU-headquartered banks on your list; HSBC, Barclays, Lloyds and UBS are outside at group level. Moody's data carries no governance metric, so no bank is ranked on it.",
 headline_src=["w1","w2"],
 sections=[
  dict(title="Who it hits: G-SIB window-dressing standard and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio",type="table",
   columns=["Name","CET1 ratio (as reported, Q2 2026)","vs median of ranked names","Stated requirement","Distance to requirement","Position"],
   rows=cet1_rows,
   note="Covers G-SIBs (G-SIB buffer); the wider assessment sample reports scores. Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by level: only three current requirements. Credit Agricole S.A. on its own: 11.3% (Q2 2026), 2.6 pp above SREP (bank-stated, 31 Mar 2026).",
   note_src=["w7","w8","w14","m2","r_gca"]),
  dict(title="What changed",type="items",items=items),
  dict(title="Who it hits: no Moody's metric",type="table",columns=["Item","Covers on this list","Metric needed","Call"],rows=watch_rows,
   note="EBA guidelines apply 'under the CRD' to institutions, with a separate framework for third-country branches; scope judged at group home. UK and Swiss groups' EU subsidiaries and branches fall under them locally.",note_src=["w1"]),
 ],
 sources=src, unresolved=[],
 notes=[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "The EBA final report PDF could not be read; scope and dates come from the EBA press release and status page. No application date is stated there.",
  "Left out (21): speeches, interviews and blogs (ECB, SRB, FINMA); newsletters (BCBS AML/CFT, PRA Digest); sanctions notices (EC, FINMA); EBA vice-chair appointment, consumer factsheet, NGFS statement, Taxonomy advice to the Commission and moved consultation deadlines; ECB supervised-entities list and Eurogroup overview; EC statistics, banking dialogue summary, tokenisation nominations and sustainability assurance standards; PRA credit union papers; FINMA Bitcoin ETF approval.",
 ],
 meta=dict(calls=dict(moodys=5,web=25)))
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
