**Earnings: Vodafone, recap** (H1 FY27 results (six months to 30 Sep 2026), call of 10 Nov 2026; 1 names)

Vodafone raised its FY27 guidance on 10 Nov, but company-reported net debt rose €8.1bn to €33.5bn on the VodafoneThree and Safaricom deals; Moody's-adjusted debt/EBITDA of 3.25x (FY to Mar 2026) sits 0.05x inside the 3.3x downgrade trigger. [1][2][3][4]

**Results against the credit view**

- **Upgraded** (Guidance): FY27 guidance raised: the upper end of the old ranges is now the midpoint, implying organic growth of about 7% in adjusted EBITDA and 21% in adjusted free cash flow (company-reported). The new ranges in euros are not in the excerpts returned. [1]
- **H1** (Operations): Group adjusted EBITDA grew 6.4% in H1 and Q2 service revenue 6.4% (company-reported). Germany EBITDA fell 3.2%, of which 2 points was a provision for the ECJ ruling worth about €100m; Europe EBITDA was down 1% (analyst's figure on the call). [1]
- **Not comparable** (Moody's forecast): Moody's forecasts are full-year only (FY27: debt/EBITDA 3.1x, RCF/net debt 29.4%), so the half-year cannot be marked against them. [4]
- **Up €8.1bn** (Net debt): Company-reported net debt €33,473m at 30 Sep 2026 vs €25,411m at 31 Mar 2026. Drivers: acquisitions €6,957m (VodafoneThree buyout €5,019m, 15% of Safaricom €1,379m, Safaricom net debt €537m), free cash outflow €845m, dividends €544m, buybacks €92m. [2]
- (Liquidity): Cash and short-term investments €8.4bn (€12.4bn at 31 Mar 2026); undrawn RCFs €7.6bn, maturing 2031 (€4.1bn) and 2028 (US$4.0bn). Moody's notes the facilities carry no financial covenants. [2][5]
- (Refinancing): Current borrowings €6,824m at 30 Sep 2026. Bonds rose €2,264m, mainly from new issues, and bank loans €1,195m (company-reported). [2]
- (Capex): Capital additions €3,320m in H1 vs €2,800m a year earlier (company-reported). Management does not guide to a material cut in German capital intensity; an analyst put Vodafone's possible OXG fibre JV equity injections at up to €1.2bn, which management says will be phased. [1][2]
- (Shareholder returns): Interim dividend 2.306 eurocents, up 2.5%; H1 buybacks €92m (company-reported). [2]

**Against Moody's triggers**

| Metric (Moody's-adjusted) | Latest | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x (FY to Mar 2026) [3] | below 2.5x [4] | fails to stay below 3.3x [4] | 0.75x to upgrade; 0.05x to downgrade [3][4] |
| RCF / Net Debt | 33.08% (FY to Mar 2026) [3] | above 25%, sustained [4] | towards 18% [4] | already met, by 8.1pp; 15.1pp to downgrade [3][4] |

Note: Worded triggers: upgrade if performance improves sustainably, "particularly in Germany"; downgrade on "a failure to turn around its German operations". [4]

**What it means for the rating and outlook**

- **Baa2 stable** (Position): Baa2 senior unsecured, stable outlook, affirmed 13 Oct 2026. The outlook assumes debt/EBITDA below 3.3x, RCF/net debt around 30% and net leverage in the lower half of the company's 2.25x-2.75x target range. [4][6]
- **Opinion predates results** (Timing): The credit opinion (21 Oct 2026) and the affirmation predate the 10 Nov results. Moody's-adjusted debt was €51,278m at Mar 2026; company net debt has since risen €8.1bn, which the filing attributes mainly to the VodafoneThree buyout and Safaricom stake. [2][3][4]
- (Moody's on the cause): The opinion cites "reduced financial flexibility following the buyout of VodafoneThree" as a constraint and still forecasts debt/EBITDA of 3.1x for FY27. Moody's has published no comment on these results. [4][5]

**Notes**

- Mode: recap, chosen because Moody's holds the H1 FY27 call transcript of 10 Nov 2026 (within 21 days).
- Company net debt and net leverage are Vodafone's own measures and are not the same as Moody's-adjusted debt. The filing's title says 'Q4'; it is the half-year report to 30 Sep 2026.

**Sources**

[1] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call · Earnings call transcript: Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 … · 2026-11-10
[2] Moody's (searchCompanyFilings) · Vodafone Group Plc half-year report H1 FY27 · Interim report titled 'Interim Report 2026 - Q4', half year to 30 Sep 2026, submitted 10 … · 2026-09-30
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted): Debt / EBITDA, RCF / Net Debt, period ending 31 Mar 2026 · 2026-03-31
[4] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation (Credit Opinion) · PBC_1496608, sections Summary, Upgrade, Downgrade, Outlook, Key indicators · 2026-10-21
[5] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action; search for comment on results, 1 Oct-15 Nov 2026 · 2026-10-13
[6] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-10-13

Earnings tab updated 2026-11-15 22:11 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html (not published as an Artifact in this run).
