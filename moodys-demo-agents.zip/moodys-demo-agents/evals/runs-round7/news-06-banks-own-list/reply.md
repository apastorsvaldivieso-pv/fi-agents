**Daily sector news: Santander, BNP Paribas, UniCredit** (72h to 15 Nov 2026 22:18 UTC (from 12 Nov 2026 22:18 UTC); 3 names)

UniCredit tapped the US market with a USD 3.5 billion multi-tranche bond while its Commerzbank move awaits final approvals; nothing material for Santander or BNP Paribas. [1]

**Top in the last 72 hours**

- **UniCredit** (Funding): UniCredit returned to the US funding market on 13 Nov with a USD 3.5 billion multi-tranche bond issue. *Why it matters:* Shows continued wholesale market access and adds dollar funding while the Commerzbank transaction is pending. [1]
- **UniCredit** (M&A): CEO Andrea Orcel expects the remaining regulatory approvals for the Commerzbank move by end-November and plans a Commerzbank EGM on supervisory board elections once the offer settles. *Why it matters:* Control of Commerzbank would change UniCredit's scale, capital and integration risk; Moody's has UniCredit's ratings under review. [2][3][4]

**Macro**

- Euro-area government bond yields rose on 13 Nov, with headlines that Italy might get a sovereign rating upgrade. *Why it matters:* Sovereign yields drive the value of banks' government bond holdings and Italian banks' funding costs. [5]
- Headlines on 15 Nov say the Bank of England is likely to raise rates further in 2027, and US October inflation beat forecasts with the Fed eyeing a December hike. *Why it matters:* A higher-for-longer rate path supports margins but raises refinancing costs for borrowers and asset-quality risk. [6][7]

**Sector**

- **Moody's research** (Sector Comment): Greece (not on the list), 13 Nov: Moody's says the competition commission's proposals are unlikely to erode the big four Greek banks' strong deposit franchises; deposit costs would rise only gradually. *Why it matters:* Low deposit costs underpin Greek banks' profitability and funding; the comment signals limited near-term pressure. [8]
- **Sector outlook** (Outlook): Moody's 2026 global banks outlook (3 Dec 2025) is stable. Country outlooks: Spain stable (9 Feb 2026), Italy stable (9 Feb 2026); no France banking system outlook was returned. *Why it matters:* Stable outlooks mean Moody's expects steady credit fundamentals for the home systems of Santander and UniCredit over 12-18 months. [9][10][11]

**By name**

| Name | Moody's rating | Last 72 hours |
|---|---|---|
| Banco Santander | A1 LT Issuer Rating, outlook stable [4] | No material credit news. |
| BNP Paribas | A1 LT Issuer Rating, outlook stable [4] | No material credit news. |
| UniCredit | A3 Senior Unsecured (foreign currency), ratings under review [4] | USD 3.5bn US bond issue; Commerzbank approvals expected by end-November. [1][2] |

Note: No Moody's rating action on these three names in the window. [4]

**Notes**

- Santander's news was searched under Banco Santander, S.A. (Spain), the rated entity; the results in the window held no credit news on the group.
- BNP Paribas Q3 results (28 Oct) and its November buyback were reported again in the window; that event predates the window and is not counted as new.

**Sources**

[1] Moody's (searchNews) · UniCredit stock: bank returns to US market with USD 3.5 billion issue (Ad Hoc … · 2026-11-13
[2] Moody's (searchNews) · UniCredit's Orcel Sets November Deadline as Commerzbank Balances Record … · 2026-11-15
[3] Moody's (searchNews) · Commerzbank's Buyback Tally Climbs as UniCredit Prepares to Reshape Its Board … · 2026-11-14
[4] Moody's ratings (getEntityRatings) · 2026-11-15
[5] Moody's (searchNews) · Eurozone bond yields rise; Italy might get ratings upgrade (MSN) · 2026-11-13
[6] Moody's (searchNews) · BOE likely to raise rates further in 2027 (Forex Factory) · 2026-11-15
[7] Moody's (searchNews) · US inflation exceeds forecasts in October, Fed eyes December hike (MSN) · 2026-11-15
[8] Moody's (searchAllDocuments) · Banks - Greece: competition commission's proposals unlikely to erode big four … · PBC_1502178 · 2026-11-13
[9] Moody's (searchAllDocuments) · Banks - Global: 2026 Outlook - Stable · PBC_1462959 · 2025-12-03
[10] Moody's (searchAllDocuments) · Banking System Outlook - Spain: Outlook stable · PBC_1471281 · 2026-02-09
[11] Moody's (searchAllDocuments) · Banking System Outlook - Italy: Outlook stable · PBC_1469157 · 2026-02-09

Dashboard: the "Daily sector news" tab was updated at 2026-11-15 22:19 UTC. Page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-06-banks-own-list/dashboard/dashboard.html (not published as an Artifact in this run).
