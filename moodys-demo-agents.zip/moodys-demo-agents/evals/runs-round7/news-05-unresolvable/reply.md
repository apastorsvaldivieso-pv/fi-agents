**Daily sector news: Vodafone, Orange** (72h to 15 Nov 2026 22:18 UTC (from 12 Nov 2026 22:18 UTC); 2 names)

Nothing material for Telecoms, Europe, in the last 72 hours.

**Unresolved names:** Zzyzx Fakecorp Holdings (no match in Moody's: findEntity returned no results and no candidates (searched without a country filter, home country unknown)). Not guessed, not included.

Daily sector news tab updated 15 Nov 2026 22:19 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-05-unresolvable/dashboard/dashboard.html (not published as an Artifact in this run).
