**Regulatory watch: Banks Europe, 7 days, MREL asked** (7 days, 8 to 15 Nov 2026; 15 names)

No name can be ranked on MREL: Moody's data has no MREL field. A tighter EU MREL would cover the 11 EU banks on the list, and the UK regime the 3 UK banks. No primary regulator published an MREL change from 8 to 15 Nov.

**What changed**

- [Asked] **MREL tightening** (MREL): No regulatory change to MREL was found at the primary regulators from 8 to 15 Nov; the SRB's only MREL entry was a speech. Moody's said in Sep 2026 that EU plans to bring MREL closer to TLAC would be credit negative if they reduce bail-inable debt. *Why it matters:* Moody's has commented on loosening, not tightening; it has published no view on a tighter MREL. [1][2]
- [NEW] **PRA** (Final): PS20/26 finalises Part 2 of the large exposures changes: mandatory substitution for credit risk mitigation, no internal models for SFT exposure values, a lower intragroup trading book allowance and a single higher NCLEG limit. Effective 1 Jan 2028. *Why it matters:* Concentration limits for HSBC, Barclays and Lloyds. [3]
- [NEW] **FINMA** (Final): Partially revised FINMA Anti-Money Laundering Ordinance published, narrowing the correspondent banking rule and recognising the revised bank due-diligence agreement. In force 1 Jan 2027. [4]
- [NEW] **Basel Committee** (Consultation): Proposed additional Pillar 2 guidance on interest rate risk in the banking book (model risk, stress testing, embedded gains and losses, earnings measures) and new supervisory information banks would report. Comments by 9 Feb 2027. [5]
- [NEW] **EBA** (Final): Final methodology for the 2027 EU-wide stress test, with about 55% fewer data points and a first climate module outside the core results. Launch end Jan 2027, results end Jul 2027; templates still draft. [6]

**Who it hits: no Moody's metric**

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| MREL tightening (Asked) | EU MREL: BNP Paribas, Groupe Credit Agricole, Societe Generale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea. UK MREL: HSBC, Barclays, Lloyds | MREL ratio vs requirement | Watch |
| PRA PS20/26, large exposures | HSBC, Barclays, Lloyds | Large exposures | Watch [3] |
| FINMA AML Ordinance | UBS | AML | Watch [4] |
| Basel IRRBB Pillar 2 guidance | All 15, once home rules apply it | IRRBB | Watch [5] |
| EBA 2027 stress test | EU banks in the EBA sample; the page does not list it, so scope by name not known | Stress test results | Watch [6] |

Note: Moody's financial data has no MREL, TLAC, large exposures, IRRBB or AML field, so no name is ranked. MREL scope: EU banks under the BRRD (SRB for banking-union groups); UK banks under the UK regime. UBS is out of scope: Switzerland runs its own gone-concern regime, not MREL.

**Notes**

- Left out (window 8 to 15 Nov): speeches - SRB MREL Workshop keynote, SRB conglomerates keynote; reports to another authority - SRB note to the Eurogroup, ECB written overview for the Eurogroup; not a rule - SRB and Commission notes on the banking competitiveness dialogue, EBA support for the NGFS declaration; consumer material - EBA factsheet; not addressed to banks - Commission assurance standards feedback, tokenisation nominations.
- The MREL scope is judged from the banks' home countries; the bank sector file maps no regulator to MREL because Moody's data carries no MREL field.
- Dashboard not published: test run, Artifact step skipped.

**Sources**

[1] Web · SRB news listing (MREL Workshop keynote, 10 Nov 2026) · 2026-11-10 · https://www.srb.europa.eu/en/news
[2] Moody's (searchAllDocuments) · Banking - Europe: European regulators put more resolve into bank resolution · PBC_1491385, Sector In-Depth · 2026-09-14
[3] Web · PRA PS20/26 - Amendments to the Large Exposures Framework - Part 2 · 2026-11-10 · https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
[4] Web · FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance · 2026-11-10 · https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
[5] Web · Basel Committee: Interest rate risk in the banking book - additional Pillar 2 … · 2026-11-09 · https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
[6] Web · EBA streamlines 2027 EU-wide stress test · 2026-11-09 · https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
