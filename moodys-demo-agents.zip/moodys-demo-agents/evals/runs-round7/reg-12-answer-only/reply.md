# Regulatory watch: Banks, Europe, 8 to 15 Nov 2026

**No liquidity rule changed this week. Four other measures were published, and Moody's data has no metric for any of them. On LCR, HSBC (134.00%) [1], BNP Paribas (134.77%) [1] and Groupe Credit Agricole (135.75%) [1] have the least headroom over the 100% minimum [2].**

Window: 8 to 15 Nov 2026, both days included. Scope: 15 European banks (checked coverage list).

## Who it hits: Liquidity (asked; no regulatory change in window) (Basel Committee, LCR standard) · LCR

| Name | LCR, Q2 2026 | vs median (pp) | Stated requirement | Distance to requirement | Position |
|---|---|---|---|---|---|
| HSBC Holdings plc | 134.00% [1] | -7.00 [1] | 100% (Basel LCR standard) [2] | +34.00 pp [1][2] | Least headroom |
| BNP Paribas | 134.77% [1] | -6.23 [1] | 100% [2] | +34.77 pp [1][2] | Least headroom |
| Groupe Credit Agricole | 135.75% [1] | -5.25 [1] | 100% [2] | +35.75 pp [1][2] | Least headroom |
| ING Groep N.V. | 137.00% [1] | -4.00 [1] | 100% [2] | +37.00 pp [1][2] | Least headroom |
| Intesa Sanpaolo S.p.A. | 137.60% [1] | -3.40 [1] | 100% [2] | +37.60 pp [1][2] | Least headroom |
| UniCredit S.p.A. | 140.00% [1] | -1.00 [1] | 100% [2] | +40.00 pp [1][2] | Middle |
| Deutsche Bank AG | 140.12% [1] | -0.88 [1] | 100% [2] | +40.12 pp [1][2] | Middle |
| Commerzbank AG | 141.00% [1] | 0.00 [1] | 100% [2] | +41.00 pp [1][2] | Middle |
| Banco Bilbao Vizcaya Argentaria, S.A. | 142.00% [1] | +1.00 [1] | 100% [2] | +42.00 pp [1][2] | Middle |
| Lloyds Banking Group plc | 144.00% [1] | +3.00 [1] | 100% [2] | +44.00 pp [1][2] | Middle |
| Societe Generale | 146.41% [1] | +5.41 [1] | 100% [2] | +46.41 pp [1][2] | Most headroom |
| Nordea Bank Abp | 156.00% [1] | +15.00 [1] | 100% [2] | +56.00 pp [1][2] | Most headroom |
| Barclays PLC | 157.70% [1] | +16.70 [1] | 100% [2] | +57.70 pp [1][2] | Most headroom |
| UBS Group AG | 177.28% [1] | +36.28 [1] | 100% [2] | +77.28 pp [1][2] | Most headroom |
| CaixaBank, S.A. | 192.99% [1] | +51.99 [1] | 100% [2] | +92.99 pp [1][2] | Most headroom |

Note: The Basel LCR standard covers all 15 names. None is out of scope. Median of the 15 is 141.00% [1]. Groupe Credit Agricole is measured on the group record, pulled again at Q2 2026 to match the other banks. The issuer on the list, Credit Agricole S.A., reports an LCR of 141.29% for Q2 2026 [1].

## What changed

- **FINMA, final (10 Nov).** FINMA published its partly revised Anti-Money Laundering Ordinance, recognised revised industry self-regulation as minimum standards, and issued guidance on the scope of Circular 2011/1. It takes effect on 1 Jan 2027, and the self-regulation has a four-month transition [3]. Channel: AML (`watch`).
- **PRA, final (10 Nov).** PS20/26 completes the large exposures reforms. It makes credit risk mitigation substitution mandatory, removes internal models for securities financing exposures, and sets a single 350% limit for trading-book intragroup exposures. It takes effect on 1 Jan 2028 [4]. Channel: large exposures (`watch`).
- **Basel Committee, consultation (9 Nov).** Adds Pillar 2 guidance on interest rate risk in the banking book, covering model risk, stress testing, controls, and embedded gains and losses in securities portfolios. Comments are due by 9 Feb 2027 [5]. Channel: IRRBB (`watch`).
- **EBA, final methodology (9 Nov).** The 2027 EU-wide stress test cuts requested data by 55% and adds a separate climate module that does not affect core results. Launch is at the end of Jan 2027 and results are due at the end of Jul 2027 [6]. Channel: stress testing (`watch`).
- **Asked: Liquidity (LCR).** No regulatory change to liquidity rules was found at the primary regulators in the window. It is carried into the table above.

Moody's had published no comment on any of these four items by 15 Nov.

## Who it hits: no Moody's metric

| Item | Covers on this list | Metric needed | Call |
|---|---|---|---|
| FINMA AML Ordinance (10 Nov) | UBS Group AG | none in Moody's data (AML) | watch |
| PRA PS20/26 large exposures (10 Nov) | HSBC, Barclays, Lloyds | none in Moody's data (large exposures) | watch |
| BCBS IRRBB Pillar 2 guidance, consultation (9 Nov) | All 15, once home supervisors apply it | none in Moody's data (IRRBB) | watch |
| EBA 2027 stress test methodology (9 Nov) | Scope not known: the page does not list the sample. The EU/EEA names on the list are BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. HSBC, Barclays, Lloyds and UBS are out of scope (not EU/EEA). | none in Moody's data (stress testing) | watch |

## Notes

- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact. 100% is the Basel minimum. Local rules can be higher.
- Left out as not a rule or not addressed to banks: speeches and news from the SRB (10, 11 and 13 Nov); the ECB Supervisory Board Chair's written overview for the Eurogroup (9 Nov); EBA statements and consumer material (9 and 13 Nov); and European Commission items (9, 11 and 12 Nov: a call for stakeholder nominations, a dialogue summary, and a consultation on sustainability assurance standards).
- The running item list could not be read in this session, so no item is marked NEW and nothing was added to the list.
- Dashboard not updated: there is no folder to write to, scripts cannot run, and publishing is not available.

## Sources

1. Moody's, getEntityFinancials_v2: Basel III Liquidity Coverage Ratio (LCR) (as reported), Q2 2026 (period end 30 Jun 2026), all 15 names plus Credit Agricole S.A. Groupe Credit Agricole was requested again at Q2 2026.
2. Web: Basel Framework (LEV, LCR, NSF standards), https://www.bis.org/basel_framework/
3. Web: FINMA, "FINMA publishes partially revised FINMA Anti-Money Laundering Ordinance", 10 Nov 2026, https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/
4. Web: PRA, "PS20/26 – Amendments to the Large Exposures Framework – Part 2", 10 Nov 2026, https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement
5. Web: Basel Committee, "Interest rate risk in the banking book – additional Pillar 2 guidance" (consultative), 9 Nov 2026, https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance
6. Web: EBA, "The EBA streamlines the 2027 EU-wide stress test with more than 55% reduction in requested data", 9 Nov 2026, https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data
