**Earnings: Vodafone, preview** (Next results after H1 FY27 (reported 10 Nov 2026); 1 names)

Vodafone Group Plc (Baa2 stable) has 0.05x of room under its 3.3x Moody's-adjusted debt/EBITDA downgrade trigger at FY26 (3.25x); company-reported net debt has since risen to €33.5bn from €25.4bn on the VodafoneThree and Safaricom deals, after the 21 Oct 2026 credit opinion. [1][2][3][4]

**Rating and outlook**

Baa2 senior unsecured (foreign currency), outlook stable, affirmed 13 Oct 2026. Credit opinion dated 21 Oct 2026: stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt around 30%, the lower half of the company's net leverage range and excellent liquidity. [1][3]

**What to watch against Moody's triggers**

| Metric (Moody's-adjusted) | Latest, FY to 31 Mar 2026 | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x [2] | below 2.5x [3] | fails to stay below 3.3x, sustained [3] | 0.75x to upgrade; 0.05x to downgrade [2][3] |
| RCF / Net Debt | 33.1% [2] | above 25%, sustained [3] | towards 18%, sustained [3] | already met, by 8.1pp; 15.1pp to downgrade [2][3] |

Note: Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade if "operating performance deteriorates, including a failure to turn around its German operations". [3]

**Sector metrics to watch**

| Metric | Latest value and period | Basis | Trigger it bears on |
|---|---|---|---|
| Service revenue growth | +5.8% organic H1 FY27; Q2 +6.4% [5][6] | Reported | Worded: operating performance |
| Germany | service revenue €5,483m (H1 FY26 €5,425m); adj. EBITDAaL €2,139m (€2,191m) [7] | Reported | Worded: German turnaround |
| EBITDA | €15,762m, FY26 [2] | Moody's-adjusted | Debt / EBITDA |
| Capex | capital additions €3,320m H1 FY27 (H1 FY26 €2,800m) [8] | Reported | (EBITDA - CAPEX) / Interest: 2.39x FY26, no stated trigger [2] |
| Free cash flow | -€845m H1 FY27 [8] | Reported | RCF / Net Debt |
| Net debt | €33,473m at 30 Sep 2026 (€25.4bn at 31 Mar 2026) [4][9] | Reported | Debt / EBITDA, RCF / Net Debt |
| Liquidity | cash €5.0bn plus undrawn RCF €7.6bn, 30 Sep 2026 [10] | Reported | Outlook: excellent liquidity |
| Maturities | No data not in the Moody's data returned |  |  |
| M&A, dividends, buybacks | €6,957m deals; €544m dividends; €92m buybacks, H1 FY27 [4] | Reported | RCF / Net Debt |

**What management guided on the last call**

- **FY27 guidance raised**: Adjusted EBITDAaL now €13.2-13.4bn (was €13.0-13.3bn) and adjusted FCF €2.8-3.0bn (was €2.6-2.9bn); Europe EBITDAaL kept at €7.6-7.9bn. Half Year 2027 call, 10 Nov 2026. *Why it matters:* Higher EBITDA and FCF bear directly on debt/EBITDA and RCF/net debt. [5][6]
- **Leverage target**: Company targets the lower half of a 2.25-2.75x net debt / adjusted EBITDAaL range; this is the company's measure, not Moody's-adjusted debt/EBITDA. *Why it matters:* The stable outlook assumes Vodafone stays in that lower half. [3][9]
- **Germany**: Germany H1 EBITDA fell 3.2%, 2 points of it from a provision for the ECJ ruling (about €100m); management said it is "under no illusion" about Germany and guided no material cut in German capital intensity. *Why it matters:* Germany is the named worded trigger in both directions. [6]
- **OXG fibre JV**: An analyst put Vodafone's possible equity injections into the OXG JV at up to €1.2bn (analyst's figure); management said any equity would be phased over the build. *Why it matters:* Added cash outflows would weigh on RCF/net debt. [6]

**Moody's expectations**

| Metric | 2026 | 2027F | 2028F | 2029F |
|---|---|---|---|---|
| Debt / EBITDA | 3.3x [3] | 3.1x [3] | 3.0x [3] | 2.9x [3] |
| RCF / Net Debt | 33.1% [3] | 29.4% [3] | 30.9% [3] | 31.7% [3] |
| (EBITDA - CAPEX) / Interest | 2.4x [3] | 2.6x [3] | 2.8x [3] | 3.0x [3] |

Note: Key indicators table of the 21 Oct 2026 credit opinion; F = Moody's forecast. [3]

**Notes**

- Mode: preview, as asked. Vodafone already reported H1 FY27 on 10 Nov 2026, so this preview is for the next results; a recap of the H1 FY27 results is available on request.
- The credit opinion (21 Oct 2026) and Moody's-adjusted figures (FY to 31 Mar 2026) predate the H1 FY27 results and the rise in company-reported net debt.
- Company-reported figures (net debt, EBITDAaL, FCF) are not the same measures as Moody's-adjusted debt and EBITDA.

**Sources**

[1] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-10-13
[2] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted), FY to 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[3] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, triggers, outlook, key indicators · 2026-10-21
[4] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, net debt · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, p.11 · 2026-11-10
[5] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, Outlook · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, p.3 · 2026-11-10
[6] Moody's (searchCompanyFilings) · Earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, 10 Nov 2026 · 2026-11-10
[7] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, segments · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, p.5 · 2026-11-10
[8] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, cash flow · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, p.29 · 2026-11-10
[9] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, highlights · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, pp.2 and 4 · 2026-11-10
[10] Moody's (searchCompanyFilings) · Vodafone H1 FY27 results, going concern · Interim Report 2026 - Q4 (H1 FY27, to 30 Sep 2026), submitted 10 Nov 2026, p.16 · 2026-11-10

Earnings tab updated 15 Nov 2026, 22:13 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-01-vodafone-preview/dashboard/dashboard.html. Not published to the private link in this session.
