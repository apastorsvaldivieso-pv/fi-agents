**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (both days included)**

I found 12 regulatory items in the window. All of them are new to the running list, because this is its first run. Only one item touches a metric Moody's carries: the Basel Committee's G-SIB package of 16 Oct. It contains a final rule against window dressing and a consultation reviewing the G-SIB methodology.

**Who it hits: G-SIB package (Basel Committee, 16 Oct 2026) · CET1 ratio**

The table covers the 8 G-SIBs on the list, ranked by CET1 level. It could not be ranked by headroom because only 3 of the 8 have a current stated requirement.

| Name | CET1 (Q2 2026) | vs median | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% | -1.04 | 10.51% (30 Sep 2025, older) | +2.46 pp (older) | Weaker third |
| ING Groep | 13.07% | -0.94 | 11.03% MDA trigger (31 Dec 2025, older) | +2.04 pp (older) | Weaker third |
| Societe Generale | 13.2% | -0.81 | 10.26% (vs 31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | -0.09 | not stated | not stated | Middle |
| HSBC | 14.1% | +0.09 | not stated | not stated | Middle |
| Barclays | 14.3% | +0.29 | 12.2% (31 Dec 2025, older) | +2.10 pp (older) | Middle |
| UBS | 14.38% | +0.37 | 10.83% Swiss going-concern (30 Jun 2026) | +3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | +3.22 | total not stated | +6.7 pp (bank-stated, 31 Mar 2026) | Stronger third |

- **Out of scope:** Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank and Nordea are not on the FSB G-SIB list of 27 Nov 2025. I found no 2026 list on fsb.org yet.
- **Reporting vs capital:** banks in the Basel assessment sample have to report the G-SIB indicators, but the buffer only falls on banks that are on the list.
- **Credit Agricole:** the bank on our list is Credit Agricole S.A. Its own phased-in CET1 was 11.4%, 2.6 pp above its SREP requirement at 31 Mar 2026.

**What changed (newest first)**
- **10 Nov, PRA, final:** PS20/26 changes the Large Exposures framework, effective 1 Jan 2028. It covers HSBC, Barclays and Lloyds.
- **10 Nov, FINMA, final:** revised AML Ordinance, in force 1 Jan 2027. It covers UBS.
- **9 Nov, Basel Committee, consultation:** additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB). Comments are due by 9 Feb 2027.
- **9 Nov, EBA:** final methodology for the 2027 EU-wide stress test. The exercise launches at the end of Jan 2027. The page does not name the sample of banks.
- **6 Nov, EBA:** next steps on simplifying supervisory reporting. The first reference date moves to Dec 2027, and some reporting areas move to Dec 2028.
- **5 Nov, EBA, final:** revised Guidelines on internal governance. A Moody's Sector Comment of 11 Nov calls them credit positive, mainly for smaller EU banks.
- **5 Nov, Basel Committee, consultation:** consequential amendments that move Basel Framework text into the consolidated guidelines. Comments are due by 21 Dec 2026.
- **4 Nov, FINMA, consultation:** revision of Circular 2019/2 on interest rate risk. Comments are due by 15 Jan 2027. It covers UBS.
- **22 Oct, European Commission:** political agreement on the Securitisation Framework review. It is not yet formally adopted.
- **22 Oct, PRA, consultation:** CP14/26, phase 2 of the SM&CR review. Comments are due by 22 Jan 2027.
- **16 Oct, Basel Committee, final:** G-SIB window-dressing amendments. Banks move to reporting indicators as averages by 2030, and the reporting threshold rises to EUR 350bn from 2027.
- **16 Oct, Basel Committee, consultation:** review of the G-SIB methodology, including how cross-border exposures inside the Banking Union are treated. Comments are due by 14 Jan 2027.

The 10 items without a Moody's metric are tagged `watch` (IRRBB, governance, reporting, stress test, securitisation, large exposures, AML, framework restructuring). Each one lists which names it covers.

**Notes**
- **ECB:** its press feed returned only speeches for the window, so ECB press releases may be missing.
- **Left out:** 23 entries, grouped by reason in the notes. They include speeches, newsletters, sanctions notices, appointments, credit-union papers and a moved consultation deadline.

**Dashboard:** I updated the Regulatory watch tab at 2026-11-15 21:27 UTC. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r1/dashboard/dashboard.html`. Publishing to the shared link was skipped for this test run.

*Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.*
