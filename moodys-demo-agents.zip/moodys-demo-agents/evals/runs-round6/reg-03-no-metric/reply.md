**Regulatory watch, European banks, 30 days (16 Oct to 15 Nov 2026)**

**EBA revised Guidelines on internal governance (EBA/GL/2026/10), final, published 5 Nov 2026**

- **What changed:** The guidelines are updated for CRD VI and aligned with DORA. They add a mapping of duties for board members and key function holders, a governance framework for third-country branches, clearer conflict-of-interest rules (including combined Chair and CEO roles) and more proportionality. They are final but still awaiting translation. The EBA page does not yet give an application date. ([EBA](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and))
- **Which of your banks it covers:** the 11 EU/EEA groups: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea.
- **Not covered at group level:** HSBC, Barclays, Lloyds (UK, under the PRA) and UBS (Switzerland, under FINMA). Their EU branches and subsidiaries may be covered locally through the new third-country-branch framework.
- **No ranking:** Moody's data has no governance metric, so none of these banks is ranked or positioned. The item shows as *watch*.
- **Moody's view:** A Sector Comment of 11 Nov 2026 (PBC_1502042) calls the revision credit positive for EU banks. Moody's expects a bigger effect at smaller banks, because the larger ones already follow the guidelines.

**Everything else in the window** (12 items; full detail is on the dashboard tab)

- **Basel Committee, 16 Oct:**
  - Final G-SIB window-dressing amendments, effective 1 Jan 2030.
  - G-SIB methodology review, a consultation with comments due 14 Jan 2027. It asks whether to fold the banking-union cross-border treatment into the framework.
  - Both hit the G-SIB buffer, so they are the only items ranked on a Moody's metric (CET1, Q2 2026). The eight listed G-SIBs on your list are ranked by CET1 level, because only three of them have a current stated requirement.
  - Weaker third: BNP Paribas 12.97% and ING 13.07%.
  - Stronger third: Groupe Credit Agricole 17.23% and UBS 14.38%.
  - The other seven names are not G-SIBs.
- **Watch, no Moody's metric:**
  - EBA 2027 stress-test methodology (final)
  - EBA reporting simplification, with new dates
  - Basel Committee IRRBB Pillar 2 guidance (consultation)
  - Basel Committee consolidated-guidelines amendments (consultation)
  - EU securitisation political agreement
  - PRA PS20/26 on large exposures (final)
  - PRA CP14/26 on SM&CR (consultation)
  - FINMA interest rate risk circular (consultation)
  - FINMA anti-money-laundering ordinance (final)

**Caveats**

- I could not read the EBA final report PDF, so I don't have the application date or the compliance deadline yet.
- I found no FSB 2026 G-SIB list, so the 27 Nov 2025 list is used.
- 21 publications were left out: speeches, sanctions notices, newsletters, and items for credit unions or other firms.

The Regulatory watch tab was updated at 21:27 UTC on 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-03-no-metric/dashboard/dashboard.html` (not published as an Artifact on this test run).
