**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (both days included)**

The main item is the Basel Committee's G-SIB package of 16 Oct. It finalised amendments against window dressing: G-SIB indicators will be reported as averages over the year by 1 Jan 2030, and the leverage-exposure reporting threshold rises from EUR 200bn to EUR 350bn from 1 Jan 2027. It also opened a consultation on the G-SIB methodology, with comments due 14 Jan 2027. The other 10 items have no Moody's metric, so they show as watch.

**Who it hits: G-SIB package · CET1 ratio (as reported, Q2 2026, Moody's financials)**

| Name | CET1 | vs median (14.01%) | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% | -1.04 pp | 10.51% (30 Sep 2025, older) | 2.46 pp (older) | Weaker third |
| ING Groep | 13.07% | -0.94 pp | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp (older) | Weaker third |
| Societe Generale | 13.20% | -0.81 pp | 10.26% (vs 31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | -0.09 pp | not stated | n/a | Middle |
| HSBC Holdings | 14.10% | +0.09 pp | not stated | n/a | Middle |
| Barclays | 14.30% | +0.29 pp | 12.2% (31 Dec 2025, older) | 2.10 pp (older) | Middle |
| UBS Group | 14.38% | +0.37 pp | 10.83% (30 Jun 2026) | 3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | +3.22 pp | total not stated | 6.7 pp, bank-stated (31 Mar 2026) | Stronger third |

- **Ranking:** names are ranked by CET1 level. Ranking by headroom needs a current stated requirement for at least six names, and only three have one.
- **Out of scope:** Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank and Nordea are not on the FSB G-SIB list of 27 Nov 2025. The 2026 list was not yet out.
- **Credit Agricole:** Groupe Credit Agricole is measured in place of Credit Agricole S.A. Credit Agricole S.A. on its own had a phased-in CET1 of 11.4%, 2.6 pp above its SREP requirement, at 31 Mar 2026.
- **Methodology consultation:** its banking-union cross-border question bears most on BNP, Credit Agricole, SocGen, Deutsche Bank and ING.

**What changed (all new on the running list, newest first)**
- **PRA, 10 Nov:** PS20/26, Large Exposures Part 2, is final and applies from 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **FINMA, 10 Nov:** the revised AML Ordinance is final and in force from 1 Jan 2027. Covers UBS.
- **EBA, 9 Nov:** final methodology for the 2027 EU-wide stress test, with more than 55% less data requested. Launch end Jan 2027, results end Jul 2027. The press page does not list the bank sample.
- **Basel Committee, 9 Nov:** consultation on additional Pillar 2 guidance for interest rate risk in the banking book. Comments by 9 Feb 2027.
- **EBA, 6 Nov:** reporting simplification. The final ITS report is due Dec 2026, the first reference date moves to Dec 2027, and liquidity, asset encumbrance, benchmarking and ESG reporting move to Dec 2028.
- **EBA, 5 Nov:** final revised internal governance guidelines (CRD VI). Moody's Sector Comment of 11 Nov calls them credit positive, mainly for smaller EU banks.
- **Basel Committee, 5 Nov:** consultation on consequential amendments to the consolidated guidelines (housekeeping). Comments by 21 Dec 2026.
- **FINMA, 4 Nov:** consultation on Circular 2019/2, interest rate risks for banks. Comments by 15 Jan 2027.
- **European Commission, 22 Oct:** provisional political agreement on the Securitisation Framework review, including more risk-sensitive CRR treatment. Still awaits formal adoption.
- **PRA, 22 Oct:** CP14/26, SM&CR phase 2. Comments by 22 Jan 2027.
- **Basel Committee, 16 Oct:** the G-SIB standard and the G-SIB consultation described above.

**No Moody's metric (watch):** large exposures, AML, stress testing, interest rate risk in the banking book, reporting, governance, securitisation and SM&CR. Each is mapped on the tab to the names it covers by home supervisor.

**Left out:** 21 entries that are not rules for banks: speeches, newsletters, sanctions notices, appointments, periodic lists, a moved consultation deadline, advice between authorities, and items addressed to credit unions or funds.

The Regulatory watch tab was updated at 21:28 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r2/dashboard/dashboard.html`. It was not published as an Artifact, because this is a test run.

*Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.*
