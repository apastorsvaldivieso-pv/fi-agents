**Regulatory watch: your 12 banks, 16 Oct to 15 Nov 2026 (30 days)**

**Your list.** Eight names came from the checked European banks list. I resolved the other four in Moody's, and each has a current rating. The list is saved as `banks-europe-own.json`, and the full sector list is unchanged.

| Name | Country |
|---|---|
| HSBC Holdings plc | GB |
| BNP Paribas | FR |
| Deutsche Bank AG | DE |
| UBS Group AG | CH |
| Barclays PLC | GB |
| ING Groep N.V. | NL |
| Societe Generale | FR |
| Credit Agricole S.A. (measured as Groupe Credit Agricole) | FR |
| Danske Bank A/S | DK |
| KBC Group N.V. | BE |
| Banco de Sabadell, S.A. | ES |
| Swedbank AB | SE |

Every name resolved.

**Headline.** On 16 Oct the Basel Committee finalised changes to how G-SIB buffers are measured, to stop window dressing. They cover 8 of your 12 banks. Of those 8, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios at Q2 2026.

**Who it hits: G-SIB window-dressing amendments (BCBS, final, 16 Oct) · CET1 ratio, Q2 2026**

| Name | CET1 | vs median (14.01%) | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| BNP Paribas | 12.97% | -1.04 | 10.51% (30 Sep 2025, older) | +2.46 pp | Weaker third |
| ING Groep | 13.07% | -0.94 | 11.03% MDA trigger (31 Dec 2025, older) | +2.04 pp | Weaker third |
| Societe Generale | 13.20% | -0.81 | 10.26% (31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | -0.09 | not stated | – | Middle |
| HSBC | 14.10% | +0.09 | not stated | – | Middle |
| Barclays | 14.30% | +0.29 | 12.2% (31 Dec 2025, older) | +2.10 pp | Middle |
| UBS | 14.38% | +0.37 | 10.83% (30 Jun 2026) | +3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | +3.22 | total not stated | 6.7 pp, bank-stated, 31 Mar 2026 | Stronger third |

The table ranks by CET1 level, not headroom, because only 3 of the 8 have a current stated requirement. Danske Bank, KBC Group, Banco Sabadell and Swedbank are out of scope because they are not on the FSB G-SIB list (27 Nov 2025). The FSB had not published its 2026 list by 15 Nov. Credit Agricole S.A.'s own figures are a phased-in CET1 of 11.4% and 2.6 pp above its SREP requirement, at 31 Mar 2026.

**Who it hits: G-SIB methodology review (BCBS, consultation, 16 Oct) · CET1 ratio, Q2 2026**
This covers the banking-union G-SIBs, which is my reading of the page; it does not name banks. They are BNP Paribas 12.97%, ING 13.07%, Societe Generale 13.20%, Deutsche Bank 13.92% and Groupe Credit Agricole 17.23%. Five names are too few to rank. Out of scope: HSBC, Barclays and UBS (outside the banking union), and the four non-G-SIBs.

**What changed (all new, newest first)**
- **FINMA, final, 10 Nov:** revised FINMA Anti-Money Laundering Ordinance, in force 1 Jan 2027. Covers UBS. *watch*
- **PRA, final, 10 Nov:** PS20/26 Large Exposures Part 2, which removes the internal model option for securities financing exposures and cuts trading-book and intragroup allowances to 85% of Tier 1. Applies from 1 Jan 2028. Covers HSBC and Barclays. *watch*
- **BCBS, consultation, 9 Nov:** additional Pillar 2 guidance on interest rate risk in the banking book, plus a supervisory reporting regime. Comments by 9 Feb 2027. Covers all 12 once applied at home. *watch*
- **EBA, final, 9 Nov:** 2027 EU-wide stress test methodology, with requested data cut by more than 55%. Launches end-Jan 2027, results end-Jul 2027. The page does not name the sample banks. *watch*
- **EBA, next steps, 6 Nov:** supervisory reporting simplification, with timelines pushed to Dec 2027 and Dec 2028. Covers the 9 EU/EEA names. *watch*
- **EBA, final, 5 Nov:** revised internal governance Guidelines under CRD VI. Moody's (sector comment, 11 Nov) calls them credit positive, mainly for smaller EU banks. Covers the 9 EU/EEA names. *watch*
- **BCBS, consultation, 5 Nov:** consequential amendments to the consolidated guidelines, mostly cross-reference housekeeping. Comments by 21 Dec 2026. The channel map has no row for this; I put it under watch on my own judgment. *watch*
- **FINMA, consultation, 4 Nov:** revision of Circular 2019/2 on interest rate risk, which adopts the recalibrated Basel rate shocks. Comments by 15 Jan 2027. Covers UBS. *watch*
- **PRA, consultation, 22 Oct:** CP14/26 SM&CR Phase 2, which moves about half of Senior Manager Functions to notification. Comments by 22 Jan 2027. Covers HSBC and Barclays. *watch*
- **European Commission, political agreement, 22 Oct:** securitisation framework review, amending the Securitisation Regulation and the CRR. Formal adoption is pending, so it is not yet law. Covers the 9 EU/EEA names. *watch*
- **BCBS, consultation, 16 Oct:** G-SIB methodology review. See the second table.
- **BCBS, final, 16 Oct:** G-SIB window-dressing amendments, with indicators averaged over the year by 2030. See the first table.

*watch* means Moody's data has no metric for that channel, so no bank is given a position.

**Notes**
- I left out 19 entries: speeches, newsletters, sanctions notices, statistics, consumer material and items addressed to other firms. The dashboard lists them.
- Danske Bank and Swedbank are supervised by the Danish and Swedish national supervisors. Those sites are not on the primary regulator list, so I did not search them.
- I found no ECB press release dated in the window.
- Positions show where each bank sits among the banks a rule covers, on the stated metric. They are not an estimate of impact.

**Dashboard:** the Regulatory watch tab was updated at 21:28 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html`. Publishing was skipped for this test run.
