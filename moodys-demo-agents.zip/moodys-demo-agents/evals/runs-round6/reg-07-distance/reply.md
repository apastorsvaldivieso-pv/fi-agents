**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

None of the seven primary regulators (Basel Committee, EBA, ECB, SRB, European Commission, PRA, FINMA) changed the LCR in the window. As you asked, the liquidity channel is still in "who it hits": all 15 banks are above the 100% Basel III minimum.

**Liquidity channel (asked): distance to the 100% LCR minimum, Q2 2026, as reported**

| Bank | LCR | Distance | Position |
|---|---|---|---|
| HSBC | 134.00% | +34.00 pp | Least headroom |
| BNP Paribas | 134.77% | +34.77 pp | Least headroom |
| Groupe Credit Agricole | 135.75% | +35.75 pp | Least headroom |
| ING | 137.00% | +37.00 pp | Least headroom |
| Intesa Sanpaolo | 137.60% | +37.60 pp | Least headroom |
| UniCredit | 140.00% | +40.00 pp | Middle |
| Deutsche Bank | 140.12% | +40.12 pp | Middle |
| Commerzbank | 141.00% | +41.00 pp | Middle (median) |
| BBVA | 142.00% | +42.00 pp | Middle |
| Lloyds | 144.00% | +44.00 pp | Middle |
| Societe Generale | 146.41% | +46.41 pp | Most headroom |
| Nordea | 156.00% | +56.00 pp | Most headroom |
| Barclays | 157.70% | +57.70 pp | Most headroom |
| UBS | 177.28% | +77.28 pp | Most headroom |
| CaixaBank | 192.99% | +92.99 pp | Most headroom |

Credit Agricole is measured on the group record. Credit Agricole S.A.'s own LCR is 141.29%. Local minimums can be higher than 100%. The only liquidity-related step in the window was a reporting change: the EBA deferred its new liquidity reporting requirements to December 2028.

**Capital channel (CET1): G-SIB items from the Basel Committee, 16 Oct**
- **Final standard against window dressing.** G-SIB indicators will be reported as year averages by 2030. This covers the 8 G-SIBs on the list. They are ranked by CET1 level because only 3 have a current stated requirement:
  - Weaker third: BNP Paribas (12.97%) and ING (13.07%).
  - Stronger third: UBS (14.38%) and Groupe Credit Agricole (17.23%).
- **Consultation on how cross-border exposures within the Banking Union are treated.** I counted it as covering the five banking-union G-SIBs. With only five names the list is too short to rank.

**Other items, with no Moody's metric (watch)**
- Basel Committee consultation on IRRBB Pillar 2 guidance.
- FINMA consultation on its interest-rate-risk circular.
- Basel Committee consultation on consolidated-guidelines amendments.
- EBA 2027 stress-test methodology.
- EBA reporting simplification.
- EBA governance guidelines. Moody's called these credit positive on 11 Nov, mostly for smaller banks.
- Political agreement on the EU securitisation framework.
- PRA large-exposures policy statement PS20/26.
- PRA consultation on the Senior Managers and Certification Regime (SM&CR).
- FINMA anti-money-laundering ordinance.

The positions show where each bank sits among the names a rule covers. They are not an estimate of impact.

The dashboard's Regulatory watch tab was updated at 21:28 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html`. I didn't publish it to the shared link in this run.
