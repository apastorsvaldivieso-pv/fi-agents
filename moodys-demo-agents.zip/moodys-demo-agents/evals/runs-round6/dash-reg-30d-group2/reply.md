**Regulatory watch: European banks, 30 days (16 Oct to 15 Nov 2026)**

I found 11 regulatory items in the window. None are new since the last run: the running list already held all 11, and a fresh pass over every regulator listing turned up nothing extra. Only one item maps to a Moody's metric.

**Who it hits: Basel Committee G-SIB package (16 Oct 2026) · CET1 ratio, Q2 2026**
The package has two parts. The final part reports G-SIB indicators as yearly averages from 1 Jan 2030. The consultation looks at cross-border exposures within the Banking Union, with comments due 14 Jan 2027. Only 3 of the 8 G-SIBs on the list state a current CET1 requirement, so the table ranks by CET1 level, not by headroom. The median is 14.01%.

| Name | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| BNP Paribas | 12.97% | 10.51% (Sep 2025, older) | 2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% MDA (Dec 2025, older) | 2.04 pp | Weaker third |
| Societe Generale | 13.2% | 10.26% | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | | Middle |
| HSBC | 14.1% | not stated | | Middle |
| Barclays | 14.3% | 12.2% (Dec 2025, older) | 2.10 pp | Middle |
| UBS | 14.38% | 10.83% (Jun 2026) | 3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | total not stated | 6.7 pp (bank-stated, Mar 2026) | Stronger third |

- **Out of scope:** Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank and Nordea. None of them is on the FSB G-SIB list of 27 Nov 2025, and the FSB had not yet published a 2026 list.
- **The consultation** bears on the five Banking Union G-SIBs: BNP, Credit Agricole, SocGen, Deutsche and ING.

**What changed (newest first)**
- **PRA, 10 Nov:** PS20/26 finalises the large exposures framework, Part 2. It takes effect 1 Jan 2028.
- **FINMA, 10 Nov:** the revised AML Ordinance comes into force 1 Jan 2027.
- **EBA, 9 Nov:** final methodology for the 2027 EU-wide stress test, which launches end January 2027.
- **Basel Committee, 9 Nov:** consultation on IRRBB Pillar 2 guidance. Comments are due 9 Feb 2027.
- **EBA, 6 Nov:** next steps on simplifying supervisory reporting. The first reference date is December 2027.
- **EBA, 5 Nov:** final revised guidelines on internal governance. Moody's calls them credit positive for small EU banks (Sector Comment, 11 Nov).
- **Basel Committee, 5 Nov:** consultation on consequential amendments from the consolidated guidelines. Comments are due 21 Dec 2026.
- **FINMA, 4 Nov:** consultation on Circular 2019/2, interest rate risks. It runs until 15 Jan 2027.
- **PRA, 22 Oct:** CP14/26 consults on SM&CR Phase 2. Responses are due 22 Jan 2027.
- **European Commission, 22 Oct:** political agreement on the securitisation framework review. It is not yet a final rule.
- **Basel Committee, 16 Oct:** the G-SIB package covered in the table above.

Moody's data has no metric for the last ten channels. The dashboard tags them `watch` and lists which names each rule covers. Items left out (speeches, sanctions notices, newsletters, credit-union papers and the like) are grouped by reason in the tab's notes.

One decision on the running list may need a second look. An 11 Nov ECB newsletter article describes a leaner SREP methodology for liquidity and funding risk. The list leaves it out as a newsletter.

**Dashboard:** I updated the Regulatory watch tab at 21:32 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/dash-reg-30d-group2/dashboard/dashboard.html`. It was not published as an Artifact because this is a test run.
