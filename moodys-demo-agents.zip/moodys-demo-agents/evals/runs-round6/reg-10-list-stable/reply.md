**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (both days included)**

I checked every regulator listing again and found nothing new since your last run. The same 12 items are in the window, with the same decisions, so none is marked NEW.

**Who it hits: Basel Committee G-SIB package (16 Oct) · CET1 ratio, Q2 2026**
The final window-dressing amendments and the methodology review consultation hit the G-SIB buffer, so only the 8 G-SIBs on the list are in the table. The table is ranked by CET1 level, not by headroom, because only 3 of the 8 have a current stated requirement.
- Weaker third: BNP Paribas 12.97%, ING 13.07%
- Middle: Societe Generale 13.2%, Deutsche Bank 13.92%, HSBC 14.1%, Barclays 14.3%
- Stronger third: UBS 14.38%, Groupe Credit Agricole 17.23%
- Out of scope (not on the FSB G-SIB list of 27 Nov 2025; I found no 2026 list): Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea.

**What changed, newest first** (Moody's has no metric for these channels, so they are shown as watch)
- PRA PS20/26, large exposures part 2: final, effective 1 Jan 2028. Covers HSBC, Barclays, Lloyds.
- FINMA, revised AML Ordinance: final, in force 1 Jan 2027. Covers UBS.
- Basel Committee, IRRBB Pillar 2 guidance: consultation, comments by 9 Feb 2027.
- EBA, 2027 EU-wide stress test: methodology final, templates still draft.
- EBA, reporting simplification next steps: the first reference date moves to Dec 2027.
- EBA, revised internal governance guidelines: final. Moody's said on 11 Nov that they are credit positive, mostly for smaller banks.
- Basel Committee, consolidated guidelines consequential amendments: consultation, comments by 21 Dec 2026.
- FINMA, Circular 2019/2 IRRBB revision: consultation, comments by 15 Jan 2027.
- EU Securitisation Framework review: political agreement only, not yet final law.
- PRA CP14/26, SM&CR phase 2: consultation, comments by 22 Jan 2027.
- Basel Committee, G-SIB window-dressing amendments (final) and G-SIB methodology review (consultation): see the table above.

Notes: The Basel Committee's listing links its 19 Oct AML newsletter to a page whose address names the BCBS 239 principles, so that link on the running list may be wrong. The ECB press feed again showed only speeches.

I updated the Regulatory watch tab at 21:32 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-10-list-stable/dashboard/dashboard.html`. This was a test run, so I did not publish it to the shared link.
