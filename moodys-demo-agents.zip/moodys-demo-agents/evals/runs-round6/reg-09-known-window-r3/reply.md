**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (both days included)**

I read the regulators' own listings for every entry in the window: Basel Committee, EBA, ECB Banking Supervision, SRB, European Commission, PRA and FINMA. 12 items affect the 15 banks on the list, and all are new to the running list. Each one was checked on the regulator's own page.

**Headline:** On 16 Oct the Basel Committee finalised its G-SIB window-dressing rules, which average the score indicators and must be in place by 1 Jan 2030. On the same day it opened a consultation on the G-SIB methodology. Of the eight G-SIBs on the list, BNP Paribas (12.97%) and ING (13.07%) have the lowest CET1 ratios at Q2 2026 (Moody's data, as reported).

**Who it hits: G-SIB window-dressing amendments (final) · CET1, Q2 2026**
These are ranked by CET1 level, not by headroom: only 3 of the 8 banks have a stated requirement that applies in 2026.

| Name | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | 2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp | Weaker third |
| Societe Generale | 13.20% | 10.26% (vs 31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | – | Middle |
| HSBC | 14.10% | not stated | – | Middle |
| Barclays | 14.30% | 12.2% (31 Dec 2025, older) | 2.10 pp | Middle |
| UBS | 14.38% | 10.83% (30 Jun 2026) | 3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | total not stated | 6.7 pp, bank-stated (31 Mar 2026) | Stronger third |

Groupe Credit Agricole is measured in place of Credit Agricole S.A., whose own CET1 was 11.30% at Q2 2026. Seven banks are out of scope because they are not on the FSB's G-SIB list of 27 Nov 2025: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. I found no 2026 list published yet.

**Who it hits: G-SIB methodology review (consultation, comments by 14 Jan 2027) · CET1**
The consultation is about how cross-border exposures within the banking union are treated, so I read it as covering the banking-union G-SIBs: BNP Paribas, ING, Societe Generale, Deutsche Bank and Groupe Credit Agricole. With only five banks, the list is too short to rank.

**What changed (newest first)**
- **PRA PS20/26, Large Exposures Part 2** (final, 10 Nov; applies from 1 Jan 2028). Covers HSBC, Barclays and Lloyds.
- **FINMA, revised Anti-Money Laundering Ordinance** (final, 10 Nov; in force 1 Jan 2027). Covers UBS.
- **Basel Committee, additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB)** (consultation, 9 Nov; comments by 9 Feb 2027).
- **EBA, 2027 EU-wide stress test methodology** (final, 9 Nov). The test launches at the end of January 2027 and results come out at the end of July 2027. The release does not name the sample of banks.
- **EBA, next steps on simplifying supervisory reporting** (6 Nov). The first reference date is December 2027. Some templates move to December 2028.
- **EBA, revised internal governance Guidelines** (final, 5 Nov). Moody's said on 11 Nov 2026 that these are credit positive for EU banks.
- **Basel Committee, consequential amendments to the consolidated guidelines** (consultation, 5 Nov; comments by 21 Dec 2026).
- **FINMA, consultation on Circular 2019/2 on interest rate risks** (4 Nov; comments by 15 Jan 2027). Covers UBS.
- **EU Securitisation Framework review** (political agreement, 22 Oct). It still needs formal adoption.
- **PRA CP14/26, SM&CR Phase 2** (consultation, 22 Oct; comments by 22 Jan 2027).
- The two Basel G-SIB items from 16 Oct, shown in the tables above.

Ten of these items carry no Moody's metric and are marked `watch`. They cover large exposures, AML, IRRBB, stress testing, reporting, governance, securitisation and the Basel framework structure. I left out 19 listing entries: speeches, newsletters, sanctions notices, statistics, consumer material and items for other kinds of firm. They are grouped in the run notes.

The Regulatory watch tab was updated at 21:28 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r3/dashboard/dashboard.html`. This is a test run, so I didn't publish it to the shared link.
