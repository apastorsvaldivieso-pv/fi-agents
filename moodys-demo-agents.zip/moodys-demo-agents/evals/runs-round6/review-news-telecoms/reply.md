**European telecoms: sector news brief, last 7 days**
Window: 168h, 8 Nov 2026 21:46 UTC to 15 Nov 2026 21:46 UTC. Coverage: the checked 15-name Telecoms Europe list. All names resolved.

**Top this week**
1. **Telia (Baa1 Senior Unsecured, stable).** On 12 Nov Telia signed a binding agreement to buy Telavox's Nordic enterprise customer base for SEK 3.8bn, plus an earn-out of up to SEK 0.2bn. The base brings about SEK 1.1bn of annual revenue (company figure). The articles did not say how it will be funded. *Credit:* a cash outflow this size weighs on RCF / net debt unless it is paid from cash on hand.
2. **Telenor (Baa1 Senior Unsecured, positive).** Telenor Sverige bought 57.5% of Bahnhof, reported at USD 363m, and is running a mandatory cash offer at SEK 62 a share. The offer was announced on 6 Nov, before the window. On 13 Nov Bahnhof's board committee recommended that shareholders accept, and Telenor now holds about 66.9% of the shares and 90.6% of the votes. *Credit:* this is acquisition spending while the outlook is positive. Leverage after the deal is what to measure against Moody's upgrade factors.
3. **Telefonica (Baa3, stable) and Vodafone (Baa2, stable) raised guidance.** With its Q3 results on 12 Nov, Telefonica raised its guidance for adjusted EBITDA, operating cash flow after leases and free cash flow. Q3 net income was EUR 802m, against EUR 276m a year earlier. Vodafone's half-year results raised its full-year profit and cash flow guidance. All of these figures are company-reported. *Credit:* higher free cash flow gives both more room to cut debt and supports RCF / net debt.

**Macro**
- On 9 Nov Moody's published its 2027 global credit conditions outlook. It says credit will weaken because higher rates and energy costs outweigh the AI tailwind. This matters most for Altice France and VMED O2, which have to refinance at high-yield rates.
- Euro area bond yields rose on 13 Nov, which makes new and refinanced debt more expensive.

**Sector**
- Moody's took no rating action on European telecoms in the window and published no research on any name on the list.
- VMED O2 is still on review for downgrade, which started on 22 Oct.
- The latest Moody's sector outlook is Telecommunications – Global, dated 27 Oct 2026: **stable**. Solid demand and falling capital intensity offset refinancing pressure.

**By name**
| Name | Moody's rating | Last 7 days |
|---|---|---|
| Deutsche Telekom | A3 Senior Unsecured, stable | No material credit news (Q3 results came out on 5 Nov, before the window). |
| Orange | Baa1 LT Issuer, stable | No material credit news. |
| Vodafone | Baa2 Senior Unsecured, stable | Half-year results; full-year profit and cash flow guidance raised. |
| Telefonica | Baa3 Senior Unsecured, stable | Q3 results; EBITDA, operating cash flow and free cash flow guidance raised. |
| Swisscom | A2 LT Issuer, stable | No material credit news. |
| Telekom Austria | A3 LT Issuer, stable | No material credit news. |
| Proximus | A3 Senior Unsecured, stable | No material credit news. |
| Telenor | Baa1 Senior Unsecured, positive | Holds about 66.9% of Bahnhof; mandatory offer running for the rest. |
| Telia | Baa1 Senior Unsecured, stable | Buying Telavox's Nordic enterprise customer base for SEK 3.8bn (+ up to SEK 0.2bn earn-out). |
| TIM | Baa3 LT Issuer, positive | 9M results: 2026 targets kept; 9M net loss attributable of EUR 205m (EUR 109m a year earlier). New CEO at Sparkle from 1 Dec. |
| PPF Telecom | Baa2 LT Issuer, stable | No material credit news. |
| BT Group (rated at British Telecommunications Ltd) | Baa2 LT Issuer, stable | Openreach chair to step down on 31 Mar 2027 and be succeeded by Michael Jary. |
| Iliad | Ba1 Senior Unsecured, stable | No material credit news. |
| VMED O2 UK | B1 CFR, on review for downgrade | No material credit news. |
| Altice France | Caa1 Senior Secured Bank Credit Facility, positive | No material credit news. |

Ratings come from Moody's getEntityRatings, and the rating type is the one Moody's returned for each name. All results figures are company-reported, not Moody's-adjusted.

**Dashboard:** I updated the "Daily sector news" tab at 15 Nov 2026 21:48 UTC. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review-news-telecoms/dashboard/dashboard.html`. This is a test run, so I did not publish it to the Artifact link.
