**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, both days included)**

I found 12 regulatory items in the window. All are new to the running list and each was checked on the regulator's own page. Two of them touch a metric Moody's holds (CET1). The other ten have no Moody's metric and are tracked as `watch`.

**Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct, final) · CET1, Q2 2026**
This covers the 8 G-SIBs on the list. They are ranked by CET1 level, not headroom, because only 3 of them have a current stated requirement.

| Name | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | 2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp | Weaker third |
| Societe Generale | 13.2% | 10.26% (31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | – | Middle |
| HSBC | 14.1% | not stated | – | Middle |
| Barclays | 14.3% | 12.2% (31 Dec 2025, older) | 2.10 pp | Middle |
| UBS Group | 14.38% | 10.83% (30 Jun 2026) | 3.55 pp | Stronger third |
| Groupe Credit Agricole | 17.23% | total not stated | 6.7 pp (bank-stated, 31 Mar 2026) | Stronger third |

- The median CET1 of these 8 names is 14.01%.
- Out of scope: Lloyds, UniCredit, Intesa, BBVA, CaixaBank, Commerzbank and Nordea. None is on the FSB G-SIB list of 27 Nov 2025, and the 2026 list was not yet out.
- Credit Agricole S.A.'s own CET1 is 11.3%, and it states it is 2.6 pp above its SREP requirement.

**Who it hits: G-SIB methodology review, banking-union exposures (Basel Committee, 16 Oct, consultation) · CET1**
This covers the 5 banking-union G-SIBs, which is too few to rank:

| Name | CET1 |
|---|---|
| BNP Paribas | 12.97% |
| ING | 13.07% |
| Societe Generale | 13.2% |
| Deutsche Bank | 13.92% |
| Groupe Credit Agricole | 17.23% |

The Committee's page does not say who the consultation covers. I limited it to banking-union G-SIBs because the change concerns exposures inside the banking union.

**What changed (newest first)**
- **10 Nov, PRA, final:** PS20/26, large exposures part 2. Effective 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **10 Nov, FINMA, final:** revised AML Ordinance. In force 1 Jan 2027. Covers UBS.
- **9 Nov, Basel Committee, consultation:** additional Pillar 2 guidance on interest rate risk in the banking book. Comments by 9 Feb 2027.
- **9 Nov, EBA, final:** 2027 EU-wide stress test methodology. Launches end-January 2027, results end-July 2027. The page does not say which banks are in the sample.
- **6 Nov, EBA:** reporting simplification. The first reference date moves to Dec 2027, and some templates move to Dec 2028.
- **5 Nov, EBA, final:** revised internal governance guidelines. Moody's Sector Comment of 11 Nov calls them credit positive, with more effect on smaller banks.
- **5 Nov, Basel Committee, consultation:** consequential amendments to the consolidated guidelines. Comments by 21 Dec 2026.
- **4 Nov, FINMA, consultation:** Circular 2019/2 on interest rate risks. Comments by 15 Jan 2027.
- **22 Oct, PRA, consultation:** CP14/26, SM&CR review phase 2. Comments by 22 Jan 2027.
- **22 Oct, EU, political agreement:** Securitisation Framework review, including changes to the CRR. Not yet formally adopted.
- **16 Oct, Basel Committee:** the two G-SIB items in the tables above.

I left out 21 entries in the window: speeches, newsletters, sanctions notices, appointments, items for credit unions and funds, and similar. They are saved on the running list with a reason for each.

The dashboard's Regulatory watch tab was updated at 21:28 UTC on 15 Nov 2026. The page is `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`. This test run did not publish it to a link.
