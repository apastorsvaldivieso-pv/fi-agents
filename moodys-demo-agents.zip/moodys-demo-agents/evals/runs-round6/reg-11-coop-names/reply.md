**Regulatory watch: your 10 banks, 30 days (16 Oct to 15 Nov 2026)**

I found 12 new regulatory items in the window and no change on liquidity. You asked about liquidity, so it still has its own LCR table below.

**Your names.** Seven were already on the checked bank list. I resolved the other three in Moody's, and all three have a current rating:

| Name | Country |
|---|---|
| BPCE | FR |
| DZ BANK AG | DE |
| Raiffeisen Bank International AG | AT |

BPCE, DZ Bank and RBI are each the central institution or listed arm of a co-operative group, and the Moody's record may not cover the whole group. Their values are shown but not ranked. Moody's holds no CET1 or LCR for BPCE: its latest period is Q4 2024, and asking for Q2 2026 returned nothing.

**Who it hits: Basel G-SIB window-dressing amendments (final) and G-SIB methodology review (consultation), 16 Oct · CET1, Q2 2026**
Ranked by CET1 level, because only UBS and SocGen have a current stated requirement.

| Name | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | 2.46 pp | Weaker third |
| ING | 13.07% | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp | Weaker third |
| Societe Generale | 13.20% | 10.26% (against 31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | – | Middle |
| HSBC | 14.1% | not stated | – | Middle |
| Barclays | 14.3% | 12.2% (31 Dec 2025, older) | 2.10 pp | Stronger third |
| UBS | 14.38% | 10.83% (30 Jun 2026) | 3.55 pp | Stronger third |
| BPCE | not in Moody's data | not stated | – | Not ranked |

- DZ Bank and RBI are out of scope: neither is on the FSB G-SIB list of 27 Nov 2025, and I found no 2026 list.
- The methodology consultation is about cross-border exposures inside the banking union. It bears most on BNP, Deutsche Bank, ING, SocGen and BPCE.

**Who it hits: liquidity channel (asked, no change in the window) · LCR, Q2 2026, against the 100% Basel minimum**

| Name | LCR | Distance | Position |
|---|---|---|---|
| HSBC | 134% | 34.0 pp | Least headroom |
| BNP Paribas | 134.77% | 34.77 pp | Least headroom |
| ING | 137% | 37.0 pp | Middle |
| Deutsche Bank | 140.12% | 40.12 pp | Middle |
| Societe Generale | 146.41% | 46.41 pp | Middle |
| Barclays | 157.7% | 57.7 pp | Most headroom |
| UBS | 177.28% | 77.28 pp | Most headroom |
| RBI | 143.65% | 43.65 pp | Not ranked (co-operative group) |
| DZ Bank | 148.75% | 48.75 pp | Not ranked (co-operative group) |
| BPCE | not in Moody's data | – | Not ranked |

The only liquidity-related item in the window is about reporting, not the requirement itself: the EBA moved new liquidity reporting templates to Dec 2028 (6 Nov).

**What changed (all new, newest first)**
- **PRA PS20/26** large exposures, part 2. Final, takes effect 1 Jan 2028. Covers HSBC and Barclays.
- **FINMA** revised Anti-Money Laundering Ordinance. Final, in force 1 Jan 2027. Covers UBS.
- **Basel Committee** additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB). Consultation, comments by 9 Feb 2027.
- **EBA** final methodology for the 2027 EU-wide stress test. Launches end-Jan 2027, results end-Jul 2027. I could not confirm which of your names are in the sample.
- **EBA** next steps on simplifying supervisory reporting. New requirements start Dec 2027; liquidity and some other reporting areas Dec 2028.
- **EBA** revised internal governance guidelines. Final. Moody's (11 Nov) calls them credit positive, mainly for smaller banks.
- **Basel Committee** consequential amendments for its consolidated guidelines. Consultation, comments by 21 Dec 2026.
- **FINMA** Circular 2019/2 on interest rate risks at banks. Consultation until 15 Jan 2027. Covers UBS.
- **EU** political agreement on the Securitisation Framework review. Awaits formal adoption.
- **PRA CP14/26** review of the Senior Managers and Certification Regime (SM&CR), phase 2. Consultation, comments by 22 Jan 2027. Covers HSBC and Barclays.
- **Basel Committee** G-SIB window-dressing amendments. Final; threshold change from 1 Jan 2027, average-value reporting by 1 Jan 2030.
- **Basel Committee** G-SIB methodology review. Consultation, comments by 14 Jan 2027.

Ten of these items have no Moody's metric. They are listed on the dashboard as "watch", with the names each one covers.

**Caveats**
- The ECB press feed only ran to 6 Nov and FINMA's to 10 Nov. A search found no ECB press release dated 7 to 15 Nov.
- Local LCR rules can be higher than 100%.
- Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.

The dashboard's Regulatory watch tab was updated at 21:27 UTC on 15 Nov 2026:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-11-coop-names/dashboard/dashboard.html`
