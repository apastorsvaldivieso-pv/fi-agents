**European banks: sector news brief, last 7 days**
Window: 8 Nov 2026 21:46 UTC to 15 Nov 2026 21:46 UTC (168h). Coverage: the 15-name checked European banks list.

**Top this week**
1. **UniCredit / Commerzbank.** UniCredit already has ECB approval for control of Commerzbank and expects the remaining approvals by late November. Reports say EU antitrust clearance, expected to be unconditional, is due by 16 Nov. UniCredit plans a Commerzbank EGM on board elections once the offer settles, and it raised its 2026 net profit ambition to well above EUR 11.5bn. UniCredit's A3 Senior Unsecured rating is under review. *Why it matters:* control of Commerzbank changes UniCredit's scale, capital and funding mix, and Commerzbank's ownership and governance. Moody's view will come through the open review.
2. **Credit Agricole S.A.** On 9 Nov it proposed merging CA Italia with Banco BPM, and Banco BPM's board opened talks on 13 Nov. On 13 Nov Moody's said this will likely have no immediate rating implications for CASA, Groupe Credit Agricole, Banco BPM or CA Italia. A completed merger could ultimately be positive for Banco BPM's ratings. *Why it matters:* a deal would deepen CASA's Italian exposure. For now Moody's sees no immediate effect on CASA's ratings.
3. **Italian bank levies.** On 12 Nov Intesa Sanpaolo's CEO criticised the bank levies in the 2027 budget, calling some of the measures unconstitutional. He warned the ECB may ask Italian banks to cut their sovereign exposure. The government later called it a misunderstanding. *Why it matters:* higher levies would reduce Italian banks' earnings and capital generation. Cutting sovereign holdings would change their liquidity portfolios.

**Macro**
- Euro-area and US government bond yields rose on 13 Nov. Headlines flagged a possible upgrade for Italy, with an S&P decision pending. *Why it matters:* higher yields help net interest income but lower the value of bond portfolios, and Italy's sovereign rating caps Italian banks' ratings.

**Sector (Moody's)**
- 12 Nov: Moody's upgraded the deposit ratings of VUB (Intesa's Slovak subsidiary) to A1 from A2, with the outlook moved to stable.
- 9 Nov: Moody's assigned Baa1 issuer ratings to UniCredit Bank Czech Republic and Slovakia and affirmed its A2 deposit ratings. Outlook stable.
- 11 Nov: Moody's said the EBA's revised governance guidelines are credit positive for EU banks, more so for smaller ones.
- 13 Nov (Greek banks, not on the list): Moody's said competition proposals are unlikely to erode the big four banks' deposit franchises.
- Outlook: the latest global banks outlook is stable (3 Dec 2025). Country outlooks: Germany positive (9 Feb 2026), Finland positive (9 Mar 2026), Spain, Italy, UK and Netherlands stable (Feb 2026). The search returned no outlook for France or Switzerland.

**By name**
| Name | Rating (class, outlook) | This week |
|---|---|---|
| BNP Paribas | A1 LT Issuer, stable | No material credit news. |
| HSBC Holdings | A3 Sr Unsec, positive | Issued USD 1.5bn 7.625% AT1 to refinance 6.000% AT1 via tender. |
| Credit Agricole S.A. | A1 LT Issuer, stable | Proposed CA Italia / Banco BPM merger. Moody's: no immediate rating implications. |
| Barclays | Baa1 LT Issuer, stable | Reported cutting about 200 investment bank jobs. |
| Societe Generale | A1 LT Issuer, negative | No material credit news. |
| Deutsche Bank | A1 LT Issuer, positive | BaFin EUR 8m fine over Postbank migration failures (11 Nov). |
| UBS Group | A2 Sr Unsec, stable | Swiss capital proposal goes to parliamentary commission on 23-24 Nov (reports). |
| ING Groep | Baa1 Sr Unsec, stable | OCBC reported near a USD 1.5bn deal for ING's Asian private bank (unconfirmed). |
| Lloyds Banking Group | A3 Sr Unsec, stable | USD 2.75bn senior callable notes in two tranches (2030/2032). |
| UniCredit | A3 Sr Unsec, under review | Commerzbank approvals expected by late Nov. Raised 2026 profit ambition. First US deal: USD 3.5bn senior non-preferred. |
| Intesa Sanpaolo | A3 LT Issuer, stable | Opposed budget levies. GBP 500m green senior non-preferred at UKT +130bp. Rules out foreign M&A. |
| BBVA | A2 LT Issuer, stable | EUR 1bn AT1 (9 Nov) and USD 2.05bn senior non-preferred (13 Nov). |
| CaixaBank | A2 LT Issuer, stable | EUR 1bn 5-year senior preferred green bond at MS +70bp. |
| Commerzbank | A2 LT Issuer, stable | UniCredit control nears: EU decision due 16 Nov, EGM planned after settlement. |
| Nordea | Aa3 Sr Unsec, stable | Fined DKK 155m in 2012-15 AML controls case. Cleared on 5 of 7 charges; DKK 6.6bn had been sought. |

Moody's took no rating action on any listed name in the window. Commerzbank's nine-month results and BNP's Q3 buyback were announced before the window, so they are not shown as new.

The **Daily sector news** tab was updated at 2026-11-15 21:49 UTC. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/review-news-banks/dashboard/dashboard.html`. The Artifact publish step was skipped (test run).
