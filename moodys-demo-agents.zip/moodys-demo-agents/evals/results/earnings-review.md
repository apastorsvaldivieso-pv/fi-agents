# Line-by-line review of the earnings recap

Done on 15 Nov 2026. One fresh run of `earnings-credit` on Opus 5.5 ("Earnings recap for Vodafone", half-year results of 10 Nov 2026), then checked by a separate reader that re-pulled the credit opinion, ratings, Moody's-adjusted metrics, the call transcript and the results report from Moody's. The run is in `evals/runs/review-earn-vodafone/`. Method: `evals/REVIEW.md`.

| Wrong | Missing | Unsupported | Facts checked |
|---|---|---|---|
| 1 | 6 | 1 (not verified) | about 50 |

## Wrong (1)

| What the answer said | What the source says |
|---|---|
| "The opinion text returned does not mention Safaricom" | The credit opinion (PBC_1496608, 21 Oct 2026) and the affirmation of 13 Oct (PR_528027) both say net leverage rose "following the UK transaction and the acquisition of an additional 20% stake in Safaricom", and that Moody's expects it back in the lower half of 2.25x to 2.75x by the end of the fiscal year. Moody's has already addressed the main cause of the rise in net debt, and the recap says it has not |

## Missing (6)

| Item | Where it is |
|---|---|
| Kenya's High Court declared the Safaricom deal null and void (15 Sep 2026); the Court of Appeal kept the status quo pending appeal (13 Oct 2026). The deal accounts for EUR 1,379m of the rise in net debt | Interim report, page 3 and note 11; call Q&A |
| The guidance ranges: adjusted EBITDAaL EUR 13.2bn to 13.4bn (from 13.0bn to 13.3bn); adjusted free cash flow EUR 2.8bn to 3.0bn (from 2.6bn to 2.9bn). The recap says the ranges "are not in the excerpts" | Interim report, page 3 |
| Size of the German impairment: EUR 4.85bn, all goodwill, and the warning that higher bond yields alone would cause a further impairment | Interim report, note 3 |
| EUR 3,022m remeasurement gain on Safaricom, which partly offset the loss | Interim report |
| EUR 474m of other movements that reduced net debt, including EUR 908m from the settlement of a VodafoneZiggo loan | Interim report, net debt bridge |
| 2,300 further job cuts in Germany | Call |

## Unsupported (1, not verified)

The half-year loss attributable to owners of EUR 4,789m: the reader could not find it in the excerpts pulled. The impairment (EUR 4,850m) and the loss per share (20.75c) are confirmed. Treat as not checked, not as wrong.

## What was right

- Baa2 senior unsecured, stable, affirmed 13 Oct 2026; trigger and outlook wording; Moody's forecasts (3.1x and 29.4%); Moody's-adjusted metrics (3.25x and 33.08% for the year to March 2026); the room to each trigger.
- Net debt EUR 33,473m against EUR 25,411m and its six drivers; cash; facilities and maturities; gross debt; capex; dividend; Germany EBITDA and the provision inside it.
- An analyst's EUR 1.2bn figure is labelled as the analyst's.
- The opinion (21 Oct) predates the results; Moody's has published nothing on Vodafone since 1 Nov.
- No Moody's ratio recomputed from company figures, no consensus comparison, no rating forecast, no view on bonds or shares.

## Minor

- Two growth rates are organic and not labelled so.
- "RCF / net debt has already met the upgrade level" can read as if half an upgrade case is in place; Moody's needs all its conditions together.

## What this shows (my reading)

The recap reads parts of the results report and of the opinion, not all of the parts that matter. It answered its filing query (net debt, liquidity, maturities, distributions) well, and missed what that query does not ask for: the guidance table, the impairment note and legal proceedings. It also stated that the opinion says nothing on a subject when the text it had pulled did not include the passage.

## Proposed fixes (all three applied later on 15 Nov 2026; the review after them is `earnings-review-2.md`)

1. Add to the recap's filing query: guidance ranges, impairments, legal proceedings and contingent liabilities, one-off gains.
2. Add the opinion's leverage and financial policy passages to the recap's opinion call, and never say the opinion "does not mention" something: say "not in the sections pulled".
3. Net debt drivers: include the netting items so the bridge adds up.
