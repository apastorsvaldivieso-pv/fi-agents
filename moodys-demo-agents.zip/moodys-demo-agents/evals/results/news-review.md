# Line-by-line review of the news brief

Done on 15 Nov 2026. Two fresh 7-day runs of `sector-news-brief` on Opus 5.5 (European telecoms, European banks; window 8 to 15 Nov 2026), each then checked by a separate reader that re-pulled ratings, research and news from Moody's and did not rely on the brief's own sources. The runs are in `evals/runs/review-news-telecoms/` and `evals/runs/review-news-banks/`.

Both runs pass every script check. The review still found errors and omissions, listed below. The fixes proposed at the end were then approved and applied; the review made after them is `news-review-2.md`.

## What was right

- All 30 ratings: level, rating class, outlook or review status, and last-action date.
- No Moody's rating action on a listed name was missed (there was none in the window).
- The telecoms outlook cited is the latest one.
- Every figure the briefs did state for Telia, Telenor, Telefonica, TIM and BT, and most bank figures and dates.
- No investment opinion and no rating-action forecast.

## Wrong (7)

| Brief | What it said | What the source says |
|---|---|---|
| Telecoms | No Moody's research on any listed name in the window | An Issuer Profile on Deutsche Telekom was published on 9 Nov (PBC_1500087) |
| Telecoms | Telia's deal weighs on RCF / net debt "unless paid from cash on hand", and funding is not disclosed | Cash payment also raises net debt. The cited release itself says net debt / EBITDA rises about 0.1x and the 2027 cash flow target is unchanged |
| Telecoms | Headline: Telenor "moved to full control" of Bahnhof | 66.9% of shares and 90.6% of votes, offer still open |
| Banks | UniCredit's USD 3.5bn bond is its "first US deal" | A return to the US market, the first since 2021 |
| Banks | UniCredit's A3 senior unsecured rating is under review | The senior rating was affirmed with a stable outlook on 21 Jul 2026 (PR_526711). The review, for upgrade, covers the BCA and junior ratings |
| Banks | No Moody's outlook for France or Switzerland | Both exist: France stable (PBC_1470906, 9 Feb 2026), Switzerland stable (PBC_1468651, 11 Feb 2026) |
| Banks | Banco BPM's board opened talks with Credit Agricole on 13 Nov | The board acted on 12 Nov; 13 Nov was Credit Agricole's statement |

## Missing (material items in Moody's news for a listed name, inside the window)

| Name | Item |
|---|---|
| Vodafone | Half-year loss of EUR 3.6bn against a EUR 1.1bn profit, on a EUR 4.85bn Germany impairment, and 2,300 German job cuts. The brief gave only the guidance raise |
| Vodafone | A Kenyan court ruling that threatens the USD 1.6bn Safaricom stake purchase |
| TIM | Dispute with FiberCop over more than EUR 500m of payments; net debt after leases EUR 7.2bn and leverage below 1.9x |
| Telefonica | Net debt EUR 25.2bn, leverage 2.63x from 2.78x, free cash flow guidance about EUR 3.1bn from EUR 3.0bn. The brief said only "raised" |
| Telia | Latvian buyout of its LMT and Tet stakes: about EUR 0.5bn indicative, proposals due 17 Nov |
| Swisscom, TIM | Tower-contract disputes with INWIT (no cost stated) |
| Intesa Sanpaolo | Offer document for the Monte dei Paschi takeover published 10 Nov; the ECB asked for caution on dividends in approving it; a EUR 1.25bn senior non-preferred bond |
| UniCredit | Third-quarter net profit EUR 3.3bn, CET1 15%, EUR 4.5bn interim dividend |
| HSBC | Risk transfers on about USD 7bn of corporate loans |
| Italian banks | Reported bank levies of about EUR 7bn over 2027 to 2029 |
| Credit Agricole | Terms of the Banco BPM deal: stake to about 45%, EUR 1bn extraordinary dividend, completion in the second half of 2027 |

## Unsupported (a claim with no source behind it)

- Telecoms macro: Altice France and VMED O2 "have large refinancing needs". The Moody's document cited names neither.
- Telenor: "Moody's upgrade factors" invoked without a citation. Telia: "no action pending". Vodafone: "more room to cut debt".
- Nordea: a ruling "removes a long-running litigation risk". The release says either side can appeal within two weeks.
- Credit Agricole: Banco BPM as its "largest foreign subsidiary".
- ING / OCBC: the only sources are four auto-generated articles citing one outlet; no wire article was found, and the item may be old news recycled.

## Minor

- TIM's results came out on 10 Nov; the brief gives the date of the call, 11 Nov.
- Rating class missing in two "Top" lines; classes differ across banks because the tool returns different ones.
- One item rests on a single aggregator article.

## What this shows

1. **Ratings are reliable; news content is not yet.** The agent gets the structured Moody's facts right and gets free-text news partly wrong.
2. **Results are reported one-sidedly.** A guidance raise is shown without the loss, the impairment or the leverage figure that came with it.
3. **Material items are dropped** even when they are in Moody's news for that name in the window.
4. **"Why it matters" lines assert things no source says.**
5. **Absolute statements ("no research", "no outlook") are made on the strength of one search.**
6. **The script checks cannot see any of this.** They test form and citations. A check that reads the output against the sources has to be part of the test for every agent.

## Proposed fixes (all seven applied later on 15 Nov 2026)

1. **Results in full.** When a name reported in the window, give profit or loss including impairments, the guidance change, and leverage or net debt (capital and distributions for a bank).
2. **A materiality checklist per name**: results, deals, court and regulatory rulings with a stated amount, large bond issues, dividends and buybacks, CEO or CFO changes. Anything on it goes in.
3. **"Why it matters" only from a source.** If no cited source or Moody's opinion says it, drop the clause.
4. **No absolute statements from one search.** "None returned by this search", not "none exists". The bank outlook lookup searches each country.
5. **Ratings under review:** say which ratings and in which direction, from the rating action itself.
6. **Thin sourcing is flagged.** An item resting on one aggregator article is marked unconfirmed and kept out of the top three.
7. **The same source review as a standing test** for all three agents.

Two adjustments were made when the fixes were approved. Fix 3: the "why it matters" line is kept where one credit opinion call for the top names gives it a source, and dropped where nothing sourced can be added. Length: a material item is never cut to fit the word limit; the brief runs over and says so in one line.

Result of the second review: 4 wrong, 5 missing, 3 unsupported, against 7, 11 and 7 here. See `news-review-2.md`.
