# Refresh test from the Claude app

Run on 15 Nov 2026 by a fresh Claude Opus 5.5 session in the Claude desktop app, following `plugin/skills/dashboard-feed/SKILL.md` with no other guidance.

| Step | Result |
|---|---|
| One Moody's call (BNP Paribas CET1, Q2 2026: 12.97%) | Returned |
| Write the run file to `dashboard/data/` | Done |
| Rebuild with the script | First build rejected the file: the headline had a figure with no source. Fixed and rebuilt |
| Negative check: same file with the citation removed | Rejected by the script, as intended |
| Read the private Artifact, then publish to the same link | Worked. Same URL, version 1 to version 2 |
| Tool calls | 14 |

What the test changed in the skill:
- Headlines can now carry sources (`headline_src`), so a figure in a headline can be cited.
- The `--check` option is documented.
- Required fields, what `updated_at` and a source `date` mean, and the script path are spelled out.

Not covered by this test: a run from Cowork with the plugin installed. That needs the plugin installed on your side.

Later on 15 Nov 2026: the user installed the plugin and reported it working. After the three fixes, the page was rebuilt and republished to the same link by the build session (version 5 onwards), not by a fresh session following the skill.
