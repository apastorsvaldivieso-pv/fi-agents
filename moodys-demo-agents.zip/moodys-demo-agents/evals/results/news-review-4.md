# Fourth line-by-line review of the news brief

Done on 16 Nov 2026, on runs made late on 15 Nov, after the third set of fixes (the results report as a last resort for a profit or loss figure; a second keyword search per bank; issuer profiles in the research search; every rating a review covers; dates of filings and articles written as such). Same method as before: two fresh 7-day runs of `sector-news-brief` on Opus 5.5 (European telecoms, European banks; window 8 Nov 23:37 to 15 Nov 23:37 UTC), each checked by a separate reader that re-pulled from Moody's. The runs are in `evals/runs/review4-news-telecoms/` and `evals/runs/review4-news-banks/`.

**The target is zero wrong and zero unsupported. It has not been met in any of the four reviews.**

| | Wrong | Missing | Unsupported |
|---|---|---|---|
| Telecoms: first / second / third / **fourth** | 3 / 2 / 2 / **2** | 6 / 3 / 1 / **2** | 4 / 2 / 0 / **0** |
| Banks: first / second / third / **fourth** | 4 / 2 / 2 / **1** | 5 / 2 / 1 / **1** | 3 / 1 / 0 / **1** |
| **Total** | 7 / 4 / 4 / **3** | 11 / 5 / 2 / **3** | 7 / 3 / 0 / **1** |

On the one unsupported claim: this reader could not find the article behind the Italian levy figures (EUR 5.9bn in 2027, EUR 12bn through 2029). The reader of the third review found those same figures in a Reuters article in Moody's news. So the figures have a source; this reader did not retrieve it.

The readers checked about 70 facts (telecoms) and about 60 (banks). All 30 ratings, classes and outlooks are right, for the fourth time. Nothing has been changed since this review.

## What this round fixed

- **Vodafone's results are complete on the points that matter**: the loss with the EUR 4.85bn Germany impairment, net debt up to EUR 33.5bn and the raised guidance, all from the company's interim report and all matching it. This was missing in the first three reviews.
- **Intesa's offer for Monte dei Paschi is reported**, with the offer document, the EUR 34.5bn size and the ECB's request for caution on dividends. Missing in the first three reviews.
- **The Deutsche Telekom issuer profile is reported**, correctly described.
- **The Italian levy cost is given.**
- UniCredit's results are again in full, and its review status is right.

## What is still wrong

### Wrong (3)

| Brief | What it said | What the source says |
|---|---|---|
| Telecoms | Telenor "completed the purchase of 57.5%" of Bahnhof and made a mandatory offer, as a top item of the week | Both happened on 6 Nov, before the window. The article used is dated 11 Nov. Only the 13 Nov board recommendation (Telenor at 66.9% of shares) is new |
| Telecoms | TIM's nine-month results "reported 12 Nov" | Published 10 Nov. 12 Nov is the date of the article used |
| Banks | ING Groep: "EUR 3.5bn bond, reported on 10 Nov" | A post-stabilisation notice for an ING Bank N.V. issue launched around 2 Nov: a subsidiary's bond from before the window, shown as the group's news this week |

### Missing (3)

| Name | Item |
|---|---|
| TIM | Net debt. The brief says it was "not in the sources returned". Moody's news has it: EUR 7.21bn, up from EUR 6.854bn, leverage 1.89x. The third review's brief did give it |
| Vodafone | The interim dividend (2.306 eurocents, up 2.5%) |
| Intesa Sanpaolo | The follow-on offer for Mediobanca minorities, published 10 to 11 Nov |

### Minor

- VMED O2: the review covers all ratings; the brief names two.
- Intesa's offer for Monte dei Paschi is the week's largest deal and sits in the table, not in the top items; its terms and timetable are left out.
- Credit Agricole / Banco BPM: the terms (stake to about 45%, a 20% premium, a EUR 1bn extraordinary dividend) are left out.
- BBVA's senior non-preferred bond is dated by its filing.
- Telefonica's nine-month profit is given without the EUR 870m loss on discontinued operations.
- No last rating action dates in the table.

## What four reviews show

1. **Each round of fixes removes the errors it was written for.** Unsupported "why it matters" lines, the wrong review attribution, one-sided results, the missing Vodafone loss, the missing Intesa deal: each went away after its fix and did not come back.
2. **Each fresh run then makes two or three new mistakes of the same two kinds**: an item dated by its article and not by its event (so old news is shown as new), and a figure or item that is in the sources and not in the brief. Which name it happens to changes from run to run.
3. **The structured Moody's facts are reliable**: 30 of 30 ratings in all four reviews, every "why it matters" line sourced in the last three.
4. **The free-text news is not yet reliable enough to hand to an analyst unread.** In a 7-day brief on 15 names, expect one or two statements a specialist would correct.

## What I would and would not do next

Not another round of rule changes: three rounds have moved the total from 7 wrong to 3 or 4, and the last round did not move it. What is left is not a missing rule (the rules for dates and for completeness are already in the skill); it is the agent not applying them every time across 15 names and 40 or more searches.

What would move it:

1. **A second pass inside the agent**: after writing the brief, re-open the source of each top item and each results line, and check three things: the event's date, the company the figure belongs to, and that nothing on the checklist in that source was left out. This is the reader's job done by the agent itself. It roughly doubles the cost of a run.
2. **A narrower default for client demos**: the 24-hour brief on a list of 15, or a 7-day brief on five names. Fewer items, fewer chances to slip.
3. **Say what the brief is**: a first read, sourced line by line so an analyst can check any item in one click. That is true today.
