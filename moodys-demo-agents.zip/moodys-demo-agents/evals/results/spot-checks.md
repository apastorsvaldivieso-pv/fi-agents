# Spot-checks against the source

Done on 15 Nov 2026. Each figure below was reported by an agent in a live eval run and then pulled again from the source, separately from the agent: by a direct call to the Moody's tool named, by an independent read of the transcript, or by an independent fetch of the regulator's page. "Match" means the same value, period and label.

In total 189 figures were checked and none was wrong in the final runs: 133 in the first build, 50 more after the three fixes of 15 Nov 2026, and 6 for the Groupe Credit Agricole fix (last section). Three data problems surfaced in the first build and were fixed in the skills; they are listed further down.

## sector-news-brief (18 checked, 18 match)

| # | Reported by the agent | Source re-pulled | Result |
|---|---|---|---|
| 1 | Vodafone: Baa2, Senior Unsecured - Fgn Curr, stable, affirmed 13 Oct 2026 | `getEntityRatings` | Match |
| 2 | Telefonica: Baa3, Senior Unsecured - Dom Curr, stable | `getEntityPeers` (rating class and outlook fields) | Match |
| 3 | Orange: Baa1, LT Issuer Rating, stable, affirmed 11 Jun 2026 | `getEntityPeers` | Match |
| 4 | Telenor: Baa1, Senior Unsecured - Fgn Curr, positive | `getEntityRatings` | Match |
| 5 | TIM: Baa3, LT Issuer Rating - Dom Curr, positive | `getEntityRatings` | Match |
| 6 | Altice France: Caa1, Senior Secured Bank Credit Facility, positive | `getEntityRatings` | Match |
| 7 | Deutsche Telekom: A3, Senior Unsecured, stable | `getEntityRatings` | Match |
| 8 | PPF Telecom Holdings: Baa2, LT Issuer Rating - Dom Curr, stable | `getEntityRatings` | Match |
| 9 | VMED O2 UK Holdings: B1 CFR, on review for downgrade since 22 Oct 2026 | `getEntityPeers`; rating action PR_531559 | Match |
| 10 | BT: Baa2, rated at British Telecommunications Limited | `findEntity`; Moody's rating action text | Match |
| 11 | Telefonica Q3 net income EUR 802m against EUR 276m a year earlier | `searchNews` (12 Nov 2026) | Match |
| 12 | Telenor: 57.5% of Bahnhof bought; 66.9% of shares and 90.6% of votes; SEK 62 per share | `searchNews` (12 and 13 Nov 2026) | Match |
| 13 | Latest telecoms outlook: global, stable, 27 Oct 2026 (PBC_1496503) | `searchAllDocuments`, document type Outlook | Match |
| 14 | Banks outlook: global 2026 outlook stable, 3 Dec 2025 (PBC_1462959); Spain and Italy system outlooks stable, 9 Feb 2026 | `searchAllDocuments`, document type Outlook | Match |
| 15 | Banco Santander: A1, LT Issuer Rating, stable, affirmed 22 Oct 2026; UniCredit: A3, under review; BNP Paribas: A1 stable, affirmed 31 Aug 2026 | `getEntityRatings` | Match |
| 16 | UniCredit USD 3.5bn multi-tranche bond | `searchNews` (13 Nov 2026) | Match |
| 17 | VUB deposit ratings upgraded to A1 from A2, outlook to stable, 12 Nov 2026 (PR_531483) | `searchAllDocuments`, Rating Action | Match |
| 18 | Telia to buy Telavox's Nordic enterprise base for SEK 3.8bn plus up to SEK 0.2bn earn-out | `searchNews` (13 Nov 2026) | Match |

## reg-watch (68 checked, 68 match)

| # | Reported by the agent | Source re-pulled | Result |
|---|---|---|---|
| 1–15 | CET1 ratio, Q2 2026, for all 15 banks (from 11.30% Credit Agricole to 15.70% Nordea) | `getEntityFinancials_v2`, exact field, 15 names | 15 of 15 match |
| 16–30 | LCR, Q2 2026, for all 15 banks (from 134.00% HSBC to 192.99% CaixaBank) | same call | 15 of 15 match |
| 31–40 | Leverage ratio, fully loaded, Q2 2026, for the 10 banks that report it (3.7% Credit Agricole to 6% BBVA) | same call | 10 of 10 match |
| 41 | CET1 list median 13.60% | recomputed from the 15 values | Match |
| 42 | LCR list median 141.29% | recomputed from the 15 values | Match |
| 43 | Distance to the 100% LCR minimum (for example BNP Paribas +34.77 pp) | recomputed: LCR minus 100 | Match |
| 44 | Exposed = five lowest LCRs, resilient = five highest | re-ranked from the 15 values | Match |
| 45 | Moody's Sector Comment on the EBA governance guidelines, 11 Nov 2026 (PBC_1502042) | `searchAllDocuments` | Match |
| 46–50 | Basel Committee G-SIB release: dated 16 Oct 2026; averaging of indicators; implementation 1 Jan 2030; consultation comments by 14 Jan 2027; threshold EUR 200bn to EUR 350bn | independent fetch of the bis.org page | 5 of 5 match |
| 51–53 | Basel Committee IRRBB guidance: dated 9 Nov 2026; consultative; comments by 9 Feb 2027 | independent fetch of the bis.org page | 3 of 3 match |
| 54–57 | PRA PS20/26: published 10 Nov 2026; final policy; effective 1 Jan 2028; 350% of Tier 1 limit | independent fetch of the Bank of England page | 4 of 4 match |
| 58 | EBA governance guidelines published 5 Nov 2026 | Moody's Sector Comment PBC_1502042 and EBA press release title | Match |
| 59–63 | EBA 2027 stress test: published 9 Nov 2026; final methodology and draft templates; data points cut by 55%; launch end of January 2027 and results end of July 2027; climate module outside the core results | independent fetch of the eba.europa.eu page | 5 of 5 match |
| 64–67 | PRA CP14/26: published 22 Oct 2026; consultation on phase 2 of the SM&CR review; closes 22 Jan 2027; implementation expected in the second half of 2027 | independent fetch of the Bank of England page | 4 of 4 match |
| 68 | FINMA partially revised Anti-Money Laundering Ordinance, 10 Nov 2026 | independent fetch of FINMA's news feed | Match |

## earnings-credit (47 checked, 47 match)

| # | Reported by the agent | Source re-pulled | Result |
|---|---|---|---|
| 1 | Vodafone Moody's-adjusted debt/EBITDA 3.25x, fiscal year to 31 Mar 2026 | `getEntityFinancials_v2`, adjusted key indicators | Match |
| 2 | Vodafone RCF/net debt 33.08% | same call | Match |
| 3–6 | Triggers: downgrade if debt/EBITDA fails to stay below 3.3x or RCF/net debt declines towards 18%; upgrade below 2.5x and RCF/net debt above 25% | `getCreditOpinion` (21 Oct 2026, PBC_1496608) | 4 of 4 match |
| 7–10 | Moody's fiscal 2027 forecasts: revenue EUR 43.7bn, debt/EBITDA 3.1x, RCF/net debt 29.4%, (EBITDA - capex)/interest 2.6x | `getCreditOpinion`, key indicators | 4 of 4 match |
| 11 | Baa2 stable, affirmed 13 Oct 2026 | `getEntityRatings` | Match |
| 12 | Room to the downgrade trigger 0.05x | recomputed: 3.3 minus 3.25 | Match |
| 13–25 | Thirteen statements from the 10 Nov 2026 call, including the 7% EBITDA and 21% free cash flow growth implied by guidance, 6.4% Q2 service revenue growth, Germany H1 EBITDA down 3.2%, the EUR 100m ECJ effect, the 8% against 7.5% discount rate, 2,300 role reductions, the cost programme figures, the EUR 1.2bn and EUR 700m analyst figures, and the capital intensity quote | independent read of the transcript through `searchCompanyFilings` | 13 of 13 match |
| 26–27 | Iliad Holding: Moody's-adjusted debt/EBITDA 4.20x and RCF/net debt 13.99%, LTM to 30 Jun 2026 | `getEntityFinancials_v2` | Match |
| 28 | Iliad Holding: Ba2 CFR, stable, upgraded from Ba3 on 19 Jun 2026 | `getEntityRatings` | Match |
| 29 | Iliad Holding triggers: upgrade below 3.5x and RCF/net debt towards 25%; downgrade "well above 4.0x" | `getCreditOpinion` (30 Jun 2026, PBC_1488484) | Match |
| 30 | Iliad Holding forecasts: debt/EBITDA 4.3x, 4.0x, 3.7x for 2026 to 2028 | `getCreditOpinion`, key indicators | Match |
| 31 | BNP Paribas: upgrade condition of return on assets of 0.6% and above; Net Income / Tangible Assets 0.4% at June 2026; A1 stable, affirmed 31 Aug 2026 | `getCreditOpinion` (2 Sep 2026); `getEntityRatings` | Match |
| 32–43 | BNP Paribas sector metrics: net interest margin 0.9%, TCE/RWA 13.7%, problem loans 2.9%, cost/income 60.6%, HQLA/tangible banking assets 15.9%, gross loans/due to customers 85.8% (Moody's, June 2026); CET1 12.97%, impaired loans 2.93%, reserves/impaired loans 57.68%, LCR 134.77%, NSFR 108.63%, loans/deposits 82.30% (reported, Q2 2026) | `getCreditOpinion` key indicators; `getEntityFinancials_v2` | 12 of 12 match |
| 44–47 | Vodafone liquidity, from Moody's rating action of 13 Oct 2026: cash of about EUR 4.1bn, about EUR 1.6bn restricted, short-term investments EUR 3.4bn, undrawn committed facilities EUR 7.5bn maturing 2028 and 2031 | `searchAllDocuments` (PR_528027) | 4 of 4 match |

Two wording notes from the transcript check, neither a mismatch: the call gives the free cash flow growth as "21%", "just above 20%" and "over 20%" in different places, and gives the cost programme as "13%" and "more than 10%" of Europe EBITDA in different places. The agent used the first of each.

## Data problems found by the live runs, and the fix

| Problem | Where it showed | Fix |
|---|---|---|
| KPN was on the checked telecoms list, but Moody's withdrew its ratings on 18 Dec 2024. BT Group Plc returns no rating; it is rated at British Telecommunications Limited. | First news run | KPN replaced by PPF Telecom Holdings. BT's entry now carries the rated entity for ratings. `coverage-list` now confirms ratings for new names. |
| UBS came back with Q3 2018 figures when only two bank fields were requested. With the full field list it returns Q2 2026. | First regulatory watch run | The bank call now always sends the full field list, and a name with an older period is asked for again with the explicit period. |
| "Banco Santander" resolves first to a subsidiary (Brazil, Portugal or Open Bank, depending on the filter). The rated Spanish parent returns no financials. | Probes before the build | Name resolution checks the returned name and uses alternatives. Santander is left off the checked bank list. |

## After the three fixes (50 checked, 50 match)

Checked on 15 Nov 2026 against the runs made with the fixed skills. "My own pull" means a call made separately from the agent's run and from the search that first found the figure.

### reg-watch (32 checked, 32 match)

| # | Reported by the agent | Source re-pulled | Result |
|---|---|---|---|
| 1–8 | CET1 ratio, Q2 2026, for the eight G-SIBs on the list: Credit Agricole S.A. 11.30%, BNP Paribas 12.97%, ING 13.07%, Societe Generale 13.20%, Deutsche Bank 13.92%, HSBC 14.10%, Barclays 14.30%, UBS 14.38% | `getEntityFinancials_v2`, full field list, my own pull | 8 of 8 match |
| 9 | Median of the eight ranked values, 13.56% | recomputed | Match |
| 10–14 | Distance to stated requirement: BNP Paribas 2.46 pp, ING 2.04 pp, Societe Generale 2.94 pp, Barclays 2.10 pp, UBS 3.55 pp | recomputed from the values above and the requirement table | 5 of 5 match |
| 15–22 | LCR, Q2 2026, for the same eight banks (134% HSBC to 177.28% UBS) | same call | 8 of 8 match |
| 23 | BNP Paribas: CET1 requirement 10.51% at 30 Sep 2025 | `searchCompanyFilings`, interim, my own pull | Match |
| 24 | UBS: required going-concern CET1 capital 10.83% at 30 Jun 2026 | `searchCompanyFilings`, interim, my own pull | Match |
| 25 | UniCredit: CET1 overall capital requirement 10.21% at 30 Jun 2026 (10.20% at 31 Mar 2026) | `searchCompanyFilings`, interim, my own pull | Match |
| 26 | CaixaBank: CET1 requirement 9.12% at 30 Jun 2026; 339 bp above the MDA trigger | `searchCompanyFilings`, interim, my own pull | Match |
| 27 | Intesa Sanpaolo: overall CET1 requirement 9.96%, from 1 Jan 2026 | `searchCompanyFilings`, interim, my own pull | Match |
| 28 | BBVA: consolidated CET1 requirement 8.98%, in force from 1 Jan 2026 | `searchCompanyFilings`, annual, my own pull | Match |
| 29 | Societe Generale: CET1 requirement 10.26% | two separate searches (Q3 2025 report and Q1 2026 report) returned the same figure | Match |
| 30 | ING: MDA trigger level 11.03% at end of 4Q2025 | two separate searches of the 2025 annual report returned the same sentence | Match |
| 31 | Credit Agricole S.A.: 2.6 pp above the SREP requirement at 31 Mar 2026 (bank-stated) | two separate searches of the Q1 2026 slides | Match |
| 32 | Barclays: overall capital requirement for CET1 12.2% at 31 Dec 2025 | one search of the 2025 annual report (verbatim sentence); a Q1 2026 slide label also shows "12.2% MDA" | Match |

Scope and items, checked as facts:

| Fact | Source | Result |
|---|---|---|
| The 29 banks on the FSB list of 27 Nov 2025, by bucket; eight of the fifteen listed banks are on it | the FSB's own PDF, read directly | Match |
| No 2026 list published by 15 Nov 2026 | fsb.org G-SIFI page ("Last updated: 27 November 2025") | Match |
| Ten known regulatory items, 16 Oct to 15 Nov 2026: date, body and status of each | each regulator's own page, fetched separately | 10 of 10 match |
| An eleventh item (Basel Committee, consolidated guidelines, consultation, 5 Nov 2026) | the Basel Committee's page and listing | Match |

### earnings-credit (18 checked, 18 match)

All from Vodafone's half-year report as held in Moody's (`searchCompanyFilings`, interim, my own pull).

| # | Reported by the agent | Result |
|---|---|---|
| 1–3 | Net debt EUR 33,473m at 30 Sep 2026, against EUR 25,411m at 31 Mar 2026: an increase of EUR 8,062m | Match |
| 4–9 | Drivers: free cash outflow EUR 845m; acquisitions and disposals EUR 6,957m, of which VodafoneThree buyout EUR 5,019m, Safaricom stake EUR 1,379m and net debt acquired EUR 537m; other movements EUR 474m | 6 of 6 match |
| 10–11 | Equity dividends EUR 544m and share buybacks EUR 92m | Match |
| 12 | Gross debt EUR 42,697m | Match |
| 13–14 | Cash and short-term investments EUR 8.4bn, against EUR 12.4bn at 31 Mar 2026 | Match |
| 15–16 | Undrawn revolving credit facilities EUR 7.6bn, of which EUR 4.1bn in euros | Match |
| 17 | Interim dividend 2.306 eurocents per share | Match |
| 18 | Bond cash flows due within one year EUR 3,003m (annual report) | Match |

### Groupe Credit Agricole (6 checked, 6 match)

Added on 15 Nov 2026 after the G-SIB table was found to rank Credit Agricole S.A. in place of the group.

| # | Reported | Source re-pulled | Result |
|---|---|---|---|
| 1 | Groupe Credit Agricole exists as its own Moody's record, France | `findEntity`, my own pull | Match |
| 2–4 | The group at Q2 2026: CET1 17.23%, LCR 135.75%, NSFR 119.67% | `getEntityFinancials_v2`, full field list, period Q2 2026, my own pull | 3 of 3 match |
| 5 | Moody's assessment of Credit Agricole S.A. "is driven by the assessment of the Group's creditworthiness on a consolidated basis" | `getCreditOpinion`, Summary, opinion of 15 Jun 2026 | Match |
| 6 | The group's stated distance: 6.7 pp above the SREP requirement on a phased-in CET1 of 17.1% at 31 Mar 2026; Credit Agricole S.A.: 2.6 pp on 11.4% | `searchCompanyFilings`, interim, Credit Agricole S.A.'s Q1 2026 results slides, my own pull | Match. The slide's title did not come through; the figures are identified as the group's by the CET1 level and the TLAC and MREL ratios beside them |

The other fourteen banks on the checked list: Moody's financials for each are the consolidated accounts of the top company of the group (HSBC Holdings plc, Barclays PLC, Lloyds Banking Group plc, UBS Group AG, ING Groep N.V., BNP Paribas, Societe Generale, Deutsche Bank AG, Commerzbank AG, UniCredit S.p.A., Intesa Sanpaolo S.p.A., BBVA, CaixaBank, Nordea Bank Abp), checked by my own pull. For seven of them the CET1 in Moody's data equals the group figure the bank states in its own filing for the same or the nearest period (UBS 14.38%, UniCredit 14.26%, Barclays 14.3%, Commerzbank 14.4%, CaixaBank 12.3% regulatory, Intesa Sanpaolo 13.0%, Nordea 15.7%). Seven of the eight G-SIBs among them are named on the FSB list as the same company; only Credit Agricole is listed as a "Groupe".

### Not confirmed

- Deutsche Bank's CET1 requirement: the table in its annual report came back garbled from Moody's filings and two passages disagree, so no figure was recorded.
- HSBC, Lloyds, Commerzbank and Nordea: no total CET1 requirement was found in the filings Moody's returned. Nordea's annual report did not finish loading in six tries.
- Barclays' and ING's figures are dated 31 Dec 2025. Slides from 2026 carry labels ("12.2% MDA", "11.1% expected fully-loaded CET1 MDA") that suggest little change, but neither states the requirement in force in 2026, so both are recorded as older.
