# The agents on sectors that were never prepared

Run on 16 Nov 2026. The build prepared two sectors by hand (European banks, European telecoms): a sector file and a checked list of 15 names each. Clients cover other sectors, so each agent was run once or twice on a sector with no prepared file, from its own folder in `agents/` and with nothing else readable (`evals/RUNNER-STANDALONE.md`). These runs were read for whether the agent works as built; their content was not re-checked against the source by a separate reader.

| Agent | Request | Result |
|---|---|---|
| News brief | "Sector news brief for European utilities, last 7 days, for: Enel, Iberdrola, EDF, E.ON, RWE, Engie." | **Works.** All six names resolved to the right rated parent. All four parts returned (top items, macro, sector, by name). 34 Moody's calls |
| News brief | "Run the sector news brief for European auto manufacturers for the last 72 hours." (no names) | **Works.** Built its own list of eight car makers from Moody's, dropping six financing vehicles and the parts suppliers. All four parts returned. 16 Moody's calls |
| Earnings | "Earnings recap for Volkswagen." | **Works.** Resolved Volkswagen AG, not its financing arms. Moody's-adjusted metrics, triggers and forecasts found through the general route. All three sections returned |
| Regulatory watch | "Run the regulatory watch for European insurers for the last 30 days, for: Allianz, AXA, Generali, Zurich Insurance, Aviva, Munich Re." | **Lists what changed; cannot rank.** This agent is built for banks. Moody's returned no adjusted financials for the six insurers, the agent chose the regulators itself, and its bank-oriented rules left out two EIOPA publications. Outside its intended use |

## What a client can rely on

- **Their own names, in any sector: yes.** Each name is resolved to its Moody's record without guessing, and the brief or recap has every part.
- **A sector with no names given: yes, with a caveat.** The list is built from one Moody's search and is only as complete as that search. For auto makers it did not return Porsche or Ferrari, and the agent will not add names from memory. It shows the list, so the user can add what is missing.

## What was weaker than on the prepared sectors

1. **The sector outlook lookup is only written down for banks and telecoms.** Both news runs worked it out by analogy. For autos the first search found it (Automotive Manufacturing, Global, negative, 1 Jun 2026). For utilities it took three searches and the run was not confident it had the latest (Unregulated Electric and Gas Utilities, Europe, 18 Nov 2025, with no outlook returned for regulated networks).
2. **Whether suppliers belong to "the sector"** was the run's own call.
3. **A car maker with a finance arm** has two "net debt" figures; the recap chose the automotive one and listed the other, with no rule to follow.
4. **Moody's held no group call for Volkswagen**, only Audi's, filed under the parent. The recap used it as a labelled Audi item.
5. **Results figures were thinner**: for two utilities, Moody's held no call transcript and only an older filing, so a profit and a net debt figure are stated as not returned.

## The fix, applied on 16 Nov 2026

One general edit to `plugin/skills/sector-metrics/SKILL.md`, under "A sector with no file": how to find the latest Moody's outlook for any sector. Up to three searches of Moody's outlooks (the sector and the region; then the region without the sector filter; then the sector without the region), stopping at the first that returns one. The answer gives the outlook's title, its own scope and its date, never presents another region's outlook as the one for these names, and says when none was returned. It applies to every sector at once; nothing is set up per client.

Tested once after the edit, from the news agent's own folder: "Sector news brief for European utilities, last 72 hours, for: Enel, Iberdrola, EDF, E.ON, RWE, Engie." The run followed the new step, found the outlook on the second search (three improvised searches before), and reported it with its title, scope (Europe) and date (18 Nov 2025), adding that no regulated-networks outlook was returned. All six names resolved and all four parts were present. One wording clash the run pointed out in the new step was cleared afterwards; that last wording change was not rerun.
