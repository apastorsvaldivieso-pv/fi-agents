# Second line-by-line review of the news brief

Done on 15 Nov 2026, after the seven fixes from `news-review.md` were applied. Same method as the first review: two fresh 7-day runs of `sector-news-brief` on Opus 5.5 (European telecoms, European banks; window 8 Nov 22:49 to 15 Nov 22:49 UTC), each then checked by a separate reader that re-pulled ratings, research and news from Moody's and did not rely on the brief's own sources. The runs are in `evals/runs/review2-news-telecoms/` and `evals/runs/review2-news-banks/`.

**The target was zero wrong and zero unsupported. It was not met.**

| | Wrong | Missing | Unsupported |
|---|---|---|---|
| Telecoms, first review | 3 | 6 | 4 |
| Telecoms, this review | 2 | 3 | 2 |
| Banks, first review | 4 | 5 | 3 |
| Banks, this review | 2 | 2 | 1 |
| **Total, first review** | **7** | **11** | **7** |
| **Total, this review** | **4** | **5** | **3** |

The readers checked about 70 facts (telecoms) and about 95 facts (banks).

## What the fixes did fix

- **"Why it matters" lines.** All six in the two briefs match Moody's trigger or outlook wording in the credit opinion they cite. The first review found seven unsupported claims, most of them in these lines.
- **Ratings under review.** UniCredit is described correctly: the baseline credit assessment and the junior and subordinated ratings are on review for upgrade; the A3 senior rating was affirmed with a stable outlook.
- **Absolute statements about Moody's research and outlooks.** Both briefs say what the search returned. The banks brief cites the country outlooks; the reader confirmed they are the latest.
- **Thin sourcing.** ING / OCBC and the UBS capital proposal are marked "single source, unconfirmed" and kept out of the top items. The reader confirmed both marks are true.
- **Ratings.** All 30 ratings, classes and outlooks are right again, and no Moody's action on a listed name was missed.
- **Items left out with a reason.** The reasons given (Deutsche Telekom, Proximus and BT results as old news retold; Vodafone Idea and Vodacom as not group credit) are true.

## What is still wrong

### Wrong (4)

| Brief | What it said | What the source says |
|---|---|---|
| Telecoms | Telefonica: "the articles give no leverage figure" | The Q3 call transcript gives net debt EUR 25.2bn and net debt / EBITDA 2.63x, from 2.78x (company figures) |
| Telecoms | VMED O2: "No news in the window" | Two articles in the window: Telefonica will not fund higher leverage at VMO2 (13 Nov); VMO2's GBP 800m savings plan (9 Nov). Neither is on the checklist, but the statement is false |
| Banks | BBVA's EUR 1bn AT1 "placed (12 Nov)" | Announced 10 Nov. 12 Nov is the date of the article |
| Banks | Commerzbank "reaffirmed at least EUR 3.4bn 2026 net profit" shown as this week's news | That came with results on 5 Nov, before the window. The same day it cut net interest income guidance to about EUR 8.5bn from about EUR 8.6bn, which the brief does not say |

### Missing (5)

| Name | Item |
|---|---|
| Vodafone | Half-year results of 10 Nov: net loss EUR 3.6bn, EUR 4.85bn Germany impairment, 2,300 German job cuts, guidance for adjusted EBITDAaL raised to EUR 13.2bn to 13.4bn from EUR 13.0bn to 13.3bn. The brief shows "guidance raised, no figures given; single source, unconfirmed". That reason is false: four outlets and the company release carry the results |
| Telefonica | Full-year revenue guidance cut to 1% to 1.5%; net debt and leverage. The brief says only "guidance raised" |
| TIM | EUR 314m of non-recurring costs (EUR 139m of it litigation and contingent liabilities), reported EBITDA down 1.5%, adjusted net debt EUR 7.2bn, leverage 1.89x. The figures are in the brief's own source |
| Intesa Sanpaolo | Offer document for the EUR 34.5bn Monte dei Paschi bid published 10 Nov; the ECB asked for a cautious approach to dividends. Also missing in the first review |
| UniCredit | Q3 net profit EUR 3.3bn, nine-month profit EUR 9.4bn, interim dividend raised to EUR 4.5bn. The figures are in the brief's own source |

### Unsupported (3)

- Telefonica Q3 net income "EUR 802m against EUR 276m": the reader could not open the article cited; another outlet gives EUR 860m from continuing operations.
- Telefonica "adjusted net income EUR 629m, down 1%": no source found. EUR 629m is Poste Italiane's Q3 adjusted net profit in an article returned by the same search, so the figure may come from the wrong company.
- BNP Paribas "EUR 1.3bn buyback (announced 28 Oct)" in a note: not found in Moody's news.

### Minor

- Telenor / Bahnhof: the 57.5% purchase and the offer date from 6 Nov, before the window; only the 66.9% holding and the board recommendation are new.
- VMED O2: all ratings are on review for downgrade, not only the two the brief names.
- A Deutsche Telekom issuer profile of 9 Nov is in the window; the sector line says research found was only on issuers outside the list.
- TIM "despite revenue and EBITDA growth": EBITDA after leases rose, reported EBITDA fell.
- Banco BPM board date (12 or 13 Nov): sources differ.
- Credit Agricole's stake in the merged Banco BPM (about 45%) is left out.
- HSBC "why it matters": the new AT1 replaces one being tendered, so it is not new capital.

## What this shows

1. **The fixes that add a rule about wording worked.** Sourced "why it matters", the review direction, "the search returned", the single-source mark.
2. **"Results in full" did not work.** Five of the nine findings that matter are a name that reported in the window and whose loss, impairment, guidance cut or leverage is not in the brief. This is the same failure as in the first review. The eval case `news-02` fails the same expectation.
3. **Why (my reading, not yet tested).** The per-name news search returns 20 headlines, many from aggregators, and the figures are in article bodies or in the call transcript, which the skill does not fetch. The skill says what a results item must contain but gives no step that goes and gets it. The reader found every missing figure with one keyword search per name or in the transcript.
4. **The single-source mark became a way out.** Vodafone's results were marked "single source, unconfirmed" when one more search would have confirmed them.
5. **Two new kinds of error.** A figure attached to the wrong company (EUR 629m), and an article's date given as the event's date (BBVA, Commerzbank).

## Proposed fixes (all six applied later on 15 Nov 2026; the review after them is `news-review-3.md`)

1. **A results step.** When a name's headlines show it reported inside the window, make one more call for that name before writing: a news search on "<name> results net profit impairment net debt guidance", and if that does not give the figures, the call transcript. About one extra call per reporting name.
2. **Single source means confirm, not park.** For an item on the checklist, one confirming search before marking it unconfirmed.
3. **A figure comes from an article about that name.** Check the company named in the article before using its figure.
4. **Event date, not article date.** Use the date the source gives for the event; if only the article's date is known, say "reported on".
5. **"No news" becomes "no material credit news"** unless the search returned nothing at all.
6. **A script check** that a row saying "results" carries at least a profit or loss figure and a debt or capital figure, or says which was not returned.
