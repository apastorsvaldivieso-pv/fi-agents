# Line-by-line review of the regulatory watch

Done on 15 Nov 2026. One fresh 30-day run of `reg-watch` on Opus 5.5 (European banks, 16 Oct to 15 Nov 2026), then checked by a separate reader that opened each regulator's own listing and each item's page, and re-pulled every metric from Moody's. The run is in `evals/runs/review-reg-banks/`. Method: `evals/REVIEW.md`.

| Wrong | Missing | Unsupported | Facts checked |
|---|---|---|---|
| 1 | 0 | 0 | about 115 |

## Wrong (1)

| What the answer said | What the source says |
|---|---|
| PRA CP14/26 (22 Oct 2026) is "moving most Senior Manager approvals to notification" | The PRA would "remove the pre-approval requirement for almost half of the current Senior Manager Functions". Pre-approval stays for the chief executive, chief finance and chief risk roles, among others |

## Missing

None found. The reader read all seven listings for the window. Every entry inside it is either shown (12 items) or left out for a reason the skill allows. The counts of grouped entries match the listings.

## Unsupported

None found. The Moody's comment quoted (PBC_1502042, 11 Nov 2026, on the EBA's governance guidelines) exists, with the title, date and direction given.

## What was right

- CET1 for all eight G-SIBs at Q2 2026, the median (14.01%), every distance to the median and to a stated requirement, and the thirds.
- Credit Agricole is measured as the group (17.23%); Credit Agricole S.A. (11.3%) is given in the note.
- Three of eight names have a current requirement, so ranking by level is the right case; the second table (five banking-union G-SIBs, methodology consultation) is correctly not ranked and labelled as a judgment.
- Every stated requirement and date matches `banks-scope.md`; names out of scope are named.
- On the ten other items: date, body, status, deadline and effective date.
- "More than 55%" keeps the qualifier in the EBA's headline. The EBA's own body text says "by 55%".

## Minor

1. The window-dressing threshold is given as "EUR 200bn to 350bn" without the measure (leverage ratio exposure), and called a "reporting" threshold where Basel says "reporting and disclosure".
2. PS20/26: "up to 85% of Tier 1" leaves out that it applies to third-party trading book exposures for no more than ten business days.
3. CP14/26: "dropping certification fitness assessments" overstates; firms must still take reasonable steps to check integrity and honesty.
4. A note says "older ones are not ranked" while the table ranks by level and marks BNP Paribas and ING as weaker. Correct, but it reads as a contradiction.
5. Several requirement cells drop the name the bank gives its requirement.

## Not checked

The Basel consultation's PDF (only its page), the end of the CP14/26 page, and the banks' stated requirements against the filings themselves (checked against `banks-scope.md` only).

## Proposed fix (applied later on 15 Nov 2026; the review after it is `reg-review-2.md`)

Extend the qualifier rule from figures to scope: keep the regulator's own words for how much of something a measure covers ("almost half", "most", "all"), and do not paraphrase them upward.
