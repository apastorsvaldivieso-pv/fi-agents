# Second line-by-line review of the earnings recap

Done on 15 Nov 2026, after three changes to the recap: a second filing query (guidance ranges, impairments, one-offs, legal matters), more sections of the credit opinion, and a net debt movement that has to add up. Same method as the first review (`earnings-review.md`): a fresh Vodafone recap on Opus 5.5, then a separate reader that re-pulled the opinion, ratings, metrics, transcript and results report from Moody's. The run is in `evals/runs/review2-earn-vodafone/`.

| | Wrong | Missing | Unsupported | Facts checked |
|---|---|---|---|---|
| First review | 1 | 6 | 1 (not verified) | about 50 |
| **This review** | **1** | **4** | **0** | about 48 |

The target of zero wrong was not met.

## What the fixes did fix

- **The Kenyan court ruling** on the Safaricom deal is in, with both dates.
- **The size of the German impairment** (EUR 4.85bn) and **the Safaricom gain** (EUR 3,022m) are in.
- **The net debt movement adds up**: 845 + 6,957 + 544 + 92 + 98 of currency effects, less 474 = 8,062.
- The answer no longer says the opinion "does not mention" Safaricom.

## Wrong (1)

| What the answer said | What the source says |
|---|---|
| Operating profit EUR 1,199m against a loss of EUR 631m a year earlier | The interim report gives operating profit of EUR 517m against EUR 2,162m, down 76.1%. Neither EUR 1,199m nor EUR 631m is in the report |

This is a new error: the first recap did not give an operating profit figure.

## Missing (4)

| Item | Where it is |
|---|---|
| The guidance ranges: adjusted EBITDAaL EUR 13.2bn to 13.4bn (from 13.0bn to 13.3bn), adjusted free cash flow EUR 2.8bn to 3.0bn (from 2.6bn to 2.9bn). The answer says "Euro ranges not found in the report search" | Interim report, pages 1 and 3 |
| The net loss for the period, EUR 3,597m (profit of EUR 1,052m a year earlier), the loss to owners of EUR 4,789m, and the EUR 2.2bn write-down of UK deferred tax assets inside it. The answer gives only the loss per share | Interim report, pages 1 and 3 |
| 2,300 further job cuts in Germany | Call |
| What Moody's says about Safaricom. The answer says it is "not in the sections pulled". The rating action the answer itself cites (PR_528027) says net leverage rose "following the UK transaction and the acquisition of an additional 20% stake in Safaricom" | Rating action of 13 Oct 2026; credit opinion |

## Minor

- "The old range's upper end is the new midpoint" was an analyst's wording on the call, labelled company-reported.
- The impairment's cause (about three-quarters from higher German bond yields; discount rate 8.0% from 7.5%) and the report's sensitivity are left out.
- The EUR 474m of other inflows is net of EUR 213m paid in advance to the Government of Kenya.
- Moody's put this year's EBITDAaL at about EUR 13bn in its opinion, the low end of the old guidance; the answer does not set that against the raise.

## What was right

Rating, outlook, triggers, forecasts, Moody's-adjusted metrics and the room to each trigger; net debt and every driver; cash, facilities and maturities; gross debt; capex; adjusted EBITDAaL; dividend; the impairment, the gain and the ruling; the analyst's figure labelled as the analyst's; the opinion predating the results; no Moody's comment since 1 Nov.

## What the eval reruns add

- **All three Vodafone recaps say the euro guidance ranges were not found in the report.** The preview case (`earn-01`) did find them in the same report, with the preview's query ("guidance, outlook and targets for the year"). The recap's new second query does not bring that page back.
- **No recap gives the net loss in euros.** All three give the loss per share.
- All three mention the Kenyan ruling, the impairment size and the gain.
- The answer written with no dashboard and no scripts (`earn-08`) fails two checks: figures with no reference, and 757 words against a limit of 700. Its net debt drivers do not add up (the currency line is missing), and the run used a shell search once against its own test rules.

## Why (my reading, not yet tested)

1. The second filing query asks for six things at once. The search returns the passages closest to the whole query, and the outlook page loses to the impairment and legal notes. The preview's shorter query finds it.
2. Nothing asks for the income statement, so the recap has the loss per share (from the dividend and earnings passage) and not the loss.
3. The operating profit figure has no source in the report: the answer check lets a figure through when it has a reference number, whether or not the reference contains it.
4. The Safaricom sentence is in the rating action the recap already pulls. The rule says to search the sections and the rating action for the cause by name; the run searched the sections only.

## Proposed fixes (all five applied later on 15 Nov 2026; the review after them is `earnings-review-3.md`)

1. Split the recap's second filing query in two: (b) "outlook and guidance for the year: ranges for adjusted EBITDAaL, free cash flow" (the preview's wording, which works), and (c) "loss or profit for the period, operating profit, impairment, one-off gains and charges, legal proceedings and contingent liabilities".
2. Require the profit or loss for the period in euros, with the comparison, before the loss per share.
3. A figure for profit, loss or operating profit is copied with the page it is on; if the saved result does not contain the exact figure, it is not used.
4. Search the rating action text, not only the opinion sections, for the cause of the change in net debt, and quote it.
5. A script check that a recap states a profit or loss for the period in currency, and that it does not contain "not found in the report" for guidance ranges without also giving the transcript's figures.
