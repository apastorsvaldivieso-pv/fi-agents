# Third line-by-line review of the news brief

Done on 15 Nov 2026, after the second set of fixes (a results step, confirming a thin item before parking it, figures only from an article about the name, event dates, "no material credit news"). Same method as before: two fresh 7-day runs of `sector-news-brief` on Opus 5.5 (European telecoms, European banks; window 8 Nov 23:16 to 15 Nov 23:16 UTC), each then checked by a separate reader that re-pulled ratings, research and news from Moody's. The runs are in `evals/runs/review3-news-telecoms/` and `evals/runs/review3-news-banks/`.

**The target is zero wrong and zero unsupported. Unsupported is now zero. Wrong is not.**

| | Wrong | Missing | Unsupported |
|---|---|---|---|
| Telecoms: first / second / **third** | 3 / 2 / **2** | 6 / 3 / **1** | 4 / 2 / **0** |
| Banks: first / second / **third** | 4 / 2 / **2** | 5 / 2 / **1** | 3 / 1 / **0** |
| **Total: first / second / third** | 7 / 4 / **4** | 11 / 5 / **2** | 7 / 3 / **0** |

The readers checked about 60 facts (telecoms) and about 55 (banks). All 30 ratings, classes and outlooks are right. 

## What this round fixed

- **Results in full, for most names.** Telefonica (Q3 profit, guidance up and down, net debt EUR 25.2bn, leverage 2.63x, a provision, the dividend), TIM (loss with its one-off costs, EBITDA down, net debt up, targets kept) and UniCredit (profit, provisions, CET1 15.0%, EUR 4.5bn interim dividend, higher profit ambition) are all complete. Each was partial in the second review.
- **No unsupported claim.** Every "why it matters" line matches Moody's wording. The figure that came from another company's article last time is gone.
- **Old news is treated as old.** Commerzbank, BNP Paribas, Barclays and Lloyds results from before the window are left out, with their dates. The reasons given for every left-out item are true.
- **Review status** is attributed to the right ratings and direction.

## What is still wrong

### Wrong (4)

| Brief | What it said | What the source says |
|---|---|---|
| Telecoms | The searches returned no Moody's research on the listed names in the window | A Moody's issuer profile of Deutsche Telekom (PBC_1500087, 9 Nov) is in the window. The skill's research search does not ask for issuer profiles, so it could not return it |
| Telecoms | VMED O2: the corporate family rating, the default rating and one bank facility are on review for downgrade | The rating action (PR_531559) placed all ratings of VMED O2 and its rated affiliates on review. Direction and date are right |
| Banks | The cost of the Italian bank levies is "not in the sources returned" | The brief's own source says Italy plans to collect EUR 5.9bn from the financial sector in 2027, rising to EUR 12bn through 2029 |
| Banks | BBVA "USD 2.05bn senior non-preferred notes (13 Nov)" | BBVA's release of 10 Nov lists the deal as already placed. 13 Nov is the date of a filing |

### Missing (2)

| Name | Item |
|---|---|
| Vodafone | The half-year net result and the Germany impairment. The brief says the net result was "not in the sources returned". Moody's news in the window carries it: a weekly review (13 Nov) gives a first-half loss of EUR 3.6bn against a EUR 1.1bn profit; another outlet (10 Nov) gives a loss to owners of EUR 4,789m. The run saw the figure only inside an article about another company, and the new rule ("a figure only from an article about that name") told it not to use it. Missing in all three reviews |
| Intesa Sanpaolo | The offer for Monte dei Paschi: offer document published 10 Nov, offer opens 24 Nov, about EUR 34.5bn to 35bn; the ECB asked for a cautious approach to dividends. The brief does not mention it. Missing in all three reviews |

### Minor

- TIM is dated by its call (11 Nov); results came out on 10 Nov.
- Telefonica's nine-month profit (EUR 464m, after an EUR 870m loss on discontinued operations) and TIM's leverage (1.89x) are in the sources and not given.
- Credit Agricole / Banco BPM: the terms (about 45%, a 20% premium, a EUR 1bn extraordinary dividend) are left out; sources differ on the board date.
- BBVA's AT1 is "reported 12 Nov" (priced 10 Nov); HSBC's AT1 "issued 13 Nov" is the settlement date (priced 5 Nov).
- The EBA sector comment is "credit positive for small EU banks"; the brief says EU banks.
- A macro line reads as if S&P's Italy rating caps Moody's bank ratings.
- No last rating action dates in the table.

## What this shows

1. **The fixes work where the figure is in an article body or a call transcript.** Three of the four names with partial results last time are now complete.
2. **Vodafone is the hard case.** Its loss is not stated on the call, and the articles that carry it are a weekly review and an aggregator. The results report itself (the interim filing Moody's holds) has it, and the skill does not look there. The "article about that name" rule, added to stop a wrong-company figure, also stopped a right one.
3. **Bank news is crowded.** Intesa's largest item of the week has been missed three times. A search for a large bank returns mostly share filings; the deal articles are there, further down.
4. **Two errors are about reading what was already pulled**: the levy cost was in the brief's own source, and the rating action lists every rating under review.
5. **Dates still slip** when the only dated thing is a filing or an article (BBVA twice, HSBC).

## Proposed fixes (all seven applied later on 15 Nov 2026; the review after them is `news-review-4.md`)

1. **Results: the report as the last resort.** If the news search and the transcript do not give the profit or loss, one `searchCompanyFilings` call for the interim or annual report ("profit or loss for the period, impairment, net debt"). It holds the figures for every listed company.
2. **Loosen the wrong-company rule by one clause.** A figure may be used when the sentence that carries it names the company, whatever the article is about; it is then quoted with its outlet ("a first-half loss of EUR 3.6bn, per ShareCast").
3. **Banks: a second search per name with keywords** ("takeover offer, merger, bond, AT1, dividend, levy, ruling"), which cuts out share-filing noise. About 15 more calls on the checked list.
4. **Research search asks for issuer profiles too**, and the line says which kinds of document were searched.
5. **A name under review: list the ratings the action lists**, or say "all ratings".
6. **Before writing "not in the sources returned", search the text already pulled** for the figure.
7. **A date is the event's date only if the source says so**; a filing date or article date is written as "filed on" or "reported on". This rule exists; a script check for a date next to a bond or deal figure could not tell the difference, so this stays a reader's check.
