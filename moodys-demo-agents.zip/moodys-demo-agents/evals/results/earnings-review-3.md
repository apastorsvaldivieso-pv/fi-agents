# Third line-by-line review of the earnings recap

Done on 15 Nov 2026, after the second set of fixes to the recap: three filing queries of one subject each, the profit or loss for the period in currency, every filing figure found in the saved result before it is used, and the rating action's text searched for what moved leverage. Same method as before (`earnings-review.md`, `earnings-review-2.md`): a fresh Vodafone recap on Opus 5.5, then a separate reader that re-pulled everything from Moody's. The run is in `evals/runs/review3-earn-vodafone/`.

| | Wrong | Missing | Unsupported | Facts checked |
|---|---|---|---|---|
| First review | 1 | 6 | 1 (not verified) | about 50 |
| Second review | 1 | 4 | 0 | about 48 |
| **This review** | **0** | **3** | **0** | about 50 |

**The target of zero wrong and zero unsupported is met in this review.** Three items are still missing.

## What this round fixed

- **The guidance ranges are in**, old and new, from the report. All three earlier recaps said they could not be found.
- **The loss is in euros**: loss for the period EUR 3,597m, loss to owners EUR 4,789m, tax charge EUR 3,224m.
- **No figure that is not in the report.** The operating profit figure that was wrong last time is gone.
- Still right: the impairment and its discount rate, the Safaricom gain, the court ruling with both dates, a net debt movement that adds up, liquidity, capex, the dividend.

## Missing (3)

| Item | Where it is |
|---|---|
| The size of the deferred tax write-downs: UK EUR 2,247m, Germany EUR 235m. The answer says their size "was not found in the report" | Interim report, tax discussion and note 4 |
| What Moody's says about Safaricom: net leverage rose "following the UK transaction and the acquisition of an additional 20% stake in Safaricom", and Moody's expects it back in the lower half of the range by the end of the fiscal year. The answer says Safaricom "is not in the sections pulled" | The rating action the answer cites (PR_528027); the credit opinion. **Missed in all three reviews** |
| 2,300 further job cuts in Germany, inside the existing restructuring budget | Call. Missed in all three reviews |

## Minor (4)

1. The answer uses the company's 15% for the Safaricom stake; Moody's says 20%. The difference is not flagged.
2. An analyst's figure for OXG equity (up to EUR 1.2bn) is left out.
3. "So Vodafone still consolidates Safaricom" is the answer's inference; the court order says only that the shares stay registered as they are.
4. "Upgrade level already met" on one ratio can read as if an upgrade were in reach.

## What the eval reruns add

- **All three Vodafone recaps now give the guidance ranges in euros**, old to new. None did last round.
- **Two of the three give the loss for the period and the loss to owners in euros**, with last year's figures. The one written with no dashboard and no scripts (`earn-08`) says the "loss for the period" line was not returned and gives the loss before tax (EUR 373m): it could read only the first third of each saved filing.
- **All three say Safaricom is "not in the sections pulled".** None quotes the rating action.
- All three mention the Kenyan ruling and show a net debt movement that adds up.
- One recap offsets the impairment with "other income of EUR 3,369m"; the other two use the EUR 3,022m Safaricom gain. Only one gives the tax charge, so the gap between the impairment and the loss is unexplained in the other two.
- All eight earnings runs pass every script check, including `earn-08`.

## Why the Safaricom sentence keeps being missed (my reading)

The recap's Moody's-comment search asks for documents about "<issuer> results" and takes a few passages of each. The rating action is returned, but the passages returned are the ones nearest "results", not the paragraph on leverage. The rule says to search the rating action's text; the text the run holds does not contain the sentence.

## Proposed fixes (none applied)

1. One more Moody's call in a recap: `searchAllDocuments` scoped to the issuer, document type Rating Action, keywords "net leverage increased following" plus the name of the largest deal in the net debt movement. Quote what comes back.
2. Add "deferred tax" to the third filing query, and require the size of each write-down named in the report.
3. Add "headcount, job cuts and restructuring" to the second transcript query.
