# Second line-by-line review of the regulatory watch

Done on 15 Nov 2026, after two changes: scope words stay the regulator's own, and the scope of the Basel methodology consultation is written into the bank scope file. Same method as the first review (`reg-review.md`): a fresh 30-day run on Opus 5.5 (European banks, 16 Oct to 15 Nov 2026), then a separate reader that opened each regulator's listing and each item's page and re-pulled every metric from Moody's. The run is in `evals/runs/review2-reg-banks/`.

| | Wrong | Missing | Unsupported | Facts checked |
|---|---|---|---|---|
| First review | 1 | 0 | 0 | about 115 |
| **This review** | **0** | **0** | **0** | about 85 |

## What the reader confirmed

- **PRA CP14/26** is now described in the PRA's words: it "would move almost half of current Senior Manager Functions to a notification approach". This was the one wrong statement last time.
- **Items.** Every entry dated inside the window on all seven listings is either shown (12 items) or named as left out, and every reason given is true. Dates, bodies, status and deadlines are right for all 12.
- **Scope.** The table ranks the eight G-SIBs on the FSB list. Its heading names only the window-dressing amendments; the methodology consultation is in the note, with the five banking-union G-SIBs, marked as our reading.
- **Figures.** CET1 for all eight at Q2 2026, the median (14.01%), every gap and distance, and the thirds. Credit Agricole is measured as the group.
- **Requirements.** Every figure, date and "older" mark matches the bank scope file.
- **Moody's view.** The one comment quoted exists, with its title, date and direction.

## Minor (5)

1. The threshold rise from EUR 200bn to EUR 350bn is given without its measure (leverage ratio exposure).
2. The table note gives one of the two facts the scope file asks for (the buffer falls on the listed G-SIBs) and not the other (a wider sample reports the scores). The out-of-scope names have no explicit reason.
3. The EBA's reporting deferral is listed as if complete; the EBA says "selected reporting areas, including".
4. The headline calls the window-dressing amendments "the one mapped to capital"; the consultation is also tagged to capital in its own line.
5. Barclays' 12.2% drops "excluding any PRA buffer". FINMA's ordinance is shown as final; its PDF is labelled provisional.

## Not checked

ECB Banking Supervision items from 7 to 15 Nov: its feed was last built on 6 Nov. A site search found only a newsletter, which is a left-out type.

## What the eval reruns add

One clean review is one answer. Across the thirteen regulatory watch reruns of this round:

- **The heading rule now holds in every run.** Last round, four of nine runs named the consultation in the heading of the eight-name table.
- **"More than 55%" holds in every run.**
- **The scope-word rule holds in seven of the nine runs that show CP14/26.** Two (`reg-02`, `reg-06`) still write "most Senior Manager Functions". The others write "almost half", "roughly half", "some" or "many".
- **One cold run missed an item**: `reg-09-known-window-r3` shows 11 items and does not show the Commission's securitisation agreement of 22 Oct.

## Proposed fixes (the check in 1 was added on 15 Nov 2026 and catches both runs)

1. A script check that a line on CP14/26, or any line naming a share of something, does not say "most" unless the source list's title does. Simpler: a `not_contains:most Senior Manager` check on the 30-day cases.
2. The two minor points on the table note (both scope facts; the reason for out-of-scope names) are already rules in the skill. No rule change proposed.
