**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, 15 names)**

**Your question: which of your banks do the EBA's revised governance guidelines hit?**

I can't name any, and I haven't forced a ranking. The guidelines affect governance, and Moody's data has no governance metric to compare your 15 banks on. That would need something like board composition or an assessment of how duties are mapped, which Moody's financials don't hold. So the item is marked **watch**, with no exposed, neutral or resilient call on any name.

What the sources do say:
- **EBA, EBA/GL/2026/10, final, published 5 Nov 2026** (awaiting translation; the page gives no application date). The guidelines add a mapping of duties for management body members and key function holders under CRD VI, a governance framework for third-country branches, simpler conflict-of-interest rules and alignment with DORA. [EBA press release](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and)
- **Moody's view** (Sector Comment, 11 Nov 2026, PBC_1502042): **credit positive** for EU banks. Moody's expects the largest relative benefit for smaller banks, banks with concentrated ownership or a history of related-party lending, and third-country branches. It sees little new for large banks, which have already been adopting most of the guidelines; the rules are applied on a comply-or-explain basis. All 15 names on your list are large groups.

**Other items in the window** (all NEW, since this is the first run)

| Date | Body | Item | Status | Channel | Call |
|---|---|---|---|---|---|
| 16 Oct | Basel Committee | G-SIB framework: indicators move to averages over the reporting year (in force 1 Jan 2030); separate consultation on Banking Union cross-border exposures, comments by 14 Jan 2027 | Final + consultation | Capital buffers (G-SIB) | CET1 table below |
| 9 Nov | Basel Committee | Additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB), comments by 9 Feb 2027 | Consultation | IRRBB | watch: no IRRBB metric in Moody's data |
| 10 Nov | PRA | PS20/26 large exposures: substitution approach becomes mandatory; one NCLEG limit of 350% of Tier 1; effective 1 Jan 2028 | Final | Large exposures | watch: no metric (UK names: HSBC, Barclays, Lloyds) |
| 6 Nov | EBA | Supervisory reporting simplification: final ITS due Dec 2026; first reference date Dec 2027 | Next steps (not final) | Reporting | watch: no metric |

**Who it hits: capital buffers (G-SIB item only).** This table ranks the whole list on CET1 ratio (as reported, Q2 2026, Moody's Bank Focus data). The averaging rule applies only to G-SIBs, and this run doesn't identify which of your names are G-SIBs.
- Exposed (lowest CET1): Credit Agricole S.A. 11.30%, CaixaBank 12.33%, BBVA 12.90%, BNP Paribas 12.97%, Intesa Sanpaolo 13.00%
- Neutral: ING 13.07%, Societe Generale 13.20%, Lloyds 13.60%, Deutsche Bank 13.92%, HSBC 14.10%
- Resilient: UniCredit 14.26%, Barclays 14.30%, UBS 14.38%, Commerzbank 14.38%, Nordea 15.70%
- List median 13.60%. CET1 minimums are set bank by bank, and no Moody's document in this run states one, so I don't show a distance to the minimum.

Calls show where each bank sits within this list on the stated metric. They are not an estimate of impact. Moody's has not commented on the G-SIB or IRRBB items in the window.

Not verified, so left out: an EBA consultation on the Article 113 joint-decision ITS (search result dated 5 Nov) and PRA CP14/26 on the Senior Managers and Certification Regime (no date found).

The "Regulatory watch" tab is updated (13:04 UTC, 15 Nov 2026): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-03-no-metric/dashboard/dashboard.html`. I didn't publish it to the shared link in this run.
