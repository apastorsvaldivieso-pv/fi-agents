**Iliad Holding S.A.S.: earnings recap**

I can't give a full recap. Moody's has no earnings call transcript for Iliad Holding S.A.S., and it has published no Issuer Comment, Rating Action or Credit Opinion on the issuer between 1 Oct and 15 Nov 2026. So there is nothing on how results compared with guidance, any change to guidance, or what management said about leverage, liquidity, capex or refinancing. I did not look for a transcript on the web.

Here is where the issuer stands on Moody's data:

**Rating and outlook.** Ba2 LT Corporate Family Rating, outlook stable. Moody's upgraded it from Ba3 on 19 Jun 2026. The latest credit opinion is dated 30 Jun 2026, so it predates any results after H1 2026. The outlook expects "steady earnings and cash flow growth" to bring some improvement in credit metrics ahead of the SFR acquisition, and leverage to come down once that deal completes.

**Against Moody's triggers (Moody's-adjusted, LTM 30 Jun 2026)**

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room to upgrade | Room to downgrade |
|---|---|---|---|---|---|
| Debt / EBITDA | 4.20x | below 3.5x | "well above 4.0x" | 0.70x | 0.20x above the 4.0x reference; Moody's does not put a number on "well above" |
| RCF / Net Debt | 13.99% | towards 25% | no number given | 11.0 pp | n/a |

Downgrade trigger in Moody's words: operating performance deteriorates, or further large debt-financed acquisitions or shareholder distributions, "such that Moody's-adjusted debt/EBITDA remains well above 4.0x and Moody's-adjusted free cash flow (FCF) weakens significantly."

**Moody's forecasts (credit opinion, 30 Jun 2026):** debt/EBITDA 4.3x in 2026F, 4.0x in 2027F and 3.7x in 2028F. RCF/net debt 14.5%, 15.3% and 16.8% over the same years.

Notes:
- Iliad Holding is the holding company of Iliad S.A., which Moody's rates separately (Ba1) and which is on the telecoms coverage list. This answer covers Iliad Holding only.
- The opinion puts 2025 debt/EBITDA at 4.3x. The financials data puts FY2025 at 4.18x. The table above uses the latest financials (LTM Jun 2026).

I can run an **earnings preview** for Iliad Holding instead, or a recap for **Iliad S.A.** if a transcript is filed under that entity. Try the recap again once Moody's comments on the results.

Sources: Moody's credit opinion PBC_1488484 (30 Jun 2026); rating history RTNG_867915244; Moody's-adjusted key indicators, LTM 30 Jun 2026; transcript search (not found); document search 1 Oct to 15 Nov 2026 (none found).

Dashboard: the Earnings tab ("Iliad Holding, recap") was updated at 13:01 UTC on 15 Nov 2026. Local page: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html (artifact publish skipped for this test run).
