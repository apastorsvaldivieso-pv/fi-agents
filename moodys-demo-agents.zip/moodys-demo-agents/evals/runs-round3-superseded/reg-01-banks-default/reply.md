**Regulatory watch: European banks, 8 to 15 Nov 2026**

Coverage: the checked list of 15 European banks (BNP Paribas, HSBC, Crédit Agricole, Barclays, Société Générale, Deutsche Bank, UBS, ING, Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea). Nothing was unresolved. Banco Santander is not on the list because its rated record returns no financials.

**What changed (both items are NEW)**

1. **Basel Committee: IRRBB additional Pillar 2 guidance. Consultation, published 9 Nov, comments due 9 Feb 2027.** It adds expectations on IRRBB model risk and validation, stress testing, controls, embedded gains and losses in securities portfolios and earnings indicators. It also adds a new "Supervisory Information" reporting category so supervisors can flag banks with excessive IRRBB earlier. It amends SRP31 and SRP98. Status: **watch**. Moody's data has no IRRBB measure such as EVE or NII sensitivity, so I make no call on any name. The channel map has no IRRBB row, so this mapping is my own judgment. I found no Moody's comment on it. [bis.org](https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance)

2. **PRA: PS20/26, Large Exposures Framework Part 2. Final, published 10 Nov, effective 1 Jan 2028.** Substitution becomes mandatory for all firms and the internal-model option for SFT exposure values is removed. The trading book excess allowance falls to up to 85% of Tier 1, intragroup trading book excess is set at 85% of Tier 1, and the higher trading book NCLEG limit is set at 350% of Tier 1. Status: **watch**. Moody's has no large exposures field, so I make no call on any name. The PRA-regulated groups on the list are HSBC, Barclays and Lloyds. I found no Moody's comment on it. [bankofengland.co.uk](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement)

**Who it hits:** I can't make any exposure calls this week. Neither item maps to a metric in Moody's bank data. I pulled financials for all 15 names (Q2 2026), but none of those metrics measures what these two rules change.

**Just outside the window:** the EBA's final internal governance guidelines (EBA/GL/2026/10) came out on 5 Nov. On 11 Nov, Moody's called them credit positive for small EU banks, with less effect on large banks that already follow them (PBC_1502042).

The Regulatory watch tab on the dashboard updated at 2026-11-15 13:03 UTC:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html`
This was a test run, so I did not publish the Artifact.
