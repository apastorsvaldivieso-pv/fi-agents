**Regulatory watch: European banks, 30 days (16 Oct to 15 Nov 2026)**

I found six items at the primary regulators. None of them touches liquidity. The only one with a capital channel is the Basel Committee's final rule on G-SIB window-dressing. As you asked, the liquidity table is included anyway: every bank on the list holds an LCR at least 34 pp above the 100% minimum (Q2 2026).

**What changed** (all NEW, since this is the first run)
- **Basel Committee, final rule plus a consultation (16 Oct).** G-SIB indicators will be reported as averages over the year, not year-end values, by 1 Jan 2030. The reporting threshold rises from EUR 200bn to EUR 350bn, effective from 2027. A separate consultation on the G-SIB methodology, including how cross-border exposures within the Banking Union are treated, closes 14 Jan 2027. Channel: capital (G-SIB buffers), so I ranked the list on CET1. No Moody's comment found.
- **Basel Committee, consultation on IRRBB Pillar 2 guidance (9 Nov).** Comments are due 9 Feb 2027. Marked *watch*: Moody's data has no IRRBB measure.
- **EBA, final revised internal governance guidelines (5 Nov).** Marked *watch*. Moody's (Sector Comment, 11 Nov) calls them credit positive, with more effect on smaller banks.
- **PRA PS20/26, final large exposures rules (10 Nov).** They take effect 1 Jan 2028. Marked *watch*: there is no Moody's metric.
- **EU securitisation review, political agreement (21–22 Oct).** Not final law yet. Marked *watch*: Moody's financials do not carry securitisation or SRT positions.
- **EBA, next steps on supervisory reporting (6 Nov).** Liquidity reporting is deferred to Dec 2028. It changes reporting only, not the LCR requirement.

**Who it hits: liquidity (LCR, as reported, Q2 2026). Shown at your request; no item hits it this month.** The list median is 141.29%.

| Name | LCR | Distance to 100% | Call |
|---|---|---|---|
| HSBC | 134.00% | +34.00 pp | exposed |
| BNP Paribas | 134.77% | +34.77 pp | exposed |
| ING | 137.00% | +37.00 pp | exposed |
| Intesa Sanpaolo | 137.60% | +37.60 pp | exposed |
| UniCredit | 140.00% | +40.00 pp | exposed |
| Deutsche Bank | 140.12% | +40.12 pp | neutral |
| Commerzbank | 141.00% | +41.00 pp | neutral |
| Crédit Agricole SA | 141.29% | +41.29 pp | neutral |
| BBVA | 142.00% | +42.00 pp | neutral |
| Lloyds | 144.00% | +44.00 pp | neutral |
| Société Générale | 146.41% | +46.41 pp | resilient |
| Nordea | 156.00% | +56.00 pp | resilient |
| Barclays | 157.70% | +57.70 pp | resilient |
| UBS | 177.28% | +77.28 pp | resilient |
| CaixaBank | 192.99% | +92.99 pp | resilient |

**Who it hits: capital (CET1, as reported, Q2 2026), for the G-SIB item.** The list median is 13.60%.
- **Exposed:** Crédit Agricole SA 11.30%, CaixaBank 12.33%, BBVA 12.90%, BNP Paribas 12.97%, Intesa 13.00%.
- **Resilient:** Nordea 15.70%, UBS 14.38%, Commerzbank 14.38%, Barclays 14.30%, UniCredit 14.26%.
- **Distance to minimum:** not shown. CET1 requirements are firm-specific, and I found no Moody's document that states them.

**How to read the tables**
- Calls show each bank's position within this list. They are not an estimate of impact.
- The 100% LCR minimum is the Basel III standard. Local rules can be higher, for example Swiss rules for UBS.
- Figures are company-reported ratios held by Moody's, for Q2 2026. Q3 results are not in Moody's data yet.
- Banco Santander is left off the list because Moody's returns no financials for it.

The Regulatory watch tab was updated at 13:05 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html`. It was not published to the private link because this is a test run.
