**European banks: news brief, last 72 hours** (12 Nov 13:00 UTC to 15 Nov 2026 13:00 UTC)

Coverage for this run:

| Name | Country | Moody's rating |
|---|---|---|
| Banco Santander, S.A. (Spain) | ES | A1 LT Issuer Rating, stable |
| BNP Paribas | FR | A1 LT Issuer Rating, stable |
| UniCredit S.p.A. | IT | A3 Senior Unsecured (foreign currency), under review |

All three resolved. Moody's first returned Open Bank, S.A. (a Santander subsidiary) for "Banco Santander". I didn't use it and took the parent, Banco Santander, S.A. (Spain), instead. Unresolved: none.

**Top, last 72 hours**
1. **UniCredit is close to taking control of Commerzbank.** It expects unconditional EU merger clearance by 16 Nov. Once the offer settles, it plans an extraordinary general meeting to elect Commerzbank's supervisory board. *Why it matters:* control of Commerzbank changes UniCredit's capital, funding and integration profile. Moody's has UniCredit's rating under review, so the completion terms are the input to watch. (Ad Hoc News, 13 and 14 Nov)
2. **UniCredit sold a USD 3.5 billion multi-tranche bond in the US market** (reported 13 Nov). *Why it matters:* it shows UniCredit can still raise dollar wholesale funding while the Commerzbank deal is pending, which supports refinancing and liquidity. (Ad Hoc News, 13 Nov)

**Macro**
- **Bank of England:** headlines expect further rate rises in 2027 and say UK price data may strengthen the case (15 Nov). *Why it matters:* this supports banks' UK net interest income but puts pressure on borrowers' refinancing and on asset quality.
- **Euro area:** government bond yields rose on 13 Nov, along with US Treasury yields. *Why it matters:* higher yields raise banks' wholesale funding costs and change the value of their bond portfolios.

**Sector (Moody's)**
- **Rating action, VUB (Slovakia, Intesa Sanpaolo subsidiary; not on your list), 12 Nov:** deposit ratings upgraded to A1 from A2, and the outlook changed to stable from positive. The action links VUB's BCA to Intesa's under the single-point-of-entry resolution approach.
- **Sector Comment, Greek banks (not on your list), 13 Nov:** Moody's says the competition commission's proposals are unlikely to erode the deposit franchises of the four systemic banks, and that deposit costs would probably rise only gradually.
- **Latest sector outlook:** the global banks outlook is stable (3 Dec 2025). The Spain and Italy banking system outlooks are both stable (9 Feb 2026). The search returned no France banking system outlook.

**By name**

| Name | Rating | News |
|---|---|---|
| Banco Santander | A1 LT Issuer Rating, stable (affirmed 22 Oct 2026) | No material credit news. |
| BNP Paribas | A1 LT Issuer Rating, stable (affirmed 31 Aug 2026) | No material credit news. |
| UniCredit | A3 Senior Unsecured (foreign currency), under review | Commerzbank control nears (EU clearance expected by 16 Nov, EGM planned); USD 3.5 billion US bond. |

Left out because they're not new or not about credit:
- BNP Paribas's Q3 results and buyback, announced 28 Oct, before the window.
- A sale of an Irish REIT stake by a BNP Paribas subsidiary.
- Share-price and broker-target stories.
- Unrelated stories tagged to Santander.

**Dashboard:** the "Daily sector news" tab was updated at 13:02 UTC on 15 Nov 2026. The local page is `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-06-banks-own-list/dashboard/dashboard.html`. I didn't publish it to the Artifact link, because this was a test run.
