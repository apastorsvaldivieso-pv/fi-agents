**Regulatory watch: European banks, PRA only, 13 to 15 November 2026: quiet.** The PRA published nothing in the window. Its most recent publication is dated 10 November 2026, before the window started. Source: [PRA publications RSS feed](https://www.bankofengland.co.uk/rss/prudential-regulation-publications).

With nothing new, there was no exposure ranking to run, so I made no Moody's calls.

The Regulatory watch tab was updated at 13:03 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-05-quiet/dashboard/dashboard.html`. I didn't publish it to the shared link because this is a test run.
