**Vodafone Group Plc, earnings recap: H1 FY27 (call of 10 Nov 2026)**

I ran this as a recap because you asked for one. Moody's has the transcript of the 10 Nov 2026 call, which is within the last 21 days.

**Rating:** Baa2 senior unsecured (foreign currency), stable outlook. Moody's affirmed it on 13 Oct 2026. The latest credit opinion is dated 21 Oct 2026, so it was written before these results.

**Results against the credit view** (figures from the call are company-reported, not Moody's-adjusted)
- **Guidance raised.** Vodafone raised its FY27 group guidance. The top of the old ranges is now the midpoint of the new ones. Management said the new midpoint means about 7% organic growth in adjusted EBITDA and about 21% in adjusted free cash flow. The euro ranges were not in the transcript excerpts. "Beat or miss" here is against the company's own guidance only.
- **H1 performance.** Group service revenue grew 6.4% in Q2, the fastest in three years. H1 adjusted EBITDA grew 6.4%. Vodafone Business grew 6.6%. Africa and Türkiye both grew at double digits organically.
- **Germany.**
  - H1 EBITDA fell 3.2%. About 2 points of that was a provision for the European Court of Justice ruling, roughly EUR 100m of EBITDA.
  - Guidance for Europe was confirmed but not raised.
  - Vodafone took a non-cash impairment on Germany. About three quarters of it came from a higher discount rate: 8%, up from 7.5%.
  - It announced 2,300 more job cuts in Germany.
  - Management said "we still have much more to do in Germany".
- **Against Moody's forecast.** Moody's FY2027 forecast is 3.1x debt/EBITDA, 29.4% RCF/net debt and 2.6x (EBITDA - capex)/interest. The call gave half-year growth rates, not these measures, so the results can't be compared directly with the forecast.
- **Leverage and liquidity.** Company net debt, leverage, liquidity, maturities, dividends and buybacks were not in the transcript excerpts.
- **Capex and funding.**
  - Management is not guiding to any material cut in German capital intensity.
  - In the OXG fibre joint venture, Société Générale replaces Altice. An analyst put Vodafone's possible equity injections at up to EUR 1.2bn. Management did not confirm the figure and said any equity would be phased over the build.
  - The class action linked to the ECJ ruling is not expected to end before late 2027 at the earliest, so no payment is expected before then, and the provision is not in this year's cash flow guidance.
  - Vodafone expects net opex cuts of more than EUR 200m in FY27.
- **Safaricom.** Vodafone has consolidated its extra 15% stake in Safaricom since 1 July. An analyst noted that Kenya's High Court declared the sale void in September. Management referred to local legal challenges.

**Against Moody's triggers** (Moody's-adjusted figures, fiscal year to 31 Mar 2026)

| Metric | Latest | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to stay below 3.3x (sustained) | 0.75x above upgrade; 0.05x below downgrade |
| RCF / Net Debt | 33.08% | above 25% (sustained) | towards 18% (sustained) | 8.08pp above upgrade; 15.08pp above downgrade |

The triggers that are stated in words:
- Upgrade requires that "underlying revenue and operating performance improve sustainably, particularly in Germany".
- Downgrade if "operating performance deteriorates, including a failure to turn around its German operations".

**What it means for the rating and outlook**
- The stable outlook expects Moody's-adjusted debt/EBITDA below 3.3x, RCF/net debt around 30%, at least stabilising trends in Germany, and Vodafone staying in the lower half of its own net leverage target range.
- On the last adjusted figures, debt/EBITDA is 0.05x inside the 3.3x downgrade trigger. RCF/net debt is above the outlook's level of about 30%.
- Both the credit opinion (21 Oct) and the affirmation (13 Oct) were published before these results. At the affirmation, Moody's said the German recovery path remains uncertain, especially once the benefit from 1&1 fades.
- Moody's has not published a comment on the H1 results; I searched from 1 Oct to 15 Nov 2026.

Sources: Moody's credit opinion PBC_1496608 (21 Oct 2026); rating action PR_528027 (13 Oct 2026); Moody's-adjusted key indicators for FY to 31 Mar 2026; transcript of the "Half Year 2027 Vodafone Group Public Ltd Co Earnings Call" (10 Nov 2026).

The Earnings tab on the dashboard ("Vodafone, recap") was updated at 13:01 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html`. I didn't publish it to a link (this was a test run).
