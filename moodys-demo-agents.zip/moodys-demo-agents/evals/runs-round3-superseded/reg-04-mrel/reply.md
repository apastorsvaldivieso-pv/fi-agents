**Regulatory watch, European banks: 8 to 15 Nov 2026**

**Short answer: Moody's data can't identify which names would be exposed to tighter MREL.** The financials Moody's holds for these banks have no MREL or TLAC field. Exposure depends on each bank's MREL requirement and how much eligible debt it holds against it, and neither is in the data. So I've marked MREL as **watch** for all 15 banks on the list and have not ranked them. Ranking on CET1 or leverage instead would be my own judgment, and the method doesn't support that.

**What changed this week**

- **MREL (you asked about this): no change this week.** The SRB, EBA, European Commission, PRA and FINMA published no MREL rule, consultation or decision in the window. The closest Moody's view is from 14 Sep 2026. It says the Commission is considering bringing the EU MREL definition closer to TLAC and making resolution planning more proportionate. Moody's calls that credit negative if it reduces the amount of bail-inable debt in the system. That points to possible loosening, not tightening. ([Moody's, PBC_1491385](https://www.moodys.com/research/doc--PBC_1491385))
- **NEW, Basel Committee consultation (9 Nov):** additional Pillar 2 guidance on interest rate risk in the banking book (IRRBB). It covers model risk and validation, stress testing, controls, embedded gains and losses in securities portfolios, earnings indicators, and a new reporting requirement. Comments are due by 9 Feb 2027. Moody's has no metric for this channel, so it is watch only. ([BIS](https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance))
- **NEW, PRA final rules, PS20/26 (10 Nov):** Large Exposures Framework, Part 2. When a bank uses credit risk mitigation, it must now count the exposure against the protection provider for large exposure limits ("mandatory substitution"). There are exemptions for sovereign collateral and tri-party repo. Internal models can no longer be used for SFT exposure values. It applies from 1 Jan 2028 to PRA-regulated firms (on this list: HSBC, Barclays, Lloyds, plus the UK entities of the others). Moody's has no metric for this channel, so it is watch only. ([Bank of England](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement))

**Who it hits**

| Channel | Moody's metric | Call on the 15 names |
|---|---|---|
| MREL / resolution (asked) | no MREL or TLAC field | watch, no call |
| Interest rate risk in the banking book | no field | watch, no call |
| Large exposures (UK) | no field | watch, no call |

None of this week's items maps to a Moody's metric, so I did not pull the sector financials. If you want to go further on MREL, the right source is each bank's Moody's credit opinion. Its Loss Given Failure section shows how much bail-in debt sits below senior creditors, and I can pull those for the names you care about.

Dashboard updated: Regulatory watch tab, 15 Nov 2026 13:08 UTC.
Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html` (Artifact publish skipped for this test run.)
