**European telecoms news brief, Monday 16 Nov 2026**
Window: 72h to 16 Nov 06:00 UTC, starting 13 Nov 06:00 UTC. My clock reads Sunday 15 Nov 13:02 UTC, so the news search stops there and anything published after that is not covered.

The weekend was quiet. Moody's published no rating actions and no research on European telecoms. One item matters for credit.

**Top this week**
- **Telenor ASA, Bahnhof offer (13 Nov).** Bahnhof's independent board committee recommended accepting Telenor Sverige's unconditional mandatory cash offer of SEK 62 per share. Telenor Sverige now holds about 66.9% of the shares and 90.6% of the votes, and it published a supplement to the offer document. The offer itself was announced on 6 Nov. *Why it matters:* the deal adds acquisition spending and debt while Telenor is on a positive outlook. These sources don't give the size of the remaining payment.

**Macro**
- Weekend headlines point to the Bank of England raising rates again in 2027, and say UK price data strengthens the case. *Why it matters:* refinancing costs rise for the UK names, and most for VMED O2 UK, whose rating is already under review for downgrade.
- Euro area and US government bond yields rose on 13 Nov. *Why it matters:* new bonds and refinancing get more expensive across the sector's large euro debt.

**Sector**
- No Moody's rating actions, sector comments or issuer comments on European telecoms were published in the window.
- Latest Moody's sector outlook: *Telecommunications – Global*, **stable**, published 27 Oct 2026. Solid demand, modest EBITDA growth and falling capital intensity support credit quality. Refinancing pressure and structural risks weigh against it.

**By name**

| Name | Moody's rating (class), outlook | News in the window |
|---|---|---|
| Deutsche Telekom AG | A3 (Senior Unsecured - Fgn Curr), stable | No material credit news. |
| Orange | Baa1 (LT Issuer Rating), stable | No material credit news. |
| Vodafone Group Plc | Baa2 (Senior Unsecured - Fgn Curr), stable | No material credit news. |
| Telefonica S.A. | Baa3 (Senior Unsecured - Dom Curr), stable | No material credit news. |
| Swisscom AG | A2 (LT Issuer Rating - Dom Curr), stable | No material credit news. |
| Telekom Austria AG | A3 (LT Issuer Rating), stable | No material credit news. |
| Proximus SA de droit public | A3 (Senior Unsecured - Dom Curr), stable | No material credit news. |
| Telenor ASA | Baa1 (Senior Unsecured - Fgn Curr), positive | Bahnhof offer: the board recommends acceptance; Telenor Sverige holds about 66.9% of shares and 90.6% of votes. |
| Telia Company AB | Baa1 (Senior Unsecured - Fgn Curr), stable | No material credit news. |
| TIM S.p.A. | Baa3 (LT Issuer Rating - Dom Curr), positive | No material credit news. |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer Rating - Dom Curr), stable | No material credit news. |
| BT Group Plc | Baa2 (LT Issuer Rating, at British Telecommunications Limited), stable | No material credit news. |
| Iliad S.A. | Ba1 (Senior Unsecured - Dom Curr), stable | No material credit news. |
| VMED O2 UK Holdings Limited | B1 (LT Corporate Family Rating - Fgn Curr), under review for downgrade | No material credit news. The review started on 22 Oct and is not new. |
| Altice France SAS | Caa1 (Senior Secured Bank Credit Facility - Fgn Curr), positive | No material credit news. |

**What I left out:**
- Deutsche Telekom's guidance raise and BT's pension valuation. Both were announced before the window, and the articles in the window add nothing new.
- Tenders and small contract awards.
- Share-price and broker commentary.
- Vodafone's ex-dividend date and a passive 13G stake filing.
- Subsidiary news that doesn't touch group credit: Vodacom, Vodafone Idea and Sparkle.

The **Daily sector news** tab is updated (15 Nov 2026 13:02 UTC). Dashboard page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-03-monday/dashboard/dashboard.html`. This was a test run, so I didn't publish to the Artifact link.
