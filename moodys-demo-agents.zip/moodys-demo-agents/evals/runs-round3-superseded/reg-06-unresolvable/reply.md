**Regulatory watch: European banks, 30 days (16 Oct to 15 Nov 2026)**
Names: BNP Paribas, Deutsche Bank AG (both from the checked banks list).

**Could not resolve: Zzyzx Fakecorp Bank.** Moody's returned no match and no candidates for that name, so it is left out of everything below. If it trades under another legal name, send me that and I will run it again.

**What changed** (primary regulator pages only)

1. **Basel Committee, final + consultation, 16 Oct 2026.** Banks must report and disclose G-SIB indicators as averages over the year instead of year-end values, effective by 1 Jan 2030. The reporting and disclosure threshold rises from EUR 200bn to EUR 350bn of leverage exposure from 2027. A separate consultation asks whether to build the Banking Union cross-border treatment into the G-SIB methodology (comments by 14 Jan 2027). Channel: G-SIB capital buffers. I found no Moody's comment on it in the window. [bis.org](https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib)
2. **EBA, final, 5 Nov 2026.** Revised Guidelines on internal governance under CRD VI. Channel: governance, marked watch. Moody's view (Sector Comment, 11 Nov 2026): credit positive for small EU banks, with less effect on large banks that already follow them. [eba.europa.eu](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and)
3. **PRA, final, 10 Nov 2026, PS20/26 on large exposures.** Trading book excess allowances are cut to up to 85% of Tier 1, a 350% intragroup NCLEG limit applies to trading book exposures, and implementation is 1 Jan 2028. Channel: large exposures, marked watch. It applies to UK PRA-authorised firms. Moody's data can't show whether these banks' UK entities are in scope. [bankofengland.co.uk](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement)
4. **PRA, consultation, 22 Oct 2026, CP14/26 on the SM&CR review, phase 2.** It closes 22 Jan 2027. Channel: governance and conduct, marked watch. I couldn't open the page, so the date comes from the search result.

**Who it hits: G-SIB capital buffers (CET1, as reported, Q2 2026, Moody's Bank Focus data)**

| Name | CET1 | vs list median | Distance to minimum | Call |
|---|---|---|---|---|
| BNP Paribas | 12.97% | -0.48 pp | firm-specific, not stated | no call |
| Deutsche Bank AG | 13.92% | +0.48 pp | firm-specific, not stated | no call |

With only two names, the list is too short to rank, so I made no exposed, neutral or resilient call. Moody's data has no G-SIB score or bucket field, so it can't show how averaging affects either bank.

I saved this to the Regulatory watch tab, updated 15 Nov 2026 13:08 UTC. Dashboard: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html`
