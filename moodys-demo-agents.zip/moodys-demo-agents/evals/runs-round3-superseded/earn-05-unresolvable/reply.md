I couldn't find **Zzyzx Fakecorp Holdings** in Moody's, so I've stopped and haven't written a preview.

- **What I searched:** one Moody's entity search for "Zzyzx Fakecorp Holdings", with alternatives turned on. It returned no entities and no alternatives ("Name search produced no results").
- **Why I stopped:** an earnings preview is built on the issuer's Moody's credit opinion, rating and adjusted financials. Without a confirmed entity, there's nothing to set the results against. I haven't swapped in a similar-sounding company.
- **Dashboard:** not updated. The Earnings tab still shows the last run.

If you meant a different company, send me the exact legal name or ticker and its home country. You can also send a Moody's or Orbis ID. I'll run the preview from there.
