**Daily sector news: Telecoms, Europe** (24h to 15 Nov 2026 13:00 UTC, 15 names)

Nothing material for Telecoms, Europe, in the last 24h.

Moody's published no rating actions and no sector or issuer research on the list in the window, and none of the company news touched leverage, cash flow, liquidity, funding, ownership, regulation or a rating. Most of what turned up was weekend recaps of Deutsche Telekom's 5 Nov Q3 results, a few small contract awards, and stories wrongly tagged to Orange, TIM, BT and Iliad. For context only: the latest Moody's sector outlook is Telecommunications – Global, stable, dated 27 Oct 2026.

The Daily sector news tab on the FI Credit Monitor dashboard was updated at 13:02 UTC on 15 Nov 2026:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/news-01-telecoms-default/dashboard/dashboard.html`
(Not published to an Artifact link because this is a test run.)
