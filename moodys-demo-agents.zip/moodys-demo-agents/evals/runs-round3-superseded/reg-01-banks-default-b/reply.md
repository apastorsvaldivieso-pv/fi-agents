**Regulatory watch: European banks, 9 to 15 Nov 2026**

I checked the primary regulators only: Basel Committee, EBA, ECB, SRB, European Commission, PRA and FINMA. I found three items this week. None of them maps to a Moody's metric, so all three are on watch and I made no exposure call on any of the 15 names on the coverage list.

**What changed (all NEW, since this is the first run)**

1. **Basel Committee: consultation on IRRBB, 9 Nov.** This is a consultative document with extra Pillar 2 guidance on interest rate risk in the banking book. It is a consultation, not a final rule. bis.org blocked automated access, so I could not open the page. The date comes from the search result, and I could not confirm the comment deadline.
2. **EBA: final methodology for the 2027 EU-wide stress test, 9 Nov.** The methodology is final. The templates are still drafts and may get minor technical changes. Banks will report 55% fewer data points, and a new climate module will not affect the core results. The test launches at the end of January 2027 and results come out at the end of July 2027. The page does not list the participating banks, and the exercise covers EU banks only, so the UK and Swiss names are outside it.
3. **PRA: PS20/26, final Large Exposures rules (Part 2), 10 Nov.** Internal models can no longer be used for SFT exposure values. Trading book excess allowances are lower. A new higher limit for intragroup exposures (NCLEG) is set at 350%, and banks must substitute exposures to credit risk mitigation providers. The rules take effect on 1 January 2028.

**Who it hits**

| Item | Metric needed | Call |
|---|---|---|
| Basel IRRBB consultation | IRRBB sensitivity (no Moody's field) | watch |
| EBA 2027 stress test | No row in the channel map; the sample of banks is not named | watch |
| PRA PS20/26 large exposures | Large exposures (no Moody's field) | watch |

**Moody's view:** Moody's has published nothing on these three items since they came out. One item from just before the window: on 11 Nov Moody's called the EBA's revised internal governance guidelines (published 5 Nov) credit positive for small EU banks.

**Gaps:** The ECB Banking Supervision and FINMA listing pages did not load. Site searches of both found nothing in the window. Speeches, newsletters, the SRB note to the Eurogroup and the dialogue on EU banking competitiveness are not regulatory items, so I left them out.

The Regulatory watch tab is updated as of 2026-11-15 13:19 UTC:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html`

Sources: [BCBS overview](https://www.bis.org/committees/bcbs/overview) · [EBA 2027 stress test](https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data) · [PRA PS20/26](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement) · Moody's PBC_1502042
