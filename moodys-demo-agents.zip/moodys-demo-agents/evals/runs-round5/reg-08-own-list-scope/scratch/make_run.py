import json
FIN="getEntityFinancials_v2"; REF="Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ)"
banks=[("Credit Agricole S.A.","m8","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/FR784608416",11.3),
("BNP Paribas","m2","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/FR662042449",12.97),
("ING Groep N.V.","m6","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/NL33231073",13.07),
("Societe Generale","m7","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/FR552120222",13.2),
("Deutsche Bank AG","m3","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/DEFEB13216",13.92),
("HSBC Holdings plc","m1","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/GB00617987",14.1),
("Barclays PLC","m5","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/GB00048839",14.3),
("UBS Group AG","m4","https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/CHCHE395345924",14.38)]
req={"UBS Group AG":("10.83% going-concern CET1 requirement, 30 Jun 2026","f1",10.83,""),
"Societe Generale":("10.26% CET1 requirement, shown against 31 Mar 2026","f2",10.26,""),
"Credit Agricole S.A.":("Total not stated; bank states distance to SREP requirement","f3",None,"+2.6 pp (bank-stated, 31 Mar 2026, phased-in CET1)"),
"BNP Paribas":("10.51% CET1 capital requirement, 30 Sep 2025 (older)","f4",10.51," (older)"),
"Barclays PLC":("12.2% overall CET1 requirement excl. PRA buffer, 31 Dec 2025 (older)","f5",12.2," (older)"),
"ING Groep N.V.":("11.03% MDA trigger level, 31 Dec 2025 (older)","f6",11.03," (older)")}
tone={"Credit Agricole S.A.":"weaker","BNP Paribas":"weaker","Barclays PLC":"stronger","UBS Group AG":"stronger"}
med=(13.2+13.92)/2
rows=[]
for n,s,u,v in banks:
    r=[n,{"v":"%.2f%%"%v,"src":[s]},{"v":"%+.2f pp"%(v-med),"src":[s]}]
    if n in req:
        t,fs,rv,suf=req[n]
        r.append({"v":t,"src":[fs]})
        if rv is None: r.append({"v":suf,"src":[fs]})
        else: r.append({"v":"%+.2f pp%s"%(v-rv,suf),"src":[s,fs]})
    else:
        r.append("not stated"); r.append("not stated")
    tn=tone.get(n,"middle")
    r.append({"tone":tn,"v":""})
    rows.append(r)
cols=["Name","CET1 ratio (as reported, Q2 2026)","vs median of ranked names (pp)","Stated requirement (date)","Distance to requirement","Position (by level)"]
note="Out of scope: Danske Bank A/S, KBC Group N.V., Banco de Sabadell, S.A., Swedbank AB (not on the FSB G-SIB list of 27 Nov 2025). Ranked by CET1 level (case B): only 3 of 8 have a current stated requirement. Median of the 8 ranked names: 13.56%. Credit Agricole S.A. is shown for Groupe Credit Agricole, the listed G-SIB."
nsrc=["w14","m1","m2","m3","m4","m5","m6","m7","m8"]
def table(title): return {"title":title,"type":"table","columns":cols,"rows":rows,"note":note,"note_src":nsrc}
EU="BNP Paribas, Deutsche Bank, ING, Societe Generale, Credit Agricole, Danske Bank, KBC Group, Banco Sabadell, Swedbank"
ALL="All 12, once each home country applies it"
items=[
 ("2026-11-10","NEW","Final","PRA","PS20/26, the second part of the Large Exposures Framework amendments: the substitution approach for credit risk mitigation becomes mandatory, the internal model option for securities financing exposures is removed, and trading book excess and intragroup limits are tightened (to 85% of Tier 1). Implementation 1 Jan 2028; permission applications from 1 Jul 2027.","Large exposures channel: no Moody's metric (watch). Covers HSBC and Barclays.",["w10"]),
 ("2026-11-10","NEW","Final","FINMA","Partially revised FINMA Anti-Money Laundering Ordinance published in final form, aligned with recent AMLA and AMLO amendments ahead of the FATF mutual evaluation; correspondent banking rules clarified. In force 1 Jan 2027.","AML channel: no Moody's metric (watch). Covers UBS.",["w12"]),
 ("2026-11-09","NEW","Consultation","Basel Committee","Proposed additional Pillar 2 guidance on interest rate risk in the banking book: model risk, stress testing, embedded gains and losses in securities portfolios, earnings indicators and new supervisory information reporting. Comments by 9 Feb 2027.","IRRBB channel: no Moody's metric (watch). Covers all 12 names once home jurisdictions apply it.",["w3"]),
 ("2026-11-09","NEW","Final","EBA","Final methodology for the 2027 EU-wide stress test, with requested data cut by more than half and a separate climate risk module that does not affect core results. Launch end-Jan 2027, results end-Jul 2027.","Stress testing channel: no Moody's metric (watch). Covers EU/EEA names; the page does not list the participating banks.",["w5"]),
 ("2026-11-06","NEW","Other","EBA","Next steps on supervisory reporting simplification (final ITS report due Dec 2026): first reference date for new requirements moved to Dec 2027; liquidity, asset encumbrance, benchmarking and ESG reporting deferred to Dec 2028.","Reporting channel: no Moody's metric (watch). Covers EU/EEA names.",["w6"]),
 ("2026-11-05","NEW","Final","EBA","Revised Guidelines on internal governance, aligned with CRD VI, with more proportionate expectations than the consultation draft. Application date not stated on the page; awaiting translation. Moody's view: Sector Comment 'EBA's revised governance guidelines are credit positive for small EU banks' (11 Nov 2026), credit positive, with a larger effect on smaller banks.","Governance channel: no Moody's metric (watch). Covers EU/EEA names.",["w7","m15"]),
 ("2026-11-05","NEW","Consultation","Basel Committee","Proposed consequential amendments so Basel Framework cross-references point to the new consolidated guidelines, moving some application guidance chapters across. Comments by 21 Dec 2026.","No row in the channel map; treated as no metric (watch) by judgment. Covers all 12 names once applied.",["w4"]),
 ("2026-11-04","NEW","Consultation","FINMA","Consultation on partially revised Circular 2019/2 'Interest rate risks - banks': updates interest rate shock scenarios to the Basel recalibration of July 2024 and puts more weight on earnings effects. Comments by 15 Jan 2027; entry into force not stated.","IRRBB channel: no Moody's metric (watch). Covers UBS.",["w13"]),
 ("2026-10-22","NEW","Other","European Commission","Provisional political agreement between Parliament and Council on the review of the Securitisation Framework, including CRR amendments to make the prudential treatment of securitisations more risk sensitive. Needs technical finalisation and formal adoption; enters into force on publication in the Official Journal.","Securitisation channel: no Moody's metric (watch). Covers EU/EEA names. Not yet final law.",["w9"]),
 ("2026-10-22","NEW","Consultation","PRA","CP14/26, phase 2 of the SM&CR review: pre-approval dropped for almost half of Senior Manager Functions and Certification Regime assessments removed. Comments by 22 Jan 2027; depends on the Financial Services and Markets Bill.","Governance channel: no Moody's metric (watch). Covers HSBC and Barclays.",["w11"]),
 ("2026-10-22","NEW","Other","EBA","Deadlines for four consultations (investment of available financial means, information exchange ITS, depositor information ITS, MiCA fines methodology) extended to 26 Oct 2026 after a website outage.","No Moody's metric (watch). Covers EU/EEA names; the deadline has passed.",["w8"]),
 ("2026-10-16","NEW","Final","Basel Committee","Final amendments to the G-SIB framework against window dressing: G-SIB indicators to be reported and disclosed as averages over the year, not year-end values, by 1 Jan 2030; reporting threshold raised to EUR 350bn leverage exposure from 1 Jan 2027.","Changes how G-SIB scores, and so the G-SIB buffer, are measured: CET1 channel. Covers the 8 G-SIBs on this list.",["w1"]),
 ("2026-10-16","NEW","Consultation","Basel Committee","Consultation in the periodic G-SIB methodology review on adding the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB framework. Comments by 14 Jan 2027. Not a final rule.","G-SIB score measurement: CET1 channel. Covers the 8 G-SIBs on this list.",["w2"]),
]
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"2026-11-15T20:19:26Z",
"scope":{"label":"Own list, 12 banks","sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":12},
"status":"ok",
"headline":"Thirteen regulatory items in the 30 days to 15 Nov; the two that reach a Moody's metric are the Basel Committee's G-SIB changes (final window-dressing amendments and a methodology consultation), which cover 8 of the 12 names, with Credit Agricole S.A. and BNP Paribas in the weaker third on CET1.",
"headline_src":["w1","w2","m8","m2"],
"sections":[
 table("Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026) · CET1 ratio"),
 table("Who it hits: G-SIB methodology review, consultation (Basel Committee, 16 Oct 2026) · CET1 ratio"),
 {"title":"What changed","type":"items","items":[{"flag":f,"tag":t,"name":b,"text":tx,"why":w,"src":s} for d,f,t,b,tx,w,s in items]},
 {"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":[
  [{"v":"PRA PS20/26 Large exposures, final (10 Nov)","src":["w10"]},"HSBC, Barclays","Large exposures (no field)",{"tone":"watch","v":""}],
  [{"v":"FINMA AML Ordinance, final (10 Nov)","src":["w12"]},"UBS","AML (no field)",{"tone":"watch","v":""}],
  [{"v":"Basel IRRBB Pillar 2 guidance, consultation (9 Nov)","src":["w3"]},ALL,"IRRBB (no field)",{"tone":"watch","v":""}],
  [{"v":"EBA 2027 stress test methodology, final (9 Nov)","src":["w5"]},EU,"Stress testing (no field)",{"tone":"watch","v":""}],
  [{"v":"EBA reporting simplification, new dates (6 Nov)","src":["w6"]},EU,"Reporting (no field)",{"tone":"watch","v":""}],
  [{"v":"EBA internal governance guidelines, final (5 Nov)","src":["w7"]},EU,"Governance (no field)",{"tone":"watch","v":""}],
  [{"v":"Basel consolidated guidelines amendments, consultation (5 Nov)","src":["w4"]},ALL,"None (no channel row)",{"tone":"watch","v":""}],
  [{"v":"FINMA Circular 2019/2 IRRBB, consultation (4 Nov)","src":["w13"]},"UBS","IRRBB (no field)",{"tone":"watch","v":""}],
  [{"v":"EU Securitisation Framework, political agreement (22 Oct)","src":["w9"]},EU,"Securitisation (no field)",{"tone":"watch","v":""}],
  [{"v":"PRA CP14/26 SM&CR phase 2, consultation (22 Oct)","src":["w11"]},"HSBC, Barclays","Governance (no field)",{"tone":"watch","v":""}],
  [{"v":"EBA consultation deadlines extended (22 Oct)","src":["w8"]},EU,"None (no field)",{"tone":"watch","v":""}]]}
],
"sources":[],
"unresolved":[],
"notes":[
 "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
 "Left out (24 entries on the list, not rules addressed to banks): Basel AML/CFT newsletter (19 Oct, newsletter); EBA NGFS declaration (13 Nov), consumer factsheet (9 Nov, consumer material), Taxonomy disclosure advice to the Commission (29 Oct, advice between authorities), Vice-Chair appointment (23 Oct); ECB speeches and interviews 19 Oct to 6 Nov, written overview for the Eurogroup (9 Nov, between authorities), list of supervised entities (23 Oct, periodic list), Supervision Newsletter (11 Nov, newsletter); SRB news, speeches and blog (6 to 13 Nov); Commission sustainability assurance feedback (12 Nov, addressed to assurance providers), banking competitiveness dialogue summary (11 Nov), tokenisation nominations (9 Nov), sanctions items (5 to 6 Nov), sustainable investment statistics (20 Oct); PRA CP15/26 and DP2/26 (3 Nov, credit unions), Regulatory Digest (2 Nov, newsletter); FINMA sanctions notices (16 Oct to 6 Nov), speech (3 Nov), Bitcoin ETF approval (20 Oct).",
 "Moody's view searched for the G-SIB changes, the securitisation agreement, the IRRBB guidance and the stress test: no Moody's comment on these was found in the window. Moody's commented on the EBA governance guidelines (shown in that item).",
 "The 3 UK and Swiss names (HSBC, Barclays, UBS) are outside EU rules and EBA items; Danske Bank and Swedbank are covered by EU/EEA items but not banking-union items. Scope is judged for the group at home; subsidiaries supervised elsewhere are not counted.",
 "Stated CET1 requirements are each bank's own total as filed and differ by regime (ECB overall requirement or MDA trigger, PRA overall requirement, Swiss going-concern requirement). HSBC and Deutsche Bank do not state a total in the filings held. The FSB's 2026 G-SIB list had not been found on 15 Nov 2026; the 2025 list is used.",
 "The ECB press feed returned only speeches and interviews for the window; no ECB supervisory press release dated in the window was found by search either."
],
"meta":{"calls":{"moodys":10,"web":26}}}
S=[]
def w(i,t,d,u): S.append({"id":i,"kind":"web","title":t,"date":d,"url":u})
w("w1","Basel Committee: Amendments to G-SIB framework to address window dressing","2026-10-16","https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing")
w("w2","Basel Committee: G-SIBs - methodology review (consultative document)","2026-10-16","https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review")
w("w3","Basel Committee: IRRBB - additional Pillar 2 guidance (consultative)","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance")
w("w4","Basel Committee: Consolidated guidelines - consequential amendments (consultative)","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments")
w("w5","EBA: 2027 EU-wide stress test streamlined","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data")
w("w6","EBA: Next steps on supervisory reporting simplification","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines")
w("w7","EBA: Revised Guidelines on internal governance","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and")
w("w8","EBA: Some consultation deadlines extended","2026-10-22","https://www.eba.europa.eu/publications-and-media/press-releases/eba-extends-some-consultation-deadlines-due-website-maintenance")
w("w9","European Commission: Political agreement on Securitisation Framework review","2026-10-22","https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en")
w("w10","PRA: PS20/26 Large Exposures Framework - Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement")
w("w11","PRA: CP14/26 Review of the SM&CR - Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper")
w("w12","FINMA: Partially revised Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/")
w("w13","FINMA: Consultation on Circular 2019/2 Interest rate risks - banks","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/")
w("w14","FSB: 2025 List of Global Systemically Important Banks","2025-11-27","https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/")
for n,s,u,v in banks:
    S.append({"id":s,"kind":"moodys","tool":FIN,"ref":REF,"title":n+" financials","date":"2026-06-30","url":u})
def f(i,n,filing,d): S.append({"id":i,"kind":"moodys","tool":"searchCompanyFilings","ref":filing+" (stated CET1 requirement, via sector-metrics banks-scope table)","title":n+" stated CET1 requirement","date":d})
f("f1","UBS Group AG","Second quarter 2026 report","2026-06-30")
f("f2","Societe Generale","First quarter 2026 results","2026-03-31")
f("f3","Credit Agricole S.A.","First quarter 2026 results slides","2026-03-31")
f("f4","BNP Paribas","Third quarter 2025 report","2025-09-30")
f("f5","Barclays PLC","Annual report on Form 20-F for 2025","2025-12-31")
f("f6","ING Groep N.V.","Annual report on Form 20-F for 2025","2025-12-31")
S.append({"id":"m15","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"})
run["sources"]=S
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
