**Regulatory watch: your 12 banks, 30 days to 15 Nov 2026 (16 Oct to 15 Nov)**

**Your list.** I took 8 names straight from the checked European banks list: HSBC, BNP Paribas, Deutsche Bank, UBS, Barclays, ING, Societe Generale and Credit Agricole S.A. I looked up the other 4 in Moody's and confirmed each has a current rating: Danske Bank A/S (DK), KBC Group N.V. (BE), Banco de Sabadell, S.A. (ES) and Swedbank AB (SE). Every name resolved. The list is saved as `banks-europe-own.json`, separate from the full list.

**The headline.** There were 13 regulatory items in the window. Only the two Basel Committee G-SIB items reach a Moody's metric. Both change how G-SIB scores, and so the G-SIB buffer, are measured, which puts them in the CET1 channel.

**Who it hits: G-SIB window-dressing amendments (final) and G-SIB methodology review (consultation), Basel Committee, 16 Oct · CET1**

These cover only the 8 banks on the FSB G-SIB list of 27 Nov 2025. Danske, KBC, Sabadell and Swedbank are out of scope because they are not on that list. I ranked by CET1 level, because only 3 of the 8 have a current stated requirement.

| Bank | CET1 (as reported, Q2 2026) | vs median (13.56%) | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | -2.26 pp | total not stated | +2.6 pp (bank-stated, 31 Mar 2026) | Weaker third |
| BNP Paribas | 12.97% | -0.59 pp | 10.51% (30 Sep 2025, older) | +2.46 pp (older) | Weaker third |
| ING Groep | 13.07% | -0.49 pp | 11.03% MDA trigger (31 Dec 2025, older) | +2.04 pp (older) | Middle |
| Societe Generale | 13.20% | -0.36 pp | 10.26% (31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | +0.36 pp | not stated | not stated | Middle |
| HSBC | 14.10% | +0.54 pp | not stated | not stated | Middle |
| Barclays | 14.30% | +0.74 pp | 12.2% (31 Dec 2025, older) | +2.10 pp (older) | Stronger third |
| UBS Group | 14.38% | +0.82 pp | 10.83% going-concern (30 Jun 2026) | +3.55 pp | Stronger third |

- **Window-dressing amendments (final).** G-SIB indicators will be reported as yearly averages by 1 Jan 2030, and the reporting threshold rises to EUR 350bn from 1 Jan 2027.
- **Methodology review (consultation, comments by 14 Jan 2027).** It asks whether to add the agreed treatment of cross-border exposures within the Banking Union to the G-SIB framework. This is not a final rule.
- Positions show where each bank sits among the names the rule covers, on this metric. They are not an estimate of impact.

**The other 11 items have no Moody's metric (watch only)**
- PRA PS20/26, large exposures part 2 (final, 10 Nov; applies from 1 Jan 2028). Covers HSBC and Barclays.
- FINMA revised AML Ordinance (final, 10 Nov; in force 1 Jan 2027). Covers UBS.
- Basel IRRBB Pillar 2 guidance (consultation, 9 Nov; comments by 9 Feb 2027). Covers all 12 once home countries apply it.
- EBA 2027 EU-wide stress test methodology (final, 9 Nov; results end-Jul 2027). Covers the 9 EU/EEA names.
- EBA supervisory reporting simplification (6 Nov). New reporting requirements now start Dec 2027, and some are pushed to Dec 2028. Covers the 9 EU/EEA names.
- EBA revised internal governance guidelines (final, 5 Nov). Covers the 9 EU/EEA names. Moody's sector comment of 11 Nov calls them credit positive, more so for small banks.
- Basel consolidated guidelines, consequential amendments (consultation, 5 Nov; comments by 21 Dec). Covers all 12.
- FINMA Circular 2019/2 on IRRBB (consultation, 4 Nov; comments by 15 Jan 2027). Covers UBS.
- EU Securitisation Framework review (political agreement, 22 Oct; still needs formal adoption). Covers the 9 EU/EEA names.
- PRA CP14/26, SM&CR phase 2 (consultation, 22 Oct; comments by 22 Jan 2027). Covers HSBC and Barclays.
- EBA extended four consultation deadlines to 26 Oct after a website outage (22 Oct). Covers the 9 EU/EEA names.

I left out 24 entries that are not rules addressed to banks: speeches, newsletters, sanctions notices, appointments, consumer material and credit-union papers. They are listed in the dashboard notes. Apart from the governance comment, I found no Moody's comment on these items in the window.

**Dashboard.** The Regulatory watch tab was updated at 20:19 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-08-own-list-scope/dashboard/dashboard.html`. I did not publish it this run.
