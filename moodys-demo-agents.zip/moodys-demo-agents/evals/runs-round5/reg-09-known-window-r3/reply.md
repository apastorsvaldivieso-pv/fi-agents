**Regulatory watch: European banks, 16 Oct to 15 Nov 2026**

I found 13 regulatory items in the window, all new to the running list. Two of them map to a Moody's metric. The rest are channels that Moody's data has no metric for.

**Who it hits: Basel Committee G-SIB changes (16 Oct) · CET1 ratio**
The Basel Committee finalised its amendments against G-SIB window dressing: G-SIB indicators are to be reported as yearly averages by 1 Jan 2030, and the reporting threshold rises to EUR 350bn on 1 Jan 2027. On the same day it opened a consultation on reviewing the G-SIB methodology, which looks at cross-border exposures inside the banking union. Comments are due 14 Jan 2027.

The rule covers the 8 G-SIBs on the list. Only 3 of them have a current stated requirement, so they are ranked by CET1 level, not by headroom (CET1 as reported, Q2 2026):

| Name | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | total not stated | +2.6 pp (bank-stated, 31 Mar 2026) | Weaker third |
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | +2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% (31 Dec 2025, older) | +2.04 pp | Middle |
| Societe Generale | 13.20% | 10.26% (31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | – | Middle |
| HSBC | 14.10% | not stated | – | Middle |
| Barclays | 14.30% | 12.2% (31 Dec 2025, older) | +2.10 pp | Stronger third |
| UBS | 14.38% | 10.83% (30 Jun 2026) | +3.55 pp | Stronger third |

Out of scope, because they are not on the FSB G-SIB list of 27 Nov 2025: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. The FSB has not yet published its 2026 list. The positions show where each bank sits among the G-SIBs on CET1. They are not an estimate of impact.

**No Moody's metric (watch)**
- **FINMA, 10 Nov (final):** revised Anti-Money Laundering Ordinance, in force 1 Jan 2027. Covers UBS.
- **PRA, 10 Nov (final):** PS20/26, Large Exposures Part 2, takes effect 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **Basel Committee, 9 Nov (consultation):** additional Pillar 2 guidance on interest rate risk in the banking book. Comments due 9 Feb 2027.
- **EBA, 9 Nov (final methodology):** 2027 EU-wide stress test asks for more than 55% less data. Launch end Jan 2027, results end Jul 2027.
- **EBA, 6 Nov:** next steps on simplifying supervisory reporting. The first reference date moves to Dec 2027, and some templates to Dec 2028.
- **EBA, 5 Nov (final):** revised internal governance guidelines. Moody's calls them "credit positive for small EU banks" (Sector Comment, 11 Nov 2026).
- **Basel Committee, 5 Nov (consultation):** consequential amendments to the consolidated guidelines. Comments due 21 Dec 2026.
- **FINMA, 4 Nov (consultation):** revised Circular 2019/2 on interest rate risk. Comments due 15 Jan 2027. Covers UBS.
- **European Commission, 22 Oct:** political agreement on the securitisation framework review. It is not yet law.
- **PRA, 22 Oct (consultation):** SM&CR Phase 2. Responses due 22 Jan 2027.
- **EBA, 22 Oct:** four consultation deadlines extended to 26 Oct 2026.

I left out 39 entries in the window, each with its reason on the tab. They were speeches, sanctions notices, newsletters, appointments, consumer material and credit-union papers.

**Gaps in the sources**
- The SRB listing only showed 6–13 Nov. I checked 16 Oct–5 Nov by search and found nothing in scope.
- The ECB press feed held only speeches and interviews in the window.

The Regulatory watch tab has been updated (20:15 UTC). The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r3/dashboard/dashboard.html`. This is a test run, so the dashboard was not published as an Artifact.
