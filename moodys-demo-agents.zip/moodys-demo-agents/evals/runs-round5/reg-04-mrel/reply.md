**Regulatory watch, European banks, 9 to 15 Nov 2026, MREL question**

**Short answer:** nothing changed on MREL this week. In principle, all 15 names on the list would be exposed to a tightening, because each one is subject to MREL or TLAC. Moody's data has no MREL or TLAC field and no requirement field, so I can't rank them from least to most headroom.

**MREL (asked, no change found)**
- I found no MREL rule, consultation or announced change at the SRB, EBA, Commission, Bank of England or FINMA in the window. The SRB published two speeches by its Chair, one at its 10th MREL Workshop, and a report on the Commission's competitiveness dialogue. None of these is a regulatory step.
- Moody's view: Sector In-Depth, "European regulators put more resolve into bank resolution", 14 Sep 2026. It says the Commission plans to simplify the EU resolution framework, including bringing MREL closer to TLAC. Moody's calls this credit negative if it reduces the amount of bail-inable debt. So the current policy direction is simplification, not tightening.
- Who a tightening would cover:
  - **SRB (banking union):** BNP Paribas, Crédit Agricole S.A., Société Générale, Deutsche Bank, Commerzbank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Nordea.
  - **Bank of England:** HSBC, Barclays, Lloyds.
  - **FINMA (gone-concern / TLAC):** UBS.
  - **TLAC as well, as G-SIBs (FSB list of 27 Nov 2025):** BNP Paribas, Crédit Agricole S.A., Société Générale, Deutsche Bank, ING, HSBC, Barclays, UBS.
- **Position: watch.** To rank by headroom I would need each bank's own stated MREL ratio and requirement from its filings. I can pull these if you want.

**Other items this week (all watch, no Moody's metric)**
- **PRA PS20/26, large exposures part 2** (final, 10 Nov): takes effect 1 Jan 2028. Applies to HSBC, Barclays and Lloyds.
- **FINMA revised AML Ordinance** (final, 10 Nov): in force 1 Jan 2027. Applies to UBS.
- **Basel Committee IRRBB Pillar 2 guidance** (consultation, 9 Nov): comments due by 9 Feb 2027. Applies to all 15 once their home regulators adopt it.
- **EBA 2027 EU-wide stress test methodology** (final, 9 Nov): requests more than 55% less data and adds a climate module. The bank sample isn't stated, so I can't say which of the 11 EU names it covers.

Eight other publications were left out because they were speeches, consumer material, appointments or not addressed to banks. They are listed in the tab notes.

The dashboard's Regulatory watch tab was updated at 2026-11-15 20:13 UTC: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-04-mrel/dashboard/dashboard.html` (this was a test run, so it was not published as an Artifact).
