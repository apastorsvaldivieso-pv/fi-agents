import json, sys
now = sys.argv[1]
S = []
def src(i, **k): S.append(dict(id=i, **k)); return i
# web sources
w = {}
for i,(t,d,u) in {
 "w1":("BCBS - Amendments to G-SIB framework to address window dressing","2026-10-16","https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing"),
 "w2":("BCBS - Global systemically important banks: methodology review (consultative document)","2026-10-16","https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review"),
 "w3":("BCBS - Consolidated guidelines: consequential amendments (consultative)","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments"),
 "w4":("BCBS - Interest rate risk in the banking book: additional Pillar 2 guidance (consultative)","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance"),
 "w5":("EBA - The EBA streamlines the 2027 EU-wide stress test","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data"),
 "w6":("EBA - Next steps on supervisory reporting simplification; implementation timelines extended","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines"),
 "w7":("EBA - Revised Guidelines on internal governance","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and"),
 "w8":("EBA - The EBA extends some consultation deadlines due to website maintenance","2026-10-22","https://www.eba.europa.eu/publications-and-media/press-releases/eba-extends-some-consultation-deadlines-due-website-maintenance"),
 "w9":("European Commission - Political agreement on the review of the Securitisation Framework","2026-10-22","https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en"),
 "w10":("PRA - CP14/26 Review of the SM&CR, Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper"),
 "w11":("PRA - PS20/26 Amendments to the Large Exposures Framework, Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement"),
 "w12":("FINMA - Partially revised FINMA Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/"),
 "w13":("FINMA - Consultation on partially revised Circular 2019/2 Interest rate risks - banks","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/"),
 "w14":("FSB - 2025 List of Global Systemically Important Banks (G-SIBs)","2025-11-27","https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/"),
}.items():
    src(i, kind="web", title=t, date=d, url=u)
src("m1", kind="moodys", tool="searchAllDocuments", ref="PBC_1502042", title="Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks", date="2026-11-11", url="https://www.moodys.com/research/doc--PBC_1502042")
fin = {"BNP Paribas":("f1",12.97,"FR662042449"),"HSBC Holdings plc":("f2",14.1,"GB00617987"),"Credit Agricole S.A.":("f3",11.3,"FR784608416"),
       "Barclays PLC":("f4",14.3,"GB00048839"),"Societe Generale":("f5",13.2,"FR552120222"),"Deutsche Bank AG":("f6",13.92,"DEFEB13216"),
       "UBS Group AG":("f7",14.38,"CHCHE395345924"),"ING Groep N.V.":("f8",13.07,"NL33231073")}
for n,(i,v,b) in fin.items():
    src(i, kind="moodys", tool="getEntityFinancials_v2", ref="Common Equity / Core Tier 1 ratio (as reported), LQ = Q2 2026", title=n+" financials", date="2026-06-30", url="https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/"+b)
req = {  # name: (value text, date, current?, filing, src id)
 "UBS Group AG":("10.83% required going-concern CET1 (30 Jun 2026)",10.83,"Second quarter 2026 report","2026-06-30","r1"),
 "Societe Generale":("10.26% CET1 requirement (shown against 31 Mar 2026)",10.26,"First quarter 2026 results","2026-03-31","r2"),
 "Credit Agricole S.A.":("Total not stated; bank-stated distance to SREP requirement 2.6 pp (phased-in CET1, 31 Mar 2026)",None,"First quarter 2026 results slides","2026-03-31","r3"),
 "BNP Paribas":("10.51% CET1 capital requirement (30 Sep 2025, older)",10.51,"Third quarter 2025 report","2025-09-30","r4"),
 "Barclays PLC":("12.2% overall CET1 requirement excl. PRA buffer (31 Dec 2025, older)",12.2,"Annual report on Form 20-F for 2025","2025-12-31","r5"),
 "ING Groep N.V.":("11.03% MDA trigger level for CET1 (31 Dec 2025, older)",11.03,"Annual report on Form 20-F for 2025","2025-12-31","r6"),
}
for n,(t,v,f,d,i) in req.items():
    src(i, kind="moodys", tool="searchCompanyFilings", ref=f"{f}: stated CET1 requirement (taken from the plugin's checked scope table, banks-scope.md, 15 Nov 2026; not re-queried in this run)", title=n+" - "+f, date=d)
order = sorted(fin, key=lambda n: fin[n][1])
vals = [fin[n][1] for n in order]; med = (vals[3]+vals[4])/2
tone = {}
for k,n in enumerate(order):
    tone[n] = "weaker" if k < 2 else ("stronger" if k >= 6 else "middle")
rows = []
for n in order:
    i,v,_ = fin[n]
    r = [n, {"v":f"{v:.2f}%","src":[i]}, {"v":f"{v-med:+.2f} pp","src":[i]}]
    if n in req:
        t,rv,_,_,ri = req[n]
        r.append({"v":t,"src":[ri]})
        if rv is None:
            r.append({"v":"2.6 pp (bank-stated, 31 Mar 2026)","src":[ri]})
        else:
            r.append({"v":f"{v-rv:.2f} pp"+("" if n in ("UBS Group AG","Societe Generale") else " (vs older requirement)"),"src":[i,ri]})
    else:
        r += ["not stated","not stated"]
    labels={"weaker":"Weaker third","middle":"Middle","stronger":"Stronger third"}
    r.append({"v":labels[tone[n]],"tone":tone[n]})
    rows.append(r)
cols = ["Name","CET1 ratio (as reported), Q2 2026","vs median of ranked names (13.56%)","Stated requirement (with date)","Distance to requirement","Position (by level: only 3 of 8 have a current stated requirement)"]
note = ("Out of scope: Lloyds Banking Group, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025; the 2026 list was not yet published at run time). "
        "Ranked by CET1 level, lowest weakest. Median of the eight ranked names: 13.56%.")
def gtable(title):
    return {"title":title,"type":"table","columns":cols,"rows":rows,"note":note,"note_src":["w14","f5","f6"]}
sections = [
 gtable("Who it hits: G-SIB window-dressing amendments (Basel Committee, 16 Oct 2026, final) · CET1 ratio"),
 gtable("Who it hits: G-SIB methodology review (Basel Committee, 16 Oct 2026, consultation) · CET1 ratio"),
]
EU = "BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea"
items = [
 ("Final","PRA","PS20/26 Amendments to the Large Exposures Framework, Part 2 (10 Nov 2026). Removes internal models for exposure values on securities financing transactions, makes substitution of credit risk mitigation mandatory (with exemptions), cuts the trading-book excess allowance for third-party exposures to 85% of Tier 1 for up to 10 business days, and sets a single higher NCLEG limit of 350% of Tier 1 for trading-book intragroup exposures. Effective 1 Jan 2028; permission applications from 1 Jul 2027.",
  "Large exposures channel: concentration limits for UK groups (Barclays, HSBC, Lloyds). Moody's data carries no large-exposures metric.",["w11"]),
 ("Final","FINMA","Partially revised FINMA Anti-Money Laundering Ordinance (10 Nov 2026). Aligns AMLO-FINMA with amended Swiss AML law ahead of the FATF evaluation; correspondent-banking rule narrowed to clients with direct account access. In force 1 Jan 2027, with a four-month transition for the related self-regulation.",
  "AML channel for UBS. No Moody's metric.",["w12"]),
 ("Consultation","Basel Committee","Additional Pillar 2 guidance on interest rate risk in the banking book (9 Nov 2026). Covers model risk, stress testing, controls, embedded gains and losses in securities portfolios and earnings indicators; amends SRP31 and SRP98 and proposes supervisory information reporting. Comments by 9 Feb 2027; no implementation date stated.",
  "IRRBB channel: Pillar 2 assessment of banking-book rate risk for all names once home supervisors apply it. No Moody's metric.",["w4"]),
 ("Final","EBA","2027 EU-wide stress test methodology final (9 Nov 2026), with more than 55% fewer data points and a first separate climate-risk module that does not affect core results. Launch end-January 2027; results end-July 2027. Templates may still get minor technical changes.",
  "Stress-test results feed supervisors' Pillar 2 guidance; the channel map has no stress-test row, so shown as watch (own judgment). The bank sample is not named on the page.",["w5"]),
 ("Other","EBA","Next steps on supervisory reporting simplification (6 Nov 2026): fewer templates and frequencies, a new stress-testing module, simpler operational-risk loss reporting, and later implementation. Final ITS report December 2026; first reference date December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting December 2028.",
  "Reporting channel: lower reporting burden for EU/EEA banks. No Moody's metric.",["w6"]),
 ("Final","EBA","Revised Guidelines on internal governance (5 Nov 2026), aligned with CRD VI, more proportionate than the consultation draft. Application date not stated on the page. Moody's view: Sector Comment 'EBA's revised governance guidelines are credit positive for small EU banks' (11 Nov 2026) calls the revisions credit positive, with a greater effect on smaller banks.",
  "Governance channel for EU/EEA banks. No Moody's metric.",["w7","m1"]),
 ("Consultation","Basel Committee","Consequential amendments to the Basel Framework for the new consolidated guidelines (5 Nov 2026): updates cross-references and moves some application-guidance chapters. Comments by 21 Dec 2026; no effective date stated.",
  "Drafting change to the Basel Framework; no channel-map row, shown as watch (own judgment). No change to requirement levels is described on the page.",["w3"]),
 ("Consultation","FINMA","Consultation on partially revised Circular 2019/2 'Interest rate risks - banks' (4 Nov 2026): updates the interest rate shocks to the Basel Committee's July 2024 recalibration and gives more weight to earnings effects. Comments by 15 Jan 2027; entry into force not stated.",
  "IRRBB channel for UBS. No Moody's metric.",["w13"]),
 ("Consultation","PRA","CP14/26 Review of the Senior Managers and Certification Regime, Phase 2 (22 Oct 2026): most Senior Management Functions move from pre-approval to notification and the Certification Regime is removed. Comments by 22 Jan 2027; implementation expected H2 2027, after the Financial Services and Markets Bill 2026.",
  "Governance channel for UK groups (Barclays, HSBC, Lloyds). No Moody's metric.",["w10"]),
 ("Other","European Commission","Provisional political agreement between Parliament and Council on the Securitisation Framework review (Commission statement 22 Oct 2026): more risk-sensitive CRR capital treatment of securitisations and lighter due-diligence and transparency rules. Awaits formal adoption; enters into force on publication; Council aims to finalise by end-2026.",
  "Securitisation channel for EU/EEA banks (capital treatment of securitisation positions). Not yet law. No Moody's metric.",["w9"]),
 ("Other","EBA","EBA extended four consultation deadlines to 26 Oct 2026 (22 Oct 2026): guidelines on investment of available financial means, ITS on information exchange, ITS on depositor information, and the MiCA fines methodology.",
  "Date change only; deposit-guarantee and depositor-information topics have no channel-map row (own judgment: watch).",["w8"]),
 ("Consultation","Basel Committee","G-SIB methodology review consultation (16 Oct 2026): whether to add the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB assessment methodology. Comments by 14 Jan 2027.",
  "Capital buffers channel (how G-SIB scores, and so G-SIB buffers, are measured): covers the eight G-SIBs on the list. Consultation, not a final rule.",["w2"]),
 ("Final","Basel Committee","G-SIB framework amendments to address window dressing (16 Oct 2026): G-SIB indicators to be reported and disclosed as averages over the year, not year-end values, by 1 Jan 2030; the leverage-exposure threshold for reporting and disclosure rises from EUR 200bn to EUR 350bn from 1 Jan 2027.",
  "Capital buffers channel (how G-SIB scores, and so G-SIB buffers, are measured): covers the eight G-SIBs on the list. The threshold change is a reporting matter.",["w1"]),
]
items_sorted = items  # already newest first except same-day ordering
sections.append({"title":"What changed","type":"items","items":[{"flag":"NEW","tag":t,"name":b,"text":x,"why":y,"src":s} for t,b,x,y,s in items_sorted]})
ALL = "All 15 names, once home supervisors apply the standard"
W = lambda v: {"v":v,"tone":"watch"}
sections.append({"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":[
 [{"v":"PRA PS20/26 Large exposures, Part 2 (final, 10 Nov 2026)","src":["w11"]},"Barclays, HSBC, Lloyds","Large exposures (no field)",W("watch")],
 [{"v":"FINMA AML Ordinance revision (final, 10 Nov 2026)","src":["w12"]},"UBS","AML (no field)",W("watch")],
 [{"v":"BCBS IRRBB additional Pillar 2 guidance (consultation, 9 Nov 2026)","src":["w4"]},ALL,"IRRBB (no field)",W("watch")],
 [{"v":"EBA 2027 EU-wide stress test methodology (final, 9 Nov 2026)","src":["w5"]},"Scope not known: EU/EEA sample not named on the page","Stress-test results (no field)",W("watch")],
 [{"v":"EBA supervisory reporting simplification next steps (6 Nov 2026)","src":["w6"]},EU,"Reporting (no field)",W("watch")],
 [{"v":"EBA revised internal governance guidelines (final, 5 Nov 2026)","src":["w7"]},EU,"Governance (no field)",W("watch")],
 [{"v":"BCBS consolidated guidelines consequential amendments (consultation, 5 Nov 2026)","src":["w3"]},ALL,"None (drafting)",W("watch")],
 [{"v":"FINMA Circular 2019/2 interest rate risks (consultation, 4 Nov 2026)","src":["w13"]},"UBS","IRRBB (no field)",W("watch")],
 [{"v":"PRA CP14/26 SM&CR Phase 2 (consultation, 22 Oct 2026)","src":["w10"]},"Barclays, HSBC, Lloyds","Governance (no field)",W("watch")],
 [{"v":"EU Securitisation Framework political agreement (22 Oct 2026)","src":["w9"]},EU,"Securitisation (no field)",W("watch")],
 [{"v":"EBA consultation deadline extensions (22 Oct 2026)","src":["w8"]},EU,"None (date change)",W("watch")],
]})
left = json.load(open("work/add_out.json"))["left_out"]
notes = [
 "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
 "Window: 16 Oct to 15 Nov 2026, as asked (31 days, not the usual 7). All 13 items are new to the running list; this is its first run.",
 "Left out (" + str(len(left)) + "): " + "; ".join(f"{l['body']} {l['published']} '{l['title']}' ({l['reason']})" for l in left) + ".",
 "Both G-SIB items are mapped to the CET1 row because they change how G-SIB scores, and so G-SIB buffers, are measured (channel map rule). Only UBS, Societe Generale and Credit Agricole S.A. have a current stated requirement, so the tables rank by CET1 level, not headroom. Distances for BNP Paribas, Barclays and ING use older requirements and are not ranked on. Credit Agricole S.A.'s distance is the bank's own figure on phased-in CET1 at 31 Mar 2026; the Q2 2026 ratio beside it is the as-reported Moody's field.",
 "Scope uses the FSB 2025 G-SIB list (27 Nov 2025). The 2026 list is due in November 2026 and was not found published on fsb.org at run time. Banco Santander (a G-SIB) is not on the coverage list because its rated record returns no Moody's financials.",
 "Moody's view: searchAllDocuments found a Moody's comment only on the EBA governance guidelines. No Moody's comment was found on the G-SIB amendments, the securitisation agreement, the IRRBB guidance or the 2027 stress test in the window.",
 "ECB Banking Supervision: the press feed listed only speeches and interviews in the window, and the publications feed only the Eurogroup overview and the supervised-entities list. Two searches found no ECB press release dated in the window; one may have been missed. SRB published speeches, a blog and event news only.",
 "Basel Committee publications listing: the 19 Oct 2026 'AML/CFT supervisory newsletter' entry links to a BCBS 239 page. It was left out as a newsletter.",
]
run = {"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"sector":"Banks","region":"Europe","window":"16 Oct to 15 Nov 2026","names":15},
 "status":"ok",
 "headline":"The Basel Committee finalised G-SIB window-dressing rules and consulted on the G-SIB methodology (16 Oct); among the eight G-SIBs on the list, Credit Agricole S.A. (11.30%) and BNP Paribas (12.97%) have the lowest CET1 at Q2 2026. Eleven other items have no Moody's metric.",
 "headline_src":["w1","w2","f3","f1"],
 "sections":sections,"sources":S,"unresolved":[],"notes":notes,
 "meta":{"calls":{"moodys":5,"web":25}}}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
print(order, med)
