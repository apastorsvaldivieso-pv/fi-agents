**Regulatory watch: European banks, 16 Oct to 15 Nov 2026**

I found 13 regulatory items in the window, all new to the running list. Two of them map to a Moody's metric. The other 11 are on watch because Moody's data has no metric for their channel.

**Who it hits: the G-SIB items (Basel Committee, 16 Oct 2026)**
- *Final:* G-SIB scores will be measured on averages over the year instead of year-end values, by 1 Jan 2030. The threshold for leverage-exposure reporting and disclosure rises from EUR 200bn to EUR 350bn from 1 Jan 2027.
- *Consultation, comments by 14 Jan 2027:* adding the treatment of cross-border exposures within the Banking Union to the G-SIB methodology.

Both change how G-SIB buffers are measured, so they map to CET1. They cover the eight G-SIBs on the list (FSB list of 27 Nov 2025; the 2026 list was not yet out). Only three of the eight have a current stated requirement, so the names are ranked by CET1 level, not headroom.

| Bank | CET1 (as reported, Q2 2026) | Stated requirement | Distance | Position |
|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | bank-stated distance only | 2.6 pp (bank-stated, 31 Mar 2026) | Weaker third |
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | 2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% MDA trigger (31 Dec 2025, older) | 2.04 pp | Middle |
| Societe Generale | 13.20% | 10.26% (31 Mar 2026) | 2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | not stated | Middle |
| HSBC | 14.10% | not stated | not stated | Middle |
| Barclays | 14.30% | 12.2% (31 Dec 2025, older) | 2.10 pp | Stronger third |
| UBS Group | 14.38% | 10.83% (30 Jun 2026) | 3.55 pp | Stronger third |

Out of scope (not G-SIBs): Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea. Positions show where each bank sits among the names the rule covers, on the stated metric. They are not an estimate of impact.

**Watch: no Moody's metric**
- PRA PS20/26, large exposures Part 2 (final, 10 Nov; effective 1 Jan 2028): Barclays, HSBC, Lloyds
- FINMA AML Ordinance revision (final, 10 Nov; in force 1 Jan 2027): UBS
- Basel IRRBB additional Pillar 2 guidance (consultation, 9 Nov; comments by 9 Feb 2027): all names
- EBA 2027 EU-wide stress test methodology (final, 9 Nov; results end-July 2027): sample not named
- EBA reporting simplification next steps (6 Nov; first reference date Dec 2027): EU/EEA banks
- EBA revised internal governance guidelines (final, 5 Nov): EU/EEA banks. Moody's called this credit positive, mainly for small EU banks (Sector Comment, 11 Nov 2026).
- Basel consolidated guidelines, consequential amendments (consultation, 5 Nov; comments by 21 Dec): all names
- FINMA Circular 2019/2 on interest rate risk (consultation, 4 Nov; comments by 15 Jan 2027): UBS
- PRA CP14/26, SM&CR Phase 2 (consultation, 22 Oct; comments by 22 Jan 2027): Barclays, HSBC, Lloyds
- EU Securitisation Framework, provisional political agreement (22 Oct; not yet adopted): EU/EEA banks
- EBA extension of four consultation deadlines to 26 Oct (22 Oct): EU/EEA banks

**Notes**
- 21 listing entries were left out: speeches, newsletters, sanctions notices, appointments, consumer material, statistics, EBA advice to the Commission, and credit-union papers. Each one, with its reason, is in the run notes.
- The ECB's own feeds showed only speeches, the Eurogroup overview and the supervised-entities list. Two searches found no ECB press release in the window, but one could have been missed.
- Moody's has published no comment yet on the G-SIB, securitisation, IRRBB or stress-test items.

The Regulatory watch tab is updated (15 Nov 2026, 20:15 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r2/dashboard/dashboard.html`. I didn't publish to the private link because this is a test run.
