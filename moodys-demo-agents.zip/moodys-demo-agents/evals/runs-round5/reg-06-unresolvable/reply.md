**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

**Names**

| Name | Country |
|---|---|
| BNP Paribas | FR |
| Deutsche Bank AG | DE |

Could not resolve: **Zzyzx Fakecorp Bank**. Moody's returned no match and no candidates, so it is left out of everything below.

**The main item:** On 16 Oct the Basel Committee finalised its G-SIB window-dressing amendments, which take effect by 1 Jan 2030. On the same day it opened a consultation on the G-SIB methodology. Both change how the G-SIB score behind the G-SIB buffer is measured, and both banks are G-SIBs.

**Who it hits: G-SIB amendments and methodology review (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1, as reported (Q2 2026) | Stated requirement | Distance |
|---|---|---|---|
| Deutsche Bank AG | 13.92% | not stated | not stated |
| BNP Paribas | 12.97% | 10.51%, 30 Sep 2025 (older) | 2.46 pp vs the older figure |

There are only two names, so the list is too short to rank.

**What changed** (newest first, all new to the list)
- 10 Nov · PRA PS20/26, Large Exposures Part 2 (final, applies 1 Jan 2028). UK banks only, so neither of your names.
- 10 Nov · FINMA revised its AML Ordinance (final, in force 1 Jan 2027). Swiss institutions only.
- 9 Nov · Basel Committee consultation on Pillar 2 guidance for interest rate risk in the banking book (comments by 9 Feb 2027). Covers both banks once the EU adopts it.
- 9 Nov · EBA final methodology for the 2027 EU-wide stress test: data requests cut by more than 55%, launch end Jan 2027, results end Jul 2027. The page doesn't name the banks in the sample.
- 6 Nov · EBA next steps on simplifying supervisory reporting. The first reference date for new requirements moves to Dec 2027, and some areas move to Dec 2028.
- 5 Nov · EBA revised internal governance guidelines (final). Moody's (11 Nov) calls them credit positive for EU banks, with more effect on smaller banks.
- 5 Nov · Basel Committee consultation on consequential amendments to the consolidated guidelines (cross-references only; comments by 21 Dec 2026).
- 4 Nov · FINMA consultation on its circular on interest rate risk in the banking book (comments by 15 Jan 2027). Swiss banks only.
- 22 Oct · Political agreement on the EU Securitisation Framework review, which makes securitisation capital treatment more risk-sensitive. Not yet formally adopted. Covers both banks.
- 22 Oct · PRA CP14/26, phase 2 of the senior managers and certification regime review (comments by 22 Jan 2027). UK firms only.
- 16 Oct · Basel Committee consultation on the G-SIB methodology review (comments by 14 Jan 2027).
- 16 Oct · Basel Committee final G-SIB window-dressing amendments.

Moody's has no metric for interest rate risk, stress testing, reporting, governance, securitisation, large exposures or AML. Those items are on the watch list, and no bank is ranked on them. The ECB, the SRB and the European Commission otherwise published speeches, statements and sanctions notices, which I left out. Each one is listed with its reason in the run notes.

The Regulatory watch tab was updated at 20:21 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-06-unresolvable/dashboard/dashboard.html`. It was not published to a link, because this is a test run.
