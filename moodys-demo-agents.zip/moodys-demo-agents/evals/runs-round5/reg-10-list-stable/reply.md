**Regulatory watch: European banks, 16 Oct to 15 Nov 2026**

I found 13 regulatory items in the window. All of them were already on the running list from your earlier run over the same dates, so nothing is new this time.

**Who it hits (CET1 ratio, Q2 2026, Moody's data)**
- **G-SIB window-dressing amendments** (Basel Committee, 16 Oct, final). G-SIB indicators will be averaged over the year by 1 Jan 2030. This covers the 8 G-SIBs on the list. Only 3 of them have a current stated requirement, so they are ranked by CET1 level:
  - Weaker third: Credit Agricole S.A. at 11.30% and BNP Paribas at 12.97%.
  - Stronger third: Barclays at 14.30% and UBS at 14.38%.
  - The other seven names on the list are out of scope because they are not on the FSB G-SIB list.
- **G-SIB methodology review** (Basel Committee, 16 Oct, consultation; comments by 14 Jan 2027). It covers only G-SIBs headquartered in the banking union: BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank and ING. That is five names, which is too few to rank, so values are shown without positions. HSBC, Barclays and UBS are out of scope.

**No Moody's metric (watch)**
- Final rules:
  - PRA PS20/26 on large exposures (10 Nov)
  - FINMA anti-money laundering ordinance (10 Nov)
  - EBA 2027 stress test methodology (9 Nov)
  - EBA internal governance guidelines (5 Nov). Moody's calls these credit positive for EU banks, more so for smaller banks.
- Consultations:
  - Basel Committee guidance on interest rate risk in the banking book (9 Nov)
  - Basel Committee consolidated guidelines amendments (5 Nov)
  - FINMA interest rate risk circular (4 Nov)
  - PRA CP14/26 on the senior managers regime (22 Oct)
- Other steps:
  - EBA reporting simplification timelines (6 Nov)
  - EU securitisation political agreement (22 Oct)
  - EBA consultation deadline extension (22 Oct)

17 other entries in the window were left out, keeping the decisions already on the list: speeches, sanctions notices, newsletters, appointments, credit-union papers and similar.

**One flag:** the running list shows the EBA's consultation deadline extension. The reg-watch rules would leave out a moved deadline. I kept it because the list holds it. If you agree it should go, change its decision in the list and later runs will drop it.

The Regulatory watch tab was updated at 20:22 UTC on 15 Nov 2026:
`/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-10-list-stable/dashboard/dashboard.html`

This is a test run, so the page was not published to the private link.
