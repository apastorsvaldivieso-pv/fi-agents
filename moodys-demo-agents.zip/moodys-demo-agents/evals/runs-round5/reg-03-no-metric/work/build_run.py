import json
S=[]
def src(id,**k): S.append(dict(id=id,**k)); return id
# web
src("w1",kind="web",title="EBA: revised Guidelines on internal governance (EBA/GL/2026/10)",date="2026-11-05",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and")
src("w2",kind="web",title="EBA: next steps on supervisory reporting simplification",date="2026-11-06",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines")
src("w3",kind="web",title="EBA: 2027 EU-wide stress test methodology",date="2026-11-09",url="https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data")
src("w4",kind="web",title="Basel Committee: G-SIB window-dressing measures finalised; G-SIB methodology consultation",date="2026-10-16",url="https://www.bis.org/media-releases/20261016-basel-committee-finalises-measures-address-window-dressing-g-sib-framework-and-consults-g-sib")
src("w5",kind="web",title="Basel Committee: IRRBB additional Pillar 2 guidance (consultative)",date="2026-11-09",url="https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance")
src("w6",kind="web",title="Basel Committee: Consolidated guidelines, consequential amendments (consultative)",date="2026-11-05",url="https://www.bis.org/publications/consolidated-guidelines-consequential-amendments")
src("w7",kind="web",title="European Commission: political agreement on the Securitisation Framework review",date="2026-10-22",url="https://finance.ec.europa.eu/news/commission-welcomes-political-agreement-reached-review-securitisation-framework-2026-10-22_en")
src("w8",kind="web",title="PRA PS20/26 Large Exposures Framework Part 2",date="2026-11-10",url="https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement")
src("w9",kind="web",title="PRA CP14/26 Review of SM&CR Phase 2",date="2026-10-22",url="https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper")
src("w10",kind="web",title="FINMA consultation on Circular 2019/2 Interest rate risks - banks",date="2026-11-04",url="https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/")
src("w11",kind="web",title="FINMA partially revised Anti-Money Laundering Ordinance",date="2026-11-10",url="https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/")
src("w12",kind="web",title="FSB 2025 List of Global Systemically Important Banks (G-SIBs)",date="2025-11-27",url="https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/")
src("m1",kind="moodys",tool="searchAllDocuments",ref="PBC_1502042",title="Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks",date="2026-11-11",url="https://www.moodys.com/research/doc--PBC_1502042")
fin={"BNP Paribas":("f1","12.97%","FR662042449"),"Credit Agricole S.A.":("f2","11.3%","FR784608416"),"Societe Generale":("f3","13.2%","FR552120222"),"Deutsche Bank AG":("f4","13.92%","DEFEB13216"),"ING Groep N.V.":("f5","13.07%","NL33231073"),"HSBC Holdings plc":("f6","14.1%","GB00617987"),"Barclays PLC":("f7","14.3%","GB00048839"),"UBS Group AG":("f8","14.38%","CHCHE395345924")}
for n,(i,v,b) in fin.items():
    src(i,kind="moodys",tool="getEntityFinancials_v2",ref="Common Equity / Core Tier 1 ratio (as reported), Q2 2026",title=n+" financials",date="2026-06-30",url="https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/"+b)
req=lambda i,f,d: src(i,kind="moodys",tool="searchCompanyFilings",ref="bank sector file, pulled 15 Nov 2026: %s, as of %s"%(f,d),title="Stated CET1 requirement",date={"30 Jun 2026":"2026-06-30","31 Mar 2026":"2026-03-31","30 Sep 2025":"2025-09-30","31 Dec 2025":"2025-12-31"}[d])
req("r1","UBS Second quarter 2026 report (required going-concern CET1 capital)","30 Jun 2026")
req("r2","Societe Generale First quarter 2026 results (CET1 requirement)","31 Mar 2026")
req("r3","Credit Agricole S.A. First quarter 2026 results slides (bank-stated distance to SREP requirement, phased-in CET1)","31 Mar 2026")
req("r4","BNP Paribas Third quarter 2025 report (CET1 capital requirement)","30 Sep 2025")
req("r5","Barclays Annual report on Form 20-F for 2025 (overall capital requirement for CET1, excl. PRA buffer)","31 Dec 2025")
req("r6","ING Annual report on Form 20-F for 2025 (MDA trigger level for CET1)","31 Dec 2025")
c=lambda v,s,t=None: ({"v":v,"src":s} if t is None else {"v":v,"src":s,"tone":t})
NS="not stated"
rows=[
 ["Credit Agricole S.A.",c("11.3%",["f2"]),c("-2.26 pp",["f2","f1","f3","f4","f5","f6","f7","f8"]),c("total not stated (bank states distance only), 31 Mar 2026",["r3"]),c("+2.6 pp, bank-stated, 31 Mar 2026",["r3"]),{"tone":"weaker","v":""}],
 ["BNP Paribas",c("12.97%",["f1"]),c("-0.59 pp",["f1","f2","f3","f4","f5","f6","f7","f8"]),c("10.51%, 30 Sep 2025, older",["r4"]),c("+2.46 pp (vs older requirement)",["f1","r4"]),{"tone":"weaker","v":""}],
 ["ING Groep N.V.",c("13.07%",["f5"]),c("-0.49 pp",["f5","f1","f2","f3","f4","f6","f7","f8"]),c("11.03%, 31 Dec 2025, older",["r6"]),c("+2.04 pp (vs older requirement)",["f5","r6"]),{"tone":"middle","v":""}],
 ["Societe Generale",c("13.2%",["f3"]),c("-0.36 pp",["f3","f1","f2","f4","f5","f6","f7","f8"]),c("10.26%, shown against 31 Mar 2026",["r2"]),c("+2.94 pp",["f3","r2"]),{"tone":"middle","v":""}],
 ["Deutsche Bank AG",c("13.92%",["f4"]),c("+0.36 pp",["f4","f1","f2","f3","f5","f6","f7","f8"]),NS,"n/a",{"tone":"middle","v":""}],
 ["HSBC Holdings plc",c("14.1%",["f6"]),c("+0.54 pp",["f6","f1","f2","f3","f4","f5","f7","f8"]),NS,"n/a",{"tone":"middle","v":""}],
 ["Barclays PLC",c("14.3%",["f7"]),c("+0.74 pp",["f7","f1","f2","f3","f4","f5","f6","f8"]),c("12.2%, 31 Dec 2025, older",["r5"]),c("+2.10 pp (vs older requirement)",["f7","r5"]),{"tone":"stronger","v":""}],
 ["UBS Group AG",c("14.38%",["f8"]),c("+0.82 pp",["f8","f1","f2","f3","f4","f5","f6","f7"]),c("10.83%, 30 Jun 2026",["r1"]),c("+3.55 pp",["f8","r1"]),{"tone":"stronger","v":""}],
]
gsib={"title":"Who it hits: G-SIB window-dressing standard (final) and G-SIB methodology consultation (Basel Committee, 16 Oct 2026) · CET1 ratio","type":"table",
 "columns":["Name","CET1 ratio (as reported), Q2 2026","vs median of ranked names (13.56%)","Stated CET1 requirement (date)","Distance to requirement","Position"],
 "rows":rows,
 "note":"Covers the G-SIBs on the FSB list of 27 Nov 2025 (no 2026 list found published as of 15 Nov 2026). Ranked by CET1 level, not headroom: only three of the eight names have a current stated requirement. Scope not known for UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea, Lloyds: not G-SIBs, so no G-SIB buffer, but banks above the reporting threshold take part in the G-SIB assessment and its reporting rules. Banco Santander (a G-SIB) is not on this coverage list.",
 "note_src":["w4","w12"]}
EU="BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (11)"
items=[
 {"tag":"Final","name":"PRA","text":"PS20/26 finalises Part 2 of the Large Exposures Framework changes: mandatory credit risk mitigation substitution (with exemptions), no internal models for securities financing exposure values, a reduced time-limited trading book excess allowance. Applies from 1 January 2028. Channel: large exposures (no Moody's metric).","why":"Covers UK groups only: HSBC, Barclays, Lloyds.","src":["w8"]},
 {"tag":"Final","name":"FINMA","text":"Partially revised FINMA Anti-Money Laundering Ordinance published in final form; in force 1 January 2027, with a four-month transition for the recognised self-regulation. Channel: AML (no Moody's metric).","why":"Covers UBS on this list.","src":["w11"]},
 {"tag":"Final","name":"EBA","text":"Final methodology and draft templates for the 2027 EU-wide stress test, with more than 55% fewer data points requested and a first climate risk module. Launch end of January 2027, results end of July 2027. Channel: stress testing (no Moody's metric).","why":"Sample not named on the page, so which EU banks on the list take part is not known.","src":["w3"]},
 {"tag":"Consultation","name":"Basel Committee","text":"Consults on additional Pillar 2 guidance for interest rate risk in the banking book: model risk, stress testing, controls, earnings indicators and new supervisory information reporting. Comments due 9 February 2027. Channel: IRRBB (no Moody's metric).","why":"Would reach every bank on the list once home supervisors apply it.","src":["w5"]},
 {"tag":"Other","name":"EBA","text":"Next steps on supervisory reporting simplification: final report on the draft ITS due December 2026; first reference date for new requirements December 2027; liquidity, asset encumbrance, benchmarking and ESG reporting moved to December 2028. Channel: reporting (no Moody's metric).","why":"Covers the 11 EU and EEA groups on the list.","src":["w2"]},
 {"flag":"","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance (EBA/GL/2026/10), aligned with CRD VI and DORA, replacing the 2021 guidelines. They add duty mapping for management body members and key function holders and a governance framework for third-country branches; the final text eases duty-mapping detail, conflict-of-interest provisions and diversity monitoring versus the consultation. Final, awaiting translation; application date not stated on the page. Channel: governance (no Moody's metric).","why":"Moody's (Sector Comment, 11 Nov 2026) calls the revisions credit positive for EU banks, with a greater effect on smaller banks because larger ones have already been adopting the guidelines.","src":["w1","m1"]},
 {"tag":"Consultation","name":"Basel Committee","text":"Consults on consequential amendments to the Basel Framework so its cross-references point to the new consolidated guidelines, and on moving some application guidance chapters into them. Comments due 21 December 2026. Channel: none in the channel map; shown as watch by our judgment.","why":"Structural; applies to all banks on the list via the Basel Framework.","src":["w6"]},
 {"tag":"Consultation","name":"FINMA","text":"Consultation on partially revised Circular 2019/2 Interest rate risks - banks, adopting the Basel Committee's recalibrated rate shock scenarios and giving more weight to earnings effects. Closes 15 January 2027; entry into force not stated. Channel: IRRBB (no Moody's metric).","why":"Covers UBS on this list.","src":["w10"]},
 {"tag":"Consultation","name":"PRA","text":"CP14/26, second phase of the Senior Managers and Certification Regime review: most Senior Manager Functions would move from pre-approval to notification and certification requirements would be removed. Comments due 22 January 2027; changes expected H2 2027, subject to legislation. Channel: governance (no Moody's metric).","why":"The UK counterpart on governance: covers HSBC, Barclays, Lloyds.","src":["w9"]},
 {"tag":"Legislative step","name":"European Commission","text":"Political agreement between Parliament and Council on the Securitisation Framework review, including more risk-sensitive CRR capital treatment of securitisations. Still needs technical finalisation and formal adoption; the Council aims to finish by end-2026. Channel: securitisation (no Moody's metric).","why":"Covers the 11 EU and EEA groups on the list.","src":["w7"]},
 {"tag":"Final","name":"Basel Committee","text":"Final amendments to the G-SIB framework against window-dressing: stock G-SIB indicators reported as averages over the year rather than year-end values, by 1 January 2030; reporting threshold raised to EUR 350bn leverage exposure from 2027. Channel: G-SIB buffer, CET1 row (measurement of G-SIB scores).","why":"Changes how the scores behind G-SIB buffers are measured; see the CET1 table.","src":["w4"]},
 {"tag":"Consultation","name":"Basel Committee","text":"Consults on adding the agreed treatment of cross-border exposures within the European Banking Union to the G-SIB methodology. Comments due 14 January 2027. Channel: G-SIB buffer, CET1 row.","why":"Bears on the G-SIB scores of banking-union G-SIBs (BNP Paribas, Credit Agricole, Societe Generale, Deutsche Bank, ING); see the CET1 table.","src":["w4"]},
]
for it in items: it["flag"]="NEW"
watch={"title":"Who it hits: no Moody's metric","type":"table","columns":["Item","Covers on this list","Metric needed","Call"],"rows":[
 [c("EBA revised Guidelines on internal governance (final, 5 Nov 2026)",["w1"]),EU,"Governance: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("PRA CP14/26 SM&CR Phase 2 (consultation, 22 Oct 2026)",["w9"]),"HSBC, Barclays, Lloyds","Governance: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("EBA supervisory reporting simplification next steps (6 Nov 2026)",["w2"]),EU,"Reporting: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("EBA 2027 EU-wide stress test methodology (final, 9 Nov 2026)",["w3"]),"Scope not known: sample not named; candidates are the 11 EU and EEA groups","Stress testing: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("Basel Committee IRRBB Pillar 2 guidance (consultation, 9 Nov 2026)",["w5"]),"All 15, once applied at home","IRRBB: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("FINMA Circular 2019/2 Interest rate risks (consultation, 4 Nov 2026)",["w10"]),"UBS","IRRBB: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("Basel Committee consolidated guidelines amendments (consultation, 5 Nov 2026)",["w6"]),"All 15, once applied at home","No channel row (judgment)",{"tone":"watch","v":"watch"}],
 [c("EU Securitisation Framework political agreement (22 Oct 2026)",["w7"]),EU,"Securitisation: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("PRA PS20/26 Large Exposures Part 2 (final, 10 Nov 2026)",["w8"]),"HSBC, Barclays, Lloyds","Large exposures: no Moody's field",{"tone":"watch","v":"watch"}],
 [c("FINMA Anti-Money Laundering Ordinance (final, 10 Nov 2026)",["w11"]),"UBS","AML: no Moody's field",{"tone":"watch","v":"watch"}]],
 "note":"EBA governance guidelines: out of scope on this list, HSBC, Barclays, Lloyds (group home GB, PRA) and UBS (group home CH, FINMA). Their EU subsidiaries are covered locally but are not counted here."}
run={"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":"2026-11-15T20:20:55Z",
 "scope":{"sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15,"label":"30 days, EBA governance focus"},
 "status":"ok",
 "headline":"The EBA's revised internal governance guidelines (final, 5 Nov) cover the 11 EU and EEA groups on the list, not HSBC, Barclays, Lloyds or UBS; Moody's carries no governance metric, so no bank is ranked on it, and Moody's calls the change credit positive, mostly for smaller banks.",
 "headline_src":["w1","m1"],
 "sections":[gsib,{"title":"What changed","type":"items","items":sorted(items,key=lambda x:0)},watch],
 "sources":S,"unresolved":[],
 "notes":["Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Window: 16 Oct to 15 Nov 2026, both days included, as asked (the default is 7 days). All 12 items are new to the running list, which was empty before this run.",
  "Left out (13 entries): EBA NGFS declaration (statement); EBA consumer factsheet (consumer material); ECB list of supervised entities (statistics); ECB written overview to the Eurogroup (communication to another authority); ECB speeches and interviews; BCBS AML/CFT newsletter; SRB speeches, blog and news; Commission banking competitiveness dialogue summary (meeting summary); PRA CP15/26 and DP2/26 (credit unions); PRA Regulatory Digest (newsletter); FINMA Bitcoin ETF approval (fund); FINMA sanctions notices.",
  "Moody's research was checked for the governance, G-SIB, securitisation and stress test items; only the governance guidelines had a Moody's comment in the window.",
  "Basel III minimums are not used here; CET1 requirements are each bank's own stated figure from its filings, never added up from parts."],
 "meta":{"calls":{"moodys":5,"web":28}}}
json.dump(run,open("dashboard/data/reg-watch.json","w"),indent=1,ensure_ascii=False)
