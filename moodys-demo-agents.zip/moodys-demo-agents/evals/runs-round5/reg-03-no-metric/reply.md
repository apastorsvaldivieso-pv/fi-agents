**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, both days included)**

**The EBA's revised Guidelines on internal governance: who it covers**

The EBA published final revised Guidelines on internal governance (EBA/GL/2026/10) on 5 Nov 2026. They bring the guidelines into line with CRD VI and DORA and replace the 2021 version. The changes add duty mapping for management body members and key function holders, and a governance framework for third-country branches. Compared with the consultation, the final text asks for less detail in duty mapping, simplifies the conflict-of-interest rules and asks for less granular diversity monitoring. The guidelines are final but still awaiting translation. The EBA page does not give an application date. ([EBA](https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and))

- **Covers 11 banks on your list** (groups based in the EU or EEA): BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea.
- **Does not cover 4:** HSBC, Barclays and Lloyds (UK groups, supervised by the PRA) and UBS (Swiss, supervised by FINMA). Their EU subsidiaries are covered locally, but that is not counted here.
- **No ranking:** Moody's financial data has no governance metric, so none of the 11 banks can be placed against this rule. The item is marked `watch`.
- **Moody's view:** a Sector Comment of 11 Nov 2026 ("EBA's revised governance guidelines are credit positive for small EU banks") says the effect is greater for smaller banks, because larger banks have already been applying the guidelines. It expects the benefits to build up gradually.
- **The UK equivalent:** PRA CP14/26 (22 Oct 2026, consultation, comments due 22 Jan 2027) proposes changes to the Senior Managers and Certification Regime. It covers HSBC, Barclays and Lloyds. This is also `watch`.

**Other changes in the window (12 items in total, all new)**

| Date | Body | Item | Status | Covers on your list |
|---|---|---|---|---|
| 10 Nov | PRA | PS20/26 Large Exposures Framework Part 2, applies from 1 Jan 2028 | Final | HSBC, Barclays, Lloyds |
| 10 Nov | FINMA | Revised Anti-Money Laundering Ordinance, in force 1 Jan 2027 | Final | UBS |
| 9 Nov | EBA | 2027 EU-wide stress test: methodology final, templates still draft; launch end Jan 2027, results end Jul 2027 | Final methodology | Which banks take part is not known (the page does not name the sample) |
| 9 Nov | Basel Committee | Additional Pillar 2 guidance on interest rate risk in the banking book; comments due 9 Feb 2027 | Consultation | All 15, once home supervisors apply it |
| 6 Nov | EBA | Reporting simplification: final draft ITS due Dec 2026; first reference date Dec 2027; some areas pushed back to Dec 2028 | Other (new dates) | The 11 EU/EEA groups |
| 5 Nov | Basel Committee | Consequential amendments for the consolidated guidelines; comments due 21 Dec 2026 | Consultation | All 15 |
| 4 Nov | FINMA | Revised Circular 2019/2 on interest rate risks for banks; closes 15 Jan 2027 | Consultation | UBS |
| 22 Oct | European Commission | Political agreement on the Securitisation Framework review, which includes changes to CRR capital treatment | Legislative step | The 11 EU/EEA groups |
| 16 Oct | Basel Committee | G-SIB window-dressing amendments: indicators averaged over the year, by 1 Jan 2030 | Final | G-SIBs (table below) |
| 16 Oct | Basel Committee | G-SIB methodology: treatment of cross-border exposures within the Banking Union; comments due 14 Jan 2027 | Consultation | G-SIBs (table below) |

**Who the two G-SIB items cover: CET1 ratio, Q2 2026 (Moody's)**

These two items are the only ones that change something Moody's tracks (the scores behind G-SIB capital buffers). Only three banks state a current CET1 requirement, so the table ranks by CET1 level rather than headroom. Credit Agricole S.A. and BNP Paribas are in the weaker third, and Barclays and UBS in the stronger third. ING, Societe Generale, Deutsche Bank and HSBC are in the middle. The headroom each bank states for itself is +3.55 pp for UBS, +2.94 pp for Societe Generale and +2.6 pp for Credit Agricole. BNP Paribas, Barclays and ING give older figures. For the seven banks on your list that are not G-SIBs, it is unclear whether these items reach them.

Positions show where each bank sits among the banks a rule covers, on the stated metric. They are not an estimate of impact.

The Regulatory watch tab on the dashboard has been updated (15 Nov 2026, 20:20 UTC): `evals/runs/reg-03-no-metric/dashboard/dashboard.html`. This test run skipped publishing it as an artifact.
