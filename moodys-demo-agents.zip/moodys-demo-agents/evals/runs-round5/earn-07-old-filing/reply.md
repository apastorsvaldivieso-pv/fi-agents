**BNP Paribas, earnings recap (Q3 2026, reported 28 Oct 2026)**

**Headline:** BNP Paribas reported Q3 2026 net income of EUR 3.5bn (Moody's Issuer Comment, 28 Oct 2026). Moody's has no call transcript for BNP Paribas. The latest results filing it holds is the Q3 2025 report, which is **older than the latest results**. Rating: A1 LT Issuer Rating, stable outlook, affirmed 31 Aug 2026.

**Results against the credit view**
- **Q3 2026 (Moody's Issuer Comment, 28 Oct 2026):** net income EUR 3.5bn, up 13.5% year on year. On Moody's own calculations excluding exceptional items: annualised return on RWA 169bp, return on assets 43bp, RoTE 13.0%. Cost of risk was moderate and on target, revenue grew faster than costs, and there was sizable pre-funding for 2027.
- **Guidance:** I can't test the results against current guidance because Moody's has no transcript and no Q3 2026 filing. The latest targets on file are company-reported, from the 16 Sep 2025 press release in the Q3 2025 report: RoTE of 12% in 2026 and 13% in 2028, and a CET1 ratio of 12.5% by end-2027. A new 2027-2030 plan is due in early 2027. Moody's 13.0% RoTE is its own calculation, so I haven't compared it with the company's 12% target. The credit opinion has no Moody's forecasts.
- **Capital (in place of net debt):** company-reported CET1 ratio of 12.5% at 30 Sep 2025, against a 10.51% CET1 requirement. Drivers that quarter: +30bp organic generation, -20bp distribution, -35bp AXA IM, +25bp other. The latest figure in Moody's financials is a CET1 ratio of 12.97% (as reported, Q2 2026).
- **Liquidity and funding:** company-reported at 30 Sep 2025: LCR 138% (12-month average 133%, a EUR 99bn surplus), average liquid assets EUR 398bn and a leverage ratio of 4.3%. About 94% of the EUR 22.5bn 2025 issuance plan was done by 17 Oct 2025. Moody's financials for Q2 2026 (as reported): LCR 134.8%, NSFR 108.6%.
- **Distributions:** company-reported: a 60% proposed distribution of the 2025 result, with an interim dividend of EUR 2,891m paid by 30 Sep 2025. The filings Moody's holds have no 2026 distribution figures.

**Against Moody's triggers**

| Metric | Latest Moody's value | Upgrade trigger | Downgrade trigger | Room to upgrade |
|---|---|---|---|---|
| Net income / tangible assets | 0.4% (Jun 2026) | Return on assets of 0.6% and above | No number stated | 0.2 pp below |

Worded triggers (credit opinion, 2 Sep 2026):
- **Downgrade:** "lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability". Also a marked rise in risk appetite or a risk-management failure, or worse operating conditions together with weaker funding and liquidity.
- **Upgrade:** lower financial leverage with disciplined risk management, or an upgrade of France's rating (Aa3 negative).

**Sector metrics, latest in Moody's data**

| Metric | Value | Period | Basis |
|---|---|---|---|
| CET1 ratio | 12.97% | Q2 2026 | as reported |
| LCR | 134.8% | Q2 2026 | as reported |
| NSFR | 108.6% | Q2 2026 | as reported |
| Impaired loans / gross loans | 2.93% | Q2 2026 | Moody's data |
| Reserves / impaired loans | 57.7% | Q2 2026 | Moody's data |
| Loans / deposits | 82.3% | Q2 2026 | Moody's data |
| RWA / total assets | 25.8% | Q2 2026 | Moody's data |
| Tangible common equity / RWA | 13.7% | Jun 2026 | Moody's-adjusted |
| Cost / income | 60.6% | Jun 2026 | Moody's-adjusted |

The leverage ratio (fully loaded) is not in Moody's data.

**What it means for the rating and outlook**
- A1 stable, BCA baa1. The outlook rests on "very stable and highly predictable profitability and sound risk profile".
- The credit opinion (2 Sep 2026) predates the Q3 2026 results. Return on assets is 0.4% (Jun 2026), 0.2 pp short of the 0.6% upgrade level. Moody's puts Q3 2026 annualised return on assets at 43bp on its own calculation.
- Capital went from a company-reported 12.5% (Sep 2025) to 12.97% in Moody's financials (Q2 2026). The filing does not explain the change, and the opinion text returned does not mention it. No later CET1 requirement is on file.
- Moody's own comment: "Q3 results underscore position of strength amid worsening domestic operating conditions" (Issuer Comment, 28 Oct 2026).

Sources: Moody's Credit Opinion PBC_1491623 (2 Sep 2026); rating history RTNG_91000; Moody's financials (Q2 2026); BNP Paribas Interim Report 2025 - Q3 (period 30 Sep 2025, pp. 42, 69, 80, 88); Issuer Comment PBC_1499674 (28 Oct 2026).

Dashboard: the Earnings tab was updated at 20:19 UTC on 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-07-old-filing/dashboard/dashboard.html`. It was not published as an Artifact because this is a test run.
