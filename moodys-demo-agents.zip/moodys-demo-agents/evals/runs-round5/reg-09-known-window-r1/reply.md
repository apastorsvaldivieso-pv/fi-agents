**Regulatory watch: European banks, 16 Oct to 15 Nov 2026**

I found 13 regulatory items in the window. All of them are new to the running list. Sources are the regulators' own pages (web).

**Changes that hit a Moody's metric (CET1, through the G-SIB buffer)**
- **Basel Committee, 16 Oct, final:** amendments to the G-SIB framework to stop window dressing. Stock indicators will be reported as averages over the year, by 1 Jan 2030. The leverage-exposure reporting threshold rises from EUR 200bn to EUR 350bn from 2027.
- **Basel Committee, 16 Oct, consultation:** G-SIB methodology review, which asks whether to bring Banking Union cross-border exposures into the methodology. Comments are due by 14 Jan 2027.

**Who it hits: the 8 G-SIBs on the list, CET1 ratio (as reported, Q2 2026)**

The names are ranked by CET1 level. Ranking by headroom needs at least six banks with a current stated requirement, and only three have one.

| Bank | CET1 | Stated requirement | Distance | Position |
|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | total not stated | 2.6 pp (bank-stated, 31 Mar 2026) | Weaker third |
| BNP Paribas | 12.97% | 10.51% (30 Sep 2025, older) | +2.46 pp | Weaker third |
| ING Groep | 13.07% | 11.03% (31 Dec 2025, older) | +2.04 pp | Middle |
| Societe Generale | 13.20% | 10.26% (31 Mar 2026) | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | not stated | Middle |
| HSBC | 14.10% | not stated | not stated | Middle |
| Barclays | 14.30% | 12.2% (31 Dec 2025, older) | +2.10 pp | Stronger third |
| UBS | 14.38% | 10.83% (30 Jun 2026) | +3.55 pp | Stronger third |

Out of scope, because they are not on the FSB G-SIB list of 27 Nov 2025: Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. Positions show where each bank sits among the names the rule covers. They are not an estimate of impact.

**Watch items: no Moody's metric for the channel**
- **FINMA, 10 Nov, final:** revised AML Ordinance, in force 1 Jan 2027. Covers UBS.
- **PRA, 10 Nov, final:** PS20/26 on large exposures, effective 1 Jan 2028. Covers HSBC, Barclays and Lloyds.
- **Basel Committee, 9 Nov, consultation:** additional Pillar 2 guidance on interest rate risk in the banking book. Comments due 9 Feb 2027.
- **EBA, 9 Nov, final:** methodology for the 2027 EU-wide stress test. Launch end Jan 2027, results end Jul 2027.
- **EBA, 6 Nov:** reporting simplification. The first reference date moves to Dec 2027, and some modules move to Dec 2028.
- **EBA, 5 Nov, final:** revised internal governance guidelines. Moody's (Sector Comment, 11 Nov 2026) calls them credit positive, with a bigger effect on small EU banks.
- **Basel Committee, 5 Nov, consultation:** consequential amendments to the consolidated guidelines. Comments due 21 Dec 2026.
- **FINMA, 4 Nov, consultation:** revised Circular 2019/2 on interest rate risks for banks. Consultation runs until 15 Jan 2027. Covers UBS.
- **PRA, 22 Oct, consultation:** CP14/26 on SM&CR Phase 2. Comments due 22 Jan 2027.
- **European Commission, 22 Oct:** provisional political agreement on the Securitisation Framework review. It still needs formal adoption.
- **EBA, 22 Oct:** four consultation deadlines extended to 26 Oct 2026.

I left out 17 entries: speeches, newsletters, sanctions notices, appointments, credit-union papers and advice to the Commission. They are listed with reasons in the run's notes. The ECB published no press release in the window. The FSB's 2026 G-SIB list is not out yet.

The Regulatory watch tab was updated at 20:14 UTC, 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-09-known-window-r1/dashboard/dashboard.html`. This was a test run, so I did not publish it.
