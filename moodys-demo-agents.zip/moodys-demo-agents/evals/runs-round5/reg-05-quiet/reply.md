**Regulatory watch, European banks, PRA only, 14 to 15 Nov 2026: quiet.** The PRA published nothing addressed to banks in this window. Its prudential publications feed has no entries after 10 Nov 2026 ([PRA feed](https://www.bankofengland.co.uk/rss/prudential-regulation-publications)).

Because no rule changed, there is no "who it hits" section and I made no Moody's calls.

The Regulatory watch tab was updated at 20:11 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-05-quiet/dashboard/dashboard.html`. I did not publish it as an Artifact because this is a test run.
