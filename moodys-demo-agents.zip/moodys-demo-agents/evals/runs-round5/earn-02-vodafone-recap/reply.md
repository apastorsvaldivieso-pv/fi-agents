**Vodafone Group Plc: earnings recap (half-year FY27, results and call of 10 Nov 2026)**

Vodafone raised its FY27 guidance. Its company-reported net debt rose by €8.1bn to €33.5bn, mainly because of the VodafoneThree buyout and the Safaricom stake. Moody's-adjusted debt/EBITDA is 3.25x for the year to March 2026, which leaves 0.05x before the 3.3x downgrade trigger. The credit opinion behind these figures (21 Oct 2026) was published before the results.

Rating: Baa2 Senior Unsecured (foreign currency), outlook stable, affirmed on 13 Oct 2026.

**Results against the credit view** (company-reported unless stated)
- **Guidance upgraded.** Management said the old ranges were tracking to their upper end, and that upper end is now the midpoint of the new ranges. At the midpoint, the new guidance means organic growth of 7% in adjusted EBITDA and 21% in adjusted free cash flow. The Europe outlook stays unchanged, despite a €100m EBITDA hit from the ECJ ruling in Germany. Neither the call excerpts nor the filing give the old and new ranges in euros. Moody's forecasts are annual (FY27F debt/EBITDA 3.1x), so I can't state a beat or miss against them from half-year numbers.
- **Operations.** H1 adjusted EBITDA grew 6.4%. Germany EBITDA fell 3.2%, and 2 points of that came from the ECJ provision. There was a non-cash impairment of Vodafone Germany, mainly from a higher discount rate (8% against 7.5%). The loss attributable to owners was €(4,789)m.
- **Net debt** was €33,473m at 30 Sep 2026, up from €25,411m at 31 Mar 2026. The report names these drivers:
  - free cash outflow of €845m
  - acquisitions of €6,957m: the VodafoneThree buyout (€5,019m), the extra 15% of Safaricom (€1,379m) and net debt acquired with Safaricom (€537m)
  - dividends of €544m and buybacks of €92m

  Gross debt was €42.7bn, up from €38.6bn, after new bonds and more bank loans.
- **Liquidity.** Cash and short-term investments were €8.4bn, down from €12.4bn. Undrawn RCFs total €7.6bn: €4.1bn maturing in 2031 and US$4.0bn maturing in 2028. Moody's says the facilities have no financial covenants or MAC clauses.
- **Maturities.** The half-year report gives no maturity table. The annual report (31 Mar 2026) shows €3.0bn of bond cash flows, including interest, due within one year, with a cap on maturities in any one calendar year.
- **Capex.** Capital additions were €3,320m, up from €2,800m. Adjusted free cash flow was an outflow of €440m, €143m better than a year earlier. Management does not expect capital intensity in Germany to fall materially. On the call, an analyst said Vodafone may have to put up to €1.2bn of equity into the OXG fibre JV (the analyst's figure).
- **Shareholder returns.** The interim dividend is 2.306 eurocents, up 2.5%.
- **Safaricom.** An analyst said Kenya's High Court declared the stake sale void in September (the analyst's statement). Management referred to local legal challenges.

**Against Moody's triggers** (Moody's-adjusted, year to 31 Mar 2026)

| Metric | Latest | Upgrade | Downgrade | Room to upgrade | Room to downgrade |
|---|---|---|---|---|---|
| Debt / EBITDA | 3.25x | below 2.5x | fails to stay below 3.3x | 0.75x away | 0.05x |
| RCF / Net Debt | 33.08% | above 25% sustained | towards 18% sustained | already met, by 8.1pp | 15.1pp |

Worded triggers: an upgrade needs operating performance to "improve sustainably, particularly in Germany". A downgrade would follow "a failure to turn around its German operations".

**What it means for the rating and outlook**
- The stable outlook expects adjusted debt/EBITDA below 3.3x and RCF/net debt of around 30%. It also assumes Vodafone stays in the lower half of its 2.25x-2.75x net leverage target range.
- Company net debt is €8.1bn higher than at 31 Mar 2026, the period end of the Moody's-adjusted figures. Most of the increase comes from acquisitions.
- The opinion does address the UK buyout. It cites "reduced financial flexibility following the buyout of VodafoneThree" and gives cash "pro forma for the UK buyout". The opinion text returned does not mention the Safaricom purchase.
- Moody's has published no comment or rating action on these results so far. The latest documents are the rating action of 13 Oct and the opinion of 21 Oct.

Sources: Moody's credit opinion PBC_1496608 (21 Oct 2026), rating action PR_528027 (13 Oct 2026), Moody's-adjusted key indicators (FY to Mar 2026), the H1 FY27 earnings call transcript (10 Nov 2026), the half-year report (submitted 10 Nov 2026) and the Annual Report 2026.

The Earnings tab on the dashboard is updated ("Vodafone, recap", 15 Nov 2026 20:07 UTC). The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html`. This was a test run, so the page was not published as an Artifact.
