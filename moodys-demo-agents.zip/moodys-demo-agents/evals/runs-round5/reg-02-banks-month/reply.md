**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days, both days included)**

I found 11 new items at the primary regulators. Only one of them maps to a Moody's metric: the Basel Committee's G-SIB package of 16 Oct, which bears on CET1 through the G-SIB buffer. The other ten have no Moody's metric and are shown as watch items.

**Who it hits: G-SIB window-dressing amendments (final) and G-SIB methodology review (consultation) (Basel Committee, 16 Oct 2026) · CET1 ratio**

| Name | CET1 (as reported), Q2 2026 | vs median (pp) | Stated requirement | Distance | Position |
|---|---|---|---|---|---|
| Credit Agricole S.A. | 11.30% | -2.26 | total not stated | 2.6 pp, bank-stated, 31 Mar 2026 | Weaker third |
| BNP Paribas | 12.97% | -0.59 | 10.51%, 30 Sep 2025 (older) | +2.46 pp | Weaker third |
| ING Groep | 13.07% | -0.49 | 11.03% MDA trigger, 31 Dec 2025 (older) | +2.04 pp | Middle |
| Societe Generale | 13.20% | -0.36 | 10.26%, 31 Mar 2026 | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | +0.36 | not stated | | Middle |
| HSBC | 14.10% | +0.54 | not stated | | Middle |
| Barclays | 14.30% | +0.74 | 12.2%, 31 Dec 2025 (older) | +2.10 pp | Stronger third |
| UBS Group | 14.38% | +0.82 | 10.83% Swiss going-concern, 30 Jun 2026 | +3.55 pp | Stronger third |

- **How it is ranked:** by CET1 level, not by headroom. Only 3 of the 8 banks have a current stated requirement, too few to rank by headroom.
- **Out of scope:** Lloyds, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank and Nordea. None is on the FSB G-SIB list of 27 Nov 2025, and I found no 2026 list yet.

**What changed (newest first)**
- **PRA PS20/26, large exposures part 2 (final, 10 Nov):** substitution approach becomes mandatory, internal models for SFT exposures are removed, and trading-book and intragroup limits are revised. Effective 1 Jan 2028. Applies to HSBC, Barclays and Lloyds. Watch.
- **FINMA AML Ordinance (final, 10 Nov):** revised ordinance in force 1 Jan 2027. Applies to UBS. Watch.
- **Basel Committee IRRBB Pillar 2 guidance (consultation, 9 Nov):** comments due 9 Feb 2027. Watch.
- **EBA 2027 EU-wide stress test (final methodology, 9 Nov):** more than 55% fewer data points. Launch end Jan 2027, results end Jul 2027. Watch.
- **EBA supervisory reporting (announced new dates, 6 Nov):** first reference date moves to Dec 2027. Liquidity, asset encumbrance, benchmarking and ESG reporting move to Dec 2028. Watch.
- **EBA internal governance guidelines (final, 5 Nov):** application date not stated on the page. Moody's Sector Comment of 11 Nov calls the revisions credit positive for EU banks, more so for smaller ones. Watch.
- **Basel Committee consolidated guidelines, consequential amendments (consultation, 5 Nov):** comments due 21 Dec 2026. Watch. There is no channel-map row for this, so watch is my own call.
- **FINMA Circular 2019/2 on interest rate risks (consultation, 4 Nov):** comments due 15 Jan 2027. Applies to UBS. Watch.
- **PRA CP14/26, SM&CR phase 2 (consultation, 22 Oct):** comments due 22 Jan 2027. Applies to HSBC, Barclays and Lloyds. Watch.
- **Basel Committee G-SIB window-dressing amendments (final, 16 Oct):** G-SIB indicators move to annual averages from 1 Jan 2030. The leverage exposure reporting threshold rises to EUR 350bn from 1 Jan 2027. CET1 row.
- **Basel Committee G-SIB methodology review (consultation, 16 Oct):** asks whether to bring the Banking Union cross-border treatment into the G-SIB framework. Comments due 14 Jan 2027. CET1 row.

**Left out**

I left out 39 entries: speeches, newsletters, sanctions notices, consumer material, appointments, a moved consultation deadline, reports from one authority to another, and items addressed to credit unions or other firms.

**Not included**

A search result said the PRA's liquidity policy statement had slipped to Q1 2027. I could not confirm this on a PRA page, so it is not shown.

Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.

**Dashboard**

The Regulatory watch tab was updated at 20:22 UTC, 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-02-banks-month/dashboard/dashboard.html`. Because this is a test run, I skipped publishing it as an Artifact.
