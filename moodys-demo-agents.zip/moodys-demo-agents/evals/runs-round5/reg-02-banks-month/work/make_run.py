import json, sys
now = sys.argv[1]
src = []
def W(i, title, date, url): src.append({"id": i, "kind": "web", "title": title, "date": date, "url": url})
W("w1","BCBS: Amendments to G-SIB framework to address window dressing","2026-10-16","https://www.bis.org/publications/202610-standards-amendments-g-sib-framework-address-window-dressing")
W("w2","BCBS: Global systemically important banks - methodology review (consultative)","2026-10-16","https://www.bis.org/publications/202610-consultation-global-systemically-important-banks-methodology-review")
W("w3","BCBS: Consolidated guidelines - consequential amendments (consultative)","2026-11-05","https://www.bis.org/publications/consolidated-guidelines-consequential-amendments")
W("w4","BCBS: Interest rate risk in the banking book - additional Pillar 2 guidance (consultative)","2026-11-09","https://www.bis.org/publications/interest-rate-risk-banking-book---additional-pillar-2-guidance")
W("w5","EBA: The EBA streamlines the 2027 EU-wide stress test","2026-11-09","https://www.eba.europa.eu/publications-and-media/press-releases/eba-streamlines-2027-eu-wide-stress-test-more-55-reduction-requested-data")
W("w6","EBA: Next steps on supervisory reporting simplification, extended implementation timelines","2026-11-06","https://www.eba.europa.eu/publications-and-media/press-releases/eba-outlines-next-steps-supervisory-reporting-simplification-and-extends-implementation-timelines")
W("w7","EBA: Revised Guidelines on internal governance","2026-11-05","https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-revised-guidelines-internal-governance-delivering-greater-proportionality-and")
W("w8","PRA: PS20/26 Amendments to the Large Exposures Framework - Part 2","2026-11-10","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/november/amendments-to-the-large-exposures-framework-part-2-policy-statement")
W("w9","PRA: CP14/26 Review of the SM&CR - Phase 2","2026-10-22","https://www.bankofengland.co.uk/prudential-regulation/publication/2026/october/review-of-the-smcr-phase-two-consultation-paper")
W("w10","FINMA: Partially revised FINMA Anti-Money Laundering Ordinance","2026-11-10","https://www.finma.ch/en/news/2026/11/20261110-mm-gwv-finma/")
W("w11","FINMA: Consultation on partially revised Circular 2019/2 Interest rate risks - banks","2026-11-04","https://www.finma.ch/en/news/2026/11/20261104-mm-rs-19-02/")
W("w12","FSB: 2025 List of Global Systemically Important Banks (G-SIBs)","2025-11-27","https://www.fsb.org/2025/11/2025-list-of-global-systemically-important-banks-g-sibs/")
src.append({"id":"m_gov","kind":"moodys","tool":"searchAllDocuments","ref":"PBC_1502042","title":"Financial Institutions - Europe: EBA's revised governance guidelines are credit positive for small EU banks","date":"2026-11-11","url":"https://www.moodys.com/research/doc--PBC_1502042"})
banks = {
 "casa":("Credit Agricole S.A.","FR784608416",11.30),
 "bnp":("BNP Paribas","FR662042449",12.97),
 "ing":("ING Groep N.V.","NL33231073",13.07),
 "socgen":("Societe Generale","FR552120222",13.20),
 "db":("Deutsche Bank AG","DEFEB13216",13.92),
 "hsbc":("HSBC Holdings plc","GB00617987",14.10),
 "barc":("Barclays PLC","GB00048839",14.30),
 "ubs":("UBS Group AG","CHCHE395345924",14.38)}
for k,(n,bvd,v) in banks.items():
    src.append({"id":"f_"+k,"kind":"moodys","tool":"getEntityFinancials_v2","ref":"Common Equity / Core Tier 1 ratio (as reported), Q2 2026 (LQ)","title":n+" financials","date":"2026-06-30","url":"https://bankfocus-r1.bvdinfo.com/bankfocus/1/Companies/report/bvdid/"+bvd})
reqs = {
 "ubs":("Second quarter 2026 report","30 Jun 2026","2026-06-30"),
 "socgen":("First quarter 2026 results","31 Mar 2026","2026-03-31"),
 "casa":("First quarter 2026 results slides","31 Mar 2026","2026-03-31"),
 "bnp":("Third quarter 2025 report","30 Sep 2025","2025-09-30"),
 "barc":("Annual report on Form 20-F for 2025","31 Dec 2025","2025-12-31"),
 "ing":("Annual report on Form 20-F for 2025","31 Dec 2025","2025-12-31")}
for k,(f,d,iso) in reqs.items():
    src.append({"id":"r_"+k,"kind":"moodys","tool":"searchCompanyFilings","ref":"bank sector file, pulled 15 Nov 2026: %s, as of %s" % (f,d),"title":banks[k][0]+" stated CET1 requirement","date":iso})
med = 13.56
def row(k, req, dist, tone, rs=True):
    n,_,v = banks[k]
    d = round(v-med,2)
    fs = ["f_"+k]; both = fs+(["r_"+k] if rs else [])
    return [n, {"v":"%.2f%%"%v,"src":fs}, {"v":"%+.2f"%d,"src":fs},
            ({"v":req,"src":["r_"+k]} if rs else req),
            ({"v":dist,"src":both} if dist else "not stated"),
            {"tone":tone,"v":""}]
rows = [
 row("casa","total not stated; bank states distance to SREP requirement (31 Mar 2026)","2.6 pp, bank-stated, 31 Mar 2026 (phased-in CET1)","weaker"),
 row("bnp","10.51% CET1 capital requirement, 30 Sep 2025, older","+2.46 pp (vs older figure)","weaker"),
 row("ing","11.03% MDA trigger level for CET1, 31 Dec 2025, older","+2.04 pp (vs older figure)","middle"),
 row("socgen","10.26% CET1 requirement, shown against 31 Mar 2026, current","+2.94 pp","middle"),
 row("db","not stated",None,"middle",rs=False),
 row("hsbc","not stated",None,"middle",rs=False),
 row("barc","12.2% overall CET1 requirement excl. any PRA buffer, 31 Dec 2025, older","+2.10 pp (vs older figure)","stronger"),
 row("ubs","10.83% required going-concern CET1 (Swiss), 30 Jun 2026, current","+3.55 pp","stronger"),
]
cet1 = {"title":"Who it hits: G-SIB window-dressing amendments (final) and G-SIB methodology review (consultation) (Basel Committee, 16 Oct 2026) · CET1 ratio",
 "type":"table",
 "columns":["Name","CET1 ratio (as reported), Q2 2026","vs median of ranked names (pp)","Stated requirement (date)","Distance to requirement","Position"],
 "rows":rows,
 "note":"Covers the 8 names on this list that are on the FSB G-SIB list. Out of scope: Lloyds Banking Group, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea (not on the FSB G-SIB list of 27 Nov 2025). Ranked by CET1 level, not headroom: only 3 of the 8 (UBS, Societe Generale, Credit Agricole S.A.) have a current stated requirement. Median of the 8 ranked values: 13.56%.",
 "note_src":["w12","f_casa","f_bnp","f_ing","f_socgen","f_db","f_hsbc","f_barc","f_ubs"]}
EU = "BNP Paribas, Credit Agricole S.A., Societe Generale, Deutsche Bank, ING, UniCredit, Intesa Sanpaolo, BBVA, CaixaBank, Commerzbank, Nordea"
UK = "HSBC, Barclays, Lloyds Banking Group"
ALL = "All 15 names, once each home jurisdiction applies the standard"
items = [
 {"flag":"NEW","tag":"Final","name":"PRA","text":"PS20/26, part 2 of the large exposures reform: the substitution approach for credit risk mitigation becomes mandatory, internal models can no longer be used for securities financing exposure values, and trading book and intragroup limits are revised. Takes effect 1 January 2028; permission applications open 1 July 2027.","why":"Large exposures channel: no Moody's metric, shown as watch. Applies to HSBC, Barclays and Lloyds Banking Group.","src":["w8"]},
 {"flag":"NEW","tag":"Final","name":"FINMA","text":"FINMA published its partially revised Anti-Money Laundering Ordinance, aligning with recent AML Act changes ahead of the FATF evaluation and clarifying the correspondent banking provision. In force 1 January 2027, with a four-month transition for self-regulation.","why":"AML channel: no Moody's metric, shown as watch. Applies to UBS Group AG.","src":["w10"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Proposed additional Pillar 2 guidance on interest rate risk in the banking book: stronger risk management and supervisory expectations, and new Supervisory Information that banks would report. Comments by 9 February 2027.","why":"Interest rate risk in the banking book channel: no Moody's metric, shown as watch. A consultation, not a final rule. No Moody's comment found since publication.","src":["w4"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Final methodology for the 2027 EU-wide stress test, with requested data points cut by more than 55% and a separate climate risk module that does not affect core results. Launch end January 2027; results published end July 2027.","why":"Stress testing channel: no Moody's metric, shown as watch. No Moody's comment found since publication.","src":["w5"]},
 {"flag":"NEW","tag":"Other","name":"EBA","text":"Next steps on supervisory reporting simplification after consultation: the first reference date for new requirements moves to December 2027, and liquidity, asset encumbrance, benchmarking and ESG reporting are deferred to December 2028. Final report on the draft ITS due December 2026.","why":"Reporting channel: no Moody's metric, shown as watch. An announced change of dates, not a final rule.","src":["w6"]},
 {"flag":"NEW","tag":"Final","name":"EBA","text":"Revised Guidelines on internal governance (EBA/GL/2026/10), reflecting CRD VI, with less detail required on mapping of duties and simpler conflict-of-interest provisions than in the consultation. The page does not state an application date (awaiting translation).","why":"Governance channel: no Moody's metric, shown as watch. Moody's (Sector Comment, 11 Nov 2026) calls the revisions credit positive for EU banks, with a greater effect on smaller banks.","src":["w7","m_gov"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Proposed consequential amendments to the Basel Framework so cross-references point to the new consolidated guidelines, moving some application guidance chapters into them. Comments by 21 December 2026.","why":"No channel map row; mapped to watch by judgment, as it re-points text rather than changing a requirement.","src":["w3"]},
 {"flag":"NEW","tag":"Consultation","name":"FINMA","text":"Consultation on partially revised Circular 2019/2 on interest rate risks for banks, adopting the Basel Committee's July 2024 shock recalibration and giving more weight to effects on revenues. Comments by 15 January 2027; entry into force not stated.","why":"Interest rate risk in the banking book channel: no Moody's metric, shown as watch. Applies to UBS Group AG.","src":["w11"]},
 {"flag":"NEW","tag":"Consultation","name":"PRA","text":"CP14/26, phase 2 of the SM&CR review: many Senior Manager roles would move from pre-approval to notification, and certification regime assessments would be removed. Comments by 22 January 2027; implementation expected H2 2027, mostly dependent on the Financial Services and Markets Bill 2026.","why":"Governance and conduct channel: no Moody's metric, shown as watch. Applies to HSBC, Barclays and Lloyds Banking Group.","src":["w9"]},
 {"flag":"NEW","tag":"Final","name":"Basel Committee","text":"Finalised G-SIB framework amendments against window dressing: G-SIB score indicators to be reported and disclosed as averages over the year rather than year-end figures, from 1 January 2030; the leverage exposure reporting threshold rises from EUR 200 billion to EUR 350 billion from 1 January 2027.","why":"Changes how G-SIB scores are measured, so it sits on the capital buffers row (CET1 ratio). Covers the 8 G-SIBs on the list. No Moody's comment found since publication.","src":["w1"]},
 {"flag":"NEW","tag":"Consultation","name":"Basel Committee","text":"Consultation in the periodic G-SIB methodology review on whether to bring the previously agreed treatment of cross-border exposures within the European Banking Union into the G-SIB framework. Comments by 14 January 2027.","why":"G-SIB score measurement, capital buffers row (CET1 ratio). A consultation, not a final rule. The subject bears chiefly on the five banking-union G-SIBs on the list.","src":["w2"]},
]
watch = {"title":"Who it hits: no Moody's metric","type":"table",
 "columns":["Item","Covers on this list","Metric needed","Call"],
 "rows":[
  ["PRA PS20/26 large exposures (final, 10 Nov 2026)",UK,"Large exposures: no Moody's field",{"tone":"watch","v":"watch"}],
  ["FINMA AML Ordinance revision (final, 10 Nov 2026)","UBS Group AG","AML: no Moody's field",{"tone":"watch","v":"watch"}],
  ["Basel Committee IRRBB Pillar 2 guidance (consultation, 9 Nov 2026)",ALL,"IRRBB: no Moody's field",{"tone":"watch","v":"watch"}],
  ["EBA 2027 EU-wide stress test methodology (final, 9 Nov 2026)",EU+" (EU/EEA groups; the sample itself is set by the EBA)","Stress testing: no Moody's field",{"tone":"watch","v":"watch"}],
  ["EBA supervisory reporting timelines (other, 6 Nov 2026)",EU,"Reporting: no Moody's field",{"tone":"watch","v":"watch"}],
  ["EBA internal governance guidelines (final, 5 Nov 2026)",EU,"Governance: no Moody's field",{"tone":"watch","v":"watch"}],
  ["Basel Committee consolidated guidelines amendments (consultation, 5 Nov 2026)",ALL,"None mapped (judgment)",{"tone":"watch","v":"watch"}],
  ["FINMA Circular 2019/2 interest rate risks (consultation, 4 Nov 2026)","UBS Group AG","IRRBB: no Moody's field",{"tone":"watch","v":"watch"}],
  ["PRA CP14/26 SM&CR phase 2 (consultation, 22 Oct 2026)",UK,"Governance, conduct: no Moody's field",{"tone":"watch","v":"watch"}],
 ]}
leftout = ("Left out (39 in the window, judged from the listings): speeches, interviews and a blog post (ECB, SRB, FINMA); newsletters (BCBS AML/CFT newsletter, PRA Regulatory Digest); "
 "sanctions notices (FINMA, European Commission); consumer material (EBA factsheet); an appointment (EBA Vice-Chair); a moved consultation deadline (EBA); "
 "advice or reports from one authority to another (EBA Taxonomy advice to the Commission, ECB written overview to the Eurogroup); a statistical list (ECB supervised entities); "
 "a statement of support (EBA, NGFS declaration); meeting summaries and calls for nominations (Commission, SRB); and items addressed to other firms (PRA CP15/26 and DP2/26 for credit unions, Commission assurance standards consultation, FINMA Bitcoin ETF approval).")
run = {"schema":"fi-dashboard/1","agent":"reg-watch","title":"Regulatory watch","updated_at":now,
 "scope":{"sector":"Banks","region":"Europe","window":"30 days, 16 Oct to 15 Nov 2026","names":15},
 "status":"ok",
 "headline":"Eleven new regulatory items in 30 days; the one that maps to a Moody's metric is the Basel Committee's G-SIB package of 16 Oct, and among the eight G-SIBs on the list Credit Agricole S.A. (CET1 11.30%) and BNP Paribas (12.97%) sit in the weaker third, Q2 2026.",
 "headline_src":["w1","w2","f_casa","f_bnp"],
 "sections":[cet1, {"title":"What changed","type":"items","items":items}, watch,
   {"title":"Note","type":"text","text":leftout,"src":[]}],
 "sources":src, "unresolved":[],
 "notes":[
  "Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.",
  "Window: 16 Oct to 15 Nov 2026, both days included. All 11 items are new to the running list (first run for this list).",
  "Scope uses the FSB G-SIB list of 27 Nov 2025; the 2026 list was not found on fsb.org at the time of this run.",
  "The ECB press feed returned only speeches and interviews for the window; a search of ECB pages found no supervisory press release dated in the window (the IFRS 18 reporting release is dated 15 Oct, one day before it).",
  "A search result said the PRA's liquidity policy statement on CP5/26 has moved to Q1 2027; this was not found on a PRA page and is not shown.",
  "Moody's research was searched for the G-SIB, IRRBB, stress test and large exposures items; only the EBA governance guidelines have a Moody's comment in the window.",
  "Banco Santander, a G-SIB, is not on this coverage list (its rated record returns no financials)."],
 "meta":{"calls":{"moodys":5,"web":27}}}
json.dump(run, open("dashboard/data/reg-watch.json","w"), indent=1, ensure_ascii=False)
