**Regulatory watch: European banks, 30 days (16 Oct to 15 Nov 2026)**

I found 11 regulatory items in the window. One is new this run: a Basel Committee consultation on consequential amendments for the consolidated guidelines (5 Nov, comments due 21 Dec 2026). The other 10 were already on the running list and are shown as they were decided before.

**Who it hits: the Basel G-SIB package (16 Oct) · CET1 ratio, Q2 2026**
This is the only item in the window that maps to a Moody's metric. The table covers the 8 names on the FSB G-SIB list (27 Nov 2025; I found no 2026 list yet). Only 3 of them state a current requirement, so the names are ranked by CET1 level, not by headroom.

| Bank | CET1 | Distance to stated requirement | Position |
|---|---|---|---|
| Credit Agricole S.A. | 11.3% | +2.6 pp (bank-stated, 31 Mar 2026) | Weaker third |
| BNP Paribas | 12.97% | +2.46 pp (2025 requirement) | Weaker third |
| ING | 13.07% | +2.04 pp (2025 requirement) | Middle |
| Societe Generale | 13.2% | +2.94 pp | Middle |
| Deutsche Bank | 13.92% | not stated | Middle |
| HSBC | 14.1% | not stated | Middle |
| Barclays | 14.3% | +2.10 pp (2025 requirement) | Stronger third |
| UBS | 14.38% | +3.55 pp | Stronger third |

The other 7 names are out of scope because they are not G-SIBs. The consultation in the package deals with cross-border exposures within the banking union, so it bears on BNP, Credit Agricole, Societe Generale, Deutsche Bank and ING.

**What changed (newest first)**
- **PRA, PS20/26, final:** changes to the large exposures framework. Takes effect 1 Jan 2028.
- **FINMA, revised AML Ordinance, final:** in force 1 Jan 2027.
- **EBA, 2027 EU-wide stress test methodology, final:** launches end January 2027.
- **Basel Committee, additional Pillar 2 guidance on IRRBB, consultation:** comments due 9 Feb 2027.
- **EBA, next steps on simplifying supervisory reporting:** first reference date December 2027.
- **EBA, revised Guidelines on internal governance, final:** Moody's called them credit positive for small EU banks (Sector Comment, 11 Nov).
- **Basel Committee, consequential amendments for the consolidated guidelines, consultation (NEW):** comments due 21 Dec 2026.
- **FINMA, Circular 2019/2 on interest rate risks, consultation:** runs until 15 Jan 2027.
- **PRA, CP14/26 on the SM&CR, Phase 2, consultation:** responses due 22 Jan 2027.
- **European Commission, Securitisation Framework review:** political agreement reached.
- **Basel Committee, G-SIB framework:** final window-dressing amendments plus a consultation on the methodology review.

Ten of these items have no matching field in Moody's data, so they are shown as "watch", with the names each one covers. About 30 listing entries were left out (speeches, sanctions notices, newsletters, credit-union papers and similar), and the dashboard notes list them by reason.

The Regulatory watch tab was updated at 20:34 UTC on 15 Nov 2026: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/dash-reg-30d-final2/dashboard/dashboard.html`. Positions show where each bank sits among the banks a rule covers. They are not an estimate of impact.
