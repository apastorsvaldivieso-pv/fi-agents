**BNP Paribas, earnings preview** (you didn't give a mode. Moody's holds no call transcript for BNP Paribas, so this is a preview.)

**Headline:** BNP Paribas is rated A1 (LT Issuer Rating) with a stable outlook, affirmed on 31 Aug 2026. Moody's states only one trigger as a number: a return on assets of 0.6% or more for an upgrade. The credit opinion's key indicators show 0.4% at Jun 2026. Every downgrade trigger is worded. Moody's holds no call transcript, and the latest results filing it holds (Q3 2025) is older than the latest results in Moody's data (Q2 2026).

**Rating and outlook**
A1 LT Issuer Rating, outlook stable. The last action was an affirmation on 31 Aug 2026. Moody's downgraded the bank to A1 on 17 Dec 2024. The latest credit opinion is dated 2 Sep 2026. Moody's says the stable outlook rests on "very stable and highly predictable profitability and sound risk profile".

**What to watch against Moody's triggers**

| Metric | Latest (Moody's) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Return on assets (Net Income / Tangible Assets) | 0.4%, Jun 2026 | 0.6% and above | none stated as a number | 0.2 pp below the upgrade level |

Worded triggers, quoted from the credit opinion of 2 Sep 2026:
- Upgrade: "if the group manages towards lower financial leverage and demonstrates strong and sustained stewardship through disciplined risk management", "limiting any sudden and significant increase in problem loans and risk provisioning".
- Upgrade: "An upgrade of the Government of France's rating".
- Downgrade: "if the bank maintained lower regulatory capital buffers or sustained higher regulatory leverage, together with a sustained deterioration in asset quality or profitability metrics".
- Downgrade: "a marked increase in risk appetite, loss incidents or a material risk management failure".
- Downgrade: "a material deterioration in operating conditions in the bank's main markets ... accompanied by a significant weakening of its funding and liquidity profile".
- Senior unsecured debt only: if the increase in senior unsecured and lower-ranking debt relative to tangible banking assets "falls short of our current expectations" and a one-notch government support uplift cannot offset it.

**Sector metrics to watch**

| Metric | Latest | Basis | Trigger it bears on |
|---|---|---|---|
| Net interest margin | 0.9%, Jun 2026 | Moody's key indicators | Profitability / return on assets |
| Net interest income | not in Moody's data from this run | | Profitability |
| Cost of risk | not in Moody's data | | Risk provisioning (upgrade wording) |
| CET1 ratio | 12.97%, Q2 2026 | As reported | Capital buffers (downgrade wording) |
| CET1 requirement (bank-stated) | 10.51%, 30 Sep 2025 | Company-reported | Capital buffers |
| TCE / RWA | 13.7%, Jun 2026 | Moody's key indicators | Capital buffers |
| Leverage ratio (fully loaded) | not in Moody's data | | Regulatory leverage |
| Planned distributions | not in Moody's data | | Capital buffers |
| Problem loans / gross loans | 2.9%, Jun 2026 | Moody's key indicators | Problem loans |
| Impaired loans / gross customer loans | 2.93%, Q2 2026 | As reported | Asset quality |
| Loan loss reserves / impaired loans | 57.7%, Q2 2026 | As reported | Asset quality |
| Cost / income | 60.6%, Jun 2026 | Moody's key indicators | Profitability |
| LCR / NSFR | 134.8% / 108.6%, Q2 2026 | As reported | Funding and liquidity |
| HQLA / tangible banking assets | 15.9%, Jun 2026 | Moody's key indicators | Funding and liquidity |
| Loans / deposits | 82.3%, Q2 2026 (as reported); 85.8%, Jun 2026 (Moody's) | | Funding and liquidity |

The CET1 ratio (Q2 2026) and the bank's stated requirement (30 Sep 2025) are a year apart, so I have not worked out a distance between them.

**What the latest filing says** (Q3 2025 report, period to 30 Sep 2025, company-reported)
- The bank confirmed its 2026 trajectory: revenue CAGR above 5% for 2024-2026, jaws of about +1.5 points a year, net income CAGR above 7% and EPS CAGR above 8%.
- Cost of risk: "below 40 bps in 2025 and 2026". It was 39bps in 3Q25.
- RoTE targets: 11.5% for 2025, 12% for 2026 and 13% for 2028. The 2025 net income target was more than EUR 12.2bn. RoTE is the company's own measure and is not Moody's return on assets.
- CET1 was 12.5% phased-in against a stated requirement of 10.51%. LCR was 138% and the leverage ratio 4.3%. The bank says the Basel finalisation cycle is ending, so RWA should now move mainly with organic growth.

**Moody's expectations:** the credit opinion's key indicators table has no forecast columns. It shows history from Dec 2022 to Jun 2026 only.

Notes: the FY2025 annual report is also held and states no targets. I have matched the opinion's "return on assets" wording to its Net Income / Tangible Assets row.

The Earnings tab of the FI Credit Monitor dashboard was updated at 2026-11-15 20:19 UTC: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-04-worded-triggers/dashboard/dashboard.html`. This was a test run, so the dashboard was not published to the Artifact link.
