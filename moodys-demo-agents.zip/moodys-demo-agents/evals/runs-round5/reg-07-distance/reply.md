**Regulatory watch: European banks, 16 Oct to 15 Nov 2026 (30 days)**

No regulator changed the LCR in the window. All 15 banks are at least 34 pp above the 100% minimum. HSBC is closest at 134.00% and CaixaBank furthest at 192.99% (as reported, Q2 2026). The one item that hits capital is the Basel Committee's final G-SIB window-dressing amendments, which apply to the eight G-SIBs on the list.

**Who it hits: liquidity channel (you asked; no change found) · LCR, Q2 2026**
Every name is measured against the Basel III minimum of 100%. Local rules can be higher.

| Bank | LCR | Distance to 100% | Position |
|---|---|---|---|
| HSBC | 134.00% | +34.00 pp | Least headroom |
| BNP Paribas | 134.77% | +34.77 pp | Least headroom |
| ING | 137.00% | +37.00 pp | Least headroom |
| Intesa Sanpaolo | 137.60% | +37.60 pp | Least headroom |
| UniCredit | 140.00% | +40.00 pp | Least headroom |
| Deutsche Bank | 140.12% | +40.12 pp | Middle |
| Commerzbank | 141.00% | +41.00 pp | Middle |
| Crédit Agricole S.A. | 141.29% | +41.29 pp | Middle |
| BBVA | 142.00% | +42.00 pp | Middle |
| Lloyds | 144.00% | +44.00 pp | Middle |
| Société Générale | 146.41% | +46.41 pp | Most headroom |
| Nordea | 156.00% | +56.00 pp | Most headroom |
| Barclays | 157.70% | +57.70 pp | Most headroom |
| UBS | 177.28% | +77.28 pp | Most headroom |
| CaixaBank | 192.99% | +92.99 pp | Most headroom |

Two related items, neither of them a rule change:
- The ECB's 11 Nov Supervision Newsletter describes a leaner SREP method for liquidity and funding risk, to be applied from 2027. It was left out because it is a newsletter.
- The EBA's 6 Nov reporting plan defers new liquidity reporting to December 2028.

**Who it hits: Basel G-SIB amendments and methodology review (16 Oct) · CET1, Q2 2026**
These names are ranked by CET1 level, not by headroom, because only 3 of the 8 G-SIBs have a current stated requirement.
- **Weaker third:** Crédit Agricole S.A. 11.30% (the bank states it is 2.6 pp above its SREP requirement, 31 Mar 2026) and BNP Paribas 12.97%.
- **Middle:** ING 13.07%, Société Générale 13.20% (2.94 pp above its 10.26% requirement), Deutsche Bank 13.92% and HSBC 14.10%.
- **Stronger third:** Barclays 14.30% and UBS 14.38% (3.55 pp above its 10.83% requirement).

The other seven banks are out of scope because they are not on the FSB's G-SIB list of 27 Nov 2025. I could not find a 2026 list published yet.

**What changed (all new on the list)**
- **Basel Committee, 16 Oct, final:** G-SIB indicators will be reported as yearly averages instead of year-end figures, by 1 Jan 2030. The leverage-exposure threshold for G-SIB reporting rises to EUR 350bn from 2027.
- **Basel Committee, 16 Oct, consultation:** the G-SIB methodology review proposes building the agreed treatment of Banking Union cross-border exposures into the framework. Comments are due 14 Jan 2027.
- **European Commission, 22 Oct:** political agreement on the Securitisation Framework review, with more risk-sensitive capital treatment under the CRR. It is not yet adopted.
- **PRA, 22 Oct, consultation (CP14/26):** phase 2 of the SM&CR review. Comments are due 22 Jan 2027.
- **FINMA, 4 Nov, consultation:** revision of the interest rate risk circular 2019/2. Comments are due 15 Jan 2027.
- **Basel Committee, 5 Nov, consultation:** consequential amendments for the consolidated guidelines. These are structural only.
- **EBA, 5 Nov, final:** revised internal governance guidelines. A Moody's Sector Comment of 11 Nov calls them credit positive, more so for smaller banks.
- **EBA, 6 Nov:** next steps on simplifying supervisory reporting. The first reference date is December 2027.
- **EBA, 9 Nov, final:** methodology for the 2027 EU-wide stress test. Results are due at the end of July 2027.
- **Basel Committee, 9 Nov, consultation:** additional Pillar 2 guidance on interest rate risk in the banking book. Comments are due 9 Feb 2027.
- **PRA, 10 Nov, final (PS20/26):** Large Exposures framework, part 2. It applies from 1 Jan 2028.
- **FINMA, 10 Nov, final:** revised Anti-Money Laundering Ordinance. It is in force from 1 Jan 2027.

Ten items have no Moody's metric and are marked "watch": IRRBB, large exposures, AML, stress testing, reporting, governance, securitisation and the structural Basel update. A further 39 entries were left out (speeches, newsletters, sanctions notices, consumer material and credit-union papers), each with its reason.

Positions show relative position among the names each rule covers, on the stated metric. They are not an estimate of impact.

The Regulatory watch tab was updated at 20:22 UTC on 15 Nov 2026. The page is at `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-07-distance/dashboard/dashboard.html`. It was not published as an Artifact, because this is a test run.
