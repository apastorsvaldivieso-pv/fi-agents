**Iliad Holding S.A.S.: earnings recap**

**Headline:** Moody's has no earnings call transcript and no results filing for Iliad Holding, so this recap uses Moody's data only. Moody's-adjusted debt/EBITDA is 4.20x for the 12 months to 30 Jun 2026. That is 0.70x above the 3.5x upgrade trigger and 0.20x above the 4.0x level named in the downgrade trigger. Rating: Ba2 Corporate Family Rating, stable outlook.

**What's missing.** Moody's found no call transcript for Iliad Holding S.A.S., and the interim/annual filing search came back "not found" once ingestion finished. So I can't give you guidance, beat or miss against guidance, company-reported net debt, liquidity, undrawn facilities, maturities, capex, dividends or buybacks. As the skill requires, I didn't look for the call on the web.

**Results against the credit view (Moody's-adjusted)**
- LTM to 30 Jun 2026: revenue EUR 16,712M, EBITDA EUR 7,906M, total debt EUR 33,195M, debt/EBITDA 4.20x, RCF/net debt 13.99%, (EBITDA - capex)/interest 2.27x. *(getEntityFinancials_v2)*
- FY2025: debt/EBITDA 4.18x, RCF/net debt 15.68%, total debt EUR 31,123M. Debt rose EUR 2,072M and RCF/net debt fell 1.69 points.
- Moody's 2026F (credit opinion, 30 Jun 2026): debt/EBITDA 4.3x, RCF/net debt 14.5%. The LTM figures are 0.10x below the leverage forecast and 0.51 points below the RCF forecast. They cover 12 months to June, not a full year, so I don't call this a beat or a miss.

**Against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade | Downgrade | Room |
|---|---|---|---|---|
| Debt / EBITDA | 4.20x (LTM Jun 2026) | below 3.5x | "remains well above 4.0x" | 0.70x above the upgrade level; 0.20x above 4.0x |
| RCF / Net Debt | 13.99% (LTM Jun 2026) | towards 25% | no number stated | 11.01 pts short of 25% |

Worded downgrade conditions: "operating performance deteriorates, or if the company pursues further large debt-financed acquisitions or shareholder distributions"; FCF "weakens significantly".

**What it means for the rating and outlook**
- Ba2 Corporate Family Rating, stable outlook, upgraded from Ba3 on 19 Jun 2026. The outlook expects "steady earnings and cash flow growth, supporting some improvement in credit metrics ahead of the SFR acquisition", and lower leverage once that deal completes.
- The credit opinion is dated 30 Jun 2026, so it came out before any results for that period or later. Moody's published no issuer comment, rating action or new opinion on Iliad Holding between 1 Oct and 15 Nov 2026.
- With no company-reported net debt available, I can't state the change since the Moody's-adjusted period or what caused it.

Sources: Moody's credit opinion PBC_1488484 (30 Jun 2026); rating history RTNG_867915244; Moody's-adjusted key indicators (LTM 30 Jun 2026, FY2025); searchCompanyFilings (transcript and filings: not found); searchAllDocuments (no Moody's comment, 1 Oct to 15 Nov 2026).

Note: Iliad S.A. (Ba1) is a separately rated company in the same group. I didn't use it in place of Iliad Holding. If you want, I can run the recap on Iliad S.A. instead.

Dashboard: the Earnings tab was updated at 20:08 UTC, 15 Nov 2026. Page: `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-03-no-transcript/dashboard/dashboard.html`. The Artifact publish step was skipped (test run).
