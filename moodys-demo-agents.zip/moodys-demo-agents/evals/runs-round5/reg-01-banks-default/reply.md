**Regulatory watch, European banks: 9 to 15 Nov 2026**

Four new items this week. None of them is on a channel that Moody's data measures, so no bank is ranked. Each one is marked `watch`, with the names it covers.

| Item | Status, dates | Channel | Covers on the list |
|---|---|---|---|
| **PRA PS20/26**, Large Exposures Framework Part 2 (10 Nov) | Final. Applies from 1 Jan 2028; NCLEG permission applications open 1 Jul 2027 | Large exposures | HSBC, Barclays, Lloyds |
| **FINMA**, revised AML Ordinance (AMLO-FINMA) (10 Nov) | Final. In force 1 Jan 2027 | AML | UBS |
| **Basel Committee**, additional Pillar 2 guidance on IRRBB (9 Nov) | Consultation. Comments due 9 Feb 2027 | Interest rate risk in the banking book | All 15, once their home jurisdiction applies it |
| **EBA**, final methodology for the 2027 EU-wide stress test (9 Nov) | Final. Launches end-Jan 2027, results end-Jul 2027 | Stress testing (my judgment: the channel map has no row for it) | The 11 EU names, but who takes part depends on the EBA sample, which the page does not name |

- **PRA:** credit risk mitigation now has to use substitution. The internal-model option for SFTs is removed, and trading-book intragroup exposures get a single higher NCLEG limit.
- **FINMA:** after consultation, the correspondent-banking provision was narrowed.
- **Basel Committee:** the guidance covers model risk, stress testing, embedded gains and losses, and earnings indicators. It also proposes collecting supervisory data from banks.
- **EBA:** requested data points are cut by 55%, and there is a new climate module that does not affect the core results.

**Moody's view:** I found no Moody's research published 9 to 15 Nov that comments on any of the four items.

**Left out (not rules addressed to banks):**
- Commission consultation on limited-assurance standards for sustainability reporting. It is addressed to assurance providers and all CSRD reporters.
- EBA statement supporting the NGFS declaration
- EBA consumer factsheet
- ECB written overview for the Eurogroup
- SRB speeches and news on the competitiveness dialogue
- Commission summary of that dialogue
- Commission call for nominations to a tokenisation stakeholder group

I didn't pull financials, because no item maps to a Moody's metric. The coverage list is the 15-bank checked European list. All sources are the regulators' own pages, which are web sources.

The dashboard's Regulatory watch tab is updated (15 Nov 2026, 20:13 UTC): `/Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/reg-01-banks-default/dashboard/dashboard.html`. It was not published to the private link in this test run.
