**Daily sector news: Telecoms, Europe.** Window: 168h to 15 Nov 2026 22:07 UTC (8 Nov 22:07 to 15 Nov 22:07 UTC). 15 names.

**Headline:** Two Nordic operators made debt-relevant acquisitions this week (Telia buying Telavox's enterprise base for SEK 3.8bn [2]; Telenor taking control of Bahnhof [4]), while Telefonica and Vodafone raised cash-flow guidance [6][8]. Moody's published no rating action on the sector in the window [17].

## Top this week

1. **Telia Company AB: buys Telavox's Nordic enterprise customer base.** Telia signed a binding agreement on 12 Nov to buy the base for SEK 3.8bn, plus an earn-out of up to SEK 0.2bn, and licensed Telavox's unified communications platform [2]. The acquired base brings about SEK 1.1bn of annual revenue [3]. *Why it matters:* this is a cash acquisition that adds debt or uses liquidity at a Baa1 stable issuer [1]. The funding mix has not been disclosed.

2. **Telenor ASA: takes control of Bahnhof.** Telenor Sverige completed the purchase of 57.5% of Bahnhof's shares and launched a mandatory cash offer of SEK 62 a share for the rest [5]. On 13 Nov it held about 66.9% of the shares and 90.6% of the votes, and Bahnhof's independent committee recommended acceptance [4]. *Why it matters:* the cash outflow grows as more shares are tendered, at an issuer on Baa1 positive outlook [1].

3. **Telefonica S.A. and Vodafone Group Plc: guidance raised.** On 12 Nov, with its Q3 results, Telefonica raised its full-year guidance for adjusted EBITDA, operating cash flow after leases and free cash flow [6]. It reported Q3 net income of EUR 802m (company-reported) [7]. Vodafone's half-year results raised its full-year profit and cash-flow guidance [8]. *Why it matters:* higher cash flow supports leverage and RCF / net debt at Telefonica (Baa3 stable) and Vodafone (Baa2 stable) [1].

## Macro

- Euro-area bond yields dipped on 12 Nov as traders weighed the inflation and rate outlook [15], then rose on 13 Nov [14].
- US October inflation came in above forecast, and markets are now looking at a possible Fed hike in December [16].
- *Why it matters:* higher yields raise refinancing costs, most of all for the high-yield names on the list (VMED O2, Altice France).

## Sector

- **Moody's rating actions:** none on European telecoms in the window [17]. No rating on the list carries an action dated in the window [1].
- **Moody's sector outlook:** Telecommunications – Global is **stable** (27 Oct 2026). Stronger EBITDA and lower capital intensity offset modest growth, refinancing pressure and structural risks [13].

## By name

| Name | Rating (class), outlook [1] | This week |
|---|---|---|
| Deutsche Telekom AG | A3 (Senior Unsecured), stable | No material credit news. Q3 results and guidance date from 5 Nov, before the window. |
| Orange | Baa1 (LT Issuer Rating), stable | No material credit news. |
| Vodafone Group Plc | Baa2 (Senior Unsecured), stable | H1 results: full-year profit and cash-flow guidance raised [8]. |
| Telefonica S.A. | Baa3 (Senior Unsecured), stable | Q3: EBITDA, operating cash flow and FCF guidance raised [6]. |
| Swisscom AG | A2 (LT Issuer Rating), stable | No material credit news. |
| Telekom Austria AG | A3 (LT Issuer Rating), stable | No material credit news. |
| Proximus SA de droit public | A3 (Senior Unsecured), stable | No material credit news. |
| Telenor ASA | Baa1 (Senior Unsecured), positive | Control of Bahnhof; mandatory cash offer of SEK 62 a share under way [4][5]. |
| Telia Company AB | Baa1 (Senior Unsecured), stable | Telavox base for SEK 3.8bn [2]. Latvian state buyout of Telia's LMT and Tet stakes due by 17 Nov [12]. |
| TIM S.p.A. | Baa3 (LT Issuer Rating), positive | 9M: 2026 targets kept [10]; net loss EUR 205m (company-reported) [9]. Owner Poste Italiane is launching a EUR 600m data-centre fund [11]. |
| PPF Telecom Holdings B.V. | Baa2 (LT Issuer Rating), stable | No material credit news. |
| BT Group Plc (rated at British Telecommunications Limited) | Baa2 (LT Issuer Rating), stable | No material credit news. H1 results and pension valuation date from 5 Nov, before the window. |
| Iliad S.A. | Ba1 (Senior Unsecured), stable | No material credit news. |
| VMED O2 UK Holdings Limited | B1 (Corporate Family Rating), on review for downgrade since 22 Oct 2026 | No material credit news. |
| Altice France SAS | Caa1 (Senior Secured Bank Credit Facility), positive | No material credit news. |

Note: the Telia LMT/Tet disposal brings cash in, which partly offsets the Telavox outflow [12].

Dashboard not updated: this session has no folder to write to, cannot run scripts and cannot publish.

**Sources**
1. Moody's, getEntityRatings, current rating and 1-year history for the 15 listed names (BT via British Telecommunications Limited), 15 Nov 2026.
2. Moody's, searchNews, "Telia to acquire Telavox's Nordic enterprise customer base and license its unified communications platform", TelecomTV, ID 202611120945AMSPIDERFIN_NEWS_22152_27200, 12 Nov 2026.
3. Moody's, searchNews, "Telia to Acquire Telavox Enterprise Customers for SEK 3.8 Billion…", Telecomlead.com, ID 202611120703CONTIFY_NEWS____0069708735, 12 Nov 2026.
4. Moody's, searchNews, "Bahnhof's independent board committee recommends acceptance of Telenor Sverige's unconditional mandatory cash offer…", NewsWeb, ID 202611130231AMSPIDEROPNTNEUR_76750_166542, 13 Nov 2026.
5. Moody's, searchNews, "Telenor Sverige announces a supplement to the offer document… Bahnhof", Cision, ID 202611130222AMSPIDERAMC_USR__11290_566814, 13 Nov 2026.
6. Moody's, searchNews, "Telefónica raises EBITDA and free cash flow outlook after Q3 results", Seeking Alpha, ID 202611120151AMSPIDERBLG_FIN__25812_2267290, 12 Nov 2026.
7. Moody's, searchNews, "Telefonica Q3 Net Income Soars As Revenue Rise; Revises Annual Growth Outlook", RTT News, ID 202611120357AMSPIDERFIN_NEWS_25778_1033860, 12 Nov 2026.
8. Moody's, searchNews, "FTSE 100 Vodafone (LSE:VOD) Publishes Half-Year Results", Kalkine Media, ID 202611130657AMSPIDERFIN_NEWS_260566_328912, 13 Nov 2026.
9. Moody's, searchNews, "Telecom Italia's losses soar by 88% through September", CE Noticias Financieras, ID 202611121042CONTENGEBRZL_GVT_91079729, 12 Nov 2026.
10. Moody's, searchNews, "Telecom Italia stock keeps 2026 outlook after stronger 9M growth", Ad Hoc News, ID 202611111909AMSPIDEROPNTEEUR_20218_20231259, 12 Nov 2026.
11. Moody's, searchNews, "Poste Italiane launches €600m data centre fund", Green Street, ID 202611130256AMSPIDERFIN_NEWS_284900_50483, 13 Nov 2026.
12. Moody's, searchNews, "Government's directive regarding buyout of Telia's shares in LMT and Tet to be implemented by November 17 deadline", LETA, ID 202611130000PPI_____ASIANET_LETA1311202600010004, 13 Nov 2026.
13. Moody's, searchAllDocuments (Outlook), "Telecommunications – Global: Outlook stable as solid demand, declining capital intensity offset broad range of risks", PBC_1496503, 27 Oct 2026.
14. Moody's, searchNews, "U.S., Eurozone Bond Yields Rise But Two-Year Treasury Stabilizes", Morningstar, ID 202611130510AMSPIDEROPNT__AM_835_4659581, 13 Nov 2026.
15. Moody's, searchNews, "Euro zone bond yields dip as traders mull inflation, interest rate outlook", Zawya, ID 202611120435AMSPIDERNEWSSERV_22014_1245470, 12 Nov 2026.
16. Moody's, searchNews, "US inflation exceeds forecasts in October, killing rate-cut talk as Fed eyes December hike", MSN US, ID 202611151703AMSPIDERBRDCAST__28738_11469747, 15 Nov 2026.
17. Moody's, searchAllDocuments, document type Rating Action, Telecommunications / Europe, published 8–15 Nov 2026: no documents found, 15 Nov 2026.
