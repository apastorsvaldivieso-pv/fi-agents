**Earnings: Vodafone, recap** (H1 FY27 results (six months to 30 Sep 2026), call of 10 Nov 2026; 1 names)

Vodafone (Baa2 stable) raised its FY27 guidance at its 10 Nov H1 results, but company-reported net debt rose by EUR 8.1bn to EUR 33.5bn after the VodafoneThree buyout and the Safaricom deal; Moody's-adjusted debt/EBITDA of 3.25x (FY to Mar 2026) leaves 0.05x of room to the 3.3x downgrade trigger, and the credit opinion of 21 Oct 2026 predates these results. [1][2][3][4][5][6]

**Results against the credit view**

- **Raised** (Guidance): Management raised its FY27 group guidance: the top of the old ranges is now the midpoint, which it says implies about 7% organic growth in adjusted EBITDA and about 21% in adjusted free cash flow. H1 group adjusted EBITDA grew 6.4% (company-reported). Europe guidance was left unchanged after absorbing a EUR 100m EBITDA hit from the European Court of Justice (ECJ) ruling in Germany. The euro guidance ranges are not in the call or filing excerpts Moody's returned. *Why it matters:* Higher EBITDA and cash flow are what Moody's forecasts rely on to bring leverage down from 3.25x toward its 3.1x FY27 forecast. [2][7]
- (Moody's forecast): These are half-year results, and Moody's has no half-year adjusted figures, so they cannot be scored as a beat or miss against Moody's full-year FY27 forecasts (debt/EBITDA 3.1x, RCF/net debt 29.4%). *Why it matters:* The first test against Moody's forecast will be the full-year results to March 2027. [2]
- (Net debt): Company-reported net debt rose by EUR 8,062m to EUR 33,473m at 30 Sep 2026, up from EUR 25,411m at 31 Mar 2026. Drivers: EUR 6,957m of acquisitions (VodafoneThree buyout EUR 5,019m, an extra 15% of Safaricom EUR 1,379m, Safaricom net debt taken on EUR 537m), a EUR 845m free cash outflow, EUR 544m of dividends and EUR 92m of buybacks, offset by EUR 474m of other items. *Why it matters:* Debt went up mainly because of acquisitions, not weaker trading. This is the company's own measure, not Moody's-adjusted debt. [4]
- (Liquidity): Cash and short-term investments were EUR 8.4bn, down from EUR 12.4bn at 31 Mar 2026. Undrawn revolving credit facilities were EUR 7.6bn: EUR 4.1bn maturing 2031 and USD 4.0bn (EUR 3.5bn) maturing 2028 (company-reported). *Why it matters:* Cash fell after the acquisitions, but the undrawn facilities are intact. Moody's describes liquidity as excellent. [4][5]
- (Funding): Bonds rose by EUR 2,264m in H1, mainly from new issues, and bank loans by EUR 1,195m. As of 31 Mar 2026, bond cash flows due within one year were EUR 3,003m (undiscounted, including interest; FY26 annual report). The H1 report excerpts give no updated maturity table. *Why it matters:* Part of the acquisitions was paid for with new debt. Bonds due within the year are well covered by cash and the undrawn facilities. [4][8]
- (Capex): Capital additions were EUR 3,320m, up from EUR 2,800m in H1 FY26. Adjusted free cash flow was an outflow of EUR 440m, EUR 143m better than a year earlier (company-reported). Management does not expect any material reduction in capital intensity in Germany. *Why it matters:* Higher capex holds back free cash flow and therefore the RCF/net debt ratio. [4][7]
- (Shareholder returns): The interim dividend is 2.306 eurocents, up from 2.25 a year earlier; buybacks in H1 were EUR 92m (company-reported). *Why it matters:* The progressive dividend absorbs cash that could otherwise reduce debt. [4]
- (Watch items): Germany took a non-cash impairment, about three-quarters of it from a higher discount rate (8.0% vs 7.5%). An analyst on the call put the possible equity injections into the OXG fibre joint venture at up to EUR 1.2bn; management said any equity would be paid in stages over the build. *Why it matters:* Germany is named in both Moody's upgrade and downgrade triggers. Joint-venture funding would add to cash needs. [7]

**Against Moody's triggers**

| Metric | Latest (Moody's-adjusted) | Upgrade trigger | Downgrade trigger | Room |
|---|---|---|---|---|
| Debt / EBITDA | 3.25x, FY to 31 Mar 2026 [3] | below 2.5x [1] | fails to remain below 3.3x [1] | 0.05x to downgrade; 0.75x above upgrade [1][3] |
| RCF / Net debt | 33.08%, FY to 31 Mar 2026 [3] | above 25%, sustained [1] | towards 18%, sustained [1] | upgrade level already met, by 8.1 pp; 15.1 pp to downgrade [1][3] |

Note: Worded triggers: upgrade if "underlying revenue and operating performance improve sustainably, particularly in Germany"; downgrade if operating performance deteriorates, "including a failure to turn around its German operations". Moody's FY27 forecast: debt/EBITDA 3.1x, RCF/net debt 29.4%. [1][2]

**What it means for the rating and outlook**

- (Position): Vodafone's senior unsecured rating is Baa2 with a stable outlook, affirmed on 13 Oct 2026. Moody's-adjusted debt/EBITDA (3.25x, FY to Mar 2026) is just inside the 3.3x downgrade level, and RCF/net debt (33.08%) is above the 25% upgrade level. The stable outlook assumes debt/EBITDA below 3.3x, RCF/net debt of around 30%, and that the company stays in the lower half of its own 2.25x-2.75x net leverage target range. *Why it matters:* There is little leverage headroom against the 3.3x downgrade trigger. [1][3][6]
- (Timing): The credit opinion (21 Oct 2026) and the affirmation (13 Oct 2026) both predate these results, and the adjusted figures run only to Mar 2026. Since then, company-reported net debt has risen by EUR 8.1bn, mainly because of the VodafoneThree buyout and the Safaricom deal. The opinion already factors in the buyout, citing "reduced financial flexibility following the buyout of VodafoneThree". The opinion text returned does not mention Safaricom. *Why it matters:* The rating already reflects the UK buyout but not the H1 balance sheet. The company's net leverage at H1 is not in the excerpts returned. [1][4][5]
- (Moody's comment): Moody's has not published a comment on these results: nothing has appeared since the 10 Nov results date in the issuer comment, rating action and credit opinion search covering 1 Oct to 15 Nov 2026. *Why it matters:* The latest Moody's view is the 13 Oct affirmation and the 21 Oct opinion. [5]

**Notes**

- Company-reported net debt and Moody's-adjusted total debt are different measures and are not compared here.
- Mode: recap, because Moody's holds the H1 FY27 call transcript of 10 Nov 2026. The H1 report is titled "Interim Report 2026 - Q4" in Moody's data; it covers the six months to 30 Sep 2026.

**Sources**

[1] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, sections Summary, FactorsLeadingToUpgrade, FactorsLeadingToDowngrade, … · 2026-10-21
[2] Moody's (getCreditOpinion) · Vodafone Group Plc: Update following ratings affirmation · PBC_1496608, Key indicators table, forecast column 2027F · 2026-10-21
[3] Moody's financials (getEntityFinancials_v2) · Key indicators (adjusted): Debt / EBITDA, RCF / Net Debt, FY ending 31 Mar 2026 · Vodafone Group Plc · 2026-03-31
[4] Moody's (searchCompanyFilings) · Vodafone H1 FY27 interim report · Vodafone Group Plc Interim Report 2026 - Q4 (H1 FY27 results, six months to 30 Sep 2026), … · 2026-11-10
[5] Moody's (searchAllDocuments) · Moody's Ratings affirms Vodafone's ratings; stable outlook · PR_528027, Rating Action, liquidity section; publication-date window 1 Oct-15 Nov 2026 · 2026-10-13
[6] Moody's ratings (getEntityRatings) · Vodafone Group Plc · 2026-11-15
[7] Moody's (searchCompanyFilings) · Vodafone H1 FY27 earnings call transcript · Half Year 2027 Vodafone Group Public Ltd Co Earnings Call, event date 10 Nov 2026 · 2026-11-10
[8] Moody's (searchCompanyFilings) · Vodafone FY26 annual report · Vodafone Group Plc Annual Report 2026 (FY to 31 Mar 2026), submission date 22 May 2026, … · 2026-03-31

Earnings tab updated at 2026-11-15 22:07 UTC: /Users/Usuario/Moody's Project/FI Agents/moodys-demo-agents/evals/runs/earn-02-vodafone-recap/dashboard/dashboard.html (not published to the private link in this session).
