# How the Moody's tools behave

Found by live testing in November 2026. Each point is here because getting it wrong gave a wrong answer.

## Finding the right company

- **Moody's own sector search is not a complete list.** `findEntity` with "largest packaging companies" returned only paper packaging; "largest shipping companies" missed CMA CGM and COSCO. Looking the same companies up by name found every one, with the right rating flag. So name the companies, then look them up.
- **Looking up names**: put all the names in one `findEntity` call (a second call later, for companies found in the news, is fine). Check each result: the name matches the one asked for (ignore S.A., plc, Inc., AG), the country and sector fit, and it is the parent, not a subsidiary or a funding vehicle (names with Finance, Funding, Capital, Treasury). If one looks wrong, repeat the call for that name with `getAlternatives: true`, `maxAlternatives: 5`. Count the results against the names you sent: the tool can drop a name without saying so, or return a different company for it (SMIC came back as TSMC).
- **If a name is not found**, try it once more under its short common name ("Munich Re" for "Munich Reinsurance Company").
- **If a result still looks wrong** (this happens with banks: "Banco Santander" came back as Santander Brasil), look that one name up alone, with `disambiguationCriteria.country` set to its home country. If it is still unsure, say the company could not be matched; never pick the nearest one.
- **The "rated" flag can be wrong.** KPN and BT Group Plc both showed as rated. `getEntityRatings` (up to 10 companies per call, `years: 1`) is the truth: read the "Current Rating" line. WR (withdrawn), or no current rating, means "not rated by Moody's". The words "No ratings found" under a current rating only mean no action in the last year. "No ratings data" for a company means not rated. It also shows the date of each rating action, which is how you see an action inside the window.
- **A company with no Moody's rating still belongs in the brief** when it makes material news. Show it as "not rated by Moody's". Search its news with the entity `findEntity` returned, like any other company.
- **Some groups are rated at a different company** from the one the news is filed under: BT Group at British Telecommunications Limited, Graphic Packaging Holding at Graphic Packaging International, NXP Semiconductors N.V. at NXP B.V. When a large company with public debt comes back unrated, look it up again with `getAlternatives: true` and check whether a company of the same group holds the rating. If so, use that one for ratings and credit opinions, the listed parent for news, and say in the table where the rating is held. The checked lists carry `ratingsEntityId` for these.

## News

- **Dates must be full date-times**: `dateRange: {"startDate": "2026-11-17T06:00:00Z", "endDate": "2026-11-18T06:00:00Z"}`. A plain date such as "2026-11-17" is rejected.
- **Sector and macro searches**: `query` with no company, written as a plain sentence, `searchType: "semantic"`, `rerankResults: true`, `maxResultsPerEntity: 20`, `contentType: ["headline", "summary"]`. Do not use `keywordJoiner: "OR"` with a list of words: in testing it returned patents and stock tips and missed a Moody's rating action and a major route change. Put the region in the query if there is one.
- **Company searches**: `searchNews` takes one company per call: `entities: [{entityId, orgName, importance: "significance"}]`, `sortBy: "recency"`, `maxResultsPerEntity: 15` (25 for a week or more), `contentType: ["headline", "summary"]`.
- **The credit-events query**, for a company whose search came back full: the same call with `query: "investigation probe lawsuit regulator fine bond loan financing acquisition downgrade"`, `keywordJoiner: "OR"`, `searchType: "hybrid"`, `maxResultsPerEntity: 8`, and no `sortBy`. On Nvidia's results day the plain search returned only results coverage; this call returned the SEC investigation in six of its eight results.
- **Expect noise.** A large share of results are patent notices, share-price commentary, "stocks to watch" lists and insider share sales. Skip them; do not search again to get past them. "No news found" for a company means just that: write "no news returned".
- **A headline in one search is a lead, not a fact.** Before an item goes in the top items, find its figures and date in an article's text: the company's `searchNews` call again with `contentType: ["headline", "body"]`, `maxResultsPerEntity: 4`, a short `query` naming the event and `searchType: "hybrid"`. If that returns "No news found" or another company's articles, repeat it without the `query`.
- **Date an item by the event**, from the article's text. An item first reported inside the window is new, whatever the event's date; an article inside the window that retells something already reported before it is not. If only the article's date is known, write "reported on <date>". If outlets give different dates or figures, give both with the outlets.

## Is it new?

Company and sector searches are limited to the window, so they cannot show that a story is older than it looks. In testing a brief led with a tender offer "opened" in the window; it had opened, and been reported, the day before.

- For each top item, and for a company line whose article does not date the event inside the window: one `searchNews` call for the same company (or the same plain-sentence query for a sector item), with a short `query` naming the event, `searchType: "hybrid"`, `contentType: ["headline", "summary"]`, `maxResultsPerEntity: 8`, and `dateRange` covering the fourteen days before the window starts. If the search says "No news found" for a newly formed or renamed company, repeat it once under the acquirer or the old name.
- If the event was already reported there, it is not new. It can stay in the company's row as "earlier: <what, with its date>; nothing new in the window", or be dropped. It does not go in the top items unless something new happened to it inside the window.
- Clues in the article itself: "issued the following news release" with an earlier date, "last week", "on Tuesday" when the window starts on Wednesday, and a release that is a routine weekly or monthly update. News services re-run company releases days later: for any line on results, guidance or a forecast, open the article and read the date at the top of the release.

## Moody's documents

- `searchAllDocuments` needs `keywords` (sector or issuer plus the kind of document, such as "semiconductor rating action") and filters by whole calendar days. Moody's documents carry a date and no time: one dated on any day the window touches counts as inside the window.
- **Rating actions on the listed companies**: the dates in `getEntityRatings` show any action inside the window. For its text, `searchAllDocuments` with `entities` set to that company (up to 5 per call), `filter.documentTypes: ["Rating Action"]`, `chunks: 1`.
- **Sector research and other rating actions in the window**: `searchAllDocuments` with `documentTypes: ["Rating Action", "Sector Comment", "Sector In-Depth", "Issuer Comment", "Issuer In-Depth"]`, `publishDate` set to the window, `chunks: 1`, and `filter.sectors` set to the sector **and each of its parts** (`["Packaging", "Paper Packaging", "Plastic", "Glass", "Metal"]`). Moody's sector names are its own: "Packaging" alone returned nothing on a day it downgraded a packaging company's outlook. A name Moody's does not recognise either makes the call fail or is dropped without a word. If the call fails, take out the name the error mentions and run it again. If it runs, read the titles: if they are plainly other sectors, the filter did not take; say the search returned nothing for the sector. The parts go in `filter.sectors` only when they are kinds of business. When the parts are regions or countries (banks, insurers), use the sector's own name (`["Banking"]`, `["Insurance"]`) and put the region in `filter.regions` (`["Europe"]`, or the country names; "European Union" is rejected).
- **Latest sector outlook** (not limited to the window): `documentTypes: ["Outlook"]`, `publishDate` over the last 13 months, `penalizeOlderResearch: true`, `chunks: 1`, keywords "<sector> outlook". Try with the region, then without it: many sector outlooks are global. Take the most recent one whose title names this sector, or the wider sector it belongs to (shipping sits in "Transportation"), and give its title, scope and date. A sector can have more than one (paper packaging, metal and glass): give each one found. For banks, Moody's has no single European outlook: give the global banks outlook and any country banking-system outlooks for countries on the list.
- **Do not call `getEntitySectorOutlook` or `getEntityScorecardV2`.** Both return far too much text. Use the outlook search above and `getCreditOpinion`.
- **Ratings under review**: search that name's latest rating action and say which ratings are under review and in which direction, from the document.

## Results

Headlines rarely carry the figures. For a name that published results inside the window:

1. Always first, even if a transcript is available: one more `searchNews` for that name with `query: "results net profit loss impairment guidance net debt dividend"` (for a bank: "results net profit CET1 capital dividend buyback"), `keywordJoiner: "OR"`, `searchType: "hybrid"`, `contentType: ["headline", "body"]`, `maxResultsPerEntity: 4`.
2. If the profit or loss, or the debt or capital figure, is still missing: `searchCompanyFilings` with `filingTypes: ["earnings_call_transcript"]`. Identify the call by its headline and date; the quarter label can be wrong. Cite it by title and date: its link expires in minutes.
3. If the transcript is "not found" or still loading, stop there and name what is missing. Do not fall back to interim or annual filings for a news brief: they return over 100,000 characters and are often a year old.
4. A transcript that comes back as "ingesting" is still loading: try once more at the end, and if it is still loading, say so.
5. Give the profit or loss with last year's figure from an article's text, not from a headline. Name in the line whatever is still not returned. Report results in full, never only the good half.

These results can be long. Search them for the terms you need rather than reading them whole.

## What Moody's does not have

No forward earnings calendar, no consensus estimates. Mention an upcoming results date only when an article in the results states it, with that source.
