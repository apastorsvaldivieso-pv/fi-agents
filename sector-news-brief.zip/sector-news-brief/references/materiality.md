# What is material

Read every article returned for a name against this list. A brief that reports the good half of a set of results, or leaves out the week's largest deal, is worse than a short one.

## Anything here goes in

| Kind | Report |
|---|---|
| Results or a trading update | In full: profit or loss (naming any impairment or one-off), direction of revenue and EBITDA, guidance change old to new, net debt or leverage. For a bank: profit, CET1, dividends or buybacks. The date the results came out |
| Deals | Acquisitions, disposals, mergers, stakes, offers: size, and where it stands in the source's words (agreed, pending, completed, challenged). Funding and leverage effect if stated |
| Investigations, rulings and disputes | A newly reported investigation by a regulator or prosecutor, a lawsuit that is filed or survives a motion to dismiss, a court, regulatory or tax ruling, or anything that puts a deal at risk. Report it even when no amount is stated, and say so |
| Funding | A benchmark bond, AT1 or Tier 2, a liability exercise, a large loan, bridge or revolving facility, with the amounts |
| Shareholder returns | Dividends and buybacks, with the amount |
| Management | A change of chief executive or finance chief |
| Restructuring | Job cuts, plant closures or a reorganisation, with the numbers stated |
| Moody's | Any rating action, outlook change, issuer comment or credit opinion on the name in the window |
| Financial policy | New leverage, cash flow, dividend or capital spending targets, with the old and new levels |
| Operations | An event that stops or reroutes the business: attacks, accidents, strikes, plant or route closures and reopenings, large capacity orders |
| Government measures | Export controls, tariffs, subsidies, a levy or rule aimed at the sector, with the stated cost |

The largest of these lead the Top items, whichever company they concern and however few articles carry them. The rest go in the name's line.

## Not material

Patent notices, share-price moves and commentary, "stocks to watch" lists, insider share sales, broker target changes, passive shareholding filings, small contracts and tenders, product launches with no stated financial effect, marketing, awards, management changes below the two posts above, and stories about a subsidiary that do not touch the group's credit.

## One article only

If an item rests on one article, or only on aggregators, try to confirm it with one `searchNews` for that name with a short query naming the event (`searchType: "hybrid"`). A company release, a regulator or a news wire confirms it. An article that reports a company's own release or regulatory filing, or names the outlet that broke the story ("the Wall Street Journal reported"), is already confirmed enough to lead: give the outlet. Only an item with neither goes out of the Top items, marked "single source, unconfirmed".
