---
name: sector-news-brief
description: Credit news brief for any sector or list of issuers on Moody's data - top items, macro, sector, one line per company, all sourced. Use for sector news or a daily credit brief.
---

# Sector news brief

The job: scan the sector's news, scan Moody's ratings and research on it, and tell a credit analyst what happened, with a source on every fact.

Inputs: **sector** (required), **names** (optional), **region** (optional; if none is given, cover the sector worldwide and say so). Needs the Moody's connector. Uses no web search.

Before starting, read the three files in `references/`: `rules.md` (how to source and write the answer), `moodys-tips.md` (how the Moody's tools behave, with the settings for every call below) and `materiality.md` (what counts as credit news).

## Steps

1. **Window.** The last 24 hours up to now; on a Monday, the last 72; or what the user asks. State it in the brief.

2. **Name the companies.** Skip this step if the user gave names.
   - Write down the sector's parts (packaging: paper, plastic, metal, glass; shipping: container, tanker, dry bulk; insurers: multi-line groups, life insurers, reinsurers) and about 25 companies (no more than 30) a credit analyst covering the sector would expect to see: the largest in each part (at least three per part), in every region the request covers (for a worldwide brief: the Americas, Europe and Asia), investment grade and high yield, large private and unrated ones included. A company that is not on the list does not get searched, so err on the side of a longer list. This list is yours to propose: Moody's own sector search misses major companies. Also note the next five to ten companies that did not make the list; they are named in the brief.
   - For European banks or European telecoms, start from the checked list in `references/lists/`. Its companies are already matched: use the IDs in the file as its note says and do not look them up again. They count towards the 25: when the list is already that long, add only companies that make material news. For banks, the parts are regions (UK and Ireland, France, Germany/Austria/Switzerland, Italy, Iberia, Benelux, Nordics), and a region may hold fewer than three banks.
   - Look up the companies that did not come from a checked list in one `findEntity` call, and confirm every company's rating with `getEntityRatings`. A company Moody's cannot match is dropped and named in a note. **Your knowledge supplies only the names. Every rating, figure and news item comes from Moody's.**

3. **Scan the sector's news.** Two `searchNews` calls with no company and a plain-sentence query: one on the sector's news ("shipping lines and tanker owners: results, deals and disruptions"), one on its credit events ("shipping companies: bonds, loans, ratings, investigations and lawsuits"). This scan is one way companies you did not list get found: add any company that makes material news here, or in a later search (a bidder, a target, a merger partner), to the list and look it up the same way. These additions do not count against the 30.

4. **Collect, in one step:**
   - `searchNews` once per company on the list (one company per call). A company whose search comes back full has more news than you saw: make a second call for it with the credit-events query in `moodys-tips.md`. A busy company's biggest story can hide behind its results coverage;
   - Moody's rating actions on the listed companies, Moody's sector research in the window, and the latest sector outlook (`moodys-tips.md`, "Moody's documents");
   - one macro `searchNews` on central banks, rates and the economy.

5. **Decide what is material** with `materiality.md`. Before an item leads the brief, open an article on it and take the figures and the date from the text. Then check that it is new (`moodys-tips.md`, "Is it new?"): every search so far was limited to the window, so an article inside it can be retelling something reported days earlier. Do the same check for any company line whose article does not itself date the event inside the window. For a company that published results in the window, get the figures as `moodys-tips.md`, "Results", says. For rated companies in the top items, call `getCreditOpinion` (sections `FactorsLeadingToUpgrade`, `FactorsLeadingToDowngrade`, `RatingOutlook`) for the "why it matters" line. If the company's last rating action is dated after the credit opinion, the opinion is out of date: say so and use the rating action's wording, or leave the line out.

6. **Write the brief**, in this order:
   - **Headline**: one sentence, with the window and the region.
   - **How the sector was read**: one line right after the headline, naming the parts and the number of companies checked in each ("Packaging taken as paper (8 companies), plastic (9), metal (6), glass (5); 28 checked, 21 rated by Moody's. Not checked: Sonoco, Stora Enso, Novolex, Orora, Rengo"). It ends with the next five to ten companies that did not make the list, so the reader can see a thin or missing part, or a missing name, and ask for it.
   - **Top items**: up to three, most important first, each ending with why it matters for credit, only from a source.
   - **Macro**: up to three lines.
   - **Sector**: sector-wide news, Moody's actions and research in the window, then the latest Moody's sector outlook with its date.
   - **By company**: a table grouped by the same parts, one row per company: name, Moody's rating and outlook or "not rated by Moody's", one line. "No material credit news" when the search found nothing material.
   - **Notes** (only if needed): companies that could not be matched, anything not returned.
   - **Sources**: a numbered list, as `rules.md` says.

7. **Quiet day.** Call the sector quiet only when the step 3 scan *and* every company's search found nothing material. Then the brief is one line, plus the list of companies checked.

## Do not

- Do not call a sector quiet on the strength of one search or a short list.
- Do not state anything about a company from memory: no rating, figure, deal or date without a Moody's source.
- Do not guess which entity is the right one: if the lookup is unsure, say so.
- Do not show old news as new. An item is new when it was first reported inside the window, even if the event itself is a few days older (a ruling on Saturday first reported on Tuesday): include it and give the event's date. An event already reported before the window belongs in the brief only for what happened to it inside the window (a first effect, a reaction): lead with the new part and give the original date. It never leads the top items as if it happened in the window.
- Do not put an event in a company's row unless the article names that company as a party to it.
- Do not give a view on bonds or shares, or forecast a rating action.
