---
name: earnings-credit
description: Earnings for a credit analyst on Moody's data - preview (what to watch against Moody's triggers) or recap (results against guidance and triggers), all sourced. Use for earnings previews and recaps.
---

# Earnings for credit

The job: tell a credit analyst what a company's results mean for its credit, set against Moody's rating triggers, with a source on every fact.

Inputs: **company** (required) and **mode**. `recap` (what the latest results said and what they mean for credit) is the default: use it for any question about a company's earnings or results, however long ago they came out. `preview` (what to watch in the coming results) is only for a question about results still to come ("next results", "preview", "what should I watch", "ahead of"). Needs the Moody's connector. Uses no web search.

Before starting, read the two files in `references/`: `rules.md` (how to source and write the answer) and `moodys-tips.md` (how the Moody's tools behave, with the settings for every call below).

## Steps

1. **Find the company** as `moodys-tips.md`, "Finding the right company", says. If it cannot be matched, stop and say so: never use a similar company. If Moody's does not rate it, follow "A company Moody's does not rate" below.

2. **Find the latest results in the news**, four `searchNews` calls (`moodys-tips.md`, "The latest results in the news"). Always make all four: Moody's filings search often holds no results call for the group, or a report for an older period, and the news feed is then the source for the results.
   - The first call finds the date the last results came out and the period they cover.
   - The second, limited to that day and the next, brings back the articles that carry the figures.
   - The third finds the transcript of the group's results call, which Moody's news feed usually carries even when the filings search does not.
   - The fourth covers the days since the results, when they are more than three days old: a deal approved, a profit warning, new guidance. What has happened since goes in the answer with its date.
   - If the news gives no release date, take it from the results call's date or the report.
   - **A trading update is not full results.** Some companies publish only revenues or activity figures for the first and third quarters (AXA's nine-month "activity indicators"). Then recap the update, say plainly that it carries no profit figure, and add the last full results (the half-year or full year) with their date, from one more pair of news calls for that date.
   - The headline starts with the mode, "Recap:" or "Preview:", and gives the date of the results. A recap of results more than a month old says so.

3. **Collect** (`moodys-tips.md` has the settings for each call; the filings take two rounds, a probe and then the rest):
   - the credit opinion, and its date;
   - the rating, its kind, the outlook and the last rating action. If a rating action is dated after the credit opinion, pull that action: its outlook and its factors replace the opinion's;
   - Moody's financial figures for the company, with their period (not for an insurer);
   - the latest results call from the filings search (if it returns none, or a subsidiary's, the transcript from the news feed is the call);
   - the results report for the period;
   - in a recap: Moody's documents on the company published since the results date.

4. **Read them** as `moodys-tips.md`, "Results calls and reports", says. Check that a call or report is the group's own and covers the period: Moody's can return a subsidiary's call, or last quarter's report. For the company's own figures, use the report first, then the call (from the filings search, or a transcript of the group's call published as a news article), then the news articles, and say in each point where its figures come from. Where the report and the call differ on a period-end figure, use the report's and note the other. Everything from these is company-reported. A Moody's comment on these results is a fourth source: figures it retells from the company are "company-reported, per Moody's"; ratios Moody's works out itself are Moody's figures.

5. **Fill the gaps, then say what you did not get.** If you still lack the profit or loss for the period, the period-end debt (or capital, or solvency), the liquidity position, or the guidance, make one more `searchNews` call for each (three at most), with the settings of the second news call, limited to the results day and the next, and a query that names it ("<company> nine months net profit loss"). If a report for the period is held and a point needs its legal or debt note, make one report query naming that note. Only after that write "not in the sources returned". Say in the headline which sources the answer rests on when one is missing ("from press reports of the release; the search returned no group results call, and the latest report is for the half-year"). Never present guidance or figures from an older period as current: give each with its date.

6. **Write the answer** in the order given below for the mode, then **Notes** (only if needed, at most five lines) and **Sources**, as `rules.md` says. Use the words for the kind of company (`moodys-tips.md`, "What to look for, by kind of company"): a bank's capital and an insurer's solvency take the place of a company's net debt.

## Preview

- **Headline**: "Preview:", the company, the results that are coming (name the period and date only if a source states them; otherwise "next results"), the date of the last results, and the rating and outlook.
- **Rating and outlook**: one line: the kind of rating, the company that holds it, the outlook, the date of the last rating action and the date of the credit opinion.
- **Moody's triggers**: where Moody's states a number for a named metric, a table: metric, latest value with whose figure it is and its period, the upgrade level, the downgrade level, and the difference to each as a number. Factors Moody's states in words go in a short list in Moody's terms, upgrade then downgrade, with no difference worked out. Many banks and insurers have no numbers: then there is no table.
- **Figures to watch**: the few figures that matter most for this kind of company and are not already in the trigger table, each with its period and whose figure it is.
- **What the company said last time**: three to five points, starting with the latest results: debt, capital or solvency at the latest period end, liquidity, guidance and shareholder returns, each with its source and date. Then anything older that still holds, and guidance or deals announced since (an investor day, a profit warning, an acquisition and how it is funded).
- **Moody's expectations**: the forecast columns of the key indicators table. Leave the section out if there are none.

If results came out in the last 21 days, say so in a note and offer the recap.

Name the coming results only as far as the sources allow: "the results after the nine months to September 2026" is fine; a period or date no source states is not.

## Recap

- **Headline**: "Recap:", the company, the period and date of the results, the one or two things that matter most for credit, the rating and outlook, and the sources the answer rests on if any is missing.
- **Results against the credit view**: up to six points, in this order, leaving out a point the sources say nothing on:
  1. results against the company's own guidance, and any change to guidance, old to new, including guidance given since the results. If the sources give no guidance for this period, say so;
  2. the profit or loss for the period with last year's figure or the growth rate the source states, then the items inside it as the report lists them: impairments, write-downs, one-off gains, and the tax charge when that is what turns a profit into a loss (a bank: also the cost of risk and problem loans);
  3. debt and the three largest things that moved it, as the company states them (a bank: capital and its requirement; an insurer: the solvency ratio and what moved it). Give the change since the previous quarter or half-year and since the year-end where the sources give them: a fall in the quarter is the news, not the level;
  4. liquidity, undrawn facilities, maturities and refinancing;
  5. capital spending, dividends and buybacks;
  6. a pending deal and what the company says it does to debt or capital, and any ruling, dispute or contingent liability that bears on debt or on a deal.
- **Moody's triggers**: as in the preview. Say plainly when Moody's figures are for a period before these results, or before a deal or a debt issue the results report. For a bank or insurer, add in one line the Moody's ratios from the key indicators table that bear on the results (problem loans, funding, liquidity), with their period.
- **What it means for the rating and outlook**: what the rating rests on, in one clause, where the opinion's summary says so (support from a government or parent, the standalone assessment); where the company sits against the triggers and the outlook wording; whether the credit opinion predates these results; any rating action since the opinion; and what Moody's has published on the company since the results, with title and date.

## A company Moody's does not rate

There is no credit opinion and there are no triggers. Skip the credit opinion, the rating-action pull and the financial figures call. Say "not rated by Moody's" in the headline, leave out the trigger and rating sections, title the first section "Results", and write the rest from the report, the call and the news, all labelled company-reported. Add one note that there is no Moody's credit view to set the results against.

## Do not

- No comparison with consensus or analysts' forecasts: Moody's data has none, and an article's "beat forecasts" is left out. "Ahead of" or "behind" is against the company's own guidance and Moody's forecast.
- Do not work out a Moody's-adjusted ratio from the company's numbers, and do not treat the company's net debt or leverage as the same measure as Moody's. Give the two side by side, each with its period.
- Do not work out net debt, a ratio or a growth rate yourself when the source does not state it. Give the figures the source gives.
- Do not say a rating action is likely or unlikely. State the position against the triggers.
- Do not state anything about the company from memory: no rating, figure, date or guidance without a Moody's source.
- Do not write that a document "does not mention" something when you hold only part of it. Write "not in the text returned".
- No view on the shares or the bonds.
