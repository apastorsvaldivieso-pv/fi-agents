# How the Moody's tools behave

Found by live testing in November 2026. Each point is here because getting it wrong gave a wrong answer.

## Finding the right company

- **One `findEntity` call** with the name as the user wrote it, `getAlternatives: true`, `maxAlternatives: 5`. If the user's own words give the home country ("Telecom Italia", "the Spanish bank"), set `disambiguationCriteria.country` to it as a list of ISO codes (`["IT"]`).
- **Accept a record that is the group's parent company.** Its name is the name asked for, or the company's current or formal name (Telecom Italia is "TIM S.p.A."; Hannover Re is "Hannover Reinsurance Company"; ignore S.A., plc, Inc., AG and a country in brackets), and its country and sector fit. Reject a subsidiary or foreign unit (Santander Brasil, Mapfre Uruguay), a branch, a funding vehicle (names with Finance, Funding, Capital, Treasury) and any record marked "(Old)". Look through the alternatives before giving up.
- **If the first result is a foreign unit of the group asked for** and no alternative is the parent ("Santander" returns its Brazilian, Chilean and UK banks), make one more call with `disambiguationCriteria.country` set to the group's home country. If that still gives no parent, the company could not be matched: say so and stop.
- **The "rated" flag can be wrong.** `getEntityRatings` (`years: 2`) is the truth: read the "Current Rating" line. WR (withdrawn), or "No ratings data", means "not rated by Moody's". The words "No ratings found" under a current rating only mean no action in the period asked for.
- **Two records for one group.** Some groups are rated at a different record from the one that carries their news and filings: BT Group at British Telecommunications Limited, NXP Semiconductors N.V. at NXP B.V., Banco Santander at the record "Banco Santander, S.A. (Spain)" with its news at "Banco Santander SA", Zurich Insurance Group at Zurich Insurance Company Ltd. When the parent comes back unrated, or the credit opinion call returns nothing, look among the alternatives for a record of the same group that holds the rating; check with `getEntityRatings`.
  - Use the **rated record** for ratings, the credit opinion, Moody's financial figures and Moody's documents.
  - Use the **parent that carries the news** (it usually has a ticker) for news, results calls and reports.
  - Say in the answer which company holds the rating.
- Pass `entityId` and the name (as `orgName`) to every tool.

## The latest results in the news

Four `searchNews` calls on the record that carries the news. Each takes `entities: [{entityId, orgName, importance: "significance"}]`; the first two use `searchType: "hybrid"`.

**Call 1: when did results last come out?** `query: "results quarter profit revenue guidance outlook dividend buyback debt"` (a bank: `"results quarter net profit CET1 capital guidance buyback"`; an insurer: `"results operating profit net income solvency ratio combined ratio outlook"`), `keywordJoiner: "OR"`, `contentType: ["headline", "summary"]`, `maxResultsPerEntity: 10`, `timeRange: "past90days"`.

- Read off the date the company published its last results and the period they cover (third quarter, nine months, half-year, full year). An article dated later often retells them: take the date the article gives for the release. If outlets disagree by a day, use the date most of them give and note the other.
- If nothing in 90 days reports results, repeat once with `"past180days"`.
- Results for a subsidiary (BNP Paribas Bank Polska, Santander Chile, Audi) are not the group's results.
- Later news can matter as much as the results: a profit warning, new guidance at an investor day, a deal. Note it with its date.

**Call 2: the figures.** `query: "<company> <period> results profit <one word for its balance sheet: debt, CET1 or solvency> guidance"`, `contentType: ["headline", "body"]`, `maxResultsPerEntity: 6`, and `dateRange` from the results date at 00:00 to the next day at 23:59 (full date-times: `"2026-10-28T00:00:00Z"`, `"2026-10-29T23:59:00Z"`). Without the date range this call returns later share commentary and misses the results articles. With it, in testing, it usually brought back news-wire reports with profit, capital and guidance, and sometimes a full transcript of the results call. If call 1 gave no release date, use the results call's event date, or run this call once the report shows the date.

**Call 3: the results call transcript.** `query: "earnings call transcript"`, `searchType: "keyword"`, `contentType: ["headline"]`, `maxResultsPerEntity: 5`, and `dateRange` from the results date at 00:00 to two days later at 23:59. In testing this returned the group's call for Deutsche Telekom, Allianz and BNP Paribas ("Q3 2026 BNP Paribas SA Earnings Call", from Aiera Earnings Call Transcripts), none of which the filings search held.

- Take the entry whose headline names the group and the period (not a subsidiary's call, and not a "media conference" if an analyst call is also listed). Prefer the Aiera transcript, which carries the full text; some others (Seeking Alpha) return only an opening paragraph, and a "highlights" article is a summary.
- If the filings search returns no group call, get this transcript's text: the same call again with the same query (`"earnings call transcript"`, keyword), `contentType: ["headline", "body"]`, `maxResultsPerEntity: 3`, and `dateRange` narrowed to the day of the Aiera entry, 00:00 to 23:59. From what comes back, take the Aiera entry whose headline names this company: the call can return another company's transcript from the same day (a Cellnex call came back for Deutsche Telekom), and another outlet's entry for the same call can be a two-paragraph stub. Do not put the headline in the query: that returned unrelated articles. The text is 60,000 to 100,000 characters and is saved to a file as JSON: parse it, strip the tags, and pull the passages on guidance, profit, net debt or capital, liquidity, shareholder returns, deals and legal matters. It counts as the results call: cite it as "transcript published by <outlet>, <date>".
- Read the questions and answers to the end: a figure or a period given in the prepared remarks can be corrected later in the call, and management may dispute a press report an analyst raises. Use the correction, and report the dispute.
- A transcript is speech turned into text: ratios can lose their decimal point ("leverage of 255" for 2.55x) and a currency can be mislabelled. Give such a figure only when its meaning is plain, as printed, with a note; otherwise leave it out.
- If the text still cannot be had, write "the call transcript was found as a headline only".
- If the filings search does return the group's call, use that and skip the transcript's text.
- If neither has the call, write "the searches returned no results call".

**Call 4: since the results** (skip it when the results are three days old or less). `query: "acquisition takeover approval regulator guidance profit warning bond rating downgrade lawsuit"`, `keywordJoiner: "OR"`, `searchType: "hybrid"`, `contentType: ["headline", "summary"]`, `maxResultsPerEntity: 10`, and `dateRange` from two days after the results date to now. Keep what bears on credit and is about the group: an approval or a step in a deal the results discussed, new guidance, a profit warning, a rating action by Moody's, a large bond or lawsuit. Give each with its date, in the point it belongs to, so that a reader three weeks after the results is not told that something "is expected" when it has happened.

Notes on calls 1 and 2:

- **Read every article this call returns, to the end**, and note each figure on debt, capital or solvency, liquidity, guidance and deals. The latest period-end figures are usually here, and they are newer than anything in an older call or report: they come first in the answer, in a preview as much as in a recap.
- A company release often reaches the news feed with its tables stripped: the row labels are there and the numbers are not. Then the period-end debt has to come from the call or a wire report, and if neither states it, it is not in the sources.
- Prefer, in this order: the company's own release (Business Wire, PR Newswire, GlobeNewswire, EQS, or an article that says "issued the following news release"); a news wire or its reprint (Reuters, Dow Jones, AFP, AP, RTTNews, dpa-AFX, Investing.com); then other outlets.
- A share-commentary or opinion piece (Seeking Alpha, Simply Wall St, stock blogs) may be used only for a company figure it quotes that no better source has, or for a deal it relays from a named news organisation ("Bloomberg reported ..."), each marked "single source, unconfirmed". Never its views, its forecasts or its comparison with analysts' estimates.
- Companies report several profit figures (underlying, attributable, statutory). Give each one as the source labels it; do not pick one silently, and do not call two different measures a conflict.
- If outlets give different values for the same measure, or different growth rates for the same figure, give both with the outlets and say they differ. Check this for every figure that leads a point.
- An article that call 1 showed with the figure you need, and that this call did not bring back with its text, may be cited from its summary, marked "from the article's summary".
- If this call returns no release, wire report or transcript, say so and rely on the report and the call from the filings search. If you hold neither of those, the answer rests on the summaries from call 1: say that in the headline.
- A figure in a commentary piece that the company's report or call contradicts is dropped, not shown as a second value.
- Label these figures "company-reported, per <outlet>, <date>", once per point.

## The credit view

- `getCreditOpinion` with `sections: ["Summary", "FactorsLeadingToUpgrade", "FactorsLeadingToDowngrade", "RatingOutlook", "KeyIndicatorsTable"]`; in a recap add `"CreditStrengths"` and `"CreditChallenges"`. Note the opinion's date: it may predate the results.
- The key indicators table holds Moody's figures by year, and often Moody's forecasts (columns ending in F, E or marked as projections). Take the latest actual column for "latest value" and say its period. Its currency heading can be wrong: use its ratios, and take amounts from the financial figures call.
- **Matching a trigger to a row.** The same metric in other words is a match ("net profit-to-tangible assets" is the row "Net Income / Tangible Assets"). A trigger that names a variant or a looser term ("EBIT margin after restructuring" against the row "EBIT Margin"; "return on assets" against "Net Income / Tangible Assets") is shown beside that row with the words "the trigger's measure may differ". A trigger that names no ratio ("leverage remains above 3.0x") is given in Moody's words with the leverage rows of the table listed beside it; do not choose one and do not work out a difference. If no row is close, write "no matching row in the key indicators".
- Corporate triggers are usually numbers on Moody's-adjusted ratios (debt / EBITDA, RCF / net debt). Bank and insurer triggers are mostly in words. An insurer's numeric trigger can be on its own regulatory solvency ratio, which the company reports: look for the latest value in the opinion's summary, the report, the call or the news.
- Upgrade factors usually have to hold together: do not present one that is met as an upgrade condition met.
- `getEntityRatings` with `years: 2`: the rating, its kind, the outlook and the date of the last action. Where it shows "Rating(s) Under Review", say which ratings are under review and in which direction from the credit opinion or the latest rating action, and give the outlook they state for the others. It shows one class of rating only. An action shown as "New" can be a change of rating class and not a first rating: say what the tool shows.
- **A rating action after the credit opinion.** If the last rating action is dated after the opinion, and the document search below has not already returned that action with its outlook and factors, pull it: `searchAllDocuments` with `entities` set to the rated record, `keywords: "<company> rating action"`, `filter.documentTypes: ["Rating Action"]`, `filter.publishDate` as a range from the opinion's date to today, `chunks: 8`. Take the outlook and the factors from the latest action on the company's main rating, say that it postdates the opinion, and show the opinion's factors only where the action does not restate them. An action on one instrument can repeat older wording: if its levels differ from the main action's, give the main action's and note the difference. The text returned can start partway through a list: say "in the text returned".
- **Do not call `getEntitySectorOutlook` or `getEntityScorecardV2`.** Both return far too much text.

## Moody's financial figures

One `getEntityFinancials_v2` call on the rated record.

- **Companies that are not banks or insurers**: `{ "filterCriteria": { "sections": ["key_indicators"], "reportingBasis": "adjusted" } }`. This returns Moody's-adjusted key indicators in several columns; the first can be a twelve-month period ("LTM") later than the last fiscal year. Read the period from each column. If it returns nothing on the rated record, try the record that carries the news once.
- **Banks**: send this full list, with `"periods": ["LQ"]`. With a shorter list the tool has returned a quarter from years ago.

```json
{ "filterCriteria": {
    "periods": ["LQ"],
    "accountNames": [
      "Common Equity / Core Tier 1 ratio (as reported)",
      "Basel III leverage ratio - Fully loaded",
      "Basel III Liquidity Coverage Ratio (LCR) (as reported)",
      "Basel III Net Stable Funding Ratio (NSFR) (as reported)",
      "Impaired loans / Gross customer loans & advances",
      "Loan loss reserves / Impaired loans",
      "Gross loans and advances to customers / Customer deposits",
      "Risk weighted asset intensity (RWA / Total Assets)"
    ] } }
```

  `LQ` is the latest quarter Moody's holds; show the period it returns. These are the bank's figures as reported, not Moody's-adjusted: label them so. A field can be left out without an error: "not returned". A value of 0, or a capital or leverage ratio returned as a whole number (CET1 of 14 where 14.3 is expected), is not reliable: write "not returned". LCR and NSFR are normally whole numbers (140, 124) and are fine. If the response is "No financial data available", or a long block of unrelated lines with the note "account names were not found" (Banco Santander returns one or the other), nothing was returned: do not try another record. Use the Moody's ratios in the credit opinion's key indicators table, and the capital ratio the company reported.
- **Insurers**: do not make this call. The "adjusted" setting returns nothing, and the unadjusted one can return the parent company alone, not the group. Use the credit opinion's key indicators table.
- **Which Moody's value goes beside a trigger.** The trigger is written against the credit opinion's figures, so show the opinion's value. If this call returns a later period for the same metric, give both in the row, each with its period ("4.9% for the twelve months to March 2026 in the opinion; 4.57% to June 2026 in Moody's financial data"), and the difference to the trigger for each. If the two differ for the same period only by rounding (3.3x in the opinion, 3.25x in the data), give both and work the difference from the more precise one. If they differ by more, use the opinion's and put the other in a note. A later Moody's figure for the metric in a Moody's comment on the results is shown the same way, beside the opinion's, with its period.
- **Moody's figures are usually older than the results.** They can predate a deal or a debt issue the results report. Give their period, and say so when it matters.

## Results calls and reports

Both come from `searchCompanyFilings`, on the record that carries the news. Ignore the `url` field: it expires in minutes.

**Probe first.** Make one call for the results call (query 1 below) and one for the report (query (a)). What comes back decides the rest:

- **Text came back, it is the group's own, and it covers the latest results**: make the remaining queries for that type.
- **Text came back but it is a subsidiary's document**: make no more queries of that type (they return the same document).
- **A report came back for an earlier period**: make no more report queries. Use what the probe returned for what still holds (liquidity, facilities, maturities, the capital requirement), each with its date. An older period's profit or loss is not this period's: mention it only in a few words, with its period.
- **"Ingesting" or "being ingested"**: the filing is loading, which takes about three minutes. Do everything else first, then make the same call again as your very last call before writing; if it has loaded, make the remaining queries. If it is still loading, write "still loading when this was written". A mix of "ingesting" and "not found" for the same filing type also means loading.
- **"Not found" on the first try**: the search returned none. Do not repeat it.
- **Any other error**: write "the filings search failed" and go on without it.

**Is it the group's?** Check the headline and the text. Moody's can return a subsidiary's call or report under the parent's record (the Audi call for Volkswagen, a Santander Brasil filing for Banco Santander, TIM S.A. of Brazil for TIM S.p.A.). A subsidiary's document is not used for the group: write "the search returned no group results call; it returned <subsidiary>'s", and mention the subsidiary's news only if it matters for the group's credit.

**Long results.** A result too long to show is saved to a file as one line of JSON. Parse it and pull the passages that contain the terms you need; do not read it whole. The same page can come back several times: use it once.

**The results call** (`filingTypes: ["earnings_call_transcript"]`, no year or quarter filter).

- Preview, one query (this is also the probe in a preview): "guidance, outlook and targets for the year: revenue, EBITDA, free cash flow, capex, net debt and leverage". A bank: "guidance and targets: net interest income, costs, cost of risk, CET1, distributions". An insurer: "outlook and targets: operating profit, combined ratio, solvency ratio, dividends and buybacks".
- Recap, three queries:
  1. "results against guidance and any change to guidance: revenue, EBITDA, free cash flow" (a bank: "results against guidance: net interest income, costs, cost of risk"; an insurer: "results against outlook: operating profit by segment, combined ratio");
  2. "net debt, leverage, liquidity, refinancing and maturities, capex, dividends and buybacks" (a bank: "CET1 ratio and capital requirement, liquidity, funding and issuance, dividends and buybacks"; an insurer: "solvency ratio and what moved it, debt and leverage, dividends and buybacks");
  3. "net income, earnings per share, cash and investments, impairments and one-off items, legal matters".
- Identify the call by its headline and event date. The fiscal year, quarter and period-end labels in the metadata can be wrong; take the period from the text. Latest means the most recent event date.
- A call can be mostly questions and answers, with no speaker names and no prepared remarks on the balance sheet. Take what it gives and look in the report and the news for the rest.

**The results report** (`filingTypes: ["interim"]` when the latest results are for a quarter, nine months or a half-year; `["annual"]` when they are full-year results; no year or quarter filter). Three queries in a recap, each on one subject; queries (b) and (a) in a preview:

- (a) "net debt and its movements, liquidity, undrawn facilities, debt maturities, dividends and share buybacks" (a bank: "CET1 ratio and capital requirement, liquidity, funding and issuance, dividends and share buybacks"; an insurer: "solvency ratio and its movements, debt and leverage, dividends and share buybacks");
- (b) the preview query above, word for word: it usually brings back the outlook page with the guidance. A results presentation, or a report not in English, may have none: then take guidance from the call and the news;
- (c) "profit or loss for the period, operating profit, impairment, one-off gains and charges, legal proceedings and contingent liabilities".

Reading it:

- **Check that the report covers the results.** Take its period from the text, not from the title or the metadata (Vodafone's half-year report of 10 Nov 2026 is titled "Interim Report 2026 - Q4"; the period-end field can hold the filing date). A US company's quarterly report is often filed weeks after the results: the latest one Moody's holds can be for the quarter before. A European company's latest interim report is often the half-year; a bank's latest report in Moody's can be a year old.
- If the report is for an earlier period, say so in the headline. Take from it only what still holds (maturities, facilities, the capital requirement, guidance not since changed), each with its date, and take the period's figures from the call and the news.
- The latest "interim" filing can be a routine notice (a buyback, a director's shareholding). If so, say so and use the call and the news.
- Maturities, for a company that is not a bank or insurer: if the report for the period has no maturity table, or the table came back garbled, use the latest annual report's, with its date (one more call, `filingTypes: ["annual"]`, query (a)). A table whose columns you have to rebuild by guesswork is not used.
- Debt: give the figure, the comparison the report itself makes and the three largest drivers it names, including one that reduces it. This is the company's own measure, not Moody's-adjusted debt. If the company states no net debt (Nvidia does not), give its debt and its cash as it states them, separately.
- Profit or loss: give the profit or loss for the period with last year's figure, and say which measure it is. Add the amount attributable to owners only where it tells a different story.
- Guidance, impairments and legal matters: take the ranges from the outlook section (old and new), the impairment's size and what it relates to from its note, and any ruling from the legal or contingent liabilities note. If the text returned does not hold one of these, say which.

## Moody's documents since the results (recap)

One `searchAllDocuments` call with `entities` set to the rated record, `keywords: "<the rated record's name> results"`, `filter.documentTypes: ["Issuer Comment", "Rating Action", "Announcement"]`, `filter.publishDate` as a range from the results date to today, `chunks: 10`. Moody's comment on the results often carries the asset-quality, liquidity and funding figures: read all the text returned.

- Report every document it returns that is about the company: title, date, and in one sentence what it says. Say whether the text returned refers to the results. A rating action on one instrument (a hybrid, a guaranteed note) counts: it is Moody's latest statement on the company.
- If it returns none, write "the search returned no Moody's comment, rating action or announcement on the company since the results".

## What to look for, by kind of company

| | Company (corporate) | Bank | Insurer |
|---|---|---|---|
| Results | revenue, EBITDA, free cash flow, profit or loss | net interest income, costs, cost of risk, net profit | operating profit by segment, combined ratio, net income |
| Balance sheet | net debt, leverage, liquidity, maturities | CET1 and its requirement, leverage ratio, LCR, problem loans | regulatory solvency ratio, debt and leverage, cash sent up to the holding company |
| Returns | capex, dividends, buybacks | dividends, buybacks, payout | dividends, buybacks |
| Triggers | usually numbers on Moody's-adjusted ratios | mostly words | mostly words; sometimes a solvency ratio level |

## What Moody's does not have

No forward earnings calendar and no consensus estimates. Give the period or date of coming results only when a call, a report, an article or a Moody's document states it; otherwise write "next results" and "date not in the sources returned".
