---
name: regulatory-watch
description: Regulatory watch for a sector - what its regulators published in the last 7 days, which companies each item covers, and what Moody's data and research say, all sourced. Use for a reg watch.
---

# Regulatory watch

The job: tell a credit analyst what the sector's regulators published in the window, which companies each main item covers, and what Moody's has on it, with a source on every fact.

Inputs: **sector** (required), **names** (optional), **region** (optional; Europe if none is given; one or more countries is fine), **window** (optional). Needs web search and page fetch for the regulators' own sites, and the Moody's connector for everything else. If web search is not available, say so and stop: there is no regulatory watch without the regulators' pages.

Before starting, read the three files in `references/`: `rules.md` (how to source and write the answer), `regulators.md` (which regulators and pages to read, what counts as an item, and which companies a rule covers) and `moodys-tips.md` (how the Moody's tools behave, with the settings for the calls below).

## Steps

1. **Window.** Seven days ending today, both included (on 26 November: 20 to 26 November), or the window the user asks for, counted the same way. An item is in the window when the regulator published it inside the window. State the dates in the brief, and the time the listings were read.

2. **Regulators.** Choose them as `regulators.md`, "Which regulators", says, and name them in the brief.

3. **Find the items.** Regulators' own sites only: no news sites, law-firm notes or commentary.
   - For each regulator, open its listings and read off every entry published inside the window. A regulator usually has more than one listing: news or press releases, publications or a document library, and consultations or decisions. Read each one that exists (`regulators.md`, "Reading a listing").
   - Then up to six web searches limited to those sites, to catch what the listings miss. Searches made only to find a listing's address, or to stand in for a listing that would not open or that is known to lag, do not count towards the six. Nothing from a search result's summary goes in the brief until the regulator's own page confirms it: summaries carry wrong dates and wrong facts.
   - Say for each regulator whether it was read in full, in part or not at all. Never call a regulator quiet when its listings could not be read.

4. **Sort what you found** as `regulators.md`, "What counts as an item", says, into three groups:
   - **Main items**: a measure that changes what the sector's firms must hold, pay, charge or do, or a decision on one large company. These get a row each.
   - **Other items**: real regulatory items of lesser weight. One line each.
   - **Left out**: speeches, statistics, appointments and the like. Counted only.

5. **Open the page of every main item** and take four things from the page itself: the publication date, the status (consultation, final, decision, yearly list, stress-test results, periodic price or rate setting, or other), the effective date or comment deadline (every date the page gives, each with what it applies to; do not sum them up as "the rest"), and who it applies to in the regulator's own words, with any firms the page names. For an item made of many documents, open one or two and say so. If the detail is in a PDF or annex you cannot open, say "annex not opened". If a page cannot be opened, keep the item only if the listing shows its date, and write "page not opened" in its row. A measure whose page puts this sector's firms outside the change, or whose scope you could not read at all, is an other item, not a main one.

6. **Name the companies.**
   - If the user gave names, use those.
   - European banks or telecoms: the checked list in `references/lists/` (its companies are already matched: use the IDs as its note says and do not look them up again).
   - Named European countries, for banks or telecoms: the list's companies based in those countries. If that gives fewer than eight, add the largest others based there, looked up as `moodys-tips.md` says.
   - Anything else: write down the 15 or so largest companies in the sector and region that a credit analyst would expect to see, and look them up.
   - A company that a main item's page names is added to the list only if it belongs to the sector and region asked for. Otherwise it is named in the item's row and nowhere else.
   - **Your knowledge supplies only the names. Every rating and figure comes from Moody's.**

7. **Who each main item covers** (`regulators.md`, "Who a rule covers"). Give the regulator's words, then the companies on the list it reaches, in a few words ("all 21 EU and EEA banks on the list", "the five UK groups", "named on the page: BT, Vodafone"). Name companies one by one when they are eight or fewer, and always when the measure works through a named list (the G-SIBs): then name every company on your list that is on it, in the row or in a column of the companies table.

8. **Moody's on these items** (`moodys-tips.md`, "Moody's documents"): one search for what Moody's has published on the sector's regulation in the region in the last 60 days, and at most one more, on the weightiest main item the first did not cover. If Moody's has written on a rule, give the title, the date and its stated credit effect.

9. **The companies.** `getEntityRatings` for the companies on the list. For banks only, and only in the cases in `regulators.md`, "The ratio behind a bank rule": also make the financials call in `moodys-tips.md` for the banks whose requirement changes.

10. **Write the brief**, in this order:
    - **Headline**: one sentence, with the window, the sector and the region, and the one or two main items.
    - **How it was read**: up to four lines. The regulators grouped by whether they were read in full, in part or not at all, with the number of entries read and, for those read in part, what was missed; the number of companies; and up to ten companies of the sector and region that are not on the list ("Not on the list: ...").
    - **Main items**: a table, newest first: date, regulator, what changed in one or two sentences, status, deadline or effective date, who it covers. Keep the regulator's own qualifier on every figure ("more than 55%", "at least") and its own words for how much a measure covers.
    - **Other items**: a short list, one line each: date, regulator, title in plain words.
    - **Just before the window** (only if needed): up to three lines, title and date only, for the weightiest measures published in the three days before the window that would have been main items. One on which Moody's published inside the window gets a sentence on what it changes.
    - **Moody's view**: one line per item Moody's has written on, with title and date. Research on the wider subject, not the item itself, may be given in at most two lines, labelled "on the wider subject". If the searches returned nothing relevant, one line saying so.
    - **The companies**: one table: company, Moody's rating with its kind and outlook, any Moody's rating action on it dated inside the window, and, when step 9 made the financials call, the ratio for the banks whose requirement changes, with its period. Values only: no ranking words and no judgement.
    - **Left out**: one line with counts by kind ("12 speeches, 5 statistical releases, 3 appointments").
    - **Notes** (only if needed, at most four lines), then **Sources**, as `rules.md` says.

11. **Quiet week.** If the listings and searches show no main or other item in the window, say so in one line, then the "How it was read" lines and the "Left out" line. Nothing else.

## Do not

- Do not use a news site's summary in place of the regulator's own page.
- Do not treat a consultation as a final rule.
- Do not estimate the capital or earnings effect of a rule, and do not add up a capital requirement from its parts.
- Do not set a company's ratio beside a rule that does not change a requirement on that ratio for that company: it reads as cause and effect.
- Do not say a company is covered from a title alone: use the regulator's words, the firms the page names and the company's home country.
- Do not state anything about a company from memory: no rating, ratio, requirement or line of business without a Moody's source or a regulator's page.
- Do not give a view on bonds or shares, or forecast a rating action.
