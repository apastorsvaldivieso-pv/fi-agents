# How the Moody's tools behave

Found by live testing in November 2026. Each point is here because getting it wrong gave a wrong answer.

## Finding the right company

- **Looking up names**: put all the names in one `findEntity` call. A company can be listed under its current or formal name (Phoenix Group as Standard Life plc, Telecom Italia as TIM S.p.A.): that is a match when it is plainly the same parent company. Check every result, because in testing four of fifteen insurers came back wrong ("Mapfre" as Mapfre Uruguay, "Zurich Insurance Group" as an operating company): the name matches the one asked for (ignore S.A., plc, Inc., AG), the country and sector fit, and it is the parent, not a subsidiary or a funding vehicle (names with Finance, Funding, Capital, Treasury). Count the results against the names you sent: the tool can drop a name without saying so.
- **For each one that looks wrong**, look that name up alone with `getAlternatives: true`, `maxAlternatives: 5` and `disambiguationCriteria.country` set to its home country as a list of ISO codes (`["ES"]`). Repeat calls for this purpose are fine, up to three, for the companies most likely to be rated; a company that simply comes back unrated needs no second look unless it is a large issuer of public debt. If it is still unsure, say the company could not be matched and name it in the notes. Never pick the nearest one.
- **Do not build the list from Moody's sector search** ("largest European insurers"): it misses major companies. Name the companies, then look them up.
- **The "rated" flag can be wrong.** `getEntityRatings` (up to 10 companies per call, `years: 1`) is the truth: read the "Current Rating" line. WR (withdrawn), or "No ratings data", means "not rated by Moody's". The words "No ratings found" under a current rating only mean no action in the last year.
- **The tool returns one kind of rating per company and picks the kind itself** (LT Issuer Rating, Senior Unsecured, Insurance Financial Strength, a programme rating marked "(P)"). Kinds differ between rows: name the kind in every row.
- **Some groups are rated at a different company** from the listed parent (BT Group at British Telecommunications Limited; an insurer at its main operating company). When a large company with public debt comes back unrated, look it up again with `getAlternatives: true` and check whether a company of the same group holds the rating. Say in the table where the rating is held. If the only rated record of a group is its finance company ("Bupa Finance Plc"), show that rating and say it is held there. The checked lists carry `ratingsEntityId` and `operatingBank` for these: follow the note at the top of the list file.
- A company with no Moody's rating stays in the brief as "not rated by Moody's".

## Moody's documents

`searchAllDocuments` needs `keywords` and filters by whole calendar days. Without a sector filter it returns other sectors' documents, and without a region filter other continents', so set both.

- **Moody's on the sector's regulation**, one call: `keywords: "<sector> regulation regulator rules requirements"` (banks: "bank regulation capital requirements supervisor rules"; utilities: "utilities regulation regulator price control allowed returns"), `filter.sectors`, `filter.regions`, `filter.documentTypes: ["Sector Comment", "Sector In-Depth", "Issuer Comment", "Outlook"]`, `filter.publishDate` as a range over the last 60 days, `filter.penalizeOlderResearch: true`, `chunks: 1`.
- **Sector names are Moody's own.** Pass two or three likely ones: `["Banking"]`; `["Insurance"]`; `["Telecommunications"]`; `["Electric Utilities", "Utilities", "Regulated Electric and Gas Networks"]`. A name Moody's does not know is dropped without a word or makes the call fail. Moody's titles begin with its sector name ("Regulated Electric & Gas Networks – Italy: ..."): if the first call returns almost nothing, run it once more with the names seen in titles, or with no sector filter and the sector in the keywords.
- **Regions**: "Europe", or the country names for a country brief ("Spain", "Italy", "United States"). "European Union" is rejected.
- **Read the titles.** Moody's titles say what a comment is about and whether it is credit positive or negative ("Italian regulator cuts energy networks' returns ... credit negative"; "EBA's revised governance guidelines are credit positive for small EU banks"). Match them to your items by subject.
- **One more call at most**, with keywords naming a main item the first call did not cover ("G-SIB list capital buffer"), `chunks: 2`. Searches item by item return the same documents again: do not make them.
- A document is Moody's view on an item only if its title or text is about that rule or decision. A document about the wider subject can be given as "on the wider subject". Anything else is noise: skip it.
- An item published in the last few days rarely has a Moody's comment yet. Write "the search returned no Moody's research on this item".
- Give the title, the date and the document ID, and state its credit effect in Moody's terms, quoting only a short phrase.
- **Do not call `getEntitySectorOutlook` or `getEntityScorecardV2`.** Both return far too much text.

## Bank ratios

Only for the case in `regulators.md`, "The ratio behind a bank rule". One `getEntityFinancials_v2` call for the banks the item covers, all in one call, with the full list of fields below even if the item needs one of them. With a shorter list the tool has returned a quarter from years ago.

```json
{ "filterCriteria": {
    "periods": ["LQ"],
    "accountNames": [
      "Common Equity / Core Tier 1 ratio (as reported)",
      "Basel III leverage ratio - Fully loaded",
      "Basel III Liquidity Coverage Ratio (LCR) (as reported)",
      "Basel III Net Stable Funding Ratio (NSFR) (as reported)",
      "Impaired loans / Gross customer loans & advances",
      "Loan loss reserves / Impaired loans",
      "Gross loans and advances to customers / Customer deposits",
      "Risk weighted asset intensity (RWA / Total Assets)"
    ] } }
```

- `LQ` is the latest quarter Moody's holds for each bank. Read each bank's period from the response and show it next to its value. Periods can differ between banks: show each bank's own, and do not ask again to line them up.
- These are the banks' figures as reported, not Moody's-adjusted. Round to one decimal. The quarter can be one behind the bank's latest results: if a Moody's comment returned in this run gives the ratio for a later quarter, show that one too, with its source.
- Use `entityId` from the list. A bank that returns nothing, a period more than a year old, or a block of unrelated lines with the note "account names were not found" is "not in Moody's data": Banco Santander and BPCE came back that way in testing. Do not try other records.
- A field can be missing for a bank without an error (the leverage ratio often is): "not returned". A value of 0, or a ratio returned as a whole number (14 where 14.3 is expected), is not reliable: in testing a bank shown as 12 had reported 12.8. Write "not returned" for these too.
- A response can be long. Take only the one ratio the item bears on, and its period.

## What Moody's does not have

No list of which companies a rule applies to, no capital requirement per company, no MREL or TLAC figure, no regulatory solvency ratio for insurers, and no estimate of a rule's effect. Scope comes from the regulator's page and the company's home country.
