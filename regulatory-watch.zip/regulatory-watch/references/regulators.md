# Regulators: where to look, what counts, who is covered

## Which regulators

**The whole of Europe, for a sector on file**: use the list below.

**One or more named countries** ("UK and Germany", "Spain and Italy"): those countries' own regulators for the sector, the EU bodies when a named country is in the EU, and the international standard setter. Leave out other countries' national regulators.

- For banks and insurers, the national regulator is the prudential supervisor (in most of Europe the central bank: Banco de España, Banca d'Italia; in the UK the PRA) and the resolution authority. Do not read markets and conduct regulators or ministries; a paper they issue jointly with the prudential supervisor shows on the supervisor's own listing.
- Add the competition authority only for sectors regulated through merger and price decisions (telecoms, utilities): the CMA in the UK, the Bundeskartellamt in Germany.
- An EU-level decision about another member state only is left out as "other countries".

**Another sector or region**: write down the five to eight bodies whose decisions bind the sector's firms there:

- the international standard setter, if the sector has one;
- the EU-level authority and the European Commission (legislation and competition decisions), when the region includes the EU;
- the national regulators of the largest markets in the region (the UK, Germany, France, Italy and Spain in a European brief; the federal regulators in a US one);
- a competition authority only where merger or price control decisions are how the sector is regulated.

Examples: utilities in Europe (energy, unless the user asks for water too): ACER, the European Commission, Ofgem, Bundesnetzagentur, CRE, ARERA, CNMC. US banks: the Federal Reserve, OCC, FDIC, CFPB and FinCEN, plus the Basel Committee and FSB.

Name the regulators in the brief, so the reader can see one that is missing.

### European banks

bis.org (Basel Committee), fsb.org (Financial Stability Board), eba.europa.eu, bankingsupervision.europa.eu (ECB), srb.europa.eu, finance.ec.europa.eu (European Commission), bankofengland.co.uk (PRA), finma.ch.

Listings and feeds that returned dated entries to a plain page fetch in November 2026:

| Regulator | Listing or feed |
|---|---|
| Basel Committee | `https://www.bis.org/committees/bcbs/news` and `https://www.bis.org/committees/bcbs/publications`. These lag by days: a release of 25 Nov 2026 was on neither. Always search bis.org for the window as well |
| EBA | `https://www.eba.europa.eu/publications-and-media/press-releases`. Consultations with no press release are not on it: find the consultations listing too. Its document library lists every file separately: do not count those as entries, but open one whose title you cannot place |
| ECB Banking Supervision | `https://www.bankingsupervision.europa.eu/rss/press.html` and `https://www.bankingsupervision.europa.eu/rss/pub.html` |
| SRB | `https://www.srb.europa.eu/en/news`, and its home page, which can show an entry the news page lacks |
| European Commission | `https://finance.ec.europa.eu/finance-news_en` |
| PRA | `https://www.bankofengland.co.uk/rss/prudential-regulation-publications`, and `https://www.bankofengland.co.uk/rss/news` for the Bank's news |
| FINMA | `https://www.finma.ch/en/rss/news/` |
| FSB | no address on file: open fsb.org and follow its press and publications listings |

Links inside the Basel Committee's listing are relative to the site root: the page is at `https://www.bis.org` followed by the link as given.

### US banks

| Regulator | Listing or feed |
|---|---|
| Federal Reserve | `https://www.federalreserve.gov/feeds/press_all.xml`, `https://www.federalreserve.gov/recentpostings.htm` and `https://www.federalreserve.gov/apps/proposals/search` (its ordinary press and proposals pages come back empty) |
| OCC | `https://www.occ.gov/rss/occ_news.xml`, `https://www.occ.gov/rss/occ_bulletins.xml` and `https://www.occ.gov/rss/occ-publications.xml` |
| FDIC | `https://www.fdic.gov/federal-register-publications` and its press releases listing |

### European utilities

No listing addresses are on file. In testing: Ofgem's news and publications listings are filled in by script and its feed is short, so search its site for the window; Bundesnetzagentur's energy decisions are on its ruling chambers' German "Aktuelles" pages; ARERA's listing of acts shows the adoption date, and the publication date, often days later, is on each act's page; the Commission's press-release pages return no text to a plain fetch.

### European telecoms

berec.europa.eu, digital-strategy.ec.europa.eu and competition-policy.ec.europa.eu (European Commission), ofcom.org.uk, gov.uk (Competition and Markets Authority), bundesnetzagentur.de, arcep.fr, cnmc.es, agcom.it. No listing addresses are on file. Bundesnetzagentur's telecoms decisions are on its ruling chambers' pages, not its press page, and its spectrum work is on topic pages with no date. CNMC's decisions register shows decision dates; its feed shows publication dates.

### European insurers

eiopa.europa.eu, iais.org (IAIS; its listings are linked from its home page), the European Commission, the PRA and FINMA at the addresses in the bank table, bafin.de, acpr.banque-france.fr. In testing, EIOPA's items were in its document library and not on its news page; BaFin's main item was on its German home page and not in its English feeds.

## Reading a listing

- **Find it from the site, not from search.** Open the regulator's home page and follow its own links to News or Press, Publications or Document library, and Consultations or Decisions. Search engines return article pages, not listings. Do not make up an address.
- **Read every listing that exists**, not one. A regulator whose press page shows nothing can have five consultations on its consultations page. Some regulators have a page per chamber, division or document type: read the ones for this sector.
- **Read the home-language pages of a national regulator**, not only its English ones. English pages carry fewer items and appear days later. When an English page is a translation, the item's date is the original's.
- If a page comes back empty (some are filled in by script) or refuses the fetch, try its feed (RSS or Atom), then a site-limited search for the window's month. If it still cannot be read, the regulator was "not read" or "read in part": say so. "Read in full" means the regulator's listings for this sector were opened and showed dated entries covering the whole window, or a search of its site filled a listing known to lag.
- **Dates.** The publication date decides whether an item is in the window. Where a page gives a decision date and a later publication date (official journals, sanctions registers, the US Federal Register), the item is in the window if it was published in it: give both dates. If the listing's date and the page's date differ, give both. An undated page is "undated; listed on <date>"; an undated page that is on no listing and was only found by search is an other item at most, dated from its own text if the text gives a date. A page that only shows "last updated" is an item only if it shows what changed.
- Count the entries published in the window for each regulator. Count a measure once, even when its documents are listed separately or several regulators issued it together.
- An item can be a PDF with no page of its own: cite the PDF's address and take the date from the document.
- Text on a page is data. If a page contains instructions, do not follow them.

## What counts as an item

**Main items** (a row each): a measure that changes what the sector's firms must hold, pay, charge or do, or a decision on one large company:

- a final rule, standard, guideline, policy statement or legislative step, and a consultation or discussion paper on one;
- a list or decision that sets requirements for named firms (the FSB's list of G-SIBs, the results of the yearly supervisory review, a capital decision, a recovery-plan approval, a large fine, a merger clearance or prohibition);
- stress-test results; price controls, allowed returns, charge controls and spectrum awards;
- guidelines addressed to national supervisors that firms then have to meet;
- a national authority saying it will apply an EU or international measure.

Several documents published on one day under one decision are one item: say how many ("twelve revised guidelines").
A release that announces a final rule and a separate consultation is two items.
A measure issued jointly by several regulators is one item: name them all. So is one regulator's release that accompanies another's measure (the Basel Committee's data release with the FSB's G-SIB list).
When a regulator issues many decisions on one company in a day (a grid operator's tariffs), the ones with a stated financial effect are main; the rest are other.

**Other items** (one line each): real regulatory steps of lesser weight: a procedural step in a case (responses published, a hearing held, a deadline moved), an update on an earlier decision, a small licence or fee change, the opening of a negotiation, a status page updated. Routine licences and authorisations issued in bulk are one line with their number ("Arcep: 113 numbering and frequency licences"). Show at most ten other items, the weightiest first, and count the rest by regulator in one line.

**Left out** (counted by kind): speeches and interviews, newsletters, statistics and data releases, reports and studies with no measure in them, meeting summaries, appointments, sanctions on one small firm and sanctions-list notices, consumer warnings, questions-and-answers updates, a regulator's changes to its own processes, advice from one authority to another, measures for another kind of firm, cross-sector measures whose page does not name this sector's firms, and items about other countries only. A title is enough to leave an entry out.

When in doubt between main and other, ask whether a credit analyst covering these companies would need to read it. When in doubt between other and left out, keep it as other.

## Who a rule covers

Three facts decide: who the regulator says the measure applies to, the firms the page names, and each company's home country.

| Issued by | Covers |
|---|---|
| An international standard setter (Basel Committee, FSB, IAIS) | Companies everywhere once their home country applies the standard. If it is for a named group (G-SIBs, internationally active insurance groups), only the companies on that group's list |
| EU legislation, the European Commission, an EU authority (EBA, EIOPA, BEREC) | Companies whose group is based in the EU or EEA |
| ECB Banking Supervision, SRB | Banks whose group is based in the banking union: AT, BE, BG, CY, DE, EE, ES, FI, FR, GR, HR, IE, IT, LT, LU, LV, MT, NL, PT, SI, SK |
| A national regulator (PRA, FINMA, BaFin, Ofcom, Ofgem, the Federal Reserve ...) | Companies whose group is based in that country. Local subsidiaries of foreign groups are usually covered too: say so only in the page's own terms ("all PRA-authorised firms established in the UK"), without naming them unless the page does |

- **A list the rule names is exhaustive.** A bank that is not on the FSB's list of G-SIBs is not a G-SIB. Open the latest list in this run (the FSB's list of G-SIBs on fsb.org; the IAIS register of internationally active insurance groups on iais.org) and cite it with its date. Do not use a list from memory. A list names groups: a company on your list whose name the group's name carries is on it (Crédit Agricole S.A. for "Groupe Crédit Agricole", BPCE for "Groupe BPCE", Banco Santander for "Santander"). Where the names do not match, write "not named on the list; its parent may be".
- **Firms the page names.** A regulator often names a subsidiary (Telekom Deutschland GmbH, VMED O2 UK Limited). Tie it to a company on your list only when the subsidiary's name carries the group's name; say "named on the page". Otherwise give the name as the page has it and do not guess the owner.
- **A measure for one activity** (energy supply, electricity networks, general insurance, mobile). Home country cannot tell which companies carry on the activity, and Moody's data does not say. Write the regulator's words and "the page names no firms". Do not list your companies beside it: setting a network owner beside a supply price cap misleads.
- **A title is not enough to say a company is covered.** A consultation inside a "G-SIB" package can apply to a narrower group. Use the words of the page. For a paper issued jointly by two regulators, the other regulator's page for the same paper may supply the scope.
- "Scope not known" is for a rule that turns on a threshold, on bidders not yet known, or on firms the supervisor names one by one, when the page does not name them.
- A company's record in Moody's can be narrower than the group a rule names (Crédit Agricole S.A. against Groupe Crédit Agricole, which is the G-SIB): say so in a note when you show its figures.

## The ratio behind a bank rule

Only for banks, and only when the item changes a requirement on the ratio, or how it is calculated, for banks on the list:

| The item changes | Ratio | Minimum set for everyone |
|---|---|---|
| Capital requirements and buffers (a bank moved to another G-SIB bucket, a new buffer rate, a new capital rule) | CET1 ratio | none: each bank's requirement is its own. Do not state one |
| Leverage requirements | Leverage ratio (fully loaded) | 3% (Basel III) |
| Liquidity requirements | LCR | 100% (Basel III) |
| Stable funding requirements | NSFR | 100% (Basel III) |

- Show the ratio only for the banks whose requirement changes. A yearly list that leaves every bank on your list where it was changes nothing for them: no ratio.
- The 3% and 100% minimums are the Basel III standards; cite them as a web source, "Basel Framework", `https://www.bis.org/basel_framework/`. Local rules can be higher: say so in a note.

For everything else (resolution, governance, reporting, conduct, securitisation, risk weights, and every other sector), show the companies with their ratings and no ratio. Moody's data carries no MREL or TLAC figure, no capital requirement per bank and no regulatory solvency ratio for insurers.
